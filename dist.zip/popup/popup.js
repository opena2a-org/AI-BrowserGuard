(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function generateId() {
  return crypto.randomUUID();
}
const READ_ONLY_CAPABILITIES = ["navigate", "read-dom"];
const LIMITED_CAPABILITIES = ["navigate", "read-dom", "click", "type-text"];
const ALL_CAPABILITIES = [
  "navigate",
  "read-dom",
  "click",
  "type-text",
  "submit-form",
  "download-file",
  "open-tab",
  "close-tab",
  "screenshot",
  "execute-script",
  "modify-dom"
];
function buildActionRestrictions(allowed) {
  return ALL_CAPABILITIES.map((cap) => ({
    capability: cap,
    action: allowed.includes(cap) ? "allow" : "block"
  }));
}
function createRuleFromPreset(preset, options) {
  const now = /* @__PURE__ */ new Date();
  let scope;
  switch (preset) {
    case "readOnly":
      scope = {
        sitePatterns: [],
        actionRestrictions: buildActionRestrictions(READ_ONLY_CAPABILITIES),
        timeBound: null
      };
      break;
    case "limited": {
      const durationMinutes = options?.durationMinutes ?? 60;
      const expiresAt = new Date(now.getTime() + durationMinutes * 6e4);
      const timeBound = {
        durationMinutes,
        grantedAt: now.toISOString(),
        expiresAt: expiresAt.toISOString()
      };
      scope = {
        sitePatterns: options?.sitePatterns ?? [],
        actionRestrictions: buildActionRestrictions(LIMITED_CAPABILITIES),
        timeBound
      };
      break;
    }
    case "fullAccess":
      scope = {
        sitePatterns: [],
        actionRestrictions: buildActionRestrictions(ALL_CAPABILITIES),
        timeBound: null
      };
      break;
  }
  return {
    id: generateId(),
    preset,
    scope,
    createdAt: now.toISOString(),
    isActive: true,
    label: options?.label
  };
}
const TIME_DURATION_OPTIONS = [
  { label: "15 minutes", minutes: 15 },
  { label: "1 hour", minutes: 60 },
  { label: "4 hours", minutes: 240 }
];
function createInitialWizardState() {
  return {
    currentStep: "preset",
    selectedPreset: null,
    sitePatterns: [],
    durationMinutes: null,
    label: "",
    errors: []
  };
}
function selectPreset(state, preset) {
  const nextStep2 = preset === "limited" ? "sites" : "confirm";
  return {
    ...state,
    selectedPreset: preset,
    currentStep: nextStep2,
    errors: []
  };
}
function addSitePattern(state, pattern) {
  if (!pattern.pattern.trim()) {
    return { ...state, errors: ["Pattern cannot be empty."] };
  }
  const exists = state.sitePatterns.some((p) => p.pattern === pattern.pattern);
  if (exists) {
    return { ...state, errors: ["This pattern already exists."] };
  }
  return {
    ...state,
    sitePatterns: [...state.sitePatterns, pattern],
    errors: []
  };
}
function removeSitePattern(state, index) {
  const sitePatterns = state.sitePatterns.filter((_, i) => i !== index);
  return { ...state, sitePatterns, errors: [] };
}
function setDuration(state, minutes) {
  const valid = TIME_DURATION_OPTIONS.some((opt) => opt.minutes === minutes);
  if (!valid) {
    return { ...state, errors: ["Invalid duration. Choose 15 minutes, 1 hour, or 4 hours."] };
  }
  return { ...state, durationMinutes: minutes, errors: [] };
}
function nextStep(state) {
  switch (state.currentStep) {
    case "preset":
      if (!state.selectedPreset) {
        return { ...state, errors: ["Select a delegation preset."] };
      }
      if (state.selectedPreset === "limited") {
        return { ...state, currentStep: "sites", errors: [] };
      }
      return { ...state, currentStep: "confirm", errors: [] };
    case "sites":
      if (state.sitePatterns.length === 0) {
        return { ...state, errors: ["Add at least one site pattern."] };
      }
      return { ...state, currentStep: "time", errors: [] };
    case "time":
      if (state.durationMinutes === null) {
        return { ...state, errors: ["Select a time duration."] };
      }
      return { ...state, currentStep: "confirm", errors: [] };
    case "confirm":
      return state;
    default:
      return state;
  }
}
function previousStep(state) {
  const stepOrder = ["preset", "sites", "time", "confirm"];
  const currentIndex = stepOrder.indexOf(state.currentStep);
  if (currentIndex <= 0) return state;
  if (state.currentStep === "confirm" && state.selectedPreset !== "limited") {
    return { ...state, currentStep: "preset", errors: [] };
  }
  return { ...state, currentStep: stepOrder[currentIndex - 1], errors: [] };
}
function finalizeWizard(state) {
  if (!state.selectedPreset) return null;
  if (state.selectedPreset === "limited") {
    if (state.sitePatterns.length === 0) return null;
    if (state.durationMinutes === null) return null;
  }
  return createRuleFromPreset(state.selectedPreset, {
    sitePatterns: state.sitePatterns,
    durationMinutes: state.durationMinutes ?? void 0,
    label: state.label || void 0
  });
}
const PRESET_DESCRIPTIONS = {
  readOnly: {
    title: "Read-Only",
    description: "Agent can navigate and read page content. Cannot click, type, or submit forms."
  },
  limited: {
    title: "Limited Access",
    description: "Agent can interact with specific sites you choose, with a time limit."
  },
  fullAccess: {
    title: "Full Access",
    description: "Agent can perform any action. All activity is logged with boundary alerts."
  }
};
function renderWizard(container, state, onStateChange) {
  container.innerHTML = "";
  if (state.errors.length > 0) {
    const errorDiv = document.createElement("div");
    errorDiv.className = "wizard-errors";
    errorDiv.style.cssText = "color: var(--danger); font-size: 12px; margin-bottom: 8px;";
    errorDiv.textContent = state.errors.join(" ");
    container.appendChild(errorDiv);
  }
  switch (state.currentStep) {
    case "preset":
      renderPresetStep(container, state, onStateChange);
      break;
    case "sites":
      renderSitesStep(container, state, onStateChange);
      break;
    case "time":
      renderTimeStep(container, state, onStateChange);
      break;
    case "confirm":
      renderConfirmStep(container, state, onStateChange);
      break;
  }
}
function renderPresetStep(container, state, onStateChange) {
  const presets = ["readOnly", "limited", "fullAccess"];
  for (const preset of presets) {
    const info = PRESET_DESCRIPTIONS[preset];
    const card = document.createElement("button");
    card.type = "button";
    card.className = `preset-card${state.selectedPreset === preset ? " selected" : ""}`;
    const title = document.createElement("strong");
    title.textContent = info.title;
    const desc = document.createElement("p");
    desc.style.cssText = "margin: 4px 0 0; font-size: 11px; color: var(--text-secondary);";
    desc.textContent = info.description;
    card.appendChild(title);
    card.appendChild(desc);
    card.addEventListener("click", () => {
      onStateChange(selectPreset(state, preset));
    });
    container.appendChild(card);
  }
}
function renderSitesStep(container, state, onStateChange) {
  const heading = document.createElement("p");
  heading.style.cssText = "font-size: 12px; color: var(--text-secondary); margin-bottom: 8px;";
  heading.textContent = "Add sites the agent can access (glob patterns):";
  container.appendChild(heading);
  const inputRow = document.createElement("div");
  inputRow.style.cssText = "display: flex; gap: 6px; margin-bottom: 8px;";
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "e.g., *.example.com";
  input.className = "form-input";
  input.style.cssText = "flex: 1;";
  const addBtn = document.createElement("button");
  addBtn.className = "btn btn-primary";
  addBtn.textContent = "Add";
  addBtn.style.cssText = "padding: 4px 12px; font-size: 12px;";
  addBtn.addEventListener("click", () => {
    const value = input.value.trim();
    if (value) {
      onStateChange(addSitePattern(state, { pattern: value, action: "allow" }));
      input.value = "";
    }
  });
  inputRow.appendChild(input);
  inputRow.appendChild(addBtn);
  container.appendChild(inputRow);
  for (let i = 0; i < state.sitePatterns.length; i++) {
    const p = state.sitePatterns[i];
    const row = document.createElement("div");
    row.style.cssText = "display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 12px;";
    const label = document.createElement("span");
    label.style.cssText = "color: var(--text-primary);";
    label.textContent = `${p.pattern} (${p.action})`;
    row.appendChild(label);
    const removeBtn = document.createElement("button");
    removeBtn.className = "btn btn-secondary";
    removeBtn.textContent = "Remove";
    removeBtn.style.cssText = "padding: 2px 8px; font-size: 11px;";
    removeBtn.addEventListener("click", () => onStateChange(removeSitePattern(state, i)));
    row.appendChild(removeBtn);
    container.appendChild(row);
  }
  renderNavButtons(container, state, onStateChange);
}
function renderTimeStep(container, state, onStateChange) {
  const heading = document.createElement("p");
  heading.style.cssText = "font-size: 12px; color: var(--text-secondary); margin-bottom: 8px;";
  heading.textContent = "How long should the delegation last?";
  container.appendChild(heading);
  for (const option of TIME_DURATION_OPTIONS) {
    const btn = document.createElement("button");
    btn.className = `btn ${state.durationMinutes === option.minutes ? "btn-primary" : "btn-secondary"}`;
    btn.textContent = option.label;
    btn.style.cssText = "display: block; width: 100%; margin-bottom: 6px;";
    btn.addEventListener("click", () => {
      const updated = setDuration(state, option.minutes);
      onStateChange(nextStep(updated));
    });
    container.appendChild(btn);
  }
  renderNavButtons(container, state, onStateChange, true);
}
function renderConfirmStep(container, state, onStateChange) {
  const preset = state.selectedPreset;
  if (!preset) return;
  const info = PRESET_DESCRIPTIONS[preset];
  const summary = document.createElement("div");
  summary.style.cssText = "font-size: 12px; color: var(--text-secondary);";
  let html = `<p><strong>Preset:</strong> ${info.title}</p>`;
  if (state.sitePatterns.length > 0) {
    html += `<p><strong>Sites:</strong> ${state.sitePatterns.map((p) => p.pattern).join(", ")}</p>`;
  }
  if (state.durationMinutes) {
    const opt = TIME_DURATION_OPTIONS.find((o) => o.minutes === state.durationMinutes);
    html += `<p><strong>Duration:</strong> ${opt?.label ?? state.durationMinutes + " minutes"}</p>`;
  }
  summary.innerHTML = html;
  container.appendChild(summary);
  const labelInput = document.createElement("input");
  labelInput.type = "text";
  labelInput.placeholder = "Label (optional)";
  labelInput.className = "form-input";
  labelInput.value = state.label;
  labelInput.style.cssText = "width: 100%; margin: 8px 0;";
  labelInput.addEventListener("input", () => {
    state.label = labelInput.value;
  });
  container.appendChild(labelInput);
  const activateBtn = document.createElement("button");
  activateBtn.className = "btn btn-primary";
  activateBtn.textContent = "Activate Delegation";
  activateBtn.style.cssText = "width: 100%; margin-top: 8px;";
  activateBtn.addEventListener("click", () => {
    const rule = finalizeWizard(state);
    if (rule) {
      container.dispatchEvent(
        new CustomEvent("delegation-activated", { detail: rule, bubbles: true })
      );
    }
  });
  container.appendChild(activateBtn);
  renderNavButtons(container, state, onStateChange, true);
}
function renderNavButtons(container, state, onStateChange, showBack = false) {
  const nav = document.createElement("div");
  nav.style.cssText = "display: flex; justify-content: space-between; margin-top: 8px;";
  if (showBack) {
    const backBtn = document.createElement("button");
    backBtn.className = "btn btn-secondary";
    backBtn.textContent = "Back";
    backBtn.style.cssText = "font-size: 11px;";
    backBtn.addEventListener("click", () => onStateChange(previousStep(state)));
    nav.appendChild(backBtn);
  }
  if (state.currentStep === "sites") {
    const nextBtn = document.createElement("button");
    nextBtn.className = "btn btn-primary";
    nextBtn.textContent = "Next";
    nextBtn.style.cssText = "font-size: 11px; margin-left: auto;";
    nextBtn.addEventListener("click", () => onStateChange(nextStep(state)));
    nav.appendChild(nextBtn);
  }
  if (nav.children.length > 0) {
    container.appendChild(nav);
  }
}
let popupState = {
  detectedAgents: [],
  activeDelegation: null,
  killSwitchActive: false,
  recentViolations: [],
  sessions: [],
  wizardState: null,
  loading: true,
  lifetimeStats: null
};
let countdownIntervalId = null;
function initialize() {
  document.addEventListener("DOMContentLoaded", () => {
    setupEventListeners();
    queryBackgroundStatus();
  });
}
async function queryBackgroundStatus() {
  try {
    const response = await sendToBackground("STATUS_QUERY", {});
    if (response && typeof response === "object") {
      const data = response;
      popupState.detectedAgents = data.detectedAgents ?? [];
      popupState.activeDelegation = data.activeDelegation ?? null;
      popupState.killSwitchActive = data.killSwitchActive ?? false;
      popupState.recentViolations = data.recentViolations ?? [];
      popupState.lifetimeStats = data.lifetimeStats ?? null;
    }
  } catch {
  }
  try {
    const sessionResponse = await sendToBackground("SESSION_QUERY", {});
    if (sessionResponse && typeof sessionResponse === "object") {
      const data = sessionResponse;
      popupState.sessions = data.sessions ?? [];
    }
  } catch {
  }
  popupState.loading = false;
  renderAll();
}
function setupEventListeners() {
  const killSwitchBtn = document.getElementById("kill-switch-btn");
  if (killSwitchBtn) {
    killSwitchBtn.addEventListener("click", onKillSwitchClick);
  }
  const wizardBtn = document.getElementById("delegation-wizard-btn");
  if (wizardBtn) {
    wizardBtn.addEventListener("click", onDelegationWizardClick);
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || !message.type) return;
      switch (message.type) {
        case "DETECTION_RESULT":
          queryBackgroundStatus();
          break;
        case "KILL_SWITCH_RESULT":
          popupState.killSwitchActive = true;
          renderAll();
          break;
        case "DELEGATION_UPDATE":
          queryBackgroundStatus();
          break;
      }
    });
  }
  document.addEventListener("delegation-activated", (e) => {
    const rule = e.detail;
    popupState.activeDelegation = rule;
    popupState.wizardState = null;
    const wizardContainer = document.getElementById("wizard-container");
    if (wizardContainer) {
      wizardContainer.classList.add("hidden");
      wizardContainer.innerHTML = "";
    }
    renderAll();
    sendToBackground("DELEGATION_UPDATE", rule).catch((err) => {
      console.error("[AI Browser Guard] Failed to sync delegation to background:", err);
    });
  });
}
async function onKillSwitchClick() {
  const btn = document.getElementById("kill-switch-btn");
  if (btn) btn.disabled = true;
  try {
    await sendToBackground("KILL_SWITCH_ACTIVATE", { trigger: "button" });
    popupState.killSwitchActive = true;
    popupState.detectedAgents = [];
    popupState.activeDelegation = null;
    renderAll();
  } catch {
    if (btn) btn.disabled = false;
  }
}
function onDelegationWizardClick() {
  const wizardContainer = document.getElementById("wizard-container");
  if (!wizardContainer) return;
  if (wizardContainer.classList.contains("hidden")) {
    wizardContainer.classList.remove("hidden");
    popupState.wizardState = createInitialWizardState();
    renderWizardUI();
  } else {
    wizardContainer.classList.add("hidden");
    wizardContainer.innerHTML = "";
    popupState.wizardState = null;
  }
  renderDelegationPanel();
}
function renderWizardUI() {
  const wizardContainer = document.getElementById("wizard-container");
  if (!wizardContainer || !popupState.wizardState) return;
  renderWizard(wizardContainer, popupState.wizardState, (newState) => {
    popupState.wizardState = newState;
    renderWizardUI();
  });
}
function renderAll() {
  renderDetectionPanel();
  renderKillSwitchPanel();
  renderDelegationPanel();
  renderViolationsPanel();
  renderTimelinePanel();
  renderMetricsPanel();
  renderStatusBadge();
}
function renderDetectionPanel() {
  const container = document.getElementById("detection-content");
  if (!container) return;
  if (popupState.loading) {
    container.innerHTML = '<p class="placeholder-text-inline">Loading...</p>';
    return;
  }
  if (popupState.detectedAgents.length === 0) {
    container.innerHTML = '<p class="placeholder-text-inline">No agents detected</p>';
    return;
  }
  container.innerHTML = "";
  for (const agent of popupState.detectedAgents) {
    const card = document.createElement("div");
    card.className = "detection-card";
    const headerRow = document.createElement("div");
    headerRow.style.cssText = "display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;";
    const name = document.createElement("strong");
    name.textContent = formatAgentType(agent.type);
    const badge = document.createElement("span");
    badge.className = "severity-badge severity-badge-high";
    badge.textContent = `Confidence: ${agent.confidence}`;
    headerRow.appendChild(name);
    headerRow.appendChild(badge);
    const metaRow = document.createElement("div");
    metaRow.style.cssText = "font-size: 12px; color: var(--text-secondary); font-weight: 500;";
    const ts = document.createElement("span");
    ts.textContent = formatTimestamp(agent.detectedAt) + " ";
    metaRow.appendChild(ts);
    for (const m of agent.detectionMethods) {
      const tag = document.createElement("span");
      tag.className = "method-tag";
      tag.textContent = m;
      metaRow.appendChild(tag);
    }
    const urlRow = document.createElement("div");
    urlRow.style.cssText = "font-size: 12px; color: var(--text-secondary); font-weight: 500; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;";
    urlRow.textContent = truncateUrl(agent.originUrl, 45);
    urlRow.title = agent.originUrl;
    const quickAllowRow = document.createElement("div");
    quickAllowRow.style.cssText = "display: flex; gap: 6px; margin-top: 6px;";
    const allowReadOnlyBtn = document.createElement("button");
    allowReadOnlyBtn.type = "button";
    allowReadOnlyBtn.className = "btn btn-secondary btn-sm";
    allowReadOnlyBtn.textContent = "Allow Read-Only";
    allowReadOnlyBtn.addEventListener("click", () => {
      onQuickAllowClick("readOnly");
    });
    const allowFullBtn = document.createElement("button");
    allowFullBtn.type = "button";
    allowFullBtn.className = "btn btn-primary btn-sm";
    allowFullBtn.textContent = "Allow Full Access";
    allowFullBtn.addEventListener("click", () => {
      onQuickAllowClick("fullAccess");
    });
    quickAllowRow.appendChild(allowReadOnlyBtn);
    quickAllowRow.appendChild(allowFullBtn);
    card.appendChild(headerRow);
    card.appendChild(metaRow);
    card.appendChild(urlRow);
    card.appendChild(quickAllowRow);
    container.appendChild(card);
  }
}
function renderKillSwitchPanel() {
  const btn = document.getElementById("kill-switch-btn");
  if (!btn) return;
  if (popupState.killSwitchActive) {
    btn.textContent = "Resume Monitoring";
    btn.disabled = false;
    btn.className = "btn btn-primary btn-sm";
    btn.onclick = () => {
      onResumeMonitoringClick().catch(() => {
      });
    };
  } else if (popupState.detectedAgents.length > 0) {
    btn.textContent = "Kill Switch";
    btn.disabled = false;
    btn.className = "btn-danger-compact";
    btn.onclick = () => {
      onKillSwitchClick().catch(() => {
      });
    };
  } else {
    btn.textContent = "Kill Switch";
    btn.disabled = true;
    btn.className = "btn btn-secondary btn-sm";
    btn.onclick = null;
  }
}
async function onResumeMonitoringClick() {
  const btn = document.getElementById("kill-switch-btn");
  if (btn) btn.disabled = true;
  try {
    await sendToBackground("KILL_SWITCH_RESET", {});
    popupState.killSwitchActive = false;
    renderAll();
  } catch {
    if (btn) btn.disabled = false;
  }
}
function onQuickAllowClick(preset) {
  const rule = createRuleFromPreset(preset);
  popupState.activeDelegation = rule;
  popupState.wizardState = null;
  const wizardContainer = document.getElementById("wizard-container");
  if (wizardContainer) {
    wizardContainer.classList.add("hidden");
    wizardContainer.innerHTML = "";
  }
  renderAll();
  sendToBackground("DELEGATION_UPDATE", rule).catch((err) => {
    console.error("[AI Browser Guard] Failed to sync quick-allow to background:", err);
  });
}
function renderDelegationPanel() {
  if (countdownIntervalId !== null) {
    clearInterval(countdownIntervalId);
    countdownIntervalId = null;
  }
  const content = document.getElementById("delegation-content");
  if (!content) return;
  if (popupState.activeDelegation) {
    const rule = popupState.activeDelegation;
    const presetNames = {
      readOnly: "Read-Only",
      limited: "Limited",
      fullAccess: "Full Access"
    };
    content.innerHTML = "";
    const row = document.createElement("div");
    row.className = "delegation-empty";
    const labelSpan = document.createElement("span");
    const strong = document.createElement("strong");
    strong.textContent = presetNames[rule.preset] ?? rule.preset;
    labelSpan.appendChild(strong);
    if (rule.scope.timeBound) {
      let updateCountdown = function() {
        const remaining = expiresAt - Date.now();
        if (remaining <= 0) {
          if (countdownIntervalId !== null) {
            clearInterval(countdownIntervalId);
            countdownIntervalId = null;
          }
          timeSpan.style.color = "var(--color-danger)";
          timeSpan.textContent = " (Expired)";
          queryBackgroundStatus().catch(() => {
          });
          return;
        }
        const totalSeconds = Math.floor(remaining / 1e3);
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        const paddedSecs = secs.toString().padStart(2, "0");
        timeSpan.style.color = remaining < 6e4 ? "var(--color-danger)" : "var(--color-warning)";
        timeSpan.textContent = ` (${mins}:${paddedSecs} left)`;
      };
      const expiresAt = new Date(rule.scope.timeBound.expiresAt).getTime();
      const timeSpan = document.createElement("span");
      timeSpan.id = "delegation-countdown";
      timeSpan.style.cssText = "font-size: 12px; font-weight: 500;";
      labelSpan.appendChild(timeSpan);
      updateCountdown();
      countdownIntervalId = setInterval(updateCountdown, 1e3);
    }
    const changeBtn = document.createElement("button");
    changeBtn.id = "delegation-wizard-btn";
    changeBtn.className = "btn btn-secondary btn-sm";
    changeBtn.textContent = "Change";
    changeBtn.addEventListener("click", onDelegationWizardClick);
    row.appendChild(labelSpan);
    row.appendChild(changeBtn);
    content.appendChild(row);
  } else {
    const wizardOpen = popupState.wizardState !== null;
    content.innerHTML = `
      <div class="delegation-empty">
        <span class="placeholder-text-inline">No delegation active</span>
        <button id="delegation-wizard-btn" class="btn ${wizardOpen ? "btn-secondary" : "btn-primary"} btn-sm">${wizardOpen ? "Cancel" : "Configure"}</button>
      </div>
    `;
    const wizardBtn = document.getElementById("delegation-wizard-btn");
    if (wizardBtn) {
      wizardBtn.addEventListener("click", onDelegationWizardClick);
    }
  }
}
function renderViolationsPanel() {
  const panel = document.getElementById("violations-panel");
  const container = document.getElementById("violations-list");
  if (!container || !panel) return;
  if (popupState.recentViolations.length === 0) {
    panel.classList.add("hidden");
    return;
  }
  panel.classList.remove("hidden");
  container.innerHTML = "";
  for (const alert of popupState.recentViolations.slice(-10).reverse()) {
    const item = document.createElement("div");
    item.className = "event-item";
    const dot = document.createElement("div");
    dot.className = "event-outcome outcome-blocked";
    const body = document.createElement("div");
    body.style.cssText = "flex: 1; min-width: 0;";
    const topRow = document.createElement("div");
    topRow.style.cssText = "display: flex; justify-content: space-between;";
    const titleSpan = document.createElement("span");
    titleSpan.style.cssText = "font-size: 13px; font-weight: 600;";
    titleSpan.textContent = alert.title;
    const sevBadge = document.createElement("span");
    sevBadge.className = `severity-badge severity-${alert.severity}`;
    sevBadge.textContent = alert.severity;
    topRow.appendChild(titleSpan);
    topRow.appendChild(sevBadge);
    const urlLine = document.createElement("div");
    urlLine.style.cssText = "font-size: 12px; color: var(--text-secondary); font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;";
    urlLine.textContent = truncateUrl(alert.violation.url);
    const tsLine = document.createElement("div");
    tsLine.style.cssText = "font-size: 11px; color: var(--text-secondary); font-weight: 500;";
    tsLine.textContent = formatTimestamp(alert.violation.timestamp);
    body.appendChild(topRow);
    body.appendChild(urlLine);
    body.appendChild(tsLine);
    item.appendChild(dot);
    item.appendChild(body);
    container.appendChild(item);
  }
}
function renderTimelinePanel() {
  const panel = document.getElementById("timeline-panel");
  const container = document.getElementById("timeline-list");
  if (!container || !panel) return;
  const sessions = popupState.sessions;
  const hasSessions = sessions.some((s) => s.events.length > 0);
  if (!hasSessions) {
    panel.classList.add("hidden");
    return;
  }
  panel.classList.remove("hidden");
  container.innerHTML = "";
  if (sessions.length === 0) {
    const empty = document.createElement("p");
    empty.className = "placeholder-text-inline";
    empty.textContent = "No session history";
    container.appendChild(empty);
    return;
  }
  const startExpanded = sessions.length === 1;
  for (const session of sessions) {
    let toggleGroup = function() {
      const isHidden = eventRows.classList.contains("hidden");
      if (isHidden) {
        eventRows.classList.remove("hidden");
        chevron.textContent = "-";
      } else {
        eventRows.classList.add("hidden");
        chevron.textContent = "+";
      }
    };
    if (session.events.length === 0) continue;
    const group = document.createElement("div");
    group.className = "session-group";
    const header = document.createElement("div");
    header.className = "session-header";
    header.setAttribute("role", "button");
    header.setAttribute("tabindex", "0");
    const headerLeft = document.createElement("div");
    headerLeft.className = "session-header-left";
    const agentName = document.createElement("span");
    agentName.className = "session-agent-name";
    agentName.textContent = formatAgentType(session.agent.type);
    const startLabel = document.createElement("span");
    startLabel.className = "session-time-label";
    startLabel.textContent = formatTimeShort(session.startedAt);
    const countLabel = document.createElement("span");
    countLabel.className = "session-event-count";
    countLabel.textContent = `${session.events.length} action${session.events.length === 1 ? "" : "s"}`;
    headerLeft.appendChild(agentName);
    headerLeft.appendChild(startLabel);
    headerLeft.appendChild(countLabel);
    const headerRight = document.createElement("div");
    headerRight.className = "session-header-right";
    if (session.endedAt === null) {
      const activeBadge = document.createElement("span");
      activeBadge.className = "session-status-badge session-status-active";
      activeBadge.textContent = "Active";
      headerRight.appendChild(activeBadge);
    } else {
      const endLabel = document.createElement("span");
      endLabel.className = "session-time-label";
      endLabel.textContent = `Ended ${formatTimeShort(session.endedAt)}`;
      headerRight.appendChild(endLabel);
    }
    const chevron = document.createElement("span");
    chevron.className = "session-chevron";
    chevron.textContent = startExpanded ? "-" : "+";
    headerRight.appendChild(chevron);
    header.appendChild(headerLeft);
    header.appendChild(headerRight);
    const eventRows = document.createElement("div");
    eventRows.className = "session-events";
    if (!startExpanded) {
      eventRows.classList.add("hidden");
    }
    for (const event of session.events) {
      const row = document.createElement("div");
      row.className = "session-event-row";
      const arrow = document.createElement("span");
      arrow.className = "session-event-arrow";
      arrow.textContent = "↳";
      const timeCell = document.createElement("span");
      timeCell.className = "session-event-time";
      timeCell.textContent = formatTimestamp(event.timestamp);
      const capabilityCell = document.createElement("span");
      capabilityCell.className = "session-event-capability";
      capabilityCell.textContent = event.attemptedAction ?? event.type;
      const targetCell = document.createElement("span");
      targetCell.className = "session-event-target";
      const target = event.targetSelector ? truncateUrl(event.targetSelector, 28) : truncateUrl(event.url, 28);
      targetCell.textContent = target;
      targetCell.title = event.targetSelector ?? event.url;
      const outcomeChip = document.createElement("span");
      const outcomeClass = event.outcome === "allowed" ? "outcome-chip-allowed" : event.outcome === "blocked" ? "outcome-chip-blocked" : "outcome-chip-info";
      outcomeChip.className = `outcome-chip ${outcomeClass}`;
      outcomeChip.textContent = event.outcome;
      row.appendChild(arrow);
      row.appendChild(timeCell);
      row.appendChild(capabilityCell);
      row.appendChild(targetCell);
      row.appendChild(outcomeChip);
      eventRows.appendChild(row);
    }
    header.addEventListener("click", toggleGroup);
    header.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleGroup();
      }
    });
    group.appendChild(header);
    group.appendChild(eventRows);
    container.appendChild(group);
  }
}
function renderMetricsPanel() {
  const panel = document.getElementById("metrics-panel");
  const grid = document.getElementById("metrics-grid");
  const since = document.getElementById("metrics-since");
  if (!panel || !grid || !since) return;
  const stats = popupState.lifetimeStats;
  if (!stats || stats.totalSessions === 0) {
    panel.classList.add("hidden");
    return;
  }
  panel.classList.remove("hidden");
  grid.innerHTML = "";
  addMetricCell(grid, String(stats.totalSessions), "sessions monitored");
  if (stats.totalActionsBlocked > 0) {
    addMetricCell(grid, String(stats.totalActionsBlocked), "actions blocked");
  } else {
    addMetricCell(grid, "None", "violations detected");
  }
  const types = Object.entries(stats.agentTypesDetected);
  if (types.length > 0) {
    const topType = types.sort((a, b) => b[1] - a[1])[0][0];
    addMetricCell(grid, formatAgentType(topType), "most seen framework");
  } else {
    const uniqueCount = types.length;
    addMetricCell(grid, String(uniqueCount), "framework types");
  }
  since.textContent = "";
  if (stats.firstActiveAt) {
    const date = new Date(stats.firstActiveAt);
    const daysSince = Math.floor((Date.now() - date.getTime()) / 864e5);
    const dateStr = date.toLocaleDateString(void 0, { month: "short", day: "numeric", year: "numeric" });
    const sinceText = document.createElement("span");
    sinceText.textContent = daysSince === 0 ? `Monitoring active since today (${dateStr})` : `Monitoring active since ${dateStr} (${daysSince} day${daysSince === 1 ? "" : "s"})`;
    since.appendChild(sinceText);
  }
}
function addMetricCell(container, value, label) {
  const cell = document.createElement("div");
  cell.className = "metric-cell";
  const val = document.createElement("div");
  val.className = "metric-value";
  val.textContent = value;
  const lbl = document.createElement("div");
  lbl.className = "metric-label";
  lbl.textContent = label;
  cell.appendChild(val);
  cell.appendChild(lbl);
  container.appendChild(cell);
}
function renderStatusBadge() {
  const indicator = document.getElementById("status-indicator");
  const statusText = document.getElementById("status-text");
  if (!indicator || !statusText) return;
  indicator.classList.remove("status-idle", "status-detected", "status-killed", "status-delegated");
  if (popupState.killSwitchActive) {
    indicator.classList.add("status-killed");
    statusText.textContent = "Killed";
  } else if (popupState.detectedAgents.length > 0) {
    indicator.classList.add("status-detected");
    statusText.textContent = `${popupState.detectedAgents.length} Agent(s) Detected`;
  } else if (popupState.activeDelegation) {
    indicator.classList.add("status-delegated");
    statusText.textContent = "Delegated";
  } else {
    indicator.classList.add("status-idle");
    statusText.textContent = "Monitoring";
  }
}
async function sendToBackground(type, data) {
  const message = {
    type,
    data,
    sentAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (typeof chrome === "undefined" || !chrome.runtime) {
    return Promise.reject(new Error("Chrome runtime not available"));
  }
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
function formatTimestamp(isoTimestamp) {
  const date = new Date(isoTimestamp);
  return date.toLocaleTimeString(void 0, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
}
function formatTimeShort(isoTimestamp) {
  const date = new Date(isoTimestamp);
  return date.toLocaleTimeString(void 0, {
    hour: "2-digit",
    minute: "2-digit"
  });
}
function formatAgentType(type) {
  const names = {
    playwright: "Playwright",
    puppeteer: "Puppeteer",
    selenium: "Selenium",
    "anthropic-computer-use": "Anthropic Computer Use",
    "openai-operator": "OpenAI Operator",
    "cdp-generic": "CDP Agent",
    "webdriver-generic": "WebDriver Agent",
    unknown: "Unknown Agent"
  };
  return names[type] ?? type;
}
function truncateUrl(url, maxLength = 40) {
  if (url.length <= maxLength) return url;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname;
    const path = parsed.pathname;
    const available = maxLength - host.length - 3;
    if (available <= 0) return host.substring(0, maxLength - 3) + "...";
    return host + path.substring(0, available) + "...";
  } catch {
    return url.substring(0, maxLength - 3) + "...";
  }
}
initialize();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9kZWxlZ2F0aW9uL3J1bGVzLnRzIiwiLi4vLi4vc3JjL2RlbGVnYXRpb24vd2l6YXJkLnRzIiwiLi4vLi4vc3JjL3BvcHVwL3BvcHVwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogRGVsZWdhdGlvbiBydWxlIGVuZ2luZS5cbiAqXG4gKiBFdmFsdWF0ZXMgZGVsZWdhdGlvbiBydWxlcyB0byBkZXRlcm1pbmUgd2hhdCBhY3Rpb25zIGFuIGFnZW50IGlzXG4gKiBwZXJtaXR0ZWQgdG8gcGVyZm9ybS4gU3VwcG9ydHMgc2l0ZSBwYXR0ZXJucywgYWN0aW9uIHJlc3RyaWN0aW9ucyxcbiAqIGFuZCB0aW1lIGJvdW5kcy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7XG4gIERlbGVnYXRpb25SdWxlLFxuICBEZWxlZ2F0aW9uUHJlc2V0LFxuICBEZWxlZ2F0aW9uU2NvcGUsXG4gIERlbGVnYXRpb25Ub2tlbixcbiAgU2l0ZVBhdHRlcm4sXG4gIEFjdGlvblJlc3RyaWN0aW9uLFxuICBUaW1lQm91bmQsXG59IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSWQoKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKCk7XG59XG5cbmNvbnN0IFJFQURfT05MWV9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbSddO1xuY29uc3QgTElNSVRFRF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbScsICdjbGljaycsICd0eXBlLXRleHQnXTtcbmNvbnN0IEFMTF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gW1xuICAnbmF2aWdhdGUnLCAncmVhZC1kb20nLCAnY2xpY2snLCAndHlwZS10ZXh0JywgJ3N1Ym1pdC1mb3JtJyxcbiAgJ2Rvd25sb2FkLWZpbGUnLCAnb3Blbi10YWInLCAnY2xvc2UtdGFiJywgJ3NjcmVlbnNob3QnLFxuICAnZXhlY3V0ZS1zY3JpcHQnLCAnbW9kaWZ5LWRvbScsXG5dO1xuXG5mdW5jdGlvbiBidWlsZEFjdGlvblJlc3RyaWN0aW9ucyhhbGxvd2VkOiBBZ2VudENhcGFiaWxpdHlbXSk6IEFjdGlvblJlc3RyaWN0aW9uW10ge1xuICByZXR1cm4gQUxMX0NBUEFCSUxJVElFUy5tYXAoKGNhcCkgPT4gKHtcbiAgICBjYXBhYmlsaXR5OiBjYXAsXG4gICAgYWN0aW9uOiBhbGxvd2VkLmluY2x1ZGVzKGNhcCkgPyAnYWxsb3cnIGFzIGNvbnN0IDogJ2Jsb2NrJyBhcyBjb25zdCxcbiAgfSkpO1xufVxuXG4vKipcbiAqIENyZWF0ZSBhIGRlbGVnYXRpb24gcnVsZSBmcm9tIGEgcHJlc2V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUnVsZUZyb21QcmVzZXQoXG4gIHByZXNldDogRGVsZWdhdGlvblByZXNldCxcbiAgb3B0aW9ucz86IHtcbiAgICBzaXRlUGF0dGVybnM/OiBTaXRlUGF0dGVybltdO1xuICAgIGR1cmF0aW9uTWludXRlcz86IG51bWJlcjtcbiAgICBsYWJlbD86IHN0cmluZztcbiAgfVxuKTogRGVsZWdhdGlvblJ1bGUge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICBsZXQgc2NvcGU6IERlbGVnYXRpb25TY29wZTtcblxuICBzd2l0Y2ggKHByZXNldCkge1xuICAgIGNhc2UgJ3JlYWRPbmx5JzpcbiAgICAgIHNjb3BlID0ge1xuICAgICAgICBzaXRlUGF0dGVybnM6IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKFJFQURfT05MWV9DQVBBQklMSVRJRVMpLFxuICAgICAgICB0aW1lQm91bmQ6IG51bGwsXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG5cbiAgICBjYXNlICdsaW1pdGVkJzoge1xuICAgICAgY29uc3QgZHVyYXRpb25NaW51dGVzID0gb3B0aW9ucz8uZHVyYXRpb25NaW51dGVzID8/IDYwO1xuICAgICAgY29uc3QgZXhwaXJlc0F0ID0gbmV3IERhdGUobm93LmdldFRpbWUoKSArIGR1cmF0aW9uTWludXRlcyAqIDYwMDAwKTtcbiAgICAgIGNvbnN0IHRpbWVCb3VuZDogVGltZUJvdW5kID0ge1xuICAgICAgICBkdXJhdGlvbk1pbnV0ZXMsXG4gICAgICAgIGdyYW50ZWRBdDogbm93LnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGV4cGlyZXNBdDogZXhwaXJlc0F0LnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogb3B0aW9ucz8uc2l0ZVBhdHRlcm5zID8/IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKExJTUlURURfQ0FQQUJJTElUSUVTKSxcbiAgICAgICAgdGltZUJvdW5kLFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGNhc2UgJ2Z1bGxBY2Nlc3MnOlxuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogW10sXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogYnVpbGRBY3Rpb25SZXN0cmljdGlvbnMoQUxMX0NBUEFCSUxJVElFUyksXG4gICAgICAgIHRpbWVCb3VuZDogbnVsbCxcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGdlbmVyYXRlSWQoKSxcbiAgICBwcmVzZXQsXG4gICAgc2NvcGUsXG4gICAgY3JlYXRlZEF0OiBub3cudG9JU09TdHJpbmcoKSxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICBsYWJlbDogb3B0aW9ucz8ubGFiZWwsXG4gIH07XG59XG5cbi8qKlxuICogRXZhbHVhdGUgd2hldGhlciBhbiBhY3Rpb24gaXMgYWxsb3dlZCB1bmRlciBhIGRlbGVnYXRpb24gcnVsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV2YWx1YXRlUnVsZShcbiAgcnVsZTogRGVsZWdhdGlvblJ1bGUsXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICB1cmw6IHN0cmluZ1xuKTogeyBhbGxvd2VkOiBib29sZWFuOyByZWFzb246IHN0cmluZyB9IHtcbiAgaWYgKCFydWxlLmlzQWN0aXZlKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gcnVsZSBpcyBub3QgYWN0aXZlLicgfTtcbiAgfVxuXG4gIGlmIChpc1RpbWVCb3VuZEV4cGlyZWQocnVsZS5zY29wZS50aW1lQm91bmQpKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gaGFzIGV4cGlyZWQuJyB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgc2l0ZSBwYXR0ZXJuc1xuICBjb25zdCBkZWZhdWx0U2l0ZUFjdGlvbiA9IHJ1bGUucHJlc2V0ID09PSAnbGltaXRlZCcgPyAnYmxvY2snIGFzIGNvbnN0IDogJ2FsbG93JyBhcyBjb25zdDtcbiAgY29uc3Qgc2l0ZVJlc3VsdCA9IGV2YWx1YXRlU2l0ZVBhdHRlcm5zKHVybCwgcnVsZS5zY29wZS5zaXRlUGF0dGVybnMsIGRlZmF1bHRTaXRlQWN0aW9uKTtcbiAgaWYgKCFzaXRlUmVzdWx0LmFsbG93ZWQpIHtcbiAgICBjb25zdCBwYXR0ZXJuRGV0YWlsID0gc2l0ZVJlc3VsdC5tYXRjaGVkUGF0dGVyblxuICAgICAgPyBgIChtYXRjaGVkOiAke3NpdGVSZXN1bHQubWF0Y2hlZFBhdHRlcm4ucGF0dGVybn0pYFxuICAgICAgOiAnIChkZWZhdWx0IHBvbGljeSknO1xuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCByZWFzb246IGBVUkwgYmxvY2tlZCBieSBzaXRlIHBvbGljeSR7cGF0dGVybkRldGFpbH0uYCB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgYWN0aW9uIHJlc3RyaWN0aW9uc1xuICBjb25zdCBhY3Rpb25SZXN1bHQgPSBldmFsdWF0ZUFjdGlvblJlc3RyaWN0aW9ucyhhY3Rpb24sIHJ1bGUuc2NvcGUuYWN0aW9uUmVzdHJpY3Rpb25zKTtcbiAgaWYgKCFhY3Rpb25SZXN1bHQuYWxsb3dlZCkge1xuICAgIHJldHVybiB7XG4gICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgIHJlYXNvbjogYEFjdGlvbiBcIiR7YWN0aW9ufVwiIGlzIG5vdCBwZXJtaXR0ZWQgdW5kZXIgJHtydWxlLnByZXNldH0gZGVsZWdhdGlvbi5gLFxuICAgIH07XG4gIH1cblxuICByZXR1cm4geyBhbGxvd2VkOiB0cnVlLCByZWFzb246ICdBY3Rpb24gcGVybWl0dGVkIGJ5IGRlbGVnYXRpb24gcnVsZXMuJyB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgVVJMIG1hdGNoZXMgYW55IHNpdGUgcGF0dGVybiBpbiB0aGUgc2NvcGUuXG4gKiBGaXJzdCBtYXRjaCB3aW5zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVTaXRlUGF0dGVybnMoXG4gIHVybDogc3RyaW5nLFxuICBwYXR0ZXJuczogU2l0ZVBhdHRlcm5bXSxcbiAgZGVmYXVsdEFjdGlvbjogJ2FsbG93JyB8ICdibG9jaydcbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFBhdHRlcm46IFNpdGVQYXR0ZXJuIHwgbnVsbCB9IHtcbiAgZm9yIChjb25zdCBwYXR0ZXJuIG9mIHBhdHRlcm5zKSB7XG4gICAgaWYgKG1hdGNoR2xvYih1cmwsIHBhdHRlcm4ucGF0dGVybikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGFsbG93ZWQ6IHBhdHRlcm4uYWN0aW9uID09PSAnYWxsb3cnLFxuICAgICAgICBtYXRjaGVkUGF0dGVybjogcGF0dGVybixcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB7IGFsbG93ZWQ6IGRlZmF1bHRBY3Rpb24gPT09ICdhbGxvdycsIG1hdGNoZWRQYXR0ZXJuOiBudWxsIH07XG59XG5cbi8qKlxuICogTWF0Y2ggYSBVUkwgYWdhaW5zdCBhIGdsb2IgcGF0dGVybi5cbiAqL1xuZnVuY3Rpb24gbWF0Y2hHbG9iKHVybDogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgdHJ5IHtcbiAgICAvLyBJZiBwYXR0ZXJuIGRvZXNuJ3QgY29udGFpbiBwcm90b2NvbCwgbWF0Y2ggYWdhaW5zdCBob3N0bmFtZVxuICAgIGlmICghcGF0dGVybi5pbmNsdWRlcygnOi8vJykpIHtcbiAgICAgIGNvbnN0IHBhcnNlZFVybCA9IG5ldyBVUkwodXJsKTtcbiAgICAgIGNvbnN0IGhvc3RuYW1lID0gcGFyc2VkVXJsLmhvc3RuYW1lO1xuICAgICAgLy8gQ29udmVydCBnbG9iIHRvIHJlZ2V4OiAqIG1hdGNoZXMgYW55IGNoYXJhY3RlcnMgZXhjZXB0IGRvdHMgaW4gZG9tYWluIGNvbnRleHRcbiAgICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgICAucmVwbGFjZSgvXFwuL2csICdcXFxcLicpXG4gICAgICAgIC5yZXBsYWNlKC9cXCpcXCovZywgJy4qJylcbiAgICAgICAgLnJlcGxhY2UoL1xcKi9nLCAnW14uXSonKTtcbiAgICAgIHJldHVybiBuZXcgUmVnRXhwKGBeJHtyZWdleFN0cn0kYCkudGVzdChob3N0bmFtZSk7XG4gICAgfVxuXG4gICAgLy8gRnVsbCBVUkwgcGF0dGVybiBtYXRjaGluZ1xuICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgLnJlcGxhY2UoL1suK14ke30oKXxbXFxdXFxcXF0vZywgJ1xcXFwkJicpXG4gICAgICAucmVwbGFjZSgvXFxcXFxcKi9nLCAnLionKTtcbiAgICByZXR1cm4gbmV3IFJlZ0V4cChgXiR7cmVnZXhTdHJ9JGApLnRlc3QodXJsKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYW4gYWN0aW9uIGlzIGFsbG93ZWQgYnkgdGhlIGFjdGlvbiByZXN0cmljdGlvbiBsaXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVBY3Rpb25SZXN0cmljdGlvbnMoXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICByZXN0cmljdGlvbnM6IEFjdGlvblJlc3RyaWN0aW9uW11cbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFJlc3RyaWN0aW9uOiBBY3Rpb25SZXN0cmljdGlvbiB8IG51bGwgfSB7XG4gIGNvbnN0IHJlc3RyaWN0aW9uID0gcmVzdHJpY3Rpb25zLmZpbmQoKHIpID0+IHIuY2FwYWJpbGl0eSA9PT0gYWN0aW9uKTtcbiAgaWYgKCFyZXN0cmljdGlvbikge1xuICAgIC8vIERlZmF1bHQtYmxvY2sgaWYgbm90IGxpc3RlZFxuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCBtYXRjaGVkUmVzdHJpY3Rpb246IG51bGwgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGFsbG93ZWQ6IHJlc3RyaWN0aW9uLmFjdGlvbiA9PT0gJ2FsbG93JyxcbiAgICBtYXRjaGVkUmVzdHJpY3Rpb246IHJlc3RyaWN0aW9uLFxuICB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgdGltZSBib3VuZCBoYXMgZXhwaXJlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzVGltZUJvdW5kRXhwaXJlZCh0aW1lQm91bmQ6IFRpbWVCb3VuZCB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKHRpbWVCb3VuZCA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCkgPiBuZXcgRGF0ZSh0aW1lQm91bmQuZXhwaXJlc0F0KS5nZXRUaW1lKCk7XG59XG5cbi8qKlxuICogSXNzdWUgYSBkZWxlZ2F0aW9uIHRva2VuIGZvciBhbiBhZ2VudCBzZXNzaW9uIChsb2NhbC1vbmx5LCBsb2NhbC1vbmx5LCB1bnNpZ25lZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc3N1ZVRva2VuKFxuICBydWxlSWQ6IHN0cmluZyxcbiAgYWdlbnRJZDogc3RyaW5nLFxuICBzY29wZTogRGVsZWdhdGlvblNjb3BlLFxuICBleHBpcmVzQXQ6IHN0cmluZ1xuKTogRGVsZWdhdGlvblRva2VuIHtcbiAgcmV0dXJuIHtcbiAgICB0b2tlbklkOiBnZW5lcmF0ZUlkKCksXG4gICAgcnVsZUlkLFxuICAgIGFnZW50SWQsXG4gICAgc2NvcGUsXG4gICAgaXNzdWVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBleHBpcmVzQXQsXG4gICAgcmV2b2tlZDogZmFsc2UsXG4gIH07XG59XG5cbi8qKlxuICogUmV2b2tlIGEgZGVsZWdhdGlvbiB0b2tlbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJldm9rZVRva2VuKHRva2VuOiBEZWxlZ2F0aW9uVG9rZW4pOiBEZWxlZ2F0aW9uVG9rZW4ge1xuICByZXR1cm4geyAuLi50b2tlbiwgcmV2b2tlZDogdHJ1ZSB9O1xufVxuIiwiLyoqXG4gKiBEZWxlZ2F0aW9uIHdpemFyZCBVSSBsb2dpYy5cbiAqXG4gKiBNYW5hZ2VzIHRoZSAzLXByZXNldCBkZWxlZ2F0aW9uIHdpemFyZCB0aGF0IGFwcGVhcnMgaW4gdGhlIHBvcHVwLlxuICovXG5cbmltcG9ydCB0eXBlIHsgRGVsZWdhdGlvblByZXNldCwgRGVsZWdhdGlvblJ1bGUsIFNpdGVQYXR0ZXJuIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5pbXBvcnQgeyBjcmVhdGVSdWxlRnJvbVByZXNldCB9IGZyb20gJy4vcnVsZXMnO1xuXG5leHBvcnQgdHlwZSBXaXphcmRTdGVwID0gJ3ByZXNldCcgfCAnc2l0ZXMnIHwgJ3RpbWUnIHwgJ2NvbmZpcm0nO1xuXG5leHBvcnQgaW50ZXJmYWNlIFdpemFyZFN0YXRlIHtcbiAgY3VycmVudFN0ZXA6IFdpemFyZFN0ZXA7XG4gIHNlbGVjdGVkUHJlc2V0OiBEZWxlZ2F0aW9uUHJlc2V0IHwgbnVsbDtcbiAgc2l0ZVBhdHRlcm5zOiBTaXRlUGF0dGVybltdO1xuICBkdXJhdGlvbk1pbnV0ZXM6IG51bWJlciB8IG51bGw7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGVycm9yczogc3RyaW5nW107XG59XG5cbmV4cG9ydCBjb25zdCBUSU1FX0RVUkFUSU9OX09QVElPTlMgPSBbXG4gIHsgbGFiZWw6ICcxNSBtaW51dGVzJywgbWludXRlczogMTUgfSxcbiAgeyBsYWJlbDogJzEgaG91cicsIG1pbnV0ZXM6IDYwIH0sXG4gIHsgbGFiZWw6ICc0IGhvdXJzJywgbWludXRlczogMjQwIH0sXG5dIGFzIGNvbnN0O1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFdpemFyZFN0YXRlKCk6IFdpemFyZFN0YXRlIHtcbiAgcmV0dXJuIHtcbiAgICBjdXJyZW50U3RlcDogJ3ByZXNldCcsXG4gICAgc2VsZWN0ZWRQcmVzZXQ6IG51bGwsXG4gICAgc2l0ZVBhdHRlcm5zOiBbXSxcbiAgICBkdXJhdGlvbk1pbnV0ZXM6IG51bGwsXG4gICAgbGFiZWw6ICcnLFxuICAgIGVycm9yczogW10sXG4gIH07XG59XG5cbi8qKlxuICogU2VsZWN0IGEgZGVsZWdhdGlvbiBwcmVzZXQgYW5kIGRldGVybWluZSB0aGUgbmV4dCBzdGVwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0UHJlc2V0KHN0YXRlOiBXaXphcmRTdGF0ZSwgcHJlc2V0OiBEZWxlZ2F0aW9uUHJlc2V0KTogV2l6YXJkU3RhdGUge1xuICBjb25zdCBuZXh0U3RlcDogV2l6YXJkU3RlcCA9IHByZXNldCA9PT0gJ2xpbWl0ZWQnID8gJ3NpdGVzJyA6ICdjb25maXJtJztcbiAgcmV0dXJuIHtcbiAgICAuLi5zdGF0ZSxcbiAgICBzZWxlY3RlZFByZXNldDogcHJlc2V0LFxuICAgIGN1cnJlbnRTdGVwOiBuZXh0U3RlcCxcbiAgICBlcnJvcnM6IFtdLFxuICB9O1xufVxuXG4vKipcbiAqIEFkZCBhIHNpdGUgcGF0dGVybiB0byB0aGUgd2l6YXJkIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRTaXRlUGF0dGVybihzdGF0ZTogV2l6YXJkU3RhdGUsIHBhdHRlcm46IFNpdGVQYXR0ZXJuKTogV2l6YXJkU3RhdGUge1xuICBpZiAoIXBhdHRlcm4ucGF0dGVybi50cmltKCkpIHtcbiAgICByZXR1cm4geyAuLi5zdGF0ZSwgZXJyb3JzOiBbJ1BhdHRlcm4gY2Fubm90IGJlIGVtcHR5LiddIH07XG4gIH1cblxuICAvLyBDaGVjayBmb3IgZHVwbGljYXRlc1xuICBjb25zdCBleGlzdHMgPSBzdGF0ZS5zaXRlUGF0dGVybnMuc29tZSgocCkgPT4gcC5wYXR0ZXJuID09PSBwYXR0ZXJuLnBhdHRlcm4pO1xuICBpZiAoZXhpc3RzKSB7XG4gICAgcmV0dXJuIHsgLi4uc3RhdGUsIGVycm9yczogWydUaGlzIHBhdHRlcm4gYWxyZWFkeSBleGlzdHMuJ10gfTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgLi4uc3RhdGUsXG4gICAgc2l0ZVBhdHRlcm5zOiBbLi4uc3RhdGUuc2l0ZVBhdHRlcm5zLCBwYXR0ZXJuXSxcbiAgICBlcnJvcnM6IFtdLFxuICB9O1xufVxuXG4vKipcbiAqIFJlbW92ZSBhIHNpdGUgcGF0dGVybiBieSBpbmRleC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZVNpdGVQYXR0ZXJuKHN0YXRlOiBXaXphcmRTdGF0ZSwgaW5kZXg6IG51bWJlcik6IFdpemFyZFN0YXRlIHtcbiAgY29uc3Qgc2l0ZVBhdHRlcm5zID0gc3RhdGUuc2l0ZVBhdHRlcm5zLmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpO1xuICByZXR1cm4geyAuLi5zdGF0ZSwgc2l0ZVBhdHRlcm5zLCBlcnJvcnM6IFtdIH07XG59XG5cbi8qKlxuICogU2V0IHRoZSB0aW1lIGR1cmF0aW9uIGZvciB0aGUgbGltaXRlZCBwcmVzZXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXREdXJhdGlvbihzdGF0ZTogV2l6YXJkU3RhdGUsIG1pbnV0ZXM6IG51bWJlcik6IFdpemFyZFN0YXRlIHtcbiAgY29uc3QgdmFsaWQgPSBUSU1FX0RVUkFUSU9OX09QVElPTlMuc29tZSgob3B0KSA9PiBvcHQubWludXRlcyA9PT0gbWludXRlcyk7XG4gIGlmICghdmFsaWQpIHtcbiAgICByZXR1cm4geyAuLi5zdGF0ZSwgZXJyb3JzOiBbJ0ludmFsaWQgZHVyYXRpb24uIENob29zZSAxNSBtaW51dGVzLCAxIGhvdXIsIG9yIDQgaG91cnMuJ10gfTtcbiAgfVxuICByZXR1cm4geyAuLi5zdGF0ZSwgZHVyYXRpb25NaW51dGVzOiBtaW51dGVzLCBlcnJvcnM6IFtdIH07XG59XG5cbi8qKlxuICogQWR2YW5jZSB0byB0aGUgbmV4dCB3aXphcmQgc3RlcC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5leHRTdGVwKHN0YXRlOiBXaXphcmRTdGF0ZSk6IFdpemFyZFN0YXRlIHtcbiAgc3dpdGNoIChzdGF0ZS5jdXJyZW50U3RlcCkge1xuICAgIGNhc2UgJ3ByZXNldCc6XG4gICAgICBpZiAoIXN0YXRlLnNlbGVjdGVkUHJlc2V0KSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBlcnJvcnM6IFsnU2VsZWN0IGEgZGVsZWdhdGlvbiBwcmVzZXQuJ10gfTtcbiAgICAgIH1cbiAgICAgIGlmIChzdGF0ZS5zZWxlY3RlZFByZXNldCA9PT0gJ2xpbWl0ZWQnKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjdXJyZW50U3RlcDogJ3NpdGVzJywgZXJyb3JzOiBbXSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGN1cnJlbnRTdGVwOiAnY29uZmlybScsIGVycm9yczogW10gfTtcblxuICAgIGNhc2UgJ3NpdGVzJzpcbiAgICAgIGlmIChzdGF0ZS5zaXRlUGF0dGVybnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBlcnJvcnM6IFsnQWRkIGF0IGxlYXN0IG9uZSBzaXRlIHBhdHRlcm4uJ10gfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjdXJyZW50U3RlcDogJ3RpbWUnLCBlcnJvcnM6IFtdIH07XG5cbiAgICBjYXNlICd0aW1lJzpcbiAgICAgIGlmIChzdGF0ZS5kdXJhdGlvbk1pbnV0ZXMgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGVycm9yczogWydTZWxlY3QgYSB0aW1lIGR1cmF0aW9uLiddIH07XG4gICAgICB9XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgY3VycmVudFN0ZXA6ICdjb25maXJtJywgZXJyb3JzOiBbXSB9O1xuXG4gICAgY2FzZSAnY29uZmlybSc6XG4gICAgICByZXR1cm4gc3RhdGU7XG5cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHN0YXRlO1xuICB9XG59XG5cbi8qKlxuICogR28gYmFjayB0byB0aGUgcHJldmlvdXMgd2l6YXJkIHN0ZXAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmV2aW91c1N0ZXAoc3RhdGU6IFdpemFyZFN0YXRlKTogV2l6YXJkU3RhdGUge1xuICBjb25zdCBzdGVwT3JkZXI6IFdpemFyZFN0ZXBbXSA9IFsncHJlc2V0JywgJ3NpdGVzJywgJ3RpbWUnLCAnY29uZmlybSddO1xuICBjb25zdCBjdXJyZW50SW5kZXggPSBzdGVwT3JkZXIuaW5kZXhPZihzdGF0ZS5jdXJyZW50U3RlcCk7XG5cbiAgaWYgKGN1cnJlbnRJbmRleCA8PSAwKSByZXR1cm4gc3RhdGU7XG5cbiAgLy8gRm9yIHJlYWRPbmx5L2Z1bGxBY2Nlc3MsIGdvIGJhY2sgZnJvbSBjb25maXJtIHRvIHByZXNldFxuICBpZiAoc3RhdGUuY3VycmVudFN0ZXAgPT09ICdjb25maXJtJyAmJiBzdGF0ZS5zZWxlY3RlZFByZXNldCAhPT0gJ2xpbWl0ZWQnKSB7XG4gICAgcmV0dXJuIHsgLi4uc3RhdGUsIGN1cnJlbnRTdGVwOiAncHJlc2V0JywgZXJyb3JzOiBbXSB9O1xuICB9XG5cbiAgcmV0dXJuIHsgLi4uc3RhdGUsIGN1cnJlbnRTdGVwOiBzdGVwT3JkZXJbY3VycmVudEluZGV4IC0gMV0sIGVycm9yczogW10gfTtcbn1cblxuLyoqXG4gKiBGaW5hbGl6ZSB0aGUgd2l6YXJkIGFuZCBjcmVhdGUgYSBkZWxlZ2F0aW9uIHJ1bGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaW5hbGl6ZVdpemFyZChzdGF0ZTogV2l6YXJkU3RhdGUpOiBEZWxlZ2F0aW9uUnVsZSB8IG51bGwge1xuICBpZiAoIXN0YXRlLnNlbGVjdGVkUHJlc2V0KSByZXR1cm4gbnVsbDtcblxuICBpZiAoc3RhdGUuc2VsZWN0ZWRQcmVzZXQgPT09ICdsaW1pdGVkJykge1xuICAgIGlmIChzdGF0ZS5zaXRlUGF0dGVybnMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgICBpZiAoc3RhdGUuZHVyYXRpb25NaW51dGVzID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiBjcmVhdGVSdWxlRnJvbVByZXNldChzdGF0ZS5zZWxlY3RlZFByZXNldCwge1xuICAgIHNpdGVQYXR0ZXJuczogc3RhdGUuc2l0ZVBhdHRlcm5zLFxuICAgIGR1cmF0aW9uTWludXRlczogc3RhdGUuZHVyYXRpb25NaW51dGVzID8/IHVuZGVmaW5lZCxcbiAgICBsYWJlbDogc3RhdGUubGFiZWwgfHwgdW5kZWZpbmVkLFxuICB9KTtcbn1cblxuY29uc3QgUFJFU0VUX0RFU0NSSVBUSU9OUzogUmVjb3JkPERlbGVnYXRpb25QcmVzZXQsIHsgdGl0bGU6IHN0cmluZzsgZGVzY3JpcHRpb246IHN0cmluZyB9PiA9IHtcbiAgcmVhZE9ubHk6IHtcbiAgICB0aXRsZTogJ1JlYWQtT25seScsXG4gICAgZGVzY3JpcHRpb246ICdBZ2VudCBjYW4gbmF2aWdhdGUgYW5kIHJlYWQgcGFnZSBjb250ZW50LiBDYW5ub3QgY2xpY2ssIHR5cGUsIG9yIHN1Ym1pdCBmb3Jtcy4nLFxuICB9LFxuICBsaW1pdGVkOiB7XG4gICAgdGl0bGU6ICdMaW1pdGVkIEFjY2VzcycsXG4gICAgZGVzY3JpcHRpb246ICdBZ2VudCBjYW4gaW50ZXJhY3Qgd2l0aCBzcGVjaWZpYyBzaXRlcyB5b3UgY2hvb3NlLCB3aXRoIGEgdGltZSBsaW1pdC4nLFxuICB9LFxuICBmdWxsQWNjZXNzOiB7XG4gICAgdGl0bGU6ICdGdWxsIEFjY2VzcycsXG4gICAgZGVzY3JpcHRpb246ICdBZ2VudCBjYW4gcGVyZm9ybSBhbnkgYWN0aW9uLiBBbGwgYWN0aXZpdHkgaXMgbG9nZ2VkIHdpdGggYm91bmRhcnkgYWxlcnRzLicsXG4gIH0sXG59O1xuXG4vKipcbiAqIFJlbmRlciB0aGUgd2l6YXJkIFVJIGludG8gYSBjb250YWluZXIgZWxlbWVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbmRlcldpemFyZChcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkXG4pOiB2b2lkIHtcbiAgY29udGFpbmVyLmlubmVySFRNTCA9ICcnO1xuXG4gIC8vIEVycm9yIGRpc3BsYXlcbiAgaWYgKHN0YXRlLmVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgZXJyb3JEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBlcnJvckRpdi5jbGFzc05hbWUgPSAnd2l6YXJkLWVycm9ycyc7XG4gICAgZXJyb3JEaXYuc3R5bGUuY3NzVGV4dCA9ICdjb2xvcjogdmFyKC0tZGFuZ2VyKTsgZm9udC1zaXplOiAxMnB4OyBtYXJnaW4tYm90dG9tOiA4cHg7JztcbiAgICBlcnJvckRpdi50ZXh0Q29udGVudCA9IHN0YXRlLmVycm9ycy5qb2luKCcgJyk7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGVycm9yRGl2KTtcbiAgfVxuXG4gIHN3aXRjaCAoc3RhdGUuY3VycmVudFN0ZXApIHtcbiAgICBjYXNlICdwcmVzZXQnOlxuICAgICAgcmVuZGVyUHJlc2V0U3RlcChjb250YWluZXIsIHN0YXRlLCBvblN0YXRlQ2hhbmdlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3NpdGVzJzpcbiAgICAgIHJlbmRlclNpdGVzU3RlcChjb250YWluZXIsIHN0YXRlLCBvblN0YXRlQ2hhbmdlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3RpbWUnOlxuICAgICAgcmVuZGVyVGltZVN0ZXAoY29udGFpbmVyLCBzdGF0ZSwgb25TdGF0ZUNoYW5nZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjb25maXJtJzpcbiAgICAgIHJlbmRlckNvbmZpcm1TdGVwKGNvbnRhaW5lciwgc3RhdGUsIG9uU3RhdGVDaGFuZ2UpO1xuICAgICAgYnJlYWs7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyUHJlc2V0U3RlcChcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkXG4pOiB2b2lkIHtcbiAgY29uc3QgcHJlc2V0czogRGVsZWdhdGlvblByZXNldFtdID0gWydyZWFkT25seScsICdsaW1pdGVkJywgJ2Z1bGxBY2Nlc3MnXTtcbiAgZm9yIChjb25zdCBwcmVzZXQgb2YgcHJlc2V0cykge1xuICAgIGNvbnN0IGluZm8gPSBQUkVTRVRfREVTQ1JJUFRJT05TW3ByZXNldF07XG4gICAgY29uc3QgY2FyZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGNhcmQudHlwZSA9ICdidXR0b24nO1xuICAgIGNhcmQuY2xhc3NOYW1lID0gYHByZXNldC1jYXJkJHtzdGF0ZS5zZWxlY3RlZFByZXNldCA9PT0gcHJlc2V0ID8gJyBzZWxlY3RlZCcgOiAnJ31gO1xuXG4gICAgY29uc3QgdGl0bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHJvbmcnKTtcbiAgICB0aXRsZS50ZXh0Q29udGVudCA9IGluZm8udGl0bGU7XG5cbiAgICBjb25zdCBkZXNjID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xuICAgIGRlc2Muc3R5bGUuY3NzVGV4dCA9ICdtYXJnaW46IDRweCAwIDA7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6IHZhcigtLXRleHQtc2Vjb25kYXJ5KTsnO1xuICAgIGRlc2MudGV4dENvbnRlbnQgPSBpbmZvLmRlc2NyaXB0aW9uO1xuXG4gICAgY2FyZC5hcHBlbmRDaGlsZCh0aXRsZSk7XG4gICAgY2FyZC5hcHBlbmRDaGlsZChkZXNjKTtcbiAgICBjYXJkLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgb25TdGF0ZUNoYW5nZShzZWxlY3RQcmVzZXQoc3RhdGUsIHByZXNldCkpO1xuICAgIH0pO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChjYXJkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJTaXRlc1N0ZXAoXG4gIGNvbnRhaW5lcjogSFRNTEVsZW1lbnQsXG4gIHN0YXRlOiBXaXphcmRTdGF0ZSxcbiAgb25TdGF0ZUNoYW5nZTogKG5ld1N0YXRlOiBXaXphcmRTdGF0ZSkgPT4gdm9pZFxuKTogdm9pZCB7XG4gIGNvbnN0IGhlYWRpbmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XG4gIGhlYWRpbmcuc3R5bGUuY3NzVGV4dCA9ICdmb250LXNpemU6IDEycHg7IGNvbG9yOiB2YXIoLS10ZXh0LXNlY29uZGFyeSk7IG1hcmdpbi1ib3R0b206IDhweDsnO1xuICBoZWFkaW5nLnRleHRDb250ZW50ID0gJ0FkZCBzaXRlcyB0aGUgYWdlbnQgY2FuIGFjY2VzcyAoZ2xvYiBwYXR0ZXJucyk6JztcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGhlYWRpbmcpO1xuXG4gIC8vIElucHV0IHJvd1xuICBjb25zdCBpbnB1dFJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBpbnB1dFJvdy5zdHlsZS5jc3NUZXh0ID0gJ2Rpc3BsYXk6IGZsZXg7IGdhcDogNnB4OyBtYXJnaW4tYm90dG9tOiA4cHg7JztcblxuICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jyk7XG4gIGlucHV0LnR5cGUgPSAndGV4dCc7XG4gIGlucHV0LnBsYWNlaG9sZGVyID0gJ2UuZy4sICouZXhhbXBsZS5jb20nO1xuICBpbnB1dC5jbGFzc05hbWUgPSAnZm9ybS1pbnB1dCc7XG4gIGlucHV0LnN0eWxlLmNzc1RleHQgPSAnZmxleDogMTsnO1xuXG4gIGNvbnN0IGFkZEJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICBhZGRCdG4uY2xhc3NOYW1lID0gJ2J0biBidG4tcHJpbWFyeSc7XG4gIGFkZEJ0bi50ZXh0Q29udGVudCA9ICdBZGQnO1xuICBhZGRCdG4uc3R5bGUuY3NzVGV4dCA9ICdwYWRkaW5nOiA0cHggMTJweDsgZm9udC1zaXplOiAxMnB4Oyc7XG4gIGFkZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IGlucHV0LnZhbHVlLnRyaW0oKTtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIG9uU3RhdGVDaGFuZ2UoYWRkU2l0ZVBhdHRlcm4oc3RhdGUsIHsgcGF0dGVybjogdmFsdWUsIGFjdGlvbjogJ2FsbG93JyB9KSk7XG4gICAgICBpbnB1dC52YWx1ZSA9ICcnO1xuICAgIH1cbiAgfSk7XG5cbiAgaW5wdXRSb3cuYXBwZW5kQ2hpbGQoaW5wdXQpO1xuICBpbnB1dFJvdy5hcHBlbmRDaGlsZChhZGRCdG4pO1xuICBjb250YWluZXIuYXBwZW5kQ2hpbGQoaW5wdXRSb3cpO1xuXG4gIC8vIFBhdHRlcm4gbGlzdFxuICBmb3IgKGxldCBpID0gMDsgaSA8IHN0YXRlLnNpdGVQYXR0ZXJucy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHAgPSBzdGF0ZS5zaXRlUGF0dGVybnNbaV07XG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgcm93LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBhbGlnbi1pdGVtczogY2VudGVyOyBwYWRkaW5nOiA0cHggMDsgZm9udC1zaXplOiAxMnB4Oyc7XG4gICAgY29uc3QgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgbGFiZWwuc3R5bGUuY3NzVGV4dCA9ICdjb2xvcjogdmFyKC0tdGV4dC1wcmltYXJ5KTsnO1xuICAgIGxhYmVsLnRleHRDb250ZW50ID0gYCR7cC5wYXR0ZXJufSAoJHtwLmFjdGlvbn0pYDtcbiAgICByb3cuYXBwZW5kQ2hpbGQobGFiZWwpO1xuICAgIGNvbnN0IHJlbW92ZUJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIHJlbW92ZUJ0bi5jbGFzc05hbWUgPSAnYnRuIGJ0bi1zZWNvbmRhcnknO1xuICAgIHJlbW92ZUJ0bi50ZXh0Q29udGVudCA9ICdSZW1vdmUnO1xuICAgIHJlbW92ZUJ0bi5zdHlsZS5jc3NUZXh0ID0gJ3BhZGRpbmc6IDJweCA4cHg7IGZvbnQtc2l6ZTogMTFweDsnO1xuICAgIHJlbW92ZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IG9uU3RhdGVDaGFuZ2UocmVtb3ZlU2l0ZVBhdHRlcm4oc3RhdGUsIGkpKSk7XG4gICAgcm93LmFwcGVuZENoaWxkKHJlbW92ZUJ0bik7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKHJvdyk7XG4gIH1cblxuICAvLyBOYXYgYnV0dG9uc1xuICByZW5kZXJOYXZCdXR0b25zKGNvbnRhaW5lciwgc3RhdGUsIG9uU3RhdGVDaGFuZ2UpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJUaW1lU3RlcChcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkXG4pOiB2b2lkIHtcbiAgY29uc3QgaGVhZGluZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3AnKTtcbiAgaGVhZGluZy5zdHlsZS5jc3NUZXh0ID0gJ2ZvbnQtc2l6ZTogMTJweDsgY29sb3I6IHZhcigtLXRleHQtc2Vjb25kYXJ5KTsgbWFyZ2luLWJvdHRvbTogOHB4Oyc7XG4gIGhlYWRpbmcudGV4dENvbnRlbnQgPSAnSG93IGxvbmcgc2hvdWxkIHRoZSBkZWxlZ2F0aW9uIGxhc3Q/JztcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGhlYWRpbmcpO1xuXG4gIGZvciAoY29uc3Qgb3B0aW9uIG9mIFRJTUVfRFVSQVRJT05fT1BUSU9OUykge1xuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ0bi5jbGFzc05hbWUgPSBgYnRuICR7c3RhdGUuZHVyYXRpb25NaW51dGVzID09PSBvcHRpb24ubWludXRlcyA/ICdidG4tcHJpbWFyeScgOiAnYnRuLXNlY29uZGFyeSd9YDtcbiAgICBidG4udGV4dENvbnRlbnQgPSBvcHRpb24ubGFiZWw7XG4gICAgYnRuLnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTogYmxvY2s7IHdpZHRoOiAxMDAlOyBtYXJnaW4tYm90dG9tOiA2cHg7JztcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBjb25zdCB1cGRhdGVkID0gc2V0RHVyYXRpb24oc3RhdGUsIG9wdGlvbi5taW51dGVzKTtcbiAgICAgIG9uU3RhdGVDaGFuZ2UobmV4dFN0ZXAodXBkYXRlZCkpO1xuICAgIH0pO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChidG4pO1xuICB9XG5cbiAgcmVuZGVyTmF2QnV0dG9ucyhjb250YWluZXIsIHN0YXRlLCBvblN0YXRlQ2hhbmdlLCB0cnVlKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQ29uZmlybVN0ZXAoXG4gIGNvbnRhaW5lcjogSFRNTEVsZW1lbnQsXG4gIHN0YXRlOiBXaXphcmRTdGF0ZSxcbiAgb25TdGF0ZUNoYW5nZTogKG5ld1N0YXRlOiBXaXphcmRTdGF0ZSkgPT4gdm9pZFxuKTogdm9pZCB7XG4gIGNvbnN0IHByZXNldCA9IHN0YXRlLnNlbGVjdGVkUHJlc2V0O1xuICBpZiAoIXByZXNldCkgcmV0dXJuO1xuXG4gIGNvbnN0IGluZm8gPSBQUkVTRVRfREVTQ1JJUFRJT05TW3ByZXNldF07XG4gIGNvbnN0IHN1bW1hcnkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgc3VtbWFyeS5zdHlsZS5jc3NUZXh0ID0gJ2ZvbnQtc2l6ZTogMTJweDsgY29sb3I6IHZhcigtLXRleHQtc2Vjb25kYXJ5KTsnO1xuXG4gIGxldCBodG1sID0gYDxwPjxzdHJvbmc+UHJlc2V0Ojwvc3Ryb25nPiAke2luZm8udGl0bGV9PC9wPmA7XG4gIGlmIChzdGF0ZS5zaXRlUGF0dGVybnMubGVuZ3RoID4gMCkge1xuICAgIGh0bWwgKz0gYDxwPjxzdHJvbmc+U2l0ZXM6PC9zdHJvbmc+ICR7c3RhdGUuc2l0ZVBhdHRlcm5zLm1hcCgocCkgPT4gcC5wYXR0ZXJuKS5qb2luKCcsICcpfTwvcD5gO1xuICB9XG4gIGlmIChzdGF0ZS5kdXJhdGlvbk1pbnV0ZXMpIHtcbiAgICBjb25zdCBvcHQgPSBUSU1FX0RVUkFUSU9OX09QVElPTlMuZmluZCgobykgPT4gby5taW51dGVzID09PSBzdGF0ZS5kdXJhdGlvbk1pbnV0ZXMpO1xuICAgIGh0bWwgKz0gYDxwPjxzdHJvbmc+RHVyYXRpb246PC9zdHJvbmc+ICR7b3B0Py5sYWJlbCA/PyBzdGF0ZS5kdXJhdGlvbk1pbnV0ZXMgKyAnIG1pbnV0ZXMnfTwvcD5gO1xuICB9XG4gIHN1bW1hcnkuaW5uZXJIVE1MID0gaHRtbDtcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKHN1bW1hcnkpO1xuXG4gIC8vIExhYmVsIGlucHV0XG4gIGNvbnN0IGxhYmVsSW5wdXQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbnB1dCcpO1xuICBsYWJlbElucHV0LnR5cGUgPSAndGV4dCc7XG4gIGxhYmVsSW5wdXQucGxhY2Vob2xkZXIgPSAnTGFiZWwgKG9wdGlvbmFsKSc7XG4gIGxhYmVsSW5wdXQuY2xhc3NOYW1lID0gJ2Zvcm0taW5wdXQnO1xuICBsYWJlbElucHV0LnZhbHVlID0gc3RhdGUubGFiZWw7XG4gIGxhYmVsSW5wdXQuc3R5bGUuY3NzVGV4dCA9ICd3aWR0aDogMTAwJTsgbWFyZ2luOiA4cHggMDsnO1xuICBsYWJlbElucHV0LmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xuICAgIHN0YXRlLmxhYmVsID0gbGFiZWxJbnB1dC52YWx1ZTtcbiAgfSk7XG4gIGNvbnRhaW5lci5hcHBlbmRDaGlsZChsYWJlbElucHV0KTtcblxuICAvLyBBY3RpdmF0ZSBidXR0b25cbiAgY29uc3QgYWN0aXZhdGVCdG4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgYWN0aXZhdGVCdG4uY2xhc3NOYW1lID0gJ2J0biBidG4tcHJpbWFyeSc7XG4gIGFjdGl2YXRlQnRuLnRleHRDb250ZW50ID0gJ0FjdGl2YXRlIERlbGVnYXRpb24nO1xuICBhY3RpdmF0ZUJ0bi5zdHlsZS5jc3NUZXh0ID0gJ3dpZHRoOiAxMDAlOyBtYXJnaW4tdG9wOiA4cHg7JztcbiAgYWN0aXZhdGVCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgY29uc3QgcnVsZSA9IGZpbmFsaXplV2l6YXJkKHN0YXRlKTtcbiAgICBpZiAocnVsZSkge1xuICAgICAgLy8gRGlzcGF0Y2ggY3VzdG9tIGV2ZW50IGZvciBwb3B1cCB0byBwaWNrIHVwXG4gICAgICBjb250YWluZXIuZGlzcGF0Y2hFdmVudChcbiAgICAgICAgbmV3IEN1c3RvbUV2ZW50KCdkZWxlZ2F0aW9uLWFjdGl2YXRlZCcsIHsgZGV0YWlsOiBydWxlLCBidWJibGVzOiB0cnVlIH0pXG4gICAgICApO1xuICAgIH1cbiAgfSk7XG4gIGNvbnRhaW5lci5hcHBlbmRDaGlsZChhY3RpdmF0ZUJ0bik7XG5cbiAgcmVuZGVyTmF2QnV0dG9ucyhjb250YWluZXIsIHN0YXRlLCBvblN0YXRlQ2hhbmdlLCB0cnVlKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyTmF2QnV0dG9ucyhcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkLFxuICBzaG93QmFjayA9IGZhbHNlXG4pOiB2b2lkIHtcbiAgY29uc3QgbmF2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIG5hdi5zdHlsZS5jc3NUZXh0ID0gJ2Rpc3BsYXk6IGZsZXg7IGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjsgbWFyZ2luLXRvcDogOHB4Oyc7XG5cbiAgaWYgKHNob3dCYWNrKSB7XG4gICAgY29uc3QgYmFja0J0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJhY2tCdG4uY2xhc3NOYW1lID0gJ2J0biBidG4tc2Vjb25kYXJ5JztcbiAgICBiYWNrQnRuLnRleHRDb250ZW50ID0gJ0JhY2snO1xuICAgIGJhY2tCdG4uc3R5bGUuY3NzVGV4dCA9ICdmb250LXNpemU6IDExcHg7JztcbiAgICBiYWNrQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4gb25TdGF0ZUNoYW5nZShwcmV2aW91c1N0ZXAoc3RhdGUpKSk7XG4gICAgbmF2LmFwcGVuZENoaWxkKGJhY2tCdG4pO1xuICB9XG5cbiAgaWYgKHN0YXRlLmN1cnJlbnRTdGVwID09PSAnc2l0ZXMnKSB7XG4gICAgY29uc3QgbmV4dEJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIG5leHRCdG4uY2xhc3NOYW1lID0gJ2J0biBidG4tcHJpbWFyeSc7XG4gICAgbmV4dEJ0bi50ZXh0Q29udGVudCA9ICdOZXh0JztcbiAgICBuZXh0QnRuLnN0eWxlLmNzc1RleHQgPSAnZm9udC1zaXplOiAxMXB4OyBtYXJnaW4tbGVmdDogYXV0bzsnO1xuICAgIG5leHRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiBvblN0YXRlQ2hhbmdlKG5leHRTdGVwKHN0YXRlKSkpO1xuICAgIG5hdi5hcHBlbmRDaGlsZChuZXh0QnRuKTtcbiAgfVxuXG4gIGlmIChuYXYuY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChuYXYpO1xuICB9XG59XG4iLCIvKipcbiAqIFBvcHVwIHNjcmlwdCBmb3IgQUkgQnJvd3NlciBHdWFyZC5cbiAqXG4gKiBDb250cm9scyB0aGUgZXh0ZW5zaW9uIHBvcHVwIFVJLlxuICovXG5cbmltcG9ydCB0eXBlIHsgTWVzc2FnZVBheWxvYWQsIE1lc3NhZ2VUeXBlIH0gZnJvbSAnLi4vdHlwZXMvZXZlbnRzJztcbmltcG9ydCB0eXBlIHsgQWdlbnRJZGVudGl0eSB9IGZyb20gJy4uL3R5cGVzL2FnZW50JztcbmltcG9ydCB0eXBlIHsgRGVsZWdhdGlvblJ1bGUgfSBmcm9tICcuLi90eXBlcy9kZWxlZ2F0aW9uJztcbmltcG9ydCB0eXBlIHsgQWdlbnRTZXNzaW9uLCBMaWZldGltZVN0YXRzIH0gZnJvbSAnLi4vc2Vzc2lvbi90eXBlcyc7XG5pbXBvcnQgdHlwZSB7IEJvdW5kYXJ5QWxlcnQgfSBmcm9tICcuLi9hbGVydHMvYm91bmRhcnknO1xuaW1wb3J0IHsgY3JlYXRlSW5pdGlhbFdpemFyZFN0YXRlLCByZW5kZXJXaXphcmQgfSBmcm9tICcuLi9kZWxlZ2F0aW9uL3dpemFyZCc7XG5pbXBvcnQgdHlwZSB7IFdpemFyZFN0YXRlIH0gZnJvbSAnLi4vZGVsZWdhdGlvbi93aXphcmQnO1xuaW1wb3J0IHsgY3JlYXRlUnVsZUZyb21QcmVzZXQgfSBmcm9tICcuLi9kZWxlZ2F0aW9uL3J1bGVzJztcblxuaW50ZXJmYWNlIFBvcHVwU3RhdGUge1xuICBkZXRlY3RlZEFnZW50czogQWdlbnRJZGVudGl0eVtdO1xuICBhY3RpdmVEZWxlZ2F0aW9uOiBEZWxlZ2F0aW9uUnVsZSB8IG51bGw7XG4gIGtpbGxTd2l0Y2hBY3RpdmU6IGJvb2xlYW47XG4gIHJlY2VudFZpb2xhdGlvbnM6IEJvdW5kYXJ5QWxlcnRbXTtcbiAgc2Vzc2lvbnM6IEFnZW50U2Vzc2lvbltdO1xuICB3aXphcmRTdGF0ZTogV2l6YXJkU3RhdGUgfCBudWxsO1xuICBsb2FkaW5nOiBib29sZWFuO1xuICBsaWZldGltZVN0YXRzOiBMaWZldGltZVN0YXRzIHwgbnVsbDtcbn1cblxubGV0IHBvcHVwU3RhdGU6IFBvcHVwU3RhdGUgPSB7XG4gIGRldGVjdGVkQWdlbnRzOiBbXSxcbiAgYWN0aXZlRGVsZWdhdGlvbjogbnVsbCxcbiAga2lsbFN3aXRjaEFjdGl2ZTogZmFsc2UsXG4gIHJlY2VudFZpb2xhdGlvbnM6IFtdLFxuICBzZXNzaW9uczogW10sXG4gIHdpemFyZFN0YXRlOiBudWxsLFxuICBsb2FkaW5nOiB0cnVlLFxuICBsaWZldGltZVN0YXRzOiBudWxsLFxufTtcblxuLy8gSG9sZHMgdGhlIGludGVydmFsIElEIGZvciB0aGUgZGVsZWdhdGlvbiBjb3VudGRvd24gdGltZXIuXG4vLyBDbGVhcmVkIHdoZW5ldmVyIHRoZSBwb3B1cCByZS1yZW5kZXJzIHRvIGF2b2lkIGR1cGxpY2F0ZSB0aW1lcnMuXG5sZXQgY291bnRkb3duSW50ZXJ2YWxJZDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIGluaXRpYWxpemUoKTogdm9pZCB7XG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCAoKSA9PiB7XG4gICAgc2V0dXBFdmVudExpc3RlbmVycygpO1xuICAgIHF1ZXJ5QmFja2dyb3VuZFN0YXR1cygpO1xuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcXVlcnlCYWNrZ3JvdW5kU3RhdHVzKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZCgnU1RBVFVTX1FVRVJZJywge30pO1xuICAgIGlmIChyZXNwb25zZSAmJiB0eXBlb2YgcmVzcG9uc2UgPT09ICdvYmplY3QnKSB7XG4gICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UgYXMge1xuICAgICAgICBkZXRlY3RlZEFnZW50cz86IEFnZW50SWRlbnRpdHlbXTtcbiAgICAgICAgYWN0aXZlRGVsZWdhdGlvbj86IERlbGVnYXRpb25SdWxlIHwgbnVsbDtcbiAgICAgICAga2lsbFN3aXRjaEFjdGl2ZT86IGJvb2xlYW47XG4gICAgICAgIHJlY2VudFZpb2xhdGlvbnM/OiBCb3VuZGFyeUFsZXJ0W107XG4gICAgICB9O1xuICAgICAgcG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cyA9IGRhdGEuZGV0ZWN0ZWRBZ2VudHMgPz8gW107XG4gICAgICBwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb24gPSBkYXRhLmFjdGl2ZURlbGVnYXRpb24gPz8gbnVsbDtcbiAgICAgIHBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZSA9IGRhdGEua2lsbFN3aXRjaEFjdGl2ZSA/PyBmYWxzZTtcbiAgICAgIHBvcHVwU3RhdGUucmVjZW50VmlvbGF0aW9ucyA9IGRhdGEucmVjZW50VmlvbGF0aW9ucyA/PyBbXTtcbiAgICAgIHBvcHVwU3RhdGUubGlmZXRpbWVTdGF0cyA9IChkYXRhIGFzIHsgbGlmZXRpbWVTdGF0cz86IExpZmV0aW1lU3RhdHMgfSkubGlmZXRpbWVTdGF0cyA/PyBudWxsO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gQmFja2dyb3VuZCBtYXkgbm90IGJlIGF2YWlsYWJsZVxuICB9XG5cbiAgLy8gQWxzbyBmZXRjaCBzZXNzaW9uc1xuICB0cnkge1xuICAgIGNvbnN0IHNlc3Npb25SZXNwb25zZSA9IGF3YWl0IHNlbmRUb0JhY2tncm91bmQoJ1NFU1NJT05fUVVFUlknLCB7fSk7XG4gICAgaWYgKHNlc3Npb25SZXNwb25zZSAmJiB0eXBlb2Ygc2Vzc2lvblJlc3BvbnNlID09PSAnb2JqZWN0Jykge1xuICAgICAgY29uc3QgZGF0YSA9IHNlc3Npb25SZXNwb25zZSBhcyB7IHNlc3Npb25zPzogQWdlbnRTZXNzaW9uW10gfTtcbiAgICAgIHBvcHVwU3RhdGUuc2Vzc2lvbnMgPSBkYXRhLnNlc3Npb25zID8/IFtdO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlXG4gIH1cblxuICBwb3B1cFN0YXRlLmxvYWRpbmcgPSBmYWxzZTtcbiAgcmVuZGVyQWxsKCk7XG59XG5cbmZ1bmN0aW9uIHNldHVwRXZlbnRMaXN0ZW5lcnMoKTogdm9pZCB7XG4gIGNvbnN0IGtpbGxTd2l0Y2hCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgna2lsbC1zd2l0Y2gtYnRuJyk7XG4gIGlmIChraWxsU3dpdGNoQnRuKSB7XG4gICAga2lsbFN3aXRjaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG9uS2lsbFN3aXRjaENsaWNrKTtcbiAgfVxuXG4gIGNvbnN0IHdpemFyZEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZWxlZ2F0aW9uLXdpemFyZC1idG4nKTtcbiAgaWYgKHdpemFyZEJ0bikge1xuICAgIHdpemFyZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG9uRGVsZWdhdGlvbldpemFyZENsaWNrKTtcbiAgfVxuXG4gIC8vIExpc3RlbiBmb3IgbGl2ZSB1cGRhdGVzIGZyb20gYmFja2dyb3VuZCAoZ3VhcmQgcmVxdWlyZWQg4oCUIGNocm9tZSBpcyB1bmRlZmluZWQgb3V0c2lkZSBleHRlbnNpb24pXG4gIGlmICh0eXBlb2YgY2hyb21lICE9PSAndW5kZWZpbmVkJyAmJiBjaHJvbWUucnVudGltZT8ub25NZXNzYWdlKSB7XG4gICAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtZXNzYWdlOiBNZXNzYWdlUGF5bG9hZCkgPT4ge1xuICAgIGlmICghbWVzc2FnZSB8fCAhbWVzc2FnZS50eXBlKSByZXR1cm47XG5cbiAgICAgIHN3aXRjaCAobWVzc2FnZS50eXBlKSB7XG4gICAgICAgIGNhc2UgJ0RFVEVDVElPTl9SRVNVTFQnOlxuICAgICAgICAgIHF1ZXJ5QmFja2dyb3VuZFN0YXR1cygpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdLSUxMX1NXSVRDSF9SRVNVTFQnOlxuICAgICAgICAgIHBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgcmVuZGVyQWxsKCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ0RFTEVHQVRJT05fVVBEQVRFJzpcbiAgICAgICAgICBxdWVyeUJhY2tncm91bmRTdGF0dXMoKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9KTtcbiAgfSAvLyBlbmQgY2hyb21lLnJ1bnRpbWUgZ3VhcmRcblxuICAvLyBMaXN0ZW4gZm9yIGRlbGVnYXRpb24gYWN0aXZhdGlvbiBmcm9tIHdpemFyZC5cbiAgLy8gT3B0aW1pc3RpYyB1cGRhdGU6IGFwcGx5IHRvIFVJIGltbWVkaWF0ZWx5IHNvIHRoZSBwb3B1cCByZXNwb25kcyBpbnN0YW50bHlcbiAgLy8gZXZlbiBpZiB0aGUgYmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBpcyBzbGVlcGluZyAoY29tbW9uIGluIE1WMykuXG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2RlbGVnYXRpb24tYWN0aXZhdGVkJywgKChlOiBDdXN0b21FdmVudDxEZWxlZ2F0aW9uUnVsZT4pID0+IHtcbiAgICBjb25zdCBydWxlID0gZS5kZXRhaWw7XG5cbiAgICAvLyBVcGRhdGUgVUkgZmlyc3Qg4oCUIGRvIG5vdCB3YWl0IGZvciB0aGUgYmFja2dyb3VuZCByZXNwb25zZS5cbiAgICBwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb24gPSBydWxlO1xuICAgIHBvcHVwU3RhdGUud2l6YXJkU3RhdGUgPSBudWxsO1xuICAgIGNvbnN0IHdpemFyZENvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd3aXphcmQtY29udGFpbmVyJyk7XG4gICAgaWYgKHdpemFyZENvbnRhaW5lcikge1xuICAgICAgd2l6YXJkQ29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgICAgd2l6YXJkQ29udGFpbmVyLmlubmVySFRNTCA9ICcnO1xuICAgIH1cbiAgICByZW5kZXJBbGwoKTtcblxuICAgIC8vIFN5bmMgdG8gYmFja2dyb3VuZCBhc3luY2hyb25vdXNseS5cbiAgICBzZW5kVG9CYWNrZ3JvdW5kKCdERUxFR0FUSU9OX1VQREFURScsIHJ1bGUpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gc3luYyBkZWxlZ2F0aW9uIHRvIGJhY2tncm91bmQ6JywgZXJyKTtcbiAgICB9KTtcbiAgfSkgYXMgRXZlbnRMaXN0ZW5lcik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uS2lsbFN3aXRjaENsaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBidG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgna2lsbC1zd2l0Y2gtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQgfCBudWxsO1xuICBpZiAoYnRuKSBidG4uZGlzYWJsZWQgPSB0cnVlO1xuXG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZFRvQmFja2dyb3VuZCgnS0lMTF9TV0lUQ0hfQUNUSVZBVEUnLCB7IHRyaWdnZXI6ICdidXR0b24nIH0pO1xuICAgIHBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZSA9IHRydWU7XG4gICAgcG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cyA9IFtdO1xuICAgIHBvcHVwU3RhdGUuYWN0aXZlRGVsZWdhdGlvbiA9IG51bGw7XG4gICAgcmVuZGVyQWxsKCk7XG4gIH0gY2F0Y2gge1xuICAgIGlmIChidG4pIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9uRGVsZWdhdGlvbldpemFyZENsaWNrKCk6IHZvaWQge1xuICBjb25zdCB3aXphcmRDb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnd2l6YXJkLWNvbnRhaW5lcicpO1xuICBpZiAoIXdpemFyZENvbnRhaW5lcikgcmV0dXJuO1xuXG4gIGlmICh3aXphcmRDb250YWluZXIuY2xhc3NMaXN0LmNvbnRhaW5zKCdoaWRkZW4nKSkge1xuICAgIHdpemFyZENvbnRhaW5lci5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKTtcbiAgICBwb3B1cFN0YXRlLndpemFyZFN0YXRlID0gY3JlYXRlSW5pdGlhbFdpemFyZFN0YXRlKCk7XG4gICAgcmVuZGVyV2l6YXJkVUkoKTtcbiAgfSBlbHNlIHtcbiAgICB3aXphcmRDb250YWluZXIuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgd2l6YXJkQ29udGFpbmVyLmlubmVySFRNTCA9ICcnO1xuICAgIHBvcHVwU3RhdGUud2l6YXJkU3RhdGUgPSBudWxsO1xuICB9XG4gIC8vIFJlLXJlbmRlciBkZWxlZ2F0aW9uIHBhbmVsIHNvIENvbmZpZ3VyZS9DYW5jZWwgbGFiZWwgdXBkYXRlc1xuICByZW5kZXJEZWxlZ2F0aW9uUGFuZWwoKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyV2l6YXJkVUkoKTogdm9pZCB7XG4gIGNvbnN0IHdpemFyZENvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd3aXphcmQtY29udGFpbmVyJyk7XG4gIGlmICghd2l6YXJkQ29udGFpbmVyIHx8ICFwb3B1cFN0YXRlLndpemFyZFN0YXRlKSByZXR1cm47XG5cbiAgcmVuZGVyV2l6YXJkKHdpemFyZENvbnRhaW5lciwgcG9wdXBTdGF0ZS53aXphcmRTdGF0ZSwgKG5ld1N0YXRlKSA9PiB7XG4gICAgcG9wdXBTdGF0ZS53aXphcmRTdGF0ZSA9IG5ld1N0YXRlO1xuICAgIHJlbmRlcldpemFyZFVJKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBbGwoKTogdm9pZCB7XG4gIHJlbmRlckRldGVjdGlvblBhbmVsKCk7XG4gIHJlbmRlcktpbGxTd2l0Y2hQYW5lbCgpO1xuICByZW5kZXJEZWxlZ2F0aW9uUGFuZWwoKTtcbiAgcmVuZGVyVmlvbGF0aW9uc1BhbmVsKCk7XG4gIHJlbmRlclRpbWVsaW5lUGFuZWwoKTtcbiAgcmVuZGVyTWV0cmljc1BhbmVsKCk7XG4gIHJlbmRlclN0YXR1c0JhZGdlKCk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckRldGVjdGlvblBhbmVsKCk6IHZvaWQge1xuICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGV0ZWN0aW9uLWNvbnRlbnQnKTtcbiAgaWYgKCFjb250YWluZXIpIHJldHVybjtcblxuICBpZiAocG9wdXBTdGF0ZS5sb2FkaW5nKSB7XG4gICAgY29udGFpbmVyLmlubmVySFRNTCA9ICc8cCBjbGFzcz1cInBsYWNlaG9sZGVyLXRleHQtaW5saW5lXCI+TG9hZGluZy4uLjwvcD4nO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChwb3B1cFN0YXRlLmRldGVjdGVkQWdlbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnRhaW5lci5pbm5lckhUTUwgPSAnPHAgY2xhc3M9XCJwbGFjZWhvbGRlci10ZXh0LWlubGluZVwiPk5vIGFnZW50cyBkZXRlY3RlZDwvcD4nO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnRhaW5lci5pbm5lckhUTUwgPSAnJztcbiAgZm9yIChjb25zdCBhZ2VudCBvZiBwb3B1cFN0YXRlLmRldGVjdGVkQWdlbnRzKSB7XG4gICAgY29uc3QgY2FyZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGNhcmQuY2xhc3NOYW1lID0gJ2RldGVjdGlvbi1jYXJkJztcblxuICAgIGNvbnN0IGhlYWRlclJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGhlYWRlclJvdy5zdHlsZS5jc3NUZXh0ID0gJ2Rpc3BsYXk6IGZsZXg7IGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjsgYWxpZ24taXRlbXM6IGNlbnRlcjsgbWFyZ2luLWJvdHRvbTogMnB4Oyc7XG5cbiAgICBjb25zdCBuYW1lID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3Ryb25nJyk7XG4gICAgbmFtZS50ZXh0Q29udGVudCA9IGZvcm1hdEFnZW50VHlwZShhZ2VudC50eXBlKTtcblxuICAgIGNvbnN0IGJhZGdlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGJhZGdlLmNsYXNzTmFtZSA9ICdzZXZlcml0eS1iYWRnZSBzZXZlcml0eS1iYWRnZS1oaWdoJztcbiAgICBiYWRnZS50ZXh0Q29udGVudCA9IGBDb25maWRlbmNlOiAke2FnZW50LmNvbmZpZGVuY2V9YDtcblxuICAgIGhlYWRlclJvdy5hcHBlbmRDaGlsZChuYW1lKTtcbiAgICBoZWFkZXJSb3cuYXBwZW5kQ2hpbGQoYmFkZ2UpO1xuXG4gICAgY29uc3QgbWV0YVJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIG1ldGFSb3cuc3R5bGUuY3NzVGV4dCA9ICdmb250LXNpemU6IDEycHg7IGNvbG9yOiB2YXIoLS10ZXh0LXNlY29uZGFyeSk7IGZvbnQtd2VpZ2h0OiA1MDA7JztcblxuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHRzLnRleHRDb250ZW50ID0gZm9ybWF0VGltZXN0YW1wKGFnZW50LmRldGVjdGVkQXQpICsgJyAnO1xuICAgIG1ldGFSb3cuYXBwZW5kQ2hpbGQodHMpO1xuXG4gICAgZm9yIChjb25zdCBtIG9mIGFnZW50LmRldGVjdGlvbk1ldGhvZHMpIHtcbiAgICAgIGNvbnN0IHRhZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgIHRhZy5jbGFzc05hbWUgPSAnbWV0aG9kLXRhZyc7XG4gICAgICB0YWcudGV4dENvbnRlbnQgPSBtO1xuICAgICAgbWV0YVJvdy5hcHBlbmRDaGlsZCh0YWcpO1xuICAgIH1cblxuICAgIGNvbnN0IHVybFJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHVybFJvdy5zdHlsZS5jc3NUZXh0ID0gJ2ZvbnQtc2l6ZTogMTJweDsgY29sb3I6IHZhcigtLXRleHQtc2Vjb25kYXJ5KTsgZm9udC13ZWlnaHQ6IDUwMDsgbWFyZ2luLXRvcDogMnB4OyBvdmVyZmxvdzogaGlkZGVuOyB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpczsgd2hpdGUtc3BhY2U6IG5vd3JhcDsnO1xuICAgIHVybFJvdy50ZXh0Q29udGVudCA9IHRydW5jYXRlVXJsKGFnZW50Lm9yaWdpblVybCwgNDUpO1xuICAgIHVybFJvdy50aXRsZSA9IGFnZW50Lm9yaWdpblVybDtcblxuICAgIGNvbnN0IHF1aWNrQWxsb3dSb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBxdWlja0FsbG93Um93LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTogZmxleDsgZ2FwOiA2cHg7IG1hcmdpbi10b3A6IDZweDsnO1xuXG4gICAgY29uc3QgYWxsb3dSZWFkT25seUJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGFsbG93UmVhZE9ubHlCdG4udHlwZSA9ICdidXR0b24nO1xuICAgIGFsbG93UmVhZE9ubHlCdG4uY2xhc3NOYW1lID0gJ2J0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbSc7XG4gICAgYWxsb3dSZWFkT25seUJ0bi50ZXh0Q29udGVudCA9ICdBbGxvdyBSZWFkLU9ubHknO1xuICAgIGFsbG93UmVhZE9ubHlCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBvblF1aWNrQWxsb3dDbGljaygncmVhZE9ubHknKTtcbiAgICB9KTtcblxuICAgIGNvbnN0IGFsbG93RnVsbEJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGFsbG93RnVsbEJ0bi50eXBlID0gJ2J1dHRvbic7XG4gICAgYWxsb3dGdWxsQnRuLmNsYXNzTmFtZSA9ICdidG4gYnRuLXByaW1hcnkgYnRuLXNtJztcbiAgICBhbGxvd0Z1bGxCdG4udGV4dENvbnRlbnQgPSAnQWxsb3cgRnVsbCBBY2Nlc3MnO1xuICAgIGFsbG93RnVsbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgIG9uUXVpY2tBbGxvd0NsaWNrKCdmdWxsQWNjZXNzJyk7XG4gICAgfSk7XG5cbiAgICBxdWlja0FsbG93Um93LmFwcGVuZENoaWxkKGFsbG93UmVhZE9ubHlCdG4pO1xuICAgIHF1aWNrQWxsb3dSb3cuYXBwZW5kQ2hpbGQoYWxsb3dGdWxsQnRuKTtcblxuICAgIGNhcmQuYXBwZW5kQ2hpbGQoaGVhZGVyUm93KTtcbiAgICBjYXJkLmFwcGVuZENoaWxkKG1ldGFSb3cpO1xuICAgIGNhcmQuYXBwZW5kQ2hpbGQodXJsUm93KTtcbiAgICBjYXJkLmFwcGVuZENoaWxkKHF1aWNrQWxsb3dSb3cpO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChjYXJkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJLaWxsU3dpdGNoUGFuZWwoKTogdm9pZCB7XG4gIGNvbnN0IGJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdraWxsLXN3aXRjaC1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudCB8IG51bGw7XG4gIGlmICghYnRuKSByZXR1cm47XG5cbiAgaWYgKHBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZSkge1xuICAgIC8vIFJlcGxhY2Uga2lsbCBzd2l0Y2ggYnV0dG9uIHdpdGggUmVzdW1lIE1vbml0b3JpbmdcbiAgICBidG4udGV4dENvbnRlbnQgPSAnUmVzdW1lIE1vbml0b3JpbmcnO1xuICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbSc7XG4gICAgYnRuLm9uY2xpY2sgPSAoKSA9PiB7IG9uUmVzdW1lTW9uaXRvcmluZ0NsaWNrKCkuY2F0Y2goKCkgPT4geyAvKiBpZ25vcmUgKi8gfSk7IH07XG4gIH0gZWxzZSBpZiAocG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cy5sZW5ndGggPiAwKSB7XG4gICAgLy8gQWdlbnQgYWN0aXZlIOKAlCBzaG93IGtpbGwgc3dpdGNoIGVuYWJsZWQgYW5kIGRhbmdlcm91c1xuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdLaWxsIFN3aXRjaCc7XG4gICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgYnRuLmNsYXNzTmFtZSA9ICdidG4tZGFuZ2VyLWNvbXBhY3QnO1xuICAgIGJ0bi5vbmNsaWNrID0gKCkgPT4geyBvbktpbGxTd2l0Y2hDbGljaygpLmNhdGNoKCgpID0+IHsgLyogaWdub3JlICovIH0pOyB9O1xuICB9IGVsc2Uge1xuICAgIC8vIElkbGUg4oCUIG5vIGFnZW50IHRvIGtpbGwsIHNob3cgYXMgbmV1dHJhbC9pbmFjdGl2ZVxuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdLaWxsIFN3aXRjaCc7XG4gICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICBidG4uY2xhc3NOYW1lID0gJ2J0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbSc7XG4gICAgYnRuLm9uY2xpY2sgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uUmVzdW1lTW9uaXRvcmluZ0NsaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBidG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgna2lsbC1zd2l0Y2gtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQgfCBudWxsO1xuICBpZiAoYnRuKSBidG4uZGlzYWJsZWQgPSB0cnVlO1xuXG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZFRvQmFja2dyb3VuZCgnS0lMTF9TV0lUQ0hfUkVTRVQnLCB7fSk7XG4gICAgcG9wdXBTdGF0ZS5raWxsU3dpdGNoQWN0aXZlID0gZmFsc2U7XG4gICAgcmVuZGVyQWxsKCk7XG4gIH0gY2F0Y2gge1xuICAgIGlmIChidG4pIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9uUXVpY2tBbGxvd0NsaWNrKHByZXNldDogJ3JlYWRPbmx5JyB8ICdmdWxsQWNjZXNzJyk6IHZvaWQge1xuICBjb25zdCBydWxlID0gY3JlYXRlUnVsZUZyb21QcmVzZXQocHJlc2V0KTtcblxuICAvLyBPcHRpbWlzdGljIHVwZGF0ZSDigJQgc2FtZSBwYXR0ZXJuIGFzIHdpemFyZCBhY3RpdmF0aW9uLlxuICBwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb24gPSBydWxlO1xuICBwb3B1cFN0YXRlLndpemFyZFN0YXRlID0gbnVsbDtcbiAgY29uc3Qgd2l6YXJkQ29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dpemFyZC1jb250YWluZXInKTtcbiAgaWYgKHdpemFyZENvbnRhaW5lcikge1xuICAgIHdpemFyZENvbnRhaW5lci5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKTtcbiAgICB3aXphcmRDb250YWluZXIuaW5uZXJIVE1MID0gJyc7XG4gIH1cbiAgcmVuZGVyQWxsKCk7XG5cbiAgc2VuZFRvQmFja2dyb3VuZCgnREVMRUdBVElPTl9VUERBVEUnLCBydWxlKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgY29uc29sZS5lcnJvcignW0FJIEJyb3dzZXIgR3VhcmRdIEZhaWxlZCB0byBzeW5jIHF1aWNrLWFsbG93IHRvIGJhY2tncm91bmQ6JywgZXJyKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckRlbGVnYXRpb25QYW5lbCgpOiB2b2lkIHtcbiAgLy8gQ2xlYXIgYW55IGV4aXN0aW5nIGNvdW50ZG93biB0aW1lciB0byBhdm9pZCBkdXBsaWNhdGUgaW50ZXJ2YWxzXG4gIGlmIChjb3VudGRvd25JbnRlcnZhbElkICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChjb3VudGRvd25JbnRlcnZhbElkKTtcbiAgICBjb3VudGRvd25JbnRlcnZhbElkID0gbnVsbDtcbiAgfVxuXG4gIGNvbnN0IGNvbnRlbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGVsZWdhdGlvbi1jb250ZW50Jyk7XG4gIGlmICghY29udGVudCkgcmV0dXJuO1xuXG4gIGlmIChwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb24pIHtcbiAgICBjb25zdCBydWxlID0gcG9wdXBTdGF0ZS5hY3RpdmVEZWxlZ2F0aW9uO1xuICAgIGNvbnN0IHByZXNldE5hbWVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICAgcmVhZE9ubHk6ICdSZWFkLU9ubHknLFxuICAgICAgbGltaXRlZDogJ0xpbWl0ZWQnLFxuICAgICAgZnVsbEFjY2VzczogJ0Z1bGwgQWNjZXNzJyxcbiAgICB9O1xuXG4gICAgY29udGVudC5pbm5lckhUTUwgPSAnJztcbiAgICBjb25zdCByb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICByb3cuY2xhc3NOYW1lID0gJ2RlbGVnYXRpb24tZW1wdHknO1xuXG4gICAgY29uc3QgbGFiZWxTcGFuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGNvbnN0IHN0cm9uZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0cm9uZycpO1xuICAgIHN0cm9uZy50ZXh0Q29udGVudCA9IHByZXNldE5hbWVzW3J1bGUucHJlc2V0XSA/PyBydWxlLnByZXNldDtcbiAgICBsYWJlbFNwYW4uYXBwZW5kQ2hpbGQoc3Ryb25nKTtcblxuICAgIGlmIChydWxlLnNjb3BlLnRpbWVCb3VuZCkge1xuICAgICAgY29uc3QgZXhwaXJlc0F0ID0gbmV3IERhdGUocnVsZS5zY29wZS50aW1lQm91bmQuZXhwaXJlc0F0KS5nZXRUaW1lKCk7XG4gICAgICBjb25zdCB0aW1lU3BhbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgIHRpbWVTcGFuLmlkID0gJ2RlbGVnYXRpb24tY291bnRkb3duJztcbiAgICAgIHRpbWVTcGFuLnN0eWxlLmNzc1RleHQgPSAnZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyc7XG4gICAgICBsYWJlbFNwYW4uYXBwZW5kQ2hpbGQodGltZVNwYW4pO1xuXG4gICAgICBmdW5jdGlvbiB1cGRhdGVDb3VudGRvd24oKTogdm9pZCB7XG4gICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IGV4cGlyZXNBdCAtIERhdGUubm93KCk7XG4gICAgICAgIGlmIChyZW1haW5pbmcgPD0gMCkge1xuICAgICAgICAgIC8vIENsZWFyIHRoZSBpbnRlcnZhbCBhbmQgbWFyayBhcyBleHBpcmVkXG4gICAgICAgICAgaWYgKGNvdW50ZG93bkludGVydmFsSWQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoY291bnRkb3duSW50ZXJ2YWxJZCk7XG4gICAgICAgICAgICBjb3VudGRvd25JbnRlcnZhbElkID0gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGltZVNwYW4uc3R5bGUuY29sb3IgPSAndmFyKC0tY29sb3ItZGFuZ2VyKSc7XG4gICAgICAgICAgdGltZVNwYW4udGV4dENvbnRlbnQgPSAnIChFeHBpcmVkKSc7XG5cbiAgICAgICAgICAvLyBJZiByZS1xdWVyeSBmaW5kcyBubyBhY3RpdmUgcnVsZSwgcmVuZGVyQWxsIHdpbGwgaGlkZSB0aGUgY291bnRkb3duXG4gICAgICAgICAgcXVlcnlCYWNrZ3JvdW5kU3RhdHVzKCkuY2F0Y2goKCkgPT4geyAvKiBpZ25vcmUgKi8gfSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdG90YWxTZWNvbmRzID0gTWF0aC5mbG9vcihyZW1haW5pbmcgLyAxMDAwKTtcbiAgICAgICAgY29uc3QgbWlucyA9IE1hdGguZmxvb3IodG90YWxTZWNvbmRzIC8gNjApO1xuICAgICAgICBjb25zdCBzZWNzID0gdG90YWxTZWNvbmRzICUgNjA7XG4gICAgICAgIGNvbnN0IHBhZGRlZFNlY3MgPSBzZWNzLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKTtcbiAgICAgICAgdGltZVNwYW4uc3R5bGUuY29sb3IgPSByZW1haW5pbmcgPCA2MDAwMFxuICAgICAgICAgID8gJ3ZhcigtLWNvbG9yLWRhbmdlciknXG4gICAgICAgICAgOiAndmFyKC0tY29sb3Itd2FybmluZyknO1xuICAgICAgICB0aW1lU3Bhbi50ZXh0Q29udGVudCA9IGAgKCR7bWluc306JHtwYWRkZWRTZWNzfSBsZWZ0KWA7XG4gICAgICB9XG5cbiAgICAgIC8vIFJ1biBpbW1lZGlhdGVseSwgdGhlbiB1cGRhdGUgZXZlcnkgc2Vjb25kXG4gICAgICB1cGRhdGVDb3VudGRvd24oKTtcbiAgICAgIGNvdW50ZG93bkludGVydmFsSWQgPSBzZXRJbnRlcnZhbCh1cGRhdGVDb3VudGRvd24sIDEwMDApO1xuICAgIH1cblxuICAgIGNvbnN0IGNoYW5nZUJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGNoYW5nZUJ0bi5pZCA9ICdkZWxlZ2F0aW9uLXdpemFyZC1idG4nO1xuICAgIGNoYW5nZUJ0bi5jbGFzc05hbWUgPSAnYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtJztcbiAgICBjaGFuZ2VCdG4udGV4dENvbnRlbnQgPSAnQ2hhbmdlJztcbiAgICBjaGFuZ2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbkRlbGVnYXRpb25XaXphcmRDbGljayk7XG5cbiAgICByb3cuYXBwZW5kQ2hpbGQobGFiZWxTcGFuKTtcbiAgICByb3cuYXBwZW5kQ2hpbGQoY2hhbmdlQnRuKTtcbiAgICBjb250ZW50LmFwcGVuZENoaWxkKHJvdyk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3Qgd2l6YXJkT3BlbiA9IHBvcHVwU3RhdGUud2l6YXJkU3RhdGUgIT09IG51bGw7XG4gICAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwiZGVsZWdhdGlvbi1lbXB0eVwiPlxuICAgICAgICA8c3BhbiBjbGFzcz1cInBsYWNlaG9sZGVyLXRleHQtaW5saW5lXCI+Tm8gZGVsZWdhdGlvbiBhY3RpdmU8L3NwYW4+XG4gICAgICAgIDxidXR0b24gaWQ9XCJkZWxlZ2F0aW9uLXdpemFyZC1idG5cIiBjbGFzcz1cImJ0biAke3dpemFyZE9wZW4gPyAnYnRuLXNlY29uZGFyeScgOiAnYnRuLXByaW1hcnknfSBidG4tc21cIj4ke3dpemFyZE9wZW4gPyAnQ2FuY2VsJyA6ICdDb25maWd1cmUnfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgYDtcbiAgICBjb25zdCB3aXphcmRCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGVsZWdhdGlvbi13aXphcmQtYnRuJyk7XG4gICAgaWYgKHdpemFyZEJ0bikge1xuICAgICAgd2l6YXJkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgb25EZWxlZ2F0aW9uV2l6YXJkQ2xpY2spO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJWaW9sYXRpb25zUGFuZWwoKTogdm9pZCB7XG4gIGNvbnN0IHBhbmVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Zpb2xhdGlvbnMtcGFuZWwnKTtcbiAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Zpb2xhdGlvbnMtbGlzdCcpO1xuICBpZiAoIWNvbnRhaW5lciB8fCAhcGFuZWwpIHJldHVybjtcblxuICBpZiAocG9wdXBTdGF0ZS5yZWNlbnRWaW9sYXRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgIHBhbmVsLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICBjb250YWluZXIuaW5uZXJIVE1MID0gJyc7XG4gIGZvciAoY29uc3QgYWxlcnQgb2YgcG9wdXBTdGF0ZS5yZWNlbnRWaW9sYXRpb25zLnNsaWNlKC0xMCkucmV2ZXJzZSgpKSB7XG4gICAgY29uc3QgaXRlbSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGl0ZW0uY2xhc3NOYW1lID0gJ2V2ZW50LWl0ZW0nO1xuXG4gICAgY29uc3QgZG90ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZG90LmNsYXNzTmFtZSA9ICdldmVudC1vdXRjb21lIG91dGNvbWUtYmxvY2tlZCc7XG5cbiAgICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgYm9keS5zdHlsZS5jc3NUZXh0ID0gJ2ZsZXg6IDE7IG1pbi13aWR0aDogMDsnO1xuXG4gICAgY29uc3QgdG9wUm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdG9wUm93LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyc7XG5cbiAgICBjb25zdCB0aXRsZVNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgdGl0bGVTcGFuLnN0eWxlLmNzc1RleHQgPSAnZm9udC1zaXplOiAxM3B4OyBmb250LXdlaWdodDogNjAwOyc7XG4gICAgdGl0bGVTcGFuLnRleHRDb250ZW50ID0gYWxlcnQudGl0bGU7XG5cbiAgICBjb25zdCBzZXZCYWRnZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBzZXZCYWRnZS5jbGFzc05hbWUgPSBgc2V2ZXJpdHktYmFkZ2Ugc2V2ZXJpdHktJHthbGVydC5zZXZlcml0eX1gO1xuICAgIHNldkJhZGdlLnRleHRDb250ZW50ID0gYWxlcnQuc2V2ZXJpdHk7XG5cbiAgICB0b3BSb3cuYXBwZW5kQ2hpbGQodGl0bGVTcGFuKTtcbiAgICB0b3BSb3cuYXBwZW5kQ2hpbGQoc2V2QmFkZ2UpO1xuXG4gICAgY29uc3QgdXJsTGluZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHVybExpbmUuc3R5bGUuY3NzVGV4dCA9ICdmb250LXNpemU6IDEycHg7IGNvbG9yOiB2YXIoLS10ZXh0LXNlY29uZGFyeSk7IGZvbnQtd2VpZ2h0OiA1MDA7IG92ZXJmbG93OiBoaWRkZW47IHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzOyB3aGl0ZS1zcGFjZTogbm93cmFwOyc7XG4gICAgdXJsTGluZS50ZXh0Q29udGVudCA9IHRydW5jYXRlVXJsKGFsZXJ0LnZpb2xhdGlvbi51cmwpO1xuXG4gICAgY29uc3QgdHNMaW5lID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdHNMaW5lLnN0eWxlLmNzc1RleHQgPSAnZm9udC1zaXplOiAxMXB4OyBjb2xvcjogdmFyKC0tdGV4dC1zZWNvbmRhcnkpOyBmb250LXdlaWdodDogNTAwOyc7XG4gICAgdHNMaW5lLnRleHRDb250ZW50ID0gZm9ybWF0VGltZXN0YW1wKGFsZXJ0LnZpb2xhdGlvbi50aW1lc3RhbXApO1xuXG4gICAgYm9keS5hcHBlbmRDaGlsZCh0b3BSb3cpO1xuICAgIGJvZHkuYXBwZW5kQ2hpbGQodXJsTGluZSk7XG4gICAgYm9keS5hcHBlbmRDaGlsZCh0c0xpbmUpO1xuICAgIGl0ZW0uYXBwZW5kQ2hpbGQoZG90KTtcbiAgICBpdGVtLmFwcGVuZENoaWxkKGJvZHkpO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChpdGVtKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJUaW1lbGluZVBhbmVsKCk6IHZvaWQge1xuICBjb25zdCBwYW5lbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0aW1lbGluZS1wYW5lbCcpO1xuICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGltZWxpbmUtbGlzdCcpO1xuICBpZiAoIWNvbnRhaW5lciB8fCAhcGFuZWwpIHJldHVybjtcblxuICBjb25zdCBzZXNzaW9ucyA9IHBvcHVwU3RhdGUuc2Vzc2lvbnM7XG5cbiAgLy8gSGlkZSB0aGUgcGFuZWwgaWYgdGhlcmUgYXJlIG5vIHNlc3Npb25zIHdpdGggZXZlbnRzXG4gIGNvbnN0IGhhc1Nlc3Npb25zID0gc2Vzc2lvbnMuc29tZShzID0+IHMuZXZlbnRzLmxlbmd0aCA+IDApO1xuICBpZiAoIWhhc1Nlc3Npb25zKSB7XG4gICAgcGFuZWwuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG4gIGNvbnRhaW5lci5pbm5lckhUTUwgPSAnJztcblxuICAvLyBTaG93IFwiTm8gc2Vzc2lvbiBoaXN0b3J5XCIgbWVzc2FnZSBpZiBzZXNzaW9ucyBhcnJheSBpcyBlbXB0eVxuICBpZiAoc2Vzc2lvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgZW1wdHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XG4gICAgZW1wdHkuY2xhc3NOYW1lID0gJ3BsYWNlaG9sZGVyLXRleHQtaW5saW5lJztcbiAgICBlbXB0eS50ZXh0Q29udGVudCA9ICdObyBzZXNzaW9uIGhpc3RvcnknO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChlbXB0eSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gT25seSBvbmUgc2Vzc2lvbjogc3RhcnQgZXhwYW5kZWQuIE11bHRpcGxlIHNlc3Npb25zOiBjb2xsYXBzZWQgYnkgZGVmYXVsdC5cbiAgY29uc3Qgc3RhcnRFeHBhbmRlZCA9IHNlc3Npb25zLmxlbmd0aCA9PT0gMTtcblxuICBmb3IgKGNvbnN0IHNlc3Npb24gb2Ygc2Vzc2lvbnMpIHtcbiAgICAvLyBTa2lwIHNlc3Npb25zIHdpdGggbm8gZXZlbnRzXG4gICAgaWYgKHNlc3Npb24uZXZlbnRzLmxlbmd0aCA9PT0gMCkgY29udGludWU7XG5cbiAgICBjb25zdCBncm91cCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGdyb3VwLmNsYXNzTmFtZSA9ICdzZXNzaW9uLWdyb3VwJztcblxuICAgIC8vIC0tLSBTZXNzaW9uIGhlYWRlciAtLS1cbiAgICBjb25zdCBoZWFkZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkZXIuY2xhc3NOYW1lID0gJ3Nlc3Npb24taGVhZGVyJztcbiAgICBoZWFkZXIuc2V0QXR0cmlidXRlKCdyb2xlJywgJ2J1dHRvbicpO1xuICAgIGhlYWRlci5zZXRBdHRyaWJ1dGUoJ3RhYmluZGV4JywgJzAnKTtcblxuICAgIGNvbnN0IGhlYWRlckxlZnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkZXJMZWZ0LmNsYXNzTmFtZSA9ICdzZXNzaW9uLWhlYWRlci1sZWZ0JztcblxuICAgIGNvbnN0IGFnZW50TmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBhZ2VudE5hbWUuY2xhc3NOYW1lID0gJ3Nlc3Npb24tYWdlbnQtbmFtZSc7XG4gICAgYWdlbnROYW1lLnRleHRDb250ZW50ID0gZm9ybWF0QWdlbnRUeXBlKHNlc3Npb24uYWdlbnQudHlwZSk7XG5cbiAgICBjb25zdCBzdGFydExhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHN0YXJ0TGFiZWwuY2xhc3NOYW1lID0gJ3Nlc3Npb24tdGltZS1sYWJlbCc7XG4gICAgc3RhcnRMYWJlbC50ZXh0Q29udGVudCA9IGZvcm1hdFRpbWVTaG9ydChzZXNzaW9uLnN0YXJ0ZWRBdCk7XG5cbiAgICBjb25zdCBjb3VudExhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGNvdW50TGFiZWwuY2xhc3NOYW1lID0gJ3Nlc3Npb24tZXZlbnQtY291bnQnO1xuICAgIGNvdW50TGFiZWwudGV4dENvbnRlbnQgPSBgJHtzZXNzaW9uLmV2ZW50cy5sZW5ndGh9IGFjdGlvbiR7c2Vzc2lvbi5ldmVudHMubGVuZ3RoID09PSAxID8gJycgOiAncyd9YDtcblxuICAgIGhlYWRlckxlZnQuYXBwZW5kQ2hpbGQoYWdlbnROYW1lKTtcbiAgICBoZWFkZXJMZWZ0LmFwcGVuZENoaWxkKHN0YXJ0TGFiZWwpO1xuICAgIGhlYWRlckxlZnQuYXBwZW5kQ2hpbGQoY291bnRMYWJlbCk7XG5cbiAgICBjb25zdCBoZWFkZXJSaWdodCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGhlYWRlclJpZ2h0LmNsYXNzTmFtZSA9ICdzZXNzaW9uLWhlYWRlci1yaWdodCc7XG5cbiAgICBpZiAoc2Vzc2lvbi5lbmRlZEF0ID09PSBudWxsKSB7XG4gICAgICBjb25zdCBhY3RpdmVCYWRnZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgIGFjdGl2ZUJhZGdlLmNsYXNzTmFtZSA9ICdzZXNzaW9uLXN0YXR1cy1iYWRnZSBzZXNzaW9uLXN0YXR1cy1hY3RpdmUnO1xuICAgICAgYWN0aXZlQmFkZ2UudGV4dENvbnRlbnQgPSAnQWN0aXZlJztcbiAgICAgIGhlYWRlclJpZ2h0LmFwcGVuZENoaWxkKGFjdGl2ZUJhZGdlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgZW5kTGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgICBlbmRMYWJlbC5jbGFzc05hbWUgPSAnc2Vzc2lvbi10aW1lLWxhYmVsJztcbiAgICAgIGVuZExhYmVsLnRleHRDb250ZW50ID0gYEVuZGVkICR7Zm9ybWF0VGltZVNob3J0KHNlc3Npb24uZW5kZWRBdCl9YDtcbiAgICAgIGhlYWRlclJpZ2h0LmFwcGVuZENoaWxkKGVuZExhYmVsKTtcbiAgICB9XG5cbiAgICBjb25zdCBjaGV2cm9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGNoZXZyb24uY2xhc3NOYW1lID0gJ3Nlc3Npb24tY2hldnJvbic7XG4gICAgY2hldnJvbi50ZXh0Q29udGVudCA9IHN0YXJ0RXhwYW5kZWQgPyAnLScgOiAnKyc7XG4gICAgaGVhZGVyUmlnaHQuYXBwZW5kQ2hpbGQoY2hldnJvbik7XG5cbiAgICBoZWFkZXIuYXBwZW5kQ2hpbGQoaGVhZGVyTGVmdCk7XG4gICAgaGVhZGVyLmFwcGVuZENoaWxkKGhlYWRlclJpZ2h0KTtcblxuICAgIC8vIC0tLSBFdmVudCByb3dzIGNvbnRhaW5lciAtLS1cbiAgICBjb25zdCBldmVudFJvd3MgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBldmVudFJvd3MuY2xhc3NOYW1lID0gJ3Nlc3Npb24tZXZlbnRzJztcbiAgICBpZiAoIXN0YXJ0RXhwYW5kZWQpIHtcbiAgICAgIGV2ZW50Um93cy5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKTtcbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIHNlc3Npb24uZXZlbnRzKSB7XG4gICAgICBjb25zdCByb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIHJvdy5jbGFzc05hbWUgPSAnc2Vzc2lvbi1ldmVudC1yb3cnO1xuXG4gICAgICBjb25zdCBhcnJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgIGFycm93LmNsYXNzTmFtZSA9ICdzZXNzaW9uLWV2ZW50LWFycm93JztcbiAgICAgIGFycm93LnRleHRDb250ZW50ID0gJ1xcdTIxYjMnOyAvLyBkb3dud2FyZC1yaWdodCBhcnJvd1xuXG4gICAgICBjb25zdCB0aW1lQ2VsbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgIHRpbWVDZWxsLmNsYXNzTmFtZSA9ICdzZXNzaW9uLWV2ZW50LXRpbWUnO1xuICAgICAgdGltZUNlbGwudGV4dENvbnRlbnQgPSBmb3JtYXRUaW1lc3RhbXAoZXZlbnQudGltZXN0YW1wKTtcblxuICAgICAgY29uc3QgY2FwYWJpbGl0eUNlbGwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgICBjYXBhYmlsaXR5Q2VsbC5jbGFzc05hbWUgPSAnc2Vzc2lvbi1ldmVudC1jYXBhYmlsaXR5JztcbiAgICAgIGNhcGFiaWxpdHlDZWxsLnRleHRDb250ZW50ID0gZXZlbnQuYXR0ZW1wdGVkQWN0aW9uID8/IGV2ZW50LnR5cGU7XG5cbiAgICAgIGNvbnN0IHRhcmdldENlbGwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgICB0YXJnZXRDZWxsLmNsYXNzTmFtZSA9ICdzZXNzaW9uLWV2ZW50LXRhcmdldCc7XG4gICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXRTZWxlY3RvclxuICAgICAgICA/IHRydW5jYXRlVXJsKGV2ZW50LnRhcmdldFNlbGVjdG9yLCAyOClcbiAgICAgICAgOiB0cnVuY2F0ZVVybChldmVudC51cmwsIDI4KTtcbiAgICAgIHRhcmdldENlbGwudGV4dENvbnRlbnQgPSB0YXJnZXQ7XG4gICAgICB0YXJnZXRDZWxsLnRpdGxlID0gZXZlbnQudGFyZ2V0U2VsZWN0b3IgPz8gZXZlbnQudXJsO1xuXG4gICAgICBjb25zdCBvdXRjb21lQ2hpcCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgIGNvbnN0IG91dGNvbWVDbGFzcyA9IGV2ZW50Lm91dGNvbWUgPT09ICdhbGxvd2VkJ1xuICAgICAgICA/ICdvdXRjb21lLWNoaXAtYWxsb3dlZCdcbiAgICAgICAgOiBldmVudC5vdXRjb21lID09PSAnYmxvY2tlZCdcbiAgICAgICAgICA/ICdvdXRjb21lLWNoaXAtYmxvY2tlZCdcbiAgICAgICAgICA6ICdvdXRjb21lLWNoaXAtaW5mbyc7XG4gICAgICBvdXRjb21lQ2hpcC5jbGFzc05hbWUgPSBgb3V0Y29tZS1jaGlwICR7b3V0Y29tZUNsYXNzfWA7XG4gICAgICBvdXRjb21lQ2hpcC50ZXh0Q29udGVudCA9IGV2ZW50Lm91dGNvbWU7XG5cbiAgICAgIHJvdy5hcHBlbmRDaGlsZChhcnJvdyk7XG4gICAgICByb3cuYXBwZW5kQ2hpbGQodGltZUNlbGwpO1xuICAgICAgcm93LmFwcGVuZENoaWxkKGNhcGFiaWxpdHlDZWxsKTtcbiAgICAgIHJvdy5hcHBlbmRDaGlsZCh0YXJnZXRDZWxsKTtcbiAgICAgIHJvdy5hcHBlbmRDaGlsZChvdXRjb21lQ2hpcCk7XG4gICAgICBldmVudFJvd3MuYXBwZW5kQ2hpbGQocm93KTtcbiAgICB9XG5cbiAgICAvLyBUb2dnbGUgZXhwYW5kL2NvbGxhcHNlIG9uIGhlYWRlciBjbGlja1xuICAgIGZ1bmN0aW9uIHRvZ2dsZUdyb3VwKCk6IHZvaWQge1xuICAgICAgY29uc3QgaXNIaWRkZW4gPSBldmVudFJvd3MuY2xhc3NMaXN0LmNvbnRhaW5zKCdoaWRkZW4nKTtcbiAgICAgIGlmIChpc0hpZGRlbikge1xuICAgICAgICBldmVudFJvd3MuY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG4gICAgICAgIGNoZXZyb24udGV4dENvbnRlbnQgPSAnLSc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBldmVudFJvd3MuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgICAgIGNoZXZyb24udGV4dENvbnRlbnQgPSAnKyc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaGVhZGVyLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdG9nZ2xlR3JvdXApO1xuICAgIGhlYWRlci5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyB8fCBlLmtleSA9PT0gJyAnKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgdG9nZ2xlR3JvdXAoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGdyb3VwLmFwcGVuZENoaWxkKGhlYWRlcik7XG4gICAgZ3JvdXAuYXBwZW5kQ2hpbGQoZXZlbnRSb3dzKTtcbiAgICBjb250YWluZXIuYXBwZW5kQ2hpbGQoZ3JvdXApO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlck1ldHJpY3NQYW5lbCgpOiB2b2lkIHtcbiAgY29uc3QgcGFuZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWV0cmljcy1wYW5lbCcpO1xuICBjb25zdCBncmlkID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21ldHJpY3MtZ3JpZCcpO1xuICBjb25zdCBzaW5jZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtZXRyaWNzLXNpbmNlJyk7XG4gIGlmICghcGFuZWwgfHwgIWdyaWQgfHwgIXNpbmNlKSByZXR1cm47XG5cbiAgY29uc3Qgc3RhdHMgPSBwb3B1cFN0YXRlLmxpZmV0aW1lU3RhdHM7XG4gIGlmICghc3RhdHMgfHwgc3RhdHMudG90YWxTZXNzaW9ucyA9PT0gMCkge1xuICAgIHBhbmVsLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICBncmlkLmlubmVySFRNTCA9ICcnO1xuXG4gIC8vIFNlc3Npb25zIG1vbml0b3JlZFxuICBhZGRNZXRyaWNDZWxsKGdyaWQsIFN0cmluZyhzdGF0cy50b3RhbFNlc3Npb25zKSwgJ3Nlc3Npb25zIG1vbml0b3JlZCcpO1xuXG4gIC8vIEFjdGlvbnMgYmxvY2tlZCDigJQgc2hvdyAwIGFzIGEgcG9zaXRpdmUgKFwibm8gdmlvbGF0aW9uc1wiKVxuICBpZiAoc3RhdHMudG90YWxBY3Rpb25zQmxvY2tlZCA+IDApIHtcbiAgICBhZGRNZXRyaWNDZWxsKGdyaWQsIFN0cmluZyhzdGF0cy50b3RhbEFjdGlvbnNCbG9ja2VkKSwgJ2FjdGlvbnMgYmxvY2tlZCcpO1xuICB9IGVsc2Uge1xuICAgIGFkZE1ldHJpY0NlbGwoZ3JpZCwgJ05vbmUnLCAndmlvbGF0aW9ucyBkZXRlY3RlZCcpO1xuICB9XG5cbiAgLy8gVG9wIGRldGVjdGVkIGFnZW50IGZyYW1ld29ya1xuICBjb25zdCB0eXBlcyA9IE9iamVjdC5lbnRyaWVzKHN0YXRzLmFnZW50VHlwZXNEZXRlY3RlZCk7XG4gIGlmICh0eXBlcy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgdG9wVHlwZSA9IHR5cGVzLnNvcnQoKGEsIGIpID0+IGJbMV0gLSBhWzFdKVswXVswXTtcbiAgICBhZGRNZXRyaWNDZWxsKGdyaWQsIGZvcm1hdEFnZW50VHlwZSh0b3BUeXBlKSwgJ21vc3Qgc2VlbiBmcmFtZXdvcmsnKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB1bmlxdWVDb3VudCA9IHR5cGVzLmxlbmd0aDtcbiAgICBhZGRNZXRyaWNDZWxsKGdyaWQsIFN0cmluZyh1bmlxdWVDb3VudCksICdmcmFtZXdvcmsgdHlwZXMnKTtcbiAgfVxuXG4gIC8vIFwiQWN0aXZlIHNpbmNlXCIgbGluZVxuICBzaW5jZS50ZXh0Q29udGVudCA9ICcnO1xuICBpZiAoc3RhdHMuZmlyc3RBY3RpdmVBdCkge1xuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShzdGF0cy5maXJzdEFjdGl2ZUF0KTtcbiAgICBjb25zdCBkYXlzU2luY2UgPSBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gZGF0ZS5nZXRUaW1lKCkpIC8gODY0MDAwMDApO1xuICAgIGNvbnN0IGRhdGVTdHIgPSBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyh1bmRlZmluZWQsIHsgbW9udGg6ICdzaG9ydCcsIGRheTogJ251bWVyaWMnLCB5ZWFyOiAnbnVtZXJpYycgfSk7XG4gICAgY29uc3Qgc2luY2VUZXh0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHNpbmNlVGV4dC50ZXh0Q29udGVudCA9IGRheXNTaW5jZSA9PT0gMFxuICAgICAgPyBgTW9uaXRvcmluZyBhY3RpdmUgc2luY2UgdG9kYXkgKCR7ZGF0ZVN0cn0pYFxuICAgICAgOiBgTW9uaXRvcmluZyBhY3RpdmUgc2luY2UgJHtkYXRlU3RyfSAoJHtkYXlzU2luY2V9IGRheSR7ZGF5c1NpbmNlID09PSAxID8gJycgOiAncyd9KWA7XG4gICAgc2luY2UuYXBwZW5kQ2hpbGQoc2luY2VUZXh0KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBhZGRNZXRyaWNDZWxsKGNvbnRhaW5lcjogSFRNTEVsZW1lbnQsIHZhbHVlOiBzdHJpbmcsIGxhYmVsOiBzdHJpbmcpOiB2b2lkIHtcbiAgY29uc3QgY2VsbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBjZWxsLmNsYXNzTmFtZSA9ICdtZXRyaWMtY2VsbCc7XG5cbiAgY29uc3QgdmFsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIHZhbC5jbGFzc05hbWUgPSAnbWV0cmljLXZhbHVlJztcbiAgdmFsLnRleHRDb250ZW50ID0gdmFsdWU7XG5cbiAgY29uc3QgbGJsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIGxibC5jbGFzc05hbWUgPSAnbWV0cmljLWxhYmVsJztcbiAgbGJsLnRleHRDb250ZW50ID0gbGFiZWw7XG5cbiAgY2VsbC5hcHBlbmRDaGlsZCh2YWwpO1xuICBjZWxsLmFwcGVuZENoaWxkKGxibCk7XG4gIGNvbnRhaW5lci5hcHBlbmRDaGlsZChjZWxsKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyU3RhdHVzQmFkZ2UoKTogdm9pZCB7XG4gIGNvbnN0IGluZGljYXRvciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXMtaW5kaWNhdG9yJyk7XG4gIGNvbnN0IHN0YXR1c1RleHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzLXRleHQnKTtcbiAgaWYgKCFpbmRpY2F0b3IgfHwgIXN0YXR1c1RleHQpIHJldHVybjtcblxuICBpbmRpY2F0b3IuY2xhc3NMaXN0LnJlbW92ZSgnc3RhdHVzLWlkbGUnLCAnc3RhdHVzLWRldGVjdGVkJywgJ3N0YXR1cy1raWxsZWQnLCAnc3RhdHVzLWRlbGVnYXRlZCcpO1xuXG4gIGlmIChwb3B1cFN0YXRlLmtpbGxTd2l0Y2hBY3RpdmUpIHtcbiAgICBpbmRpY2F0b3IuY2xhc3NMaXN0LmFkZCgnc3RhdHVzLWtpbGxlZCcpO1xuICAgIHN0YXR1c1RleHQudGV4dENvbnRlbnQgPSAnS2lsbGVkJztcbiAgfSBlbHNlIGlmIChwb3B1cFN0YXRlLmRldGVjdGVkQWdlbnRzLmxlbmd0aCA+IDApIHtcbiAgICBpbmRpY2F0b3IuY2xhc3NMaXN0LmFkZCgnc3RhdHVzLWRldGVjdGVkJyk7XG4gICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9IGAke3BvcHVwU3RhdGUuZGV0ZWN0ZWRBZ2VudHMubGVuZ3RofSBBZ2VudChzKSBEZXRlY3RlZGA7XG4gIH0gZWxzZSBpZiAocG9wdXBTdGF0ZS5hY3RpdmVEZWxlZ2F0aW9uKSB7XG4gICAgaW5kaWNhdG9yLmNsYXNzTGlzdC5hZGQoJ3N0YXR1cy1kZWxlZ2F0ZWQnKTtcbiAgICBzdGF0dXNUZXh0LnRleHRDb250ZW50ID0gJ0RlbGVnYXRlZCc7XG4gIH0gZWxzZSB7XG4gICAgaW5kaWNhdG9yLmNsYXNzTGlzdC5hZGQoJ3N0YXR1cy1pZGxlJyk7XG4gICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9ICdNb25pdG9yaW5nJztcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzZW5kVG9CYWNrZ3JvdW5kKHR5cGU6IE1lc3NhZ2VUeXBlLCBkYXRhOiB1bmtub3duKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIGNvbnN0IG1lc3NhZ2U6IE1lc3NhZ2VQYXlsb2FkID0ge1xuICAgIHR5cGUsXG4gICAgZGF0YSxcbiAgICBzZW50QXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfTtcblxuICBpZiAodHlwZW9mIGNocm9tZSA9PT0gJ3VuZGVmaW5lZCcgfHwgIWNocm9tZS5ydW50aW1lKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignQ2hyb21lIHJ1bnRpbWUgbm90IGF2YWlsYWJsZScpKTtcbiAgfVxuXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobWVzc2FnZSwgKHJlc3BvbnNlKSA9PiB7XG4gICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gZm9ybWF0VGltZXN0YW1wKGlzb1RpbWVzdGFtcDogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGlzb1RpbWVzdGFtcCk7XG4gIHJldHVybiBkYXRlLnRvTG9jYWxlVGltZVN0cmluZyh1bmRlZmluZWQsIHtcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gICAgc2Vjb25kOiAnMi1kaWdpdCcsXG4gIH0pO1xufVxuXG4vLyBDb21wYWN0IEhIOk1NIGZvcm1hdCBmb3Igc3BhY2UtY29uc3RyYWluZWQgY29udGV4dHMgKHNlc3Npb24gaGVhZGVyIHJvdykuXG5mdW5jdGlvbiBmb3JtYXRUaW1lU2hvcnQoaXNvVGltZXN0YW1wOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBkYXRlID0gbmV3IERhdGUoaXNvVGltZXN0YW1wKTtcbiAgcmV0dXJuIGRhdGUudG9Mb2NhbGVUaW1lU3RyaW5nKHVuZGVmaW5lZCwge1xuICAgIGhvdXI6ICcyLWRpZ2l0JyxcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdEFnZW50VHlwZSh0eXBlOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBuYW1lczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICBwbGF5d3JpZ2h0OiAnUGxheXdyaWdodCcsXG4gICAgcHVwcGV0ZWVyOiAnUHVwcGV0ZWVyJyxcbiAgICBzZWxlbml1bTogJ1NlbGVuaXVtJyxcbiAgICAnYW50aHJvcGljLWNvbXB1dGVyLXVzZSc6ICdBbnRocm9waWMgQ29tcHV0ZXIgVXNlJyxcbiAgICAnb3BlbmFpLW9wZXJhdG9yJzogJ09wZW5BSSBPcGVyYXRvcicsXG4gICAgJ2NkcC1nZW5lcmljJzogJ0NEUCBBZ2VudCcsXG4gICAgJ3dlYmRyaXZlci1nZW5lcmljJzogJ1dlYkRyaXZlciBBZ2VudCcsXG4gICAgdW5rbm93bjogJ1Vua25vd24gQWdlbnQnLFxuICB9O1xuICByZXR1cm4gbmFtZXNbdHlwZV0gPz8gdHlwZTtcbn1cblxuZnVuY3Rpb24gdHJ1bmNhdGVVcmwodXJsOiBzdHJpbmcsIG1heExlbmd0aDogbnVtYmVyID0gNDApOiBzdHJpbmcge1xuICBpZiAodXJsLmxlbmd0aCA8PSBtYXhMZW5ndGgpIHJldHVybiB1cmw7XG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1cmwpO1xuICAgIGNvbnN0IGhvc3QgPSBwYXJzZWQuaG9zdG5hbWU7XG4gICAgY29uc3QgcGF0aCA9IHBhcnNlZC5wYXRobmFtZTtcbiAgICBjb25zdCBhdmFpbGFibGUgPSBtYXhMZW5ndGggLSBob3N0Lmxlbmd0aCAtIDM7XG4gICAgaWYgKGF2YWlsYWJsZSA8PSAwKSByZXR1cm4gaG9zdC5zdWJzdHJpbmcoMCwgbWF4TGVuZ3RoIC0gMykgKyAnLi4uJztcbiAgICByZXR1cm4gaG9zdCArIHBhdGguc3Vic3RyaW5nKDAsIGF2YWlsYWJsZSkgKyAnLi4uJztcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHVybC5zdWJzdHJpbmcoMCwgbWF4TGVuZ3RoIC0gMykgKyAnLi4uJztcbiAgfVxufVxuXG5pbml0aWFsaXplKCk7XG4iXSwibmFtZXMiOlsibmV4dFN0ZXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsU0FBUyxhQUFxQjtBQUM1QixTQUFPLE9BQU8sV0FBQTtBQUNoQjtBQUVBLE1BQU0seUJBQTRDLENBQUMsWUFBWSxVQUFVO0FBQ3pFLE1BQU0sdUJBQTBDLENBQUMsWUFBWSxZQUFZLFNBQVMsV0FBVztBQUM3RixNQUFNLG1CQUFzQztBQUFBLEVBQzFDO0FBQUEsRUFBWTtBQUFBLEVBQVk7QUFBQSxFQUFTO0FBQUEsRUFBYTtBQUFBLEVBQzlDO0FBQUEsRUFBaUI7QUFBQSxFQUFZO0FBQUEsRUFBYTtBQUFBLEVBQzFDO0FBQUEsRUFBa0I7QUFDcEI7QUFFQSxTQUFTLHdCQUF3QixTQUFpRDtBQUNoRixTQUFPLGlCQUFpQixJQUFJLENBQUMsU0FBUztBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLFFBQVEsUUFBUSxTQUFTLEdBQUcsSUFBSSxVQUFtQjtBQUFBLEVBQUEsRUFDbkQ7QUFDSjtBQUtPLFNBQVMscUJBQ2QsUUFDQSxTQUtnQjtBQUNoQixRQUFNLDBCQUFVLEtBQUE7QUFDaEIsTUFBSTtBQUVKLFVBQVEsUUFBQTtBQUFBLElBQ04sS0FBSztBQUNILGNBQVE7QUFBQSxRQUNOLGNBQWMsQ0FBQTtBQUFBLFFBQ2Qsb0JBQW9CLHdCQUF3QixzQkFBc0I7QUFBQSxRQUNsRSxXQUFXO0FBQUEsTUFBQTtBQUViO0FBQUEsSUFFRixLQUFLLFdBQVc7QUFDZCxZQUFNLGtCQUFrQixTQUFTLG1CQUFtQjtBQUNwRCxZQUFNLFlBQVksSUFBSSxLQUFLLElBQUksUUFBQSxJQUFZLGtCQUFrQixHQUFLO0FBQ2xFLFlBQU0sWUFBdUI7QUFBQSxRQUMzQjtBQUFBLFFBQ0EsV0FBVyxJQUFJLFlBQUE7QUFBQSxRQUNmLFdBQVcsVUFBVSxZQUFBO0FBQUEsTUFBWTtBQUVuQyxjQUFRO0FBQUEsUUFDTixjQUFjLFNBQVMsZ0JBQWdCLENBQUE7QUFBQSxRQUN2QyxvQkFBb0Isd0JBQXdCLG9CQUFvQjtBQUFBLFFBQ2hFO0FBQUEsTUFBQTtBQUVGO0FBQUEsSUFDRjtBQUFBLElBRUEsS0FBSztBQUNILGNBQVE7QUFBQSxRQUNOLGNBQWMsQ0FBQTtBQUFBLFFBQ2Qsb0JBQW9CLHdCQUF3QixnQkFBZ0I7QUFBQSxRQUM1RCxXQUFXO0FBQUEsTUFBQTtBQUViO0FBQUEsRUFBQTtBQUdKLFNBQU87QUFBQSxJQUNMLElBQUksV0FBQTtBQUFBLElBQ0o7QUFBQSxJQUNBO0FBQUEsSUFDQSxXQUFXLElBQUksWUFBQTtBQUFBLElBQ2YsVUFBVTtBQUFBLElBQ1YsT0FBTyxTQUFTO0FBQUEsRUFBQTtBQUVwQjtBQzFFTyxNQUFNLHdCQUF3QjtBQUFBLEVBQ25DLEVBQUUsT0FBTyxjQUFjLFNBQVMsR0FBQTtBQUFBLEVBQ2hDLEVBQUUsT0FBTyxVQUFVLFNBQVMsR0FBQTtBQUFBLEVBQzVCLEVBQUUsT0FBTyxXQUFXLFNBQVMsSUFBQTtBQUMvQjtBQUVPLFNBQVMsMkJBQXdDO0FBQ3RELFNBQU87QUFBQSxJQUNMLGFBQWE7QUFBQSxJQUNiLGdCQUFnQjtBQUFBLElBQ2hCLGNBQWMsQ0FBQTtBQUFBLElBQ2QsaUJBQWlCO0FBQUEsSUFDakIsT0FBTztBQUFBLElBQ1AsUUFBUSxDQUFBO0FBQUEsRUFBQztBQUViO0FBS08sU0FBUyxhQUFhLE9BQW9CLFFBQXVDO0FBQ3RGLFFBQU1BLFlBQXVCLFdBQVcsWUFBWSxVQUFVO0FBQzlELFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILGdCQUFnQjtBQUFBLElBQ2hCLGFBQWFBO0FBQUFBLElBQ2IsUUFBUSxDQUFBO0FBQUEsRUFBQztBQUViO0FBS08sU0FBUyxlQUFlLE9BQW9CLFNBQW1DO0FBQ3BGLE1BQUksQ0FBQyxRQUFRLFFBQVEsUUFBUTtBQUMzQixXQUFPLEVBQUUsR0FBRyxPQUFPLFFBQVEsQ0FBQywwQkFBMEIsRUFBQTtBQUFBLEVBQ3hEO0FBR0EsUUFBTSxTQUFTLE1BQU0sYUFBYSxLQUFLLENBQUMsTUFBTSxFQUFFLFlBQVksUUFBUSxPQUFPO0FBQzNFLE1BQUksUUFBUTtBQUNWLFdBQU8sRUFBRSxHQUFHLE9BQU8sUUFBUSxDQUFDLDhCQUE4QixFQUFBO0FBQUEsRUFDNUQ7QUFFQSxTQUFPO0FBQUEsSUFDTCxHQUFHO0FBQUEsSUFDSCxjQUFjLENBQUMsR0FBRyxNQUFNLGNBQWMsT0FBTztBQUFBLElBQzdDLFFBQVEsQ0FBQTtBQUFBLEVBQUM7QUFFYjtBQUtPLFNBQVMsa0JBQWtCLE9BQW9CLE9BQTRCO0FBQ2hGLFFBQU0sZUFBZSxNQUFNLGFBQWEsT0FBTyxDQUFDLEdBQUcsTUFBTSxNQUFNLEtBQUs7QUFDcEUsU0FBTyxFQUFFLEdBQUcsT0FBTyxjQUFjLFFBQVEsQ0FBQSxFQUFDO0FBQzVDO0FBS08sU0FBUyxZQUFZLE9BQW9CLFNBQThCO0FBQzVFLFFBQU0sUUFBUSxzQkFBc0IsS0FBSyxDQUFDLFFBQVEsSUFBSSxZQUFZLE9BQU87QUFDekUsTUFBSSxDQUFDLE9BQU87QUFDVixXQUFPLEVBQUUsR0FBRyxPQUFPLFFBQVEsQ0FBQywwREFBMEQsRUFBQTtBQUFBLEVBQ3hGO0FBQ0EsU0FBTyxFQUFFLEdBQUcsT0FBTyxpQkFBaUIsU0FBUyxRQUFRLENBQUEsRUFBQztBQUN4RDtBQUtPLFNBQVMsU0FBUyxPQUFpQztBQUN4RCxVQUFRLE1BQU0sYUFBQTtBQUFBLElBQ1osS0FBSztBQUNILFVBQUksQ0FBQyxNQUFNLGdCQUFnQjtBQUN6QixlQUFPLEVBQUUsR0FBRyxPQUFPLFFBQVEsQ0FBQyw2QkFBNkIsRUFBQTtBQUFBLE1BQzNEO0FBQ0EsVUFBSSxNQUFNLG1CQUFtQixXQUFXO0FBQ3RDLGVBQU8sRUFBRSxHQUFHLE9BQU8sYUFBYSxTQUFTLFFBQVEsQ0FBQSxFQUFDO0FBQUEsTUFDcEQ7QUFDQSxhQUFPLEVBQUUsR0FBRyxPQUFPLGFBQWEsV0FBVyxRQUFRLENBQUEsRUFBQztBQUFBLElBRXRELEtBQUs7QUFDSCxVQUFJLE1BQU0sYUFBYSxXQUFXLEdBQUc7QUFDbkMsZUFBTyxFQUFFLEdBQUcsT0FBTyxRQUFRLENBQUMsZ0NBQWdDLEVBQUE7QUFBQSxNQUM5RDtBQUNBLGFBQU8sRUFBRSxHQUFHLE9BQU8sYUFBYSxRQUFRLFFBQVEsQ0FBQSxFQUFDO0FBQUEsSUFFbkQsS0FBSztBQUNILFVBQUksTUFBTSxvQkFBb0IsTUFBTTtBQUNsQyxlQUFPLEVBQUUsR0FBRyxPQUFPLFFBQVEsQ0FBQyx5QkFBeUIsRUFBQTtBQUFBLE1BQ3ZEO0FBQ0EsYUFBTyxFQUFFLEdBQUcsT0FBTyxhQUFhLFdBQVcsUUFBUSxDQUFBLEVBQUM7QUFBQSxJQUV0RCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBRVQ7QUFDRSxhQUFPO0FBQUEsRUFBQTtBQUViO0FBS08sU0FBUyxhQUFhLE9BQWlDO0FBQzVELFFBQU0sWUFBMEIsQ0FBQyxVQUFVLFNBQVMsUUFBUSxTQUFTO0FBQ3JFLFFBQU0sZUFBZSxVQUFVLFFBQVEsTUFBTSxXQUFXO0FBRXhELE1BQUksZ0JBQWdCLEVBQUcsUUFBTztBQUc5QixNQUFJLE1BQU0sZ0JBQWdCLGFBQWEsTUFBTSxtQkFBbUIsV0FBVztBQUN6RSxXQUFPLEVBQUUsR0FBRyxPQUFPLGFBQWEsVUFBVSxRQUFRLENBQUEsRUFBQztBQUFBLEVBQ3JEO0FBRUEsU0FBTyxFQUFFLEdBQUcsT0FBTyxhQUFhLFVBQVUsZUFBZSxDQUFDLEdBQUcsUUFBUSxHQUFDO0FBQ3hFO0FBS08sU0FBUyxlQUFlLE9BQTJDO0FBQ3hFLE1BQUksQ0FBQyxNQUFNLGVBQWdCLFFBQU87QUFFbEMsTUFBSSxNQUFNLG1CQUFtQixXQUFXO0FBQ3RDLFFBQUksTUFBTSxhQUFhLFdBQVcsRUFBRyxRQUFPO0FBQzVDLFFBQUksTUFBTSxvQkFBb0IsS0FBTSxRQUFPO0FBQUEsRUFDN0M7QUFFQSxTQUFPLHFCQUFxQixNQUFNLGdCQUFnQjtBQUFBLElBQ2hELGNBQWMsTUFBTTtBQUFBLElBQ3BCLGlCQUFpQixNQUFNLG1CQUFtQjtBQUFBLElBQzFDLE9BQU8sTUFBTSxTQUFTO0FBQUEsRUFBQSxDQUN2QjtBQUNIO0FBRUEsTUFBTSxzQkFBd0Y7QUFBQSxFQUM1RixVQUFVO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxhQUFhO0FBQUEsRUFBQTtBQUFBLEVBRWYsU0FBUztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsYUFBYTtBQUFBLEVBQUE7QUFBQSxFQUVmLFlBQVk7QUFBQSxJQUNWLE9BQU87QUFBQSxJQUNQLGFBQWE7QUFBQSxFQUFBO0FBRWpCO0FBS08sU0FBUyxhQUNkLFdBQ0EsT0FDQSxlQUNNO0FBQ04sWUFBVSxZQUFZO0FBR3RCLE1BQUksTUFBTSxPQUFPLFNBQVMsR0FBRztBQUMzQixVQUFNLFdBQVcsU0FBUyxjQUFjLEtBQUs7QUFDN0MsYUFBUyxZQUFZO0FBQ3JCLGFBQVMsTUFBTSxVQUFVO0FBQ3pCLGFBQVMsY0FBYyxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQzVDLGNBQVUsWUFBWSxRQUFRO0FBQUEsRUFDaEM7QUFFQSxVQUFRLE1BQU0sYUFBQTtBQUFBLElBQ1osS0FBSztBQUNILHVCQUFpQixXQUFXLE9BQU8sYUFBYTtBQUNoRDtBQUFBLElBQ0YsS0FBSztBQUNILHNCQUFnQixXQUFXLE9BQU8sYUFBYTtBQUMvQztBQUFBLElBQ0YsS0FBSztBQUNILHFCQUFlLFdBQVcsT0FBTyxhQUFhO0FBQzlDO0FBQUEsSUFDRixLQUFLO0FBQ0gsd0JBQWtCLFdBQVcsT0FBTyxhQUFhO0FBQ2pEO0FBQUEsRUFBQTtBQUVOO0FBRUEsU0FBUyxpQkFDUCxXQUNBLE9BQ0EsZUFDTTtBQUNOLFFBQU0sVUFBOEIsQ0FBQyxZQUFZLFdBQVcsWUFBWTtBQUN4RSxhQUFXLFVBQVUsU0FBUztBQUM1QixVQUFNLE9BQU8sb0JBQW9CLE1BQU07QUFDdkMsVUFBTSxPQUFPLFNBQVMsY0FBYyxRQUFRO0FBQzVDLFNBQUssT0FBTztBQUNaLFNBQUssWUFBWSxjQUFjLE1BQU0sbUJBQW1CLFNBQVMsY0FBYyxFQUFFO0FBRWpGLFVBQU0sUUFBUSxTQUFTLGNBQWMsUUFBUTtBQUM3QyxVQUFNLGNBQWMsS0FBSztBQUV6QixVQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7QUFDdkMsU0FBSyxNQUFNLFVBQVU7QUFDckIsU0FBSyxjQUFjLEtBQUs7QUFFeEIsU0FBSyxZQUFZLEtBQUs7QUFDdEIsU0FBSyxZQUFZLElBQUk7QUFDckIsU0FBSyxpQkFBaUIsU0FBUyxNQUFNO0FBQ25DLG9CQUFjLGFBQWEsT0FBTyxNQUFNLENBQUM7QUFBQSxJQUMzQyxDQUFDO0FBQ0QsY0FBVSxZQUFZLElBQUk7QUFBQSxFQUM1QjtBQUNGO0FBRUEsU0FBUyxnQkFDUCxXQUNBLE9BQ0EsZUFDTTtBQUNOLFFBQU0sVUFBVSxTQUFTLGNBQWMsR0FBRztBQUMxQyxVQUFRLE1BQU0sVUFBVTtBQUN4QixVQUFRLGNBQWM7QUFDdEIsWUFBVSxZQUFZLE9BQU87QUFHN0IsUUFBTSxXQUFXLFNBQVMsY0FBYyxLQUFLO0FBQzdDLFdBQVMsTUFBTSxVQUFVO0FBRXpCLFFBQU0sUUFBUSxTQUFTLGNBQWMsT0FBTztBQUM1QyxRQUFNLE9BQU87QUFDYixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ2xCLFFBQU0sTUFBTSxVQUFVO0FBRXRCLFFBQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtBQUM5QyxTQUFPLFlBQVk7QUFDbkIsU0FBTyxjQUFjO0FBQ3JCLFNBQU8sTUFBTSxVQUFVO0FBQ3ZCLFNBQU8saUJBQWlCLFNBQVMsTUFBTTtBQUNyQyxVQUFNLFFBQVEsTUFBTSxNQUFNLEtBQUE7QUFDMUIsUUFBSSxPQUFPO0FBQ1Qsb0JBQWMsZUFBZSxPQUFPLEVBQUUsU0FBUyxPQUFPLFFBQVEsUUFBQSxDQUFTLENBQUM7QUFDeEUsWUFBTSxRQUFRO0FBQUEsSUFDaEI7QUFBQSxFQUNGLENBQUM7QUFFRCxXQUFTLFlBQVksS0FBSztBQUMxQixXQUFTLFlBQVksTUFBTTtBQUMzQixZQUFVLFlBQVksUUFBUTtBQUc5QixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sYUFBYSxRQUFRLEtBQUs7QUFDbEQsVUFBTSxJQUFJLE1BQU0sYUFBYSxDQUFDO0FBQzlCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLE1BQU0sVUFBVTtBQUNwQixVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxNQUFNLFVBQVU7QUFDdEIsVUFBTSxjQUFjLEdBQUcsRUFBRSxPQUFPLEtBQUssRUFBRSxNQUFNO0FBQzdDLFFBQUksWUFBWSxLQUFLO0FBQ3JCLFVBQU0sWUFBWSxTQUFTLGNBQWMsUUFBUTtBQUNqRCxjQUFVLFlBQVk7QUFDdEIsY0FBVSxjQUFjO0FBQ3hCLGNBQVUsTUFBTSxVQUFVO0FBQzFCLGNBQVUsaUJBQWlCLFNBQVMsTUFBTSxjQUFjLGtCQUFrQixPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ3BGLFFBQUksWUFBWSxTQUFTO0FBQ3pCLGNBQVUsWUFBWSxHQUFHO0FBQUEsRUFDM0I7QUFHQSxtQkFBaUIsV0FBVyxPQUFPLGFBQWE7QUFDbEQ7QUFFQSxTQUFTLGVBQ1AsV0FDQSxPQUNBLGVBQ007QUFDTixRQUFNLFVBQVUsU0FBUyxjQUFjLEdBQUc7QUFDMUMsVUFBUSxNQUFNLFVBQVU7QUFDeEIsVUFBUSxjQUFjO0FBQ3RCLFlBQVUsWUFBWSxPQUFPO0FBRTdCLGFBQVcsVUFBVSx1QkFBdUI7QUFDMUMsVUFBTSxNQUFNLFNBQVMsY0FBYyxRQUFRO0FBQzNDLFFBQUksWUFBWSxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sVUFBVSxnQkFBZ0IsZUFBZTtBQUNqRyxRQUFJLGNBQWMsT0FBTztBQUN6QixRQUFJLE1BQU0sVUFBVTtBQUNwQixRQUFJLGlCQUFpQixTQUFTLE1BQU07QUFDbEMsWUFBTSxVQUFVLFlBQVksT0FBTyxPQUFPLE9BQU87QUFDakQsb0JBQWMsU0FBUyxPQUFPLENBQUM7QUFBQSxJQUNqQyxDQUFDO0FBQ0QsY0FBVSxZQUFZLEdBQUc7QUFBQSxFQUMzQjtBQUVBLG1CQUFpQixXQUFXLE9BQU8sZUFBZSxJQUFJO0FBQ3hEO0FBRUEsU0FBUyxrQkFDUCxXQUNBLE9BQ0EsZUFDTTtBQUNOLFFBQU0sU0FBUyxNQUFNO0FBQ3JCLE1BQUksQ0FBQyxPQUFRO0FBRWIsUUFBTSxPQUFPLG9CQUFvQixNQUFNO0FBQ3ZDLFFBQU0sVUFBVSxTQUFTLGNBQWMsS0FBSztBQUM1QyxVQUFRLE1BQU0sVUFBVTtBQUV4QixNQUFJLE9BQU8sK0JBQStCLEtBQUssS0FBSztBQUNwRCxNQUFJLE1BQU0sYUFBYSxTQUFTLEdBQUc7QUFDakMsWUFBUSw4QkFBOEIsTUFBTSxhQUFhLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssSUFBSSxDQUFDO0FBQUEsRUFDM0Y7QUFDQSxNQUFJLE1BQU0saUJBQWlCO0FBQ3pCLFVBQU0sTUFBTSxzQkFBc0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxZQUFZLE1BQU0sZUFBZTtBQUNqRixZQUFRLGlDQUFpQyxLQUFLLFNBQVMsTUFBTSxrQkFBa0IsVUFBVTtBQUFBLEVBQzNGO0FBQ0EsVUFBUSxZQUFZO0FBQ3BCLFlBQVUsWUFBWSxPQUFPO0FBRzdCLFFBQU0sYUFBYSxTQUFTLGNBQWMsT0FBTztBQUNqRCxhQUFXLE9BQU87QUFDbEIsYUFBVyxjQUFjO0FBQ3pCLGFBQVcsWUFBWTtBQUN2QixhQUFXLFFBQVEsTUFBTTtBQUN6QixhQUFXLE1BQU0sVUFBVTtBQUMzQixhQUFXLGlCQUFpQixTQUFTLE1BQU07QUFDekMsVUFBTSxRQUFRLFdBQVc7QUFBQSxFQUMzQixDQUFDO0FBQ0QsWUFBVSxZQUFZLFVBQVU7QUFHaEMsUUFBTSxjQUFjLFNBQVMsY0FBYyxRQUFRO0FBQ25ELGNBQVksWUFBWTtBQUN4QixjQUFZLGNBQWM7QUFDMUIsY0FBWSxNQUFNLFVBQVU7QUFDNUIsY0FBWSxpQkFBaUIsU0FBUyxNQUFNO0FBQzFDLFVBQU0sT0FBTyxlQUFlLEtBQUs7QUFDakMsUUFBSSxNQUFNO0FBRVIsZ0JBQVU7QUFBQSxRQUNSLElBQUksWUFBWSx3QkFBd0IsRUFBRSxRQUFRLE1BQU0sU0FBUyxNQUFNO0FBQUEsTUFBQTtBQUFBLElBRTNFO0FBQUEsRUFDRixDQUFDO0FBQ0QsWUFBVSxZQUFZLFdBQVc7QUFFakMsbUJBQWlCLFdBQVcsT0FBTyxlQUFlLElBQUk7QUFDeEQ7QUFFQSxTQUFTLGlCQUNQLFdBQ0EsT0FDQSxlQUNBLFdBQVcsT0FDTDtBQUNOLFFBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxNQUFJLE1BQU0sVUFBVTtBQUVwQixNQUFJLFVBQVU7QUFDWixVQUFNLFVBQVUsU0FBUyxjQUFjLFFBQVE7QUFDL0MsWUFBUSxZQUFZO0FBQ3BCLFlBQVEsY0FBYztBQUN0QixZQUFRLE1BQU0sVUFBVTtBQUN4QixZQUFRLGlCQUFpQixTQUFTLE1BQU0sY0FBYyxhQUFhLEtBQUssQ0FBQyxDQUFDO0FBQzFFLFFBQUksWUFBWSxPQUFPO0FBQUEsRUFDekI7QUFFQSxNQUFJLE1BQU0sZ0JBQWdCLFNBQVM7QUFDakMsVUFBTSxVQUFVLFNBQVMsY0FBYyxRQUFRO0FBQy9DLFlBQVEsWUFBWTtBQUNwQixZQUFRLGNBQWM7QUFDdEIsWUFBUSxNQUFNLFVBQVU7QUFDeEIsWUFBUSxpQkFBaUIsU0FBUyxNQUFNLGNBQWMsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUN0RSxRQUFJLFlBQVksT0FBTztBQUFBLEVBQ3pCO0FBRUEsTUFBSSxJQUFJLFNBQVMsU0FBUyxHQUFHO0FBQzNCLGNBQVUsWUFBWSxHQUFHO0FBQUEsRUFDM0I7QUFDRjtBQzFYQSxJQUFJLGFBQXlCO0FBQUEsRUFDM0IsZ0JBQWdCLENBQUE7QUFBQSxFQUNoQixrQkFBa0I7QUFBQSxFQUNsQixrQkFBa0I7QUFBQSxFQUNsQixrQkFBa0IsQ0FBQTtBQUFBLEVBQ2xCLFVBQVUsQ0FBQTtBQUFBLEVBQ1YsYUFBYTtBQUFBLEVBQ2IsU0FBUztBQUFBLEVBQ1QsZUFBZTtBQUNqQjtBQUlBLElBQUksc0JBQTZEO0FBRWpFLFNBQVMsYUFBbUI7QUFDMUIsV0FBUyxpQkFBaUIsb0JBQW9CLE1BQU07QUFDbEQsd0JBQUE7QUFDQSwwQkFBQTtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsZUFBZSx3QkFBdUM7QUFDcEQsTUFBSTtBQUNGLFVBQU0sV0FBVyxNQUFNLGlCQUFpQixnQkFBZ0IsQ0FBQSxDQUFFO0FBQzFELFFBQUksWUFBWSxPQUFPLGFBQWEsVUFBVTtBQUM1QyxZQUFNLE9BQU87QUFNYixpQkFBVyxpQkFBaUIsS0FBSyxrQkFBa0IsQ0FBQTtBQUNuRCxpQkFBVyxtQkFBbUIsS0FBSyxvQkFBb0I7QUFDdkQsaUJBQVcsbUJBQW1CLEtBQUssb0JBQW9CO0FBQ3ZELGlCQUFXLG1CQUFtQixLQUFLLG9CQUFvQixDQUFBO0FBQ3ZELGlCQUFXLGdCQUFpQixLQUEyQyxpQkFBaUI7QUFBQSxJQUMxRjtBQUFBLEVBQ0YsUUFBUTtBQUFBLEVBRVI7QUFHQSxNQUFJO0FBQ0YsVUFBTSxrQkFBa0IsTUFBTSxpQkFBaUIsaUJBQWlCLENBQUEsQ0FBRTtBQUNsRSxRQUFJLG1CQUFtQixPQUFPLG9CQUFvQixVQUFVO0FBQzFELFlBQU0sT0FBTztBQUNiLGlCQUFXLFdBQVcsS0FBSyxZQUFZLENBQUE7QUFBQSxJQUN6QztBQUFBLEVBQ0YsUUFBUTtBQUFBLEVBRVI7QUFFQSxhQUFXLFVBQVU7QUFDckIsWUFBQTtBQUNGO0FBRUEsU0FBUyxzQkFBNEI7QUFDbkMsUUFBTSxnQkFBZ0IsU0FBUyxlQUFlLGlCQUFpQjtBQUMvRCxNQUFJLGVBQWU7QUFDakIsa0JBQWMsaUJBQWlCLFNBQVMsaUJBQWlCO0FBQUEsRUFDM0Q7QUFFQSxRQUFNLFlBQVksU0FBUyxlQUFlLHVCQUF1QjtBQUNqRSxNQUFJLFdBQVc7QUFDYixjQUFVLGlCQUFpQixTQUFTLHVCQUF1QjtBQUFBLEVBQzdEO0FBR0EsTUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLFNBQVMsV0FBVztBQUM5RCxXQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsWUFBNEI7QUFDbEUsVUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQU07QUFFN0IsY0FBUSxRQUFRLE1BQUE7QUFBQSxRQUNkLEtBQUs7QUFDSCxnQ0FBQTtBQUNBO0FBQUEsUUFDRixLQUFLO0FBQ0gscUJBQVcsbUJBQW1CO0FBQzlCLG9CQUFBO0FBQ0E7QUFBQSxRQUNGLEtBQUs7QUFDSCxnQ0FBQTtBQUNBO0FBQUEsTUFBQTtBQUFBLElBRU4sQ0FBQztBQUFBLEVBQ0g7QUFLQSxXQUFTLGlCQUFpQix3QkFBeUIsQ0FBQyxNQUFtQztBQUNyRixVQUFNLE9BQU8sRUFBRTtBQUdmLGVBQVcsbUJBQW1CO0FBQzlCLGVBQVcsY0FBYztBQUN6QixVQUFNLGtCQUFrQixTQUFTLGVBQWUsa0JBQWtCO0FBQ2xFLFFBQUksaUJBQWlCO0FBQ25CLHNCQUFnQixVQUFVLElBQUksUUFBUTtBQUN0QyxzQkFBZ0IsWUFBWTtBQUFBLElBQzlCO0FBQ0EsY0FBQTtBQUdBLHFCQUFpQixxQkFBcUIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3pELGNBQVEsTUFBTSwrREFBK0QsR0FBRztBQUFBLElBQ2xGLENBQUM7QUFBQSxFQUNILENBQW1CO0FBQ3JCO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsUUFBTSxNQUFNLFNBQVMsZUFBZSxpQkFBaUI7QUFDckQsTUFBSSxTQUFTLFdBQVc7QUFFeEIsTUFBSTtBQUNGLFVBQU0saUJBQWlCLHdCQUF3QixFQUFFLFNBQVMsVUFBVTtBQUNwRSxlQUFXLG1CQUFtQjtBQUM5QixlQUFXLGlCQUFpQixDQUFBO0FBQzVCLGVBQVcsbUJBQW1CO0FBQzlCLGNBQUE7QUFBQSxFQUNGLFFBQVE7QUFDTixRQUFJLFNBQVMsV0FBVztBQUFBLEVBQzFCO0FBQ0Y7QUFFQSxTQUFTLDBCQUFnQztBQUN2QyxRQUFNLGtCQUFrQixTQUFTLGVBQWUsa0JBQWtCO0FBQ2xFLE1BQUksQ0FBQyxnQkFBaUI7QUFFdEIsTUFBSSxnQkFBZ0IsVUFBVSxTQUFTLFFBQVEsR0FBRztBQUNoRCxvQkFBZ0IsVUFBVSxPQUFPLFFBQVE7QUFDekMsZUFBVyxjQUFjLHlCQUFBO0FBQ3pCLG1CQUFBO0FBQUEsRUFDRixPQUFPO0FBQ0wsb0JBQWdCLFVBQVUsSUFBSSxRQUFRO0FBQ3RDLG9CQUFnQixZQUFZO0FBQzVCLGVBQVcsY0FBYztBQUFBLEVBQzNCO0FBRUEsd0JBQUE7QUFDRjtBQUVBLFNBQVMsaUJBQXVCO0FBQzlCLFFBQU0sa0JBQWtCLFNBQVMsZUFBZSxrQkFBa0I7QUFDbEUsTUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsWUFBYTtBQUVqRCxlQUFhLGlCQUFpQixXQUFXLGFBQWEsQ0FBQyxhQUFhO0FBQ2xFLGVBQVcsY0FBYztBQUN6QixtQkFBQTtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyxZQUFrQjtBQUN6Qix1QkFBQTtBQUNBLHdCQUFBO0FBQ0Esd0JBQUE7QUFDQSx3QkFBQTtBQUNBLHNCQUFBO0FBQ0EscUJBQUE7QUFDQSxvQkFBQTtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsUUFBTSxZQUFZLFNBQVMsZUFBZSxtQkFBbUI7QUFDN0QsTUFBSSxDQUFDLFVBQVc7QUFFaEIsTUFBSSxXQUFXLFNBQVM7QUFDdEIsY0FBVSxZQUFZO0FBQ3RCO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxlQUFlLFdBQVcsR0FBRztBQUMxQyxjQUFVLFlBQVk7QUFDdEI7QUFBQSxFQUNGO0FBRUEsWUFBVSxZQUFZO0FBQ3RCLGFBQVcsU0FBUyxXQUFXLGdCQUFnQjtBQUM3QyxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBRWpCLFVBQU0sWUFBWSxTQUFTLGNBQWMsS0FBSztBQUM5QyxjQUFVLE1BQU0sVUFBVTtBQUUxQixVQUFNLE9BQU8sU0FBUyxjQUFjLFFBQVE7QUFDNUMsU0FBSyxjQUFjLGdCQUFnQixNQUFNLElBQUk7QUFFN0MsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLGNBQWMsZUFBZSxNQUFNLFVBQVU7QUFFbkQsY0FBVSxZQUFZLElBQUk7QUFDMUIsY0FBVSxZQUFZLEtBQUs7QUFFM0IsVUFBTSxVQUFVLFNBQVMsY0FBYyxLQUFLO0FBQzVDLFlBQVEsTUFBTSxVQUFVO0FBRXhCLFVBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxPQUFHLGNBQWMsZ0JBQWdCLE1BQU0sVUFBVSxJQUFJO0FBQ3JELFlBQVEsWUFBWSxFQUFFO0FBRXRCLGVBQVcsS0FBSyxNQUFNLGtCQUFrQjtBQUN0QyxZQUFNLE1BQU0sU0FBUyxjQUFjLE1BQU07QUFDekMsVUFBSSxZQUFZO0FBQ2hCLFVBQUksY0FBYztBQUNsQixjQUFRLFlBQVksR0FBRztBQUFBLElBQ3pCO0FBRUEsVUFBTSxTQUFTLFNBQVMsY0FBYyxLQUFLO0FBQzNDLFdBQU8sTUFBTSxVQUFVO0FBQ3ZCLFdBQU8sY0FBYyxZQUFZLE1BQU0sV0FBVyxFQUFFO0FBQ3BELFdBQU8sUUFBUSxNQUFNO0FBRXJCLFVBQU0sZ0JBQWdCLFNBQVMsY0FBYyxLQUFLO0FBQ2xELGtCQUFjLE1BQU0sVUFBVTtBQUU5QixVQUFNLG1CQUFtQixTQUFTLGNBQWMsUUFBUTtBQUN4RCxxQkFBaUIsT0FBTztBQUN4QixxQkFBaUIsWUFBWTtBQUM3QixxQkFBaUIsY0FBYztBQUMvQixxQkFBaUIsaUJBQWlCLFNBQVMsTUFBTTtBQUMvQyx3QkFBa0IsVUFBVTtBQUFBLElBQzlCLENBQUM7QUFFRCxVQUFNLGVBQWUsU0FBUyxjQUFjLFFBQVE7QUFDcEQsaUJBQWEsT0FBTztBQUNwQixpQkFBYSxZQUFZO0FBQ3pCLGlCQUFhLGNBQWM7QUFDM0IsaUJBQWEsaUJBQWlCLFNBQVMsTUFBTTtBQUMzQyx3QkFBa0IsWUFBWTtBQUFBLElBQ2hDLENBQUM7QUFFRCxrQkFBYyxZQUFZLGdCQUFnQjtBQUMxQyxrQkFBYyxZQUFZLFlBQVk7QUFFdEMsU0FBSyxZQUFZLFNBQVM7QUFDMUIsU0FBSyxZQUFZLE9BQU87QUFDeEIsU0FBSyxZQUFZLE1BQU07QUFDdkIsU0FBSyxZQUFZLGFBQWE7QUFDOUIsY0FBVSxZQUFZLElBQUk7QUFBQSxFQUM1QjtBQUNGO0FBRUEsU0FBUyx3QkFBOEI7QUFDckMsUUFBTSxNQUFNLFNBQVMsZUFBZSxpQkFBaUI7QUFDckQsTUFBSSxDQUFDLElBQUs7QUFFVixNQUFJLFdBQVcsa0JBQWtCO0FBRS9CLFFBQUksY0FBYztBQUNsQixRQUFJLFdBQVc7QUFDZixRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVLE1BQU07QUFBRSw4QkFBQSxFQUEwQixNQUFNLE1BQU07QUFBQSxNQUFlLENBQUM7QUFBQSxJQUFHO0FBQUEsRUFDakYsV0FBVyxXQUFXLGVBQWUsU0FBUyxHQUFHO0FBRS9DLFFBQUksY0FBYztBQUNsQixRQUFJLFdBQVc7QUFDZixRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVLE1BQU07QUFBRSx3QkFBQSxFQUFvQixNQUFNLE1BQU07QUFBQSxNQUFlLENBQUM7QUFBQSxJQUFHO0FBQUEsRUFDM0UsT0FBTztBQUVMLFFBQUksY0FBYztBQUNsQixRQUFJLFdBQVc7QUFDZixRQUFJLFlBQVk7QUFDaEIsUUFBSSxVQUFVO0FBQUEsRUFDaEI7QUFDRjtBQUVBLGVBQWUsMEJBQXlDO0FBQ3RELFFBQU0sTUFBTSxTQUFTLGVBQWUsaUJBQWlCO0FBQ3JELE1BQUksU0FBUyxXQUFXO0FBRXhCLE1BQUk7QUFDRixVQUFNLGlCQUFpQixxQkFBcUIsRUFBRTtBQUM5QyxlQUFXLG1CQUFtQjtBQUM5QixjQUFBO0FBQUEsRUFDRixRQUFRO0FBQ04sUUFBSSxTQUFTLFdBQVc7QUFBQSxFQUMxQjtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsUUFBeUM7QUFDbEUsUUFBTSxPQUFPLHFCQUFxQixNQUFNO0FBR3hDLGFBQVcsbUJBQW1CO0FBQzlCLGFBQVcsY0FBYztBQUN6QixRQUFNLGtCQUFrQixTQUFTLGVBQWUsa0JBQWtCO0FBQ2xFLE1BQUksaUJBQWlCO0FBQ25CLG9CQUFnQixVQUFVLElBQUksUUFBUTtBQUN0QyxvQkFBZ0IsWUFBWTtBQUFBLEVBQzlCO0FBQ0EsWUFBQTtBQUVBLG1CQUFpQixxQkFBcUIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3pELFlBQVEsTUFBTSxnRUFBZ0UsR0FBRztBQUFBLEVBQ25GLENBQUM7QUFDSDtBQUVBLFNBQVMsd0JBQThCO0FBRXJDLE1BQUksd0JBQXdCLE1BQU07QUFDaEMsa0JBQWMsbUJBQW1CO0FBQ2pDLDBCQUFzQjtBQUFBLEVBQ3hCO0FBRUEsUUFBTSxVQUFVLFNBQVMsZUFBZSxvQkFBb0I7QUFDNUQsTUFBSSxDQUFDLFFBQVM7QUFFZCxNQUFJLFdBQVcsa0JBQWtCO0FBQy9CLFVBQU0sT0FBTyxXQUFXO0FBQ3hCLFVBQU0sY0FBc0M7QUFBQSxNQUMxQyxVQUFVO0FBQUEsTUFDVixTQUFTO0FBQUEsTUFDVCxZQUFZO0FBQUEsSUFBQTtBQUdkLFlBQVEsWUFBWTtBQUNwQixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBRWhCLFVBQU0sWUFBWSxTQUFTLGNBQWMsTUFBTTtBQUMvQyxVQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFDOUMsV0FBTyxjQUFjLFlBQVksS0FBSyxNQUFNLEtBQUssS0FBSztBQUN0RCxjQUFVLFlBQVksTUFBTTtBQUU1QixRQUFJLEtBQUssTUFBTSxXQUFXO0FBT3hCLFVBQVMsa0JBQVQsV0FBaUM7QUFDL0IsY0FBTSxZQUFZLFlBQVksS0FBSyxJQUFBO0FBQ25DLFlBQUksYUFBYSxHQUFHO0FBRWxCLGNBQUksd0JBQXdCLE1BQU07QUFDaEMsMEJBQWMsbUJBQW1CO0FBQ2pDLGtDQUFzQjtBQUFBLFVBQ3hCO0FBQ0EsbUJBQVMsTUFBTSxRQUFRO0FBQ3ZCLG1CQUFTLGNBQWM7QUFHdkIsZ0NBQUEsRUFBd0IsTUFBTSxNQUFNO0FBQUEsVUFBZSxDQUFDO0FBQ3BEO0FBQUEsUUFDRjtBQUVBLGNBQU0sZUFBZSxLQUFLLE1BQU0sWUFBWSxHQUFJO0FBQ2hELGNBQU0sT0FBTyxLQUFLLE1BQU0sZUFBZSxFQUFFO0FBQ3pDLGNBQU0sT0FBTyxlQUFlO0FBQzVCLGNBQU0sYUFBYSxLQUFLLFNBQUEsRUFBVyxTQUFTLEdBQUcsR0FBRztBQUNsRCxpQkFBUyxNQUFNLFFBQVEsWUFBWSxNQUMvQix3QkFDQTtBQUNKLGlCQUFTLGNBQWMsS0FBSyxJQUFJLElBQUksVUFBVTtBQUFBLE1BQ2hEO0FBOUJBLFlBQU0sWUFBWSxJQUFJLEtBQUssS0FBSyxNQUFNLFVBQVUsU0FBUyxFQUFFLFFBQUE7QUFDM0QsWUFBTSxXQUFXLFNBQVMsY0FBYyxNQUFNO0FBQzlDLGVBQVMsS0FBSztBQUNkLGVBQVMsTUFBTSxVQUFVO0FBQ3pCLGdCQUFVLFlBQVksUUFBUTtBQTZCOUIsc0JBQUE7QUFDQSw0QkFBc0IsWUFBWSxpQkFBaUIsR0FBSTtBQUFBLElBQ3pEO0FBRUEsVUFBTSxZQUFZLFNBQVMsY0FBYyxRQUFRO0FBQ2pELGNBQVUsS0FBSztBQUNmLGNBQVUsWUFBWTtBQUN0QixjQUFVLGNBQWM7QUFDeEIsY0FBVSxpQkFBaUIsU0FBUyx1QkFBdUI7QUFFM0QsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxZQUFZLFNBQVM7QUFDekIsWUFBUSxZQUFZLEdBQUc7QUFBQSxFQUN6QixPQUFPO0FBQ0wsVUFBTSxhQUFhLFdBQVcsZ0JBQWdCO0FBQzlDLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQSx3REFHZ0MsYUFBYSxrQkFBa0IsYUFBYSxZQUFZLGFBQWEsV0FBVyxXQUFXO0FBQUE7QUFBQTtBQUcvSSxVQUFNLFlBQVksU0FBUyxlQUFlLHVCQUF1QjtBQUNqRSxRQUFJLFdBQVc7QUFDYixnQkFBVSxpQkFBaUIsU0FBUyx1QkFBdUI7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQThCO0FBQ3JDLFFBQU0sUUFBUSxTQUFTLGVBQWUsa0JBQWtCO0FBQ3hELFFBQU0sWUFBWSxTQUFTLGVBQWUsaUJBQWlCO0FBQzNELE1BQUksQ0FBQyxhQUFhLENBQUMsTUFBTztBQUUxQixNQUFJLFdBQVcsaUJBQWlCLFdBQVcsR0FBRztBQUM1QyxVQUFNLFVBQVUsSUFBSSxRQUFRO0FBQzVCO0FBQUEsRUFDRjtBQUVBLFFBQU0sVUFBVSxPQUFPLFFBQVE7QUFDL0IsWUFBVSxZQUFZO0FBQ3RCLGFBQVcsU0FBUyxXQUFXLGlCQUFpQixNQUFNLEdBQUcsRUFBRSxXQUFXO0FBQ3BFLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFFakIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUVoQixVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxNQUFNLFVBQVU7QUFFckIsVUFBTSxTQUFTLFNBQVMsY0FBYyxLQUFLO0FBQzNDLFdBQU8sTUFBTSxVQUFVO0FBRXZCLFVBQU0sWUFBWSxTQUFTLGNBQWMsTUFBTTtBQUMvQyxjQUFVLE1BQU0sVUFBVTtBQUMxQixjQUFVLGNBQWMsTUFBTTtBQUU5QixVQUFNLFdBQVcsU0FBUyxjQUFjLE1BQU07QUFDOUMsYUFBUyxZQUFZLDJCQUEyQixNQUFNLFFBQVE7QUFDOUQsYUFBUyxjQUFjLE1BQU07QUFFN0IsV0FBTyxZQUFZLFNBQVM7QUFDNUIsV0FBTyxZQUFZLFFBQVE7QUFFM0IsVUFBTSxVQUFVLFNBQVMsY0FBYyxLQUFLO0FBQzVDLFlBQVEsTUFBTSxVQUFVO0FBQ3hCLFlBQVEsY0FBYyxZQUFZLE1BQU0sVUFBVSxHQUFHO0FBRXJELFVBQU0sU0FBUyxTQUFTLGNBQWMsS0FBSztBQUMzQyxXQUFPLE1BQU0sVUFBVTtBQUN2QixXQUFPLGNBQWMsZ0JBQWdCLE1BQU0sVUFBVSxTQUFTO0FBRTlELFNBQUssWUFBWSxNQUFNO0FBQ3ZCLFNBQUssWUFBWSxPQUFPO0FBQ3hCLFNBQUssWUFBWSxNQUFNO0FBQ3ZCLFNBQUssWUFBWSxHQUFHO0FBQ3BCLFNBQUssWUFBWSxJQUFJO0FBQ3JCLGNBQVUsWUFBWSxJQUFJO0FBQUEsRUFDNUI7QUFDRjtBQUVBLFNBQVMsc0JBQTRCO0FBQ25DLFFBQU0sUUFBUSxTQUFTLGVBQWUsZ0JBQWdCO0FBQ3RELFFBQU0sWUFBWSxTQUFTLGVBQWUsZUFBZTtBQUN6RCxNQUFJLENBQUMsYUFBYSxDQUFDLE1BQU87QUFFMUIsUUFBTSxXQUFXLFdBQVc7QUFHNUIsUUFBTSxjQUFjLFNBQVMsS0FBSyxPQUFLLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFDMUQsTUFBSSxDQUFDLGFBQWE7QUFDaEIsVUFBTSxVQUFVLElBQUksUUFBUTtBQUM1QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFVBQVUsT0FBTyxRQUFRO0FBQy9CLFlBQVUsWUFBWTtBQUd0QixNQUFJLFNBQVMsV0FBVyxHQUFHO0FBQ3pCLFVBQU0sUUFBUSxTQUFTLGNBQWMsR0FBRztBQUN4QyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxjQUFjO0FBQ3BCLGNBQVUsWUFBWSxLQUFLO0FBQzNCO0FBQUEsRUFDRjtBQUdBLFFBQU0sZ0JBQWdCLFNBQVMsV0FBVztBQUUxQyxhQUFXLFdBQVcsVUFBVTtBQXdHOUIsUUFBUyxjQUFULFdBQTZCO0FBQzNCLFlBQU0sV0FBVyxVQUFVLFVBQVUsU0FBUyxRQUFRO0FBQ3RELFVBQUksVUFBVTtBQUNaLGtCQUFVLFVBQVUsT0FBTyxRQUFRO0FBQ25DLGdCQUFRLGNBQWM7QUFBQSxNQUN4QixPQUFPO0FBQ0wsa0JBQVUsVUFBVSxJQUFJLFFBQVE7QUFDaEMsZ0JBQVEsY0FBYztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQS9HQSxRQUFJLFFBQVEsT0FBTyxXQUFXLEVBQUc7QUFFakMsVUFBTSxRQUFRLFNBQVMsY0FBYyxLQUFLO0FBQzFDLFVBQU0sWUFBWTtBQUdsQixVQUFNLFNBQVMsU0FBUyxjQUFjLEtBQUs7QUFDM0MsV0FBTyxZQUFZO0FBQ25CLFdBQU8sYUFBYSxRQUFRLFFBQVE7QUFDcEMsV0FBTyxhQUFhLFlBQVksR0FBRztBQUVuQyxVQUFNLGFBQWEsU0FBUyxjQUFjLEtBQUs7QUFDL0MsZUFBVyxZQUFZO0FBRXZCLFVBQU0sWUFBWSxTQUFTLGNBQWMsTUFBTTtBQUMvQyxjQUFVLFlBQVk7QUFDdEIsY0FBVSxjQUFjLGdCQUFnQixRQUFRLE1BQU0sSUFBSTtBQUUxRCxVQUFNLGFBQWEsU0FBUyxjQUFjLE1BQU07QUFDaEQsZUFBVyxZQUFZO0FBQ3ZCLGVBQVcsY0FBYyxnQkFBZ0IsUUFBUSxTQUFTO0FBRTFELFVBQU0sYUFBYSxTQUFTLGNBQWMsTUFBTTtBQUNoRCxlQUFXLFlBQVk7QUFDdkIsZUFBVyxjQUFjLEdBQUcsUUFBUSxPQUFPLE1BQU0sVUFBVSxRQUFRLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRztBQUVqRyxlQUFXLFlBQVksU0FBUztBQUNoQyxlQUFXLFlBQVksVUFBVTtBQUNqQyxlQUFXLFlBQVksVUFBVTtBQUVqQyxVQUFNLGNBQWMsU0FBUyxjQUFjLEtBQUs7QUFDaEQsZ0JBQVksWUFBWTtBQUV4QixRQUFJLFFBQVEsWUFBWSxNQUFNO0FBQzVCLFlBQU0sY0FBYyxTQUFTLGNBQWMsTUFBTTtBQUNqRCxrQkFBWSxZQUFZO0FBQ3hCLGtCQUFZLGNBQWM7QUFDMUIsa0JBQVksWUFBWSxXQUFXO0FBQUEsSUFDckMsT0FBTztBQUNMLFlBQU0sV0FBVyxTQUFTLGNBQWMsTUFBTTtBQUM5QyxlQUFTLFlBQVk7QUFDckIsZUFBUyxjQUFjLFNBQVMsZ0JBQWdCLFFBQVEsT0FBTyxDQUFDO0FBQ2hFLGtCQUFZLFlBQVksUUFBUTtBQUFBLElBQ2xDO0FBRUEsVUFBTSxVQUFVLFNBQVMsY0FBYyxNQUFNO0FBQzdDLFlBQVEsWUFBWTtBQUNwQixZQUFRLGNBQWMsZ0JBQWdCLE1BQU07QUFDNUMsZ0JBQVksWUFBWSxPQUFPO0FBRS9CLFdBQU8sWUFBWSxVQUFVO0FBQzdCLFdBQU8sWUFBWSxXQUFXO0FBRzlCLFVBQU0sWUFBWSxTQUFTLGNBQWMsS0FBSztBQUM5QyxjQUFVLFlBQVk7QUFDdEIsUUFBSSxDQUFDLGVBQWU7QUFDbEIsZ0JBQVUsVUFBVSxJQUFJLFFBQVE7QUFBQSxJQUNsQztBQUVBLGVBQVcsU0FBUyxRQUFRLFFBQVE7QUFDbEMsWUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFVBQUksWUFBWTtBQUVoQixZQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsWUFBTSxZQUFZO0FBQ2xCLFlBQU0sY0FBYztBQUVwQixZQUFNLFdBQVcsU0FBUyxjQUFjLE1BQU07QUFDOUMsZUFBUyxZQUFZO0FBQ3JCLGVBQVMsY0FBYyxnQkFBZ0IsTUFBTSxTQUFTO0FBRXRELFlBQU0saUJBQWlCLFNBQVMsY0FBYyxNQUFNO0FBQ3BELHFCQUFlLFlBQVk7QUFDM0IscUJBQWUsY0FBYyxNQUFNLG1CQUFtQixNQUFNO0FBRTVELFlBQU0sYUFBYSxTQUFTLGNBQWMsTUFBTTtBQUNoRCxpQkFBVyxZQUFZO0FBQ3ZCLFlBQU0sU0FBUyxNQUFNLGlCQUNqQixZQUFZLE1BQU0sZ0JBQWdCLEVBQUUsSUFDcEMsWUFBWSxNQUFNLEtBQUssRUFBRTtBQUM3QixpQkFBVyxjQUFjO0FBQ3pCLGlCQUFXLFFBQVEsTUFBTSxrQkFBa0IsTUFBTTtBQUVqRCxZQUFNLGNBQWMsU0FBUyxjQUFjLE1BQU07QUFDakQsWUFBTSxlQUFlLE1BQU0sWUFBWSxZQUNuQyx5QkFDQSxNQUFNLFlBQVksWUFDaEIseUJBQ0E7QUFDTixrQkFBWSxZQUFZLGdCQUFnQixZQUFZO0FBQ3BELGtCQUFZLGNBQWMsTUFBTTtBQUVoQyxVQUFJLFlBQVksS0FBSztBQUNyQixVQUFJLFlBQVksUUFBUTtBQUN4QixVQUFJLFlBQVksY0FBYztBQUM5QixVQUFJLFlBQVksVUFBVTtBQUMxQixVQUFJLFlBQVksV0FBVztBQUMzQixnQkFBVSxZQUFZLEdBQUc7QUFBQSxJQUMzQjtBQWNBLFdBQU8saUJBQWlCLFNBQVMsV0FBVztBQUM1QyxXQUFPLGlCQUFpQixXQUFXLENBQUMsTUFBcUI7QUFDdkQsVUFBSSxFQUFFLFFBQVEsV0FBVyxFQUFFLFFBQVEsS0FBSztBQUN0QyxVQUFFLGVBQUE7QUFDRixvQkFBQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFFRCxVQUFNLFlBQVksTUFBTTtBQUN4QixVQUFNLFlBQVksU0FBUztBQUMzQixjQUFVLFlBQVksS0FBSztBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxTQUFTLHFCQUEyQjtBQUNsQyxRQUFNLFFBQVEsU0FBUyxlQUFlLGVBQWU7QUFDckQsUUFBTSxPQUFPLFNBQVMsZUFBZSxjQUFjO0FBQ25ELFFBQU0sUUFBUSxTQUFTLGVBQWUsZUFBZTtBQUNyRCxNQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFPO0FBRS9CLFFBQU0sUUFBUSxXQUFXO0FBQ3pCLE1BQUksQ0FBQyxTQUFTLE1BQU0sa0JBQWtCLEdBQUc7QUFDdkMsVUFBTSxVQUFVLElBQUksUUFBUTtBQUM1QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFVBQVUsT0FBTyxRQUFRO0FBQy9CLE9BQUssWUFBWTtBQUdqQixnQkFBYyxNQUFNLE9BQU8sTUFBTSxhQUFhLEdBQUcsb0JBQW9CO0FBR3JFLE1BQUksTUFBTSxzQkFBc0IsR0FBRztBQUNqQyxrQkFBYyxNQUFNLE9BQU8sTUFBTSxtQkFBbUIsR0FBRyxpQkFBaUI7QUFBQSxFQUMxRSxPQUFPO0FBQ0wsa0JBQWMsTUFBTSxRQUFRLHFCQUFxQjtBQUFBLEVBQ25EO0FBR0EsUUFBTSxRQUFRLE9BQU8sUUFBUSxNQUFNLGtCQUFrQjtBQUNyRCxNQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3BCLFVBQU0sVUFBVSxNQUFNLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztBQUN0RCxrQkFBYyxNQUFNLGdCQUFnQixPQUFPLEdBQUcscUJBQXFCO0FBQUEsRUFDckUsT0FBTztBQUNMLFVBQU0sY0FBYyxNQUFNO0FBQzFCLGtCQUFjLE1BQU0sT0FBTyxXQUFXLEdBQUcsaUJBQWlCO0FBQUEsRUFDNUQ7QUFHQSxRQUFNLGNBQWM7QUFDcEIsTUFBSSxNQUFNLGVBQWU7QUFDdkIsVUFBTSxPQUFPLElBQUksS0FBSyxNQUFNLGFBQWE7QUFDekMsVUFBTSxZQUFZLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxRQUFBLEtBQWEsS0FBUTtBQUNyRSxVQUFNLFVBQVUsS0FBSyxtQkFBbUIsUUFBVyxFQUFFLE9BQU8sU0FBUyxLQUFLLFdBQVcsTUFBTSxVQUFBLENBQVc7QUFDdEcsVUFBTSxZQUFZLFNBQVMsY0FBYyxNQUFNO0FBQy9DLGNBQVUsY0FBYyxjQUFjLElBQ2xDLGtDQUFrQyxPQUFPLE1BQ3pDLDJCQUEyQixPQUFPLEtBQUssU0FBUyxPQUFPLGNBQWMsSUFBSSxLQUFLLEdBQUc7QUFDckYsVUFBTSxZQUFZLFNBQVM7QUFBQSxFQUM3QjtBQUNGO0FBRUEsU0FBUyxjQUFjLFdBQXdCLE9BQWUsT0FBcUI7QUFDakYsUUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLE9BQUssWUFBWTtBQUVqQixRQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYztBQUVsQixRQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYztBQUVsQixPQUFLLFlBQVksR0FBRztBQUNwQixPQUFLLFlBQVksR0FBRztBQUNwQixZQUFVLFlBQVksSUFBSTtBQUM1QjtBQUVBLFNBQVMsb0JBQTBCO0FBQ2pDLFFBQU0sWUFBWSxTQUFTLGVBQWUsa0JBQWtCO0FBQzVELFFBQU0sYUFBYSxTQUFTLGVBQWUsYUFBYTtBQUN4RCxNQUFJLENBQUMsYUFBYSxDQUFDLFdBQVk7QUFFL0IsWUFBVSxVQUFVLE9BQU8sZUFBZSxtQkFBbUIsaUJBQWlCLGtCQUFrQjtBQUVoRyxNQUFJLFdBQVcsa0JBQWtCO0FBQy9CLGNBQVUsVUFBVSxJQUFJLGVBQWU7QUFDdkMsZUFBVyxjQUFjO0FBQUEsRUFDM0IsV0FBVyxXQUFXLGVBQWUsU0FBUyxHQUFHO0FBQy9DLGNBQVUsVUFBVSxJQUFJLGlCQUFpQjtBQUN6QyxlQUFXLGNBQWMsR0FBRyxXQUFXLGVBQWUsTUFBTTtBQUFBLEVBQzlELFdBQVcsV0FBVyxrQkFBa0I7QUFDdEMsY0FBVSxVQUFVLElBQUksa0JBQWtCO0FBQzFDLGVBQVcsY0FBYztBQUFBLEVBQzNCLE9BQU87QUFDTCxjQUFVLFVBQVUsSUFBSSxhQUFhO0FBQ3JDLGVBQVcsY0FBYztBQUFBLEVBQzNCO0FBQ0Y7QUFFQSxlQUFlLGlCQUFpQixNQUFtQixNQUFpQztBQUNsRixRQUFNLFVBQTBCO0FBQUEsSUFDOUI7QUFBQSxJQUNBO0FBQUEsSUFDQSxTQUFRLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsRUFBWTtBQUdqQyxNQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsT0FBTyxTQUFTO0FBQ3BELFdBQU8sUUFBUSxPQUFPLElBQUksTUFBTSw4QkFBOEIsQ0FBQztBQUFBLEVBQ2pFO0FBRUEsU0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsV0FBTyxRQUFRLFlBQVksU0FBUyxDQUFDLGFBQWE7QUFDaEQsVUFBSSxPQUFPLFFBQVEsV0FBVztBQUM1QixlQUFPLElBQUksTUFBTSxPQUFPLFFBQVEsVUFBVSxPQUFPLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsZ0JBQVEsUUFBUTtBQUFBLE1BQ2xCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBQ0g7QUFFQSxTQUFTLGdCQUFnQixjQUE4QjtBQUNyRCxRQUFNLE9BQU8sSUFBSSxLQUFLLFlBQVk7QUFDbEMsU0FBTyxLQUFLLG1CQUFtQixRQUFXO0FBQUEsSUFDeEMsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLEVBQUEsQ0FDVDtBQUNIO0FBR0EsU0FBUyxnQkFBZ0IsY0FBOEI7QUFDckQsUUFBTSxPQUFPLElBQUksS0FBSyxZQUFZO0FBQ2xDLFNBQU8sS0FBSyxtQkFBbUIsUUFBVztBQUFBLElBQ3hDLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxFQUFBLENBQ1Q7QUFDSDtBQUVBLFNBQVMsZ0JBQWdCLE1BQXNCO0FBQzdDLFFBQU0sUUFBZ0M7QUFBQSxJQUNwQyxZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxVQUFVO0FBQUEsSUFDViwwQkFBMEI7QUFBQSxJQUMxQixtQkFBbUI7QUFBQSxJQUNuQixlQUFlO0FBQUEsSUFDZixxQkFBcUI7QUFBQSxJQUNyQixTQUFTO0FBQUEsRUFBQTtBQUVYLFNBQU8sTUFBTSxJQUFJLEtBQUs7QUFDeEI7QUFFQSxTQUFTLFlBQVksS0FBYSxZQUFvQixJQUFZO0FBQ2hFLE1BQUksSUFBSSxVQUFVLFVBQVcsUUFBTztBQUNwQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksSUFBSSxHQUFHO0FBQzFCLFVBQU0sT0FBTyxPQUFPO0FBQ3BCLFVBQU0sT0FBTyxPQUFPO0FBQ3BCLFVBQU0sWUFBWSxZQUFZLEtBQUssU0FBUztBQUM1QyxRQUFJLGFBQWEsRUFBRyxRQUFPLEtBQUssVUFBVSxHQUFHLFlBQVksQ0FBQyxJQUFJO0FBQzlELFdBQU8sT0FBTyxLQUFLLFVBQVUsR0FBRyxTQUFTLElBQUk7QUFBQSxFQUMvQyxRQUFRO0FBQ04sV0FBTyxJQUFJLFVBQVUsR0FBRyxZQUFZLENBQUMsSUFBSTtBQUFBLEVBQzNDO0FBQ0Y7QUFFQSxXQUFBOyJ9
