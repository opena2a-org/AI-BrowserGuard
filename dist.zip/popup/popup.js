(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function generateId() {
  return crypto.randomUUID();
}
const READ_ONLY_CAPABILITIES = ["navigate", "read-dom"];
const LIMITED_CAPABILITIES = ["navigate", "read-dom", "click", "type-text"];
const ALL_CAPABILITIES = [
  "navigate",
  "read-dom",
  "click",
  "type-text",
  "submit-form",
  "download-file",
  "open-tab",
  "close-tab",
  "screenshot",
  "execute-script",
  "modify-dom"
];
function buildActionRestrictions(allowed) {
  return ALL_CAPABILITIES.map((cap) => ({
    capability: cap,
    action: allowed.includes(cap) ? "allow" : "block"
  }));
}
function createRuleFromPreset(preset, options) {
  const now = /* @__PURE__ */ new Date();
  let scope;
  switch (preset) {
    case "readOnly":
      scope = {
        sitePatterns: [],
        actionRestrictions: buildActionRestrictions(READ_ONLY_CAPABILITIES),
        timeBound: null
      };
      break;
    case "limited": {
      const durationMinutes = options?.durationMinutes ?? 60;
      const expiresAt = new Date(now.getTime() + durationMinutes * 6e4);
      const timeBound = {
        durationMinutes,
        grantedAt: now.toISOString(),
        expiresAt: expiresAt.toISOString()
      };
      scope = {
        sitePatterns: options?.sitePatterns ?? [],
        actionRestrictions: buildActionRestrictions(LIMITED_CAPABILITIES),
        timeBound
      };
      break;
    }
    case "fullAccess":
      scope = {
        sitePatterns: [],
        actionRestrictions: buildActionRestrictions(ALL_CAPABILITIES),
        timeBound: null
      };
      break;
  }
  return {
    id: generateId(),
    preset,
    scope,
    createdAt: now.toISOString(),
    isActive: true,
    label: options?.label
  };
}
const TIME_DURATION_OPTIONS = [
  { label: "15 minutes", minutes: 15 },
  { label: "1 hour", minutes: 60 },
  { label: "4 hours", minutes: 240 }
];
function createInitialWizardState() {
  return {
    currentStep: "preset",
    selectedPreset: null,
    sitePatterns: [],
    durationMinutes: null,
    label: "",
    errors: []
  };
}
function selectPreset(state, preset) {
  const nextStep2 = preset === "limited" ? "sites" : "confirm";
  return {
    ...state,
    selectedPreset: preset,
    currentStep: nextStep2,
    errors: []
  };
}
function addSitePattern(state, pattern) {
  if (!pattern.pattern.trim()) {
    return { ...state, errors: ["Pattern cannot be empty."] };
  }
  const exists = state.sitePatterns.some((p) => p.pattern === pattern.pattern);
  if (exists) {
    return { ...state, errors: ["This pattern already exists."] };
  }
  return {
    ...state,
    sitePatterns: [...state.sitePatterns, pattern],
    errors: []
  };
}
function removeSitePattern(state, index) {
  const sitePatterns = state.sitePatterns.filter((_, i) => i !== index);
  return { ...state, sitePatterns, errors: [] };
}
function setDuration(state, minutes) {
  const valid = TIME_DURATION_OPTIONS.some((opt) => opt.minutes === minutes);
  if (!valid) {
    return { ...state, errors: ["Invalid duration. Choose 15 minutes, 1 hour, or 4 hours."] };
  }
  return { ...state, durationMinutes: minutes, errors: [] };
}
function nextStep(state) {
  switch (state.currentStep) {
    case "preset":
      if (!state.selectedPreset) {
        return { ...state, errors: ["Select a delegation preset."] };
      }
      if (state.selectedPreset === "limited") {
        return { ...state, currentStep: "sites", errors: [] };
      }
      return { ...state, currentStep: "confirm", errors: [] };
    case "sites":
      if (state.sitePatterns.length === 0) {
        return { ...state, errors: ["Add at least one site pattern."] };
      }
      return { ...state, currentStep: "time", errors: [] };
    case "time":
      if (state.durationMinutes === null) {
        return { ...state, errors: ["Select a time duration."] };
      }
      return { ...state, currentStep: "confirm", errors: [] };
    case "confirm":
      return state;
    default:
      return state;
  }
}
function previousStep(state) {
  const stepOrder = ["preset", "sites", "time", "confirm"];
  const currentIndex = stepOrder.indexOf(state.currentStep);
  if (currentIndex <= 0) return state;
  if (state.currentStep === "confirm" && state.selectedPreset !== "limited") {
    return { ...state, currentStep: "preset", errors: [] };
  }
  return { ...state, currentStep: stepOrder[currentIndex - 1], errors: [] };
}
function finalizeWizard(state) {
  if (!state.selectedPreset) return null;
  if (state.selectedPreset === "limited") {
    if (state.sitePatterns.length === 0) return null;
    if (state.durationMinutes === null) return null;
  }
  return createRuleFromPreset(state.selectedPreset, {
    sitePatterns: state.sitePatterns,
    durationMinutes: state.durationMinutes ?? void 0,
    label: state.label || void 0
  });
}
const PRESET_DESCRIPTIONS = {
  readOnly: {
    title: "Read-Only",
    description: "Agent can navigate and read page content. Cannot click, type, or submit forms."
  },
  limited: {
    title: "Limited Access",
    description: "Agent can interact with specific sites you choose, with a time limit."
  },
  fullAccess: {
    title: "Full Access",
    description: "Agent can perform any action. All activity is logged with boundary alerts."
  }
};
function renderWizard(container, state, onStateChange) {
  container.innerHTML = "";
  if (state.errors.length > 0) {
    const errorDiv = document.createElement("div");
    errorDiv.className = "wizard-errors";
    errorDiv.style.cssText = "color: var(--danger); font-size: 12px; margin-bottom: 8px;";
    errorDiv.textContent = state.errors.join(" ");
    container.appendChild(errorDiv);
  }
  switch (state.currentStep) {
    case "preset":
      renderPresetStep(container, state, onStateChange);
      break;
    case "sites":
      renderSitesStep(container, state, onStateChange);
      break;
    case "time":
      renderTimeStep(container, state, onStateChange);
      break;
    case "confirm":
      renderConfirmStep(container, state, onStateChange);
      break;
  }
}
function renderPresetStep(container, state, onStateChange) {
  const presets = ["readOnly", "limited", "fullAccess"];
  for (const preset of presets) {
    const info = PRESET_DESCRIPTIONS[preset];
    const card = document.createElement("div");
    card.className = `preset-card${state.selectedPreset === preset ? " selected" : ""}`;
    card.innerHTML = `
      <strong>${info.title}</strong>
      <p style="margin: 4px 0 0; font-size: 11px; color: var(--text-secondary);">${info.description}</p>
    `;
    card.addEventListener("click", () => {
      onStateChange(selectPreset(state, preset));
    });
    container.appendChild(card);
  }
}
function renderSitesStep(container, state, onStateChange) {
  const heading = document.createElement("p");
  heading.style.cssText = "font-size: 12px; color: var(--text-secondary); margin-bottom: 8px;";
  heading.textContent = "Add sites the agent can access (glob patterns):";
  container.appendChild(heading);
  const inputRow = document.createElement("div");
  inputRow.style.cssText = "display: flex; gap: 6px; margin-bottom: 8px;";
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "e.g., *.example.com";
  input.className = "form-input";
  input.style.cssText = "flex: 1;";
  const addBtn = document.createElement("button");
  addBtn.className = "btn btn-primary";
  addBtn.textContent = "Add";
  addBtn.style.cssText = "padding: 4px 12px; font-size: 12px;";
  addBtn.addEventListener("click", () => {
    const value = input.value.trim();
    if (value) {
      onStateChange(addSitePattern(state, { pattern: value, action: "allow" }));
      input.value = "";
    }
  });
  inputRow.appendChild(input);
  inputRow.appendChild(addBtn);
  container.appendChild(inputRow);
  for (let i = 0; i < state.sitePatterns.length; i++) {
    const p = state.sitePatterns[i];
    const row = document.createElement("div");
    row.style.cssText = "display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 12px;";
    row.innerHTML = `<span style="color: var(--text-primary);">${p.pattern} (${p.action})</span>`;
    const removeBtn = document.createElement("button");
    removeBtn.className = "btn btn-secondary";
    removeBtn.textContent = "Remove";
    removeBtn.style.cssText = "padding: 2px 8px; font-size: 11px;";
    removeBtn.addEventListener("click", () => onStateChange(removeSitePattern(state, i)));
    row.appendChild(removeBtn);
    container.appendChild(row);
  }
  renderNavButtons(container, state, onStateChange);
}
function renderTimeStep(container, state, onStateChange) {
  const heading = document.createElement("p");
  heading.style.cssText = "font-size: 12px; color: var(--text-secondary); margin-bottom: 8px;";
  heading.textContent = "How long should the delegation last?";
  container.appendChild(heading);
  for (const option of TIME_DURATION_OPTIONS) {
    const btn = document.createElement("button");
    btn.className = `btn ${state.durationMinutes === option.minutes ? "btn-primary" : "btn-secondary"}`;
    btn.textContent = option.label;
    btn.style.cssText = "display: block; width: 100%; margin-bottom: 6px;";
    btn.addEventListener("click", () => {
      const updated = setDuration(state, option.minutes);
      onStateChange(nextStep(updated));
    });
    container.appendChild(btn);
  }
  renderNavButtons(container, state, onStateChange, true);
}
function renderConfirmStep(container, state, onStateChange) {
  const preset = state.selectedPreset;
  if (!preset) return;
  const info = PRESET_DESCRIPTIONS[preset];
  const summary = document.createElement("div");
  summary.style.cssText = "font-size: 12px; color: var(--text-secondary);";
  let html = `<p><strong>Preset:</strong> ${info.title}</p>`;
  if (state.sitePatterns.length > 0) {
    html += `<p><strong>Sites:</strong> ${state.sitePatterns.map((p) => p.pattern).join(", ")}</p>`;
  }
  if (state.durationMinutes) {
    const opt = TIME_DURATION_OPTIONS.find((o) => o.minutes === state.durationMinutes);
    html += `<p><strong>Duration:</strong> ${opt?.label ?? state.durationMinutes + " minutes"}</p>`;
  }
  summary.innerHTML = html;
  container.appendChild(summary);
  const labelInput = document.createElement("input");
  labelInput.type = "text";
  labelInput.placeholder = "Label (optional)";
  labelInput.className = "form-input";
  labelInput.value = state.label;
  labelInput.style.cssText = "width: 100%; margin: 8px 0;";
  labelInput.addEventListener("input", () => {
    state.label = labelInput.value;
  });
  container.appendChild(labelInput);
  const activateBtn = document.createElement("button");
  activateBtn.className = "btn btn-primary";
  activateBtn.textContent = "Activate Delegation";
  activateBtn.style.cssText = "width: 100%; margin-top: 8px;";
  activateBtn.addEventListener("click", () => {
    const rule = finalizeWizard(state);
    if (rule) {
      container.dispatchEvent(
        new CustomEvent("delegation-activated", { detail: rule, bubbles: true })
      );
    }
  });
  container.appendChild(activateBtn);
  renderNavButtons(container, state, onStateChange, true);
}
function renderNavButtons(container, state, onStateChange, showBack = false) {
  const nav = document.createElement("div");
  nav.style.cssText = "display: flex; justify-content: space-between; margin-top: 8px;";
  if (showBack) {
    const backBtn = document.createElement("button");
    backBtn.className = "btn btn-secondary";
    backBtn.textContent = "Back";
    backBtn.style.cssText = "font-size: 11px;";
    backBtn.addEventListener("click", () => onStateChange(previousStep(state)));
    nav.appendChild(backBtn);
  }
  if (state.currentStep === "sites") {
    const nextBtn = document.createElement("button");
    nextBtn.className = "btn btn-primary";
    nextBtn.textContent = "Next";
    nextBtn.style.cssText = "font-size: 11px; margin-left: auto;";
    nextBtn.addEventListener("click", () => onStateChange(nextStep(state)));
    nav.appendChild(nextBtn);
  }
  if (nav.children.length > 0) {
    container.appendChild(nav);
  }
}
let popupState = {
  detectedAgents: [],
  activeDelegation: null,
  killSwitchActive: false,
  recentViolations: [],
  sessions: [],
  wizardState: null,
  loading: true
};
function initialize() {
  document.addEventListener("DOMContentLoaded", () => {
    setupEventListeners();
    queryBackgroundStatus();
  });
}
async function queryBackgroundStatus() {
  try {
    const response = await sendToBackground("STATUS_QUERY", {});
    if (response && typeof response === "object") {
      const data = response;
      popupState.detectedAgents = data.detectedAgents ?? [];
      popupState.activeDelegation = data.activeDelegation ?? null;
      popupState.killSwitchActive = data.killSwitchActive ?? false;
      popupState.recentViolations = data.recentViolations ?? [];
    }
  } catch {
  }
  try {
    const sessionResponse = await sendToBackground("SESSION_QUERY", {});
    if (sessionResponse && typeof sessionResponse === "object") {
      const data = sessionResponse;
      popupState.sessions = data.sessions ?? [];
    }
  } catch {
  }
  popupState.loading = false;
  renderAll();
}
function setupEventListeners() {
  const killSwitchBtn = document.getElementById("kill-switch-btn");
  if (killSwitchBtn) {
    killSwitchBtn.addEventListener("click", onKillSwitchClick);
  }
  const wizardBtn = document.getElementById("delegation-wizard-btn");
  if (wizardBtn) {
    wizardBtn.addEventListener("click", onDelegationWizardClick);
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (!message || !message.type) return;
    switch (message.type) {
      case "DETECTION_RESULT":
        queryBackgroundStatus();
        break;
      case "KILL_SWITCH_RESULT":
        popupState.killSwitchActive = true;
        renderAll();
        break;
      case "DELEGATION_UPDATE":
        queryBackgroundStatus();
        break;
    }
  });
  document.addEventListener("delegation-activated", (e) => {
    const rule = e.detail;
    sendToBackground("DELEGATION_UPDATE", rule).then(() => {
      popupState.activeDelegation = rule;
      popupState.wizardState = null;
      const wizardContainer = document.getElementById("wizard-container");
      if (wizardContainer) {
        wizardContainer.classList.add("hidden");
        wizardContainer.innerHTML = "";
      }
      renderAll();
    }).catch(() => {
    });
  });
}
async function onKillSwitchClick() {
  const btn = document.getElementById("kill-switch-btn");
  if (btn) btn.disabled = true;
  try {
    await sendToBackground("KILL_SWITCH_ACTIVATE", { trigger: "button" });
    popupState.killSwitchActive = true;
    popupState.detectedAgents = [];
    popupState.activeDelegation = null;
    renderAll();
  } catch {
    if (btn) btn.disabled = false;
  }
}
function onDelegationWizardClick() {
  const wizardContainer = document.getElementById("wizard-container");
  if (!wizardContainer) return;
  if (wizardContainer.classList.contains("hidden")) {
    wizardContainer.classList.remove("hidden");
    popupState.wizardState = createInitialWizardState();
    renderWizardUI();
  } else {
    wizardContainer.classList.add("hidden");
    wizardContainer.innerHTML = "";
    popupState.wizardState = null;
  }
}
function renderWizardUI() {
  const wizardContainer = document.getElementById("wizard-container");
  if (!wizardContainer || !popupState.wizardState) return;
  renderWizard(wizardContainer, popupState.wizardState, (newState) => {
    popupState.wizardState = newState;
    renderWizardUI();
  });
}
function renderAll() {
  renderDetectionPanel();
  renderKillSwitchPanel();
  renderDelegationPanel();
  renderViolationsPanel();
  renderTimelinePanel();
  renderStatusBadge();
}
function renderDetectionPanel() {
  const container = document.getElementById("detection-content");
  if (!container) return;
  if (popupState.loading) {
    container.innerHTML = '<p class="placeholder-text-inline">Loading...</p>';
    return;
  }
  if (popupState.detectedAgents.length === 0) {
    container.innerHTML = '<p class="placeholder-text-inline">No agents detected</p>';
    return;
  }
  container.innerHTML = "";
  for (const agent of popupState.detectedAgents) {
    const card = document.createElement("div");
    card.className = "detection-card";
    card.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
        <strong>${formatAgentType(agent.type)}</strong>
        <span class="severity-badge severity-badge-high">${agent.confidence}</span>
      </div>
      <div style="font-size: 12px; color: var(--text-secondary); font-weight: 500;">
        ${formatTimestamp(agent.detectedAt)}
        ${agent.detectionMethods.map((m) => `<span class="method-tag">${m}</span>`).join(" ")}
      </div>
    `;
    container.appendChild(card);
  }
}
function renderKillSwitchPanel() {
  const btn = document.getElementById("kill-switch-btn");
  if (!btn) return;
  btn.disabled = popupState.detectedAgents.length === 0 && !popupState.killSwitchActive;
  if (popupState.killSwitchActive) {
    btn.textContent = "Killed";
    btn.disabled = true;
  } else {
    btn.textContent = "Kill Switch";
  }
}
function renderDelegationPanel() {
  const content = document.getElementById("delegation-content");
  if (!content) return;
  if (popupState.activeDelegation) {
    const rule = popupState.activeDelegation;
    const presetNames = {
      readOnly: "Read-Only",
      limited: "Limited",
      fullAccess: "Full Access"
    };
    let timeInfo = "";
    if (rule.scope.timeBound) {
      const remaining = new Date(rule.scope.timeBound.expiresAt).getTime() - Date.now();
      if (remaining > 0) {
        const mins = Math.ceil(remaining / 6e4);
        timeInfo = `<span style="font-size: 12px; font-weight: 500; color: var(--color-warning);"> (${mins}m left)</span>`;
      } else {
        timeInfo = '<span style="font-size: 12px; font-weight: 500; color: var(--color-danger);"> (expired)</span>';
      }
    }
    content.innerHTML = `
      <div class="delegation-empty">
        <span><strong>${presetNames[rule.preset] ?? rule.preset}</strong>${timeInfo}</span>
        <button id="delegation-wizard-btn" class="btn btn-secondary btn-sm">Change</button>
      </div>
    `;
    const wizardBtn = document.getElementById("delegation-wizard-btn");
    if (wizardBtn) {
      wizardBtn.addEventListener("click", onDelegationWizardClick);
    }
  } else {
    content.innerHTML = `
      <div class="delegation-empty">
        <span class="placeholder-text-inline">No delegation active</span>
        <button id="delegation-wizard-btn" class="btn btn-primary btn-sm">Configure</button>
      </div>
    `;
    const wizardBtn = document.getElementById("delegation-wizard-btn");
    if (wizardBtn) {
      wizardBtn.addEventListener("click", onDelegationWizardClick);
    }
  }
}
function renderViolationsPanel() {
  const panel = document.getElementById("violations-panel");
  const container = document.getElementById("violations-list");
  if (!container || !panel) return;
  if (popupState.recentViolations.length === 0) {
    panel.classList.add("hidden");
    return;
  }
  panel.classList.remove("hidden");
  container.innerHTML = "";
  for (const alert of popupState.recentViolations.slice(-10).reverse()) {
    const item = document.createElement("div");
    item.className = "event-item";
    item.innerHTML = `
      <div class="event-outcome outcome-blocked"></div>
      <div style="flex: 1; min-width: 0;">
        <div style="display: flex; justify-content: space-between;">
          <span style="font-size: 13px; font-weight: 600;">${alert.title}</span>
          <span class="severity-badge severity-${alert.severity}">${alert.severity}</span>
        </div>
        <div style="font-size: 12px; color: var(--text-secondary); font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
          ${truncateUrl(alert.violation.url)}
        </div>
        <div style="font-size: 11px; color: var(--text-secondary); font-weight: 500;">
          ${formatTimestamp(alert.violation.timestamp)}
        </div>
      </div>
    `;
    container.appendChild(item);
  }
}
function renderTimelinePanel() {
  const panel = document.getElementById("timeline-panel");
  const container = document.getElementById("timeline-list");
  if (!container || !panel) return;
  const latestSession = popupState.sessions[0];
  if (!latestSession || latestSession.events.length === 0) {
    panel.classList.add("hidden");
    return;
  }
  panel.classList.remove("hidden");
  container.innerHTML = "";
  const recentEvents = latestSession.events.slice(-15).reverse();
  for (const event of recentEvents) {
    const item = document.createElement("div");
    item.className = "event-item";
    const outcomeClass = event.outcome === "allowed" ? "outcome-allowed" : event.outcome === "blocked" ? "outcome-blocked" : "outcome-info";
    item.innerHTML = `
      <div class="event-outcome ${outcomeClass}"></div>
      <div style="flex: 1; min-width: 0;">
        <div style="font-size: 13px; font-weight: 500;">${event.description}</div>
        <div style="font-size: 12px; color: var(--text-secondary); font-weight: 500;">
          ${formatTimestamp(event.timestamp)} | ${truncateUrl(event.url, 30)}
        </div>
      </div>
    `;
    container.appendChild(item);
  }
}
function renderStatusBadge() {
  const indicator = document.getElementById("status-indicator");
  const statusText = document.getElementById("status-text");
  if (!indicator || !statusText) return;
  indicator.classList.remove("status-idle", "status-detected", "status-killed", "status-delegated");
  if (popupState.killSwitchActive) {
    indicator.classList.add("status-killed");
    statusText.textContent = "Killed";
  } else if (popupState.detectedAgents.length > 0) {
    indicator.classList.add("status-detected");
    statusText.textContent = `${popupState.detectedAgents.length} Agent(s) Detected`;
  } else if (popupState.activeDelegation) {
    indicator.classList.add("status-delegated");
    statusText.textContent = "Delegated";
  } else {
    indicator.classList.add("status-idle");
    statusText.textContent = "Monitoring";
  }
}
async function sendToBackground(type, data) {
  const message = {
    type,
    data,
    sentAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
function formatTimestamp(isoTimestamp) {
  const date = new Date(isoTimestamp);
  return date.toLocaleTimeString(void 0, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
}
function formatAgentType(type) {
  const names = {
    playwright: "Playwright",
    puppeteer: "Puppeteer",
    selenium: "Selenium",
    "anthropic-computer-use": "Anthropic Computer Use",
    "openai-operator": "OpenAI Operator",
    "cdp-generic": "CDP Agent",
    "webdriver-generic": "WebDriver Agent",
    unknown: "Unknown Agent"
  };
  return names[type] ?? type;
}
function truncateUrl(url, maxLength = 40) {
  if (url.length <= maxLength) return url;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname;
    const path = parsed.pathname;
    const available = maxLength - host.length - 3;
    if (available <= 0) return host.substring(0, maxLength - 3) + "...";
    return host + path.substring(0, available) + "...";
  } catch {
    return url.substring(0, maxLength - 3) + "...";
  }
}
initialize();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9kZWxlZ2F0aW9uL3J1bGVzLnRzIiwiLi4vLi4vc3JjL2RlbGVnYXRpb24vd2l6YXJkLnRzIiwiLi4vLi4vc3JjL3BvcHVwL3BvcHVwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogRGVsZWdhdGlvbiBydWxlIGVuZ2luZS5cbiAqXG4gKiBFdmFsdWF0ZXMgZGVsZWdhdGlvbiBydWxlcyB0byBkZXRlcm1pbmUgd2hhdCBhY3Rpb25zIGFuIGFnZW50IGlzXG4gKiBwZXJtaXR0ZWQgdG8gcGVyZm9ybS4gU3VwcG9ydHMgc2l0ZSBwYXR0ZXJucywgYWN0aW9uIHJlc3RyaWN0aW9ucyxcbiAqIGFuZCB0aW1lIGJvdW5kcy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7XG4gIERlbGVnYXRpb25SdWxlLFxuICBEZWxlZ2F0aW9uUHJlc2V0LFxuICBEZWxlZ2F0aW9uU2NvcGUsXG4gIERlbGVnYXRpb25Ub2tlbixcbiAgU2l0ZVBhdHRlcm4sXG4gIEFjdGlvblJlc3RyaWN0aW9uLFxuICBUaW1lQm91bmQsXG59IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSWQoKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKCk7XG59XG5cbmNvbnN0IFJFQURfT05MWV9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbSddO1xuY29uc3QgTElNSVRFRF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbScsICdjbGljaycsICd0eXBlLXRleHQnXTtcbmNvbnN0IEFMTF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gW1xuICAnbmF2aWdhdGUnLCAncmVhZC1kb20nLCAnY2xpY2snLCAndHlwZS10ZXh0JywgJ3N1Ym1pdC1mb3JtJyxcbiAgJ2Rvd25sb2FkLWZpbGUnLCAnb3Blbi10YWInLCAnY2xvc2UtdGFiJywgJ3NjcmVlbnNob3QnLFxuICAnZXhlY3V0ZS1zY3JpcHQnLCAnbW9kaWZ5LWRvbScsXG5dO1xuXG5mdW5jdGlvbiBidWlsZEFjdGlvblJlc3RyaWN0aW9ucyhhbGxvd2VkOiBBZ2VudENhcGFiaWxpdHlbXSk6IEFjdGlvblJlc3RyaWN0aW9uW10ge1xuICByZXR1cm4gQUxMX0NBUEFCSUxJVElFUy5tYXAoKGNhcCkgPT4gKHtcbiAgICBjYXBhYmlsaXR5OiBjYXAsXG4gICAgYWN0aW9uOiBhbGxvd2VkLmluY2x1ZGVzKGNhcCkgPyAnYWxsb3cnIGFzIGNvbnN0IDogJ2Jsb2NrJyBhcyBjb25zdCxcbiAgfSkpO1xufVxuXG4vKipcbiAqIENyZWF0ZSBhIGRlbGVnYXRpb24gcnVsZSBmcm9tIGEgcHJlc2V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUnVsZUZyb21QcmVzZXQoXG4gIHByZXNldDogRGVsZWdhdGlvblByZXNldCxcbiAgb3B0aW9ucz86IHtcbiAgICBzaXRlUGF0dGVybnM/OiBTaXRlUGF0dGVybltdO1xuICAgIGR1cmF0aW9uTWludXRlcz86IG51bWJlcjtcbiAgICBsYWJlbD86IHN0cmluZztcbiAgfVxuKTogRGVsZWdhdGlvblJ1bGUge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICBsZXQgc2NvcGU6IERlbGVnYXRpb25TY29wZTtcblxuICBzd2l0Y2ggKHByZXNldCkge1xuICAgIGNhc2UgJ3JlYWRPbmx5JzpcbiAgICAgIHNjb3BlID0ge1xuICAgICAgICBzaXRlUGF0dGVybnM6IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKFJFQURfT05MWV9DQVBBQklMSVRJRVMpLFxuICAgICAgICB0aW1lQm91bmQ6IG51bGwsXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG5cbiAgICBjYXNlICdsaW1pdGVkJzoge1xuICAgICAgY29uc3QgZHVyYXRpb25NaW51dGVzID0gb3B0aW9ucz8uZHVyYXRpb25NaW51dGVzID8/IDYwO1xuICAgICAgY29uc3QgZXhwaXJlc0F0ID0gbmV3IERhdGUobm93LmdldFRpbWUoKSArIGR1cmF0aW9uTWludXRlcyAqIDYwMDAwKTtcbiAgICAgIGNvbnN0IHRpbWVCb3VuZDogVGltZUJvdW5kID0ge1xuICAgICAgICBkdXJhdGlvbk1pbnV0ZXMsXG4gICAgICAgIGdyYW50ZWRBdDogbm93LnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGV4cGlyZXNBdDogZXhwaXJlc0F0LnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogb3B0aW9ucz8uc2l0ZVBhdHRlcm5zID8/IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKExJTUlURURfQ0FQQUJJTElUSUVTKSxcbiAgICAgICAgdGltZUJvdW5kLFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGNhc2UgJ2Z1bGxBY2Nlc3MnOlxuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogW10sXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogYnVpbGRBY3Rpb25SZXN0cmljdGlvbnMoQUxMX0NBUEFCSUxJVElFUyksXG4gICAgICAgIHRpbWVCb3VuZDogbnVsbCxcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGdlbmVyYXRlSWQoKSxcbiAgICBwcmVzZXQsXG4gICAgc2NvcGUsXG4gICAgY3JlYXRlZEF0OiBub3cudG9JU09TdHJpbmcoKSxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICBsYWJlbDogb3B0aW9ucz8ubGFiZWwsXG4gIH07XG59XG5cbi8qKlxuICogRXZhbHVhdGUgd2hldGhlciBhbiBhY3Rpb24gaXMgYWxsb3dlZCB1bmRlciBhIGRlbGVnYXRpb24gcnVsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV2YWx1YXRlUnVsZShcbiAgcnVsZTogRGVsZWdhdGlvblJ1bGUsXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICB1cmw6IHN0cmluZ1xuKTogeyBhbGxvd2VkOiBib29sZWFuOyByZWFzb246IHN0cmluZyB9IHtcbiAgaWYgKCFydWxlLmlzQWN0aXZlKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gcnVsZSBpcyBub3QgYWN0aXZlLicgfTtcbiAgfVxuXG4gIGlmIChpc1RpbWVCb3VuZEV4cGlyZWQocnVsZS5zY29wZS50aW1lQm91bmQpKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gaGFzIGV4cGlyZWQuJyB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgc2l0ZSBwYXR0ZXJuc1xuICBjb25zdCBkZWZhdWx0U2l0ZUFjdGlvbiA9IHJ1bGUucHJlc2V0ID09PSAnbGltaXRlZCcgPyAnYmxvY2snIGFzIGNvbnN0IDogJ2FsbG93JyBhcyBjb25zdDtcbiAgY29uc3Qgc2l0ZVJlc3VsdCA9IGV2YWx1YXRlU2l0ZVBhdHRlcm5zKHVybCwgcnVsZS5zY29wZS5zaXRlUGF0dGVybnMsIGRlZmF1bHRTaXRlQWN0aW9uKTtcbiAgaWYgKCFzaXRlUmVzdWx0LmFsbG93ZWQpIHtcbiAgICBjb25zdCBwYXR0ZXJuRGV0YWlsID0gc2l0ZVJlc3VsdC5tYXRjaGVkUGF0dGVyblxuICAgICAgPyBgIChtYXRjaGVkOiAke3NpdGVSZXN1bHQubWF0Y2hlZFBhdHRlcm4ucGF0dGVybn0pYFxuICAgICAgOiAnIChkZWZhdWx0IHBvbGljeSknO1xuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCByZWFzb246IGBVUkwgYmxvY2tlZCBieSBzaXRlIHBvbGljeSR7cGF0dGVybkRldGFpbH0uYCB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgYWN0aW9uIHJlc3RyaWN0aW9uc1xuICBjb25zdCBhY3Rpb25SZXN1bHQgPSBldmFsdWF0ZUFjdGlvblJlc3RyaWN0aW9ucyhhY3Rpb24sIHJ1bGUuc2NvcGUuYWN0aW9uUmVzdHJpY3Rpb25zKTtcbiAgaWYgKCFhY3Rpb25SZXN1bHQuYWxsb3dlZCkge1xuICAgIHJldHVybiB7XG4gICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgIHJlYXNvbjogYEFjdGlvbiBcIiR7YWN0aW9ufVwiIGlzIG5vdCBwZXJtaXR0ZWQgdW5kZXIgJHtydWxlLnByZXNldH0gZGVsZWdhdGlvbi5gLFxuICAgIH07XG4gIH1cblxuICByZXR1cm4geyBhbGxvd2VkOiB0cnVlLCByZWFzb246ICdBY3Rpb24gcGVybWl0dGVkIGJ5IGRlbGVnYXRpb24gcnVsZXMuJyB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgVVJMIG1hdGNoZXMgYW55IHNpdGUgcGF0dGVybiBpbiB0aGUgc2NvcGUuXG4gKiBGaXJzdCBtYXRjaCB3aW5zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVTaXRlUGF0dGVybnMoXG4gIHVybDogc3RyaW5nLFxuICBwYXR0ZXJuczogU2l0ZVBhdHRlcm5bXSxcbiAgZGVmYXVsdEFjdGlvbjogJ2FsbG93JyB8ICdibG9jaydcbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFBhdHRlcm46IFNpdGVQYXR0ZXJuIHwgbnVsbCB9IHtcbiAgZm9yIChjb25zdCBwYXR0ZXJuIG9mIHBhdHRlcm5zKSB7XG4gICAgaWYgKG1hdGNoR2xvYih1cmwsIHBhdHRlcm4ucGF0dGVybikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGFsbG93ZWQ6IHBhdHRlcm4uYWN0aW9uID09PSAnYWxsb3cnLFxuICAgICAgICBtYXRjaGVkUGF0dGVybjogcGF0dGVybixcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB7IGFsbG93ZWQ6IGRlZmF1bHRBY3Rpb24gPT09ICdhbGxvdycsIG1hdGNoZWRQYXR0ZXJuOiBudWxsIH07XG59XG5cbi8qKlxuICogTWF0Y2ggYSBVUkwgYWdhaW5zdCBhIGdsb2IgcGF0dGVybi5cbiAqL1xuZnVuY3Rpb24gbWF0Y2hHbG9iKHVybDogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgdHJ5IHtcbiAgICAvLyBJZiBwYXR0ZXJuIGRvZXNuJ3QgY29udGFpbiBwcm90b2NvbCwgbWF0Y2ggYWdhaW5zdCBob3N0bmFtZVxuICAgIGlmICghcGF0dGVybi5pbmNsdWRlcygnOi8vJykpIHtcbiAgICAgIGNvbnN0IHBhcnNlZFVybCA9IG5ldyBVUkwodXJsKTtcbiAgICAgIGNvbnN0IGhvc3RuYW1lID0gcGFyc2VkVXJsLmhvc3RuYW1lO1xuICAgICAgLy8gQ29udmVydCBnbG9iIHRvIHJlZ2V4OiAqIG1hdGNoZXMgYW55IGNoYXJhY3RlcnMgZXhjZXB0IGRvdHMgaW4gZG9tYWluIGNvbnRleHRcbiAgICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgICAucmVwbGFjZSgvXFwuL2csICdcXFxcLicpXG4gICAgICAgIC5yZXBsYWNlKC9cXCpcXCovZywgJy4qJylcbiAgICAgICAgLnJlcGxhY2UoL1xcKi9nLCAnW14uXSonKTtcbiAgICAgIHJldHVybiBuZXcgUmVnRXhwKGBeJHtyZWdleFN0cn0kYCkudGVzdChob3N0bmFtZSk7XG4gICAgfVxuXG4gICAgLy8gRnVsbCBVUkwgcGF0dGVybiBtYXRjaGluZ1xuICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgLnJlcGxhY2UoL1suK14ke30oKXxbXFxdXFxcXF0vZywgJ1xcXFwkJicpXG4gICAgICAucmVwbGFjZSgvXFxcXFxcKi9nLCAnLionKTtcbiAgICByZXR1cm4gbmV3IFJlZ0V4cChgXiR7cmVnZXhTdHJ9JGApLnRlc3QodXJsKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYW4gYWN0aW9uIGlzIGFsbG93ZWQgYnkgdGhlIGFjdGlvbiByZXN0cmljdGlvbiBsaXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVBY3Rpb25SZXN0cmljdGlvbnMoXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICByZXN0cmljdGlvbnM6IEFjdGlvblJlc3RyaWN0aW9uW11cbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFJlc3RyaWN0aW9uOiBBY3Rpb25SZXN0cmljdGlvbiB8IG51bGwgfSB7XG4gIGNvbnN0IHJlc3RyaWN0aW9uID0gcmVzdHJpY3Rpb25zLmZpbmQoKHIpID0+IHIuY2FwYWJpbGl0eSA9PT0gYWN0aW9uKTtcbiAgaWYgKCFyZXN0cmljdGlvbikge1xuICAgIC8vIERlZmF1bHQtYmxvY2sgaWYgbm90IGxpc3RlZFxuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCBtYXRjaGVkUmVzdHJpY3Rpb246IG51bGwgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGFsbG93ZWQ6IHJlc3RyaWN0aW9uLmFjdGlvbiA9PT0gJ2FsbG93JyxcbiAgICBtYXRjaGVkUmVzdHJpY3Rpb246IHJlc3RyaWN0aW9uLFxuICB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgdGltZSBib3VuZCBoYXMgZXhwaXJlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzVGltZUJvdW5kRXhwaXJlZCh0aW1lQm91bmQ6IFRpbWVCb3VuZCB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKHRpbWVCb3VuZCA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCkgPiBuZXcgRGF0ZSh0aW1lQm91bmQuZXhwaXJlc0F0KS5nZXRUaW1lKCk7XG59XG5cbi8qKlxuICogSXNzdWUgYSBkZWxlZ2F0aW9uIHRva2VuIGZvciBhbiBhZ2VudCBzZXNzaW9uIChsb2NhbC1vbmx5LCBsb2NhbC1vbmx5LCB1bnNpZ25lZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc3N1ZVRva2VuKFxuICBydWxlSWQ6IHN0cmluZyxcbiAgYWdlbnRJZDogc3RyaW5nLFxuICBzY29wZTogRGVsZWdhdGlvblNjb3BlLFxuICBleHBpcmVzQXQ6IHN0cmluZ1xuKTogRGVsZWdhdGlvblRva2VuIHtcbiAgcmV0dXJuIHtcbiAgICB0b2tlbklkOiBnZW5lcmF0ZUlkKCksXG4gICAgcnVsZUlkLFxuICAgIGFnZW50SWQsXG4gICAgc2NvcGUsXG4gICAgaXNzdWVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBleHBpcmVzQXQsXG4gICAgcmV2b2tlZDogZmFsc2UsXG4gIH07XG59XG5cbi8qKlxuICogUmV2b2tlIGEgZGVsZWdhdGlvbiB0b2tlbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJldm9rZVRva2VuKHRva2VuOiBEZWxlZ2F0aW9uVG9rZW4pOiBEZWxlZ2F0aW9uVG9rZW4ge1xuICByZXR1cm4geyAuLi50b2tlbiwgcmV2b2tlZDogdHJ1ZSB9O1xufVxuIiwiLyoqXG4gKiBEZWxlZ2F0aW9uIHdpemFyZCBVSSBsb2dpYy5cbiAqXG4gKiBNYW5hZ2VzIHRoZSAzLXByZXNldCBkZWxlZ2F0aW9uIHdpemFyZCB0aGF0IGFwcGVhcnMgaW4gdGhlIHBvcHVwLlxuICovXG5cbmltcG9ydCB0eXBlIHsgRGVsZWdhdGlvblByZXNldCwgRGVsZWdhdGlvblJ1bGUsIFNpdGVQYXR0ZXJuIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5pbXBvcnQgeyBjcmVhdGVSdWxlRnJvbVByZXNldCB9IGZyb20gJy4vcnVsZXMnO1xuXG5leHBvcnQgdHlwZSBXaXphcmRTdGVwID0gJ3ByZXNldCcgfCAnc2l0ZXMnIHwgJ3RpbWUnIHwgJ2NvbmZpcm0nO1xuXG5leHBvcnQgaW50ZXJmYWNlIFdpemFyZFN0YXRlIHtcbiAgY3VycmVudFN0ZXA6IFdpemFyZFN0ZXA7XG4gIHNlbGVjdGVkUHJlc2V0OiBEZWxlZ2F0aW9uUHJlc2V0IHwgbnVsbDtcbiAgc2l0ZVBhdHRlcm5zOiBTaXRlUGF0dGVybltdO1xuICBkdXJhdGlvbk1pbnV0ZXM6IG51bWJlciB8IG51bGw7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGVycm9yczogc3RyaW5nW107XG59XG5cbmV4cG9ydCBjb25zdCBUSU1FX0RVUkFUSU9OX09QVElPTlMgPSBbXG4gIHsgbGFiZWw6ICcxNSBtaW51dGVzJywgbWludXRlczogMTUgfSxcbiAgeyBsYWJlbDogJzEgaG91cicsIG1pbnV0ZXM6IDYwIH0sXG4gIHsgbGFiZWw6ICc0IGhvdXJzJywgbWludXRlczogMjQwIH0sXG5dIGFzIGNvbnN0O1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFdpemFyZFN0YXRlKCk6IFdpemFyZFN0YXRlIHtcbiAgcmV0dXJuIHtcbiAgICBjdXJyZW50U3RlcDogJ3ByZXNldCcsXG4gICAgc2VsZWN0ZWRQcmVzZXQ6IG51bGwsXG4gICAgc2l0ZVBhdHRlcm5zOiBbXSxcbiAgICBkdXJhdGlvbk1pbnV0ZXM6IG51bGwsXG4gICAgbGFiZWw6ICcnLFxuICAgIGVycm9yczogW10sXG4gIH07XG59XG5cbi8qKlxuICogU2VsZWN0IGEgZGVsZWdhdGlvbiBwcmVzZXQgYW5kIGRldGVybWluZSB0aGUgbmV4dCBzdGVwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0UHJlc2V0KHN0YXRlOiBXaXphcmRTdGF0ZSwgcHJlc2V0OiBEZWxlZ2F0aW9uUHJlc2V0KTogV2l6YXJkU3RhdGUge1xuICBjb25zdCBuZXh0U3RlcDogV2l6YXJkU3RlcCA9IHByZXNldCA9PT0gJ2xpbWl0ZWQnID8gJ3NpdGVzJyA6ICdjb25maXJtJztcbiAgcmV0dXJuIHtcbiAgICAuLi5zdGF0ZSxcbiAgICBzZWxlY3RlZFByZXNldDogcHJlc2V0LFxuICAgIGN1cnJlbnRTdGVwOiBuZXh0U3RlcCxcbiAgICBlcnJvcnM6IFtdLFxuICB9O1xufVxuXG4vKipcbiAqIEFkZCBhIHNpdGUgcGF0dGVybiB0byB0aGUgd2l6YXJkIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRTaXRlUGF0dGVybihzdGF0ZTogV2l6YXJkU3RhdGUsIHBhdHRlcm46IFNpdGVQYXR0ZXJuKTogV2l6YXJkU3RhdGUge1xuICBpZiAoIXBhdHRlcm4ucGF0dGVybi50cmltKCkpIHtcbiAgICByZXR1cm4geyAuLi5zdGF0ZSwgZXJyb3JzOiBbJ1BhdHRlcm4gY2Fubm90IGJlIGVtcHR5LiddIH07XG4gIH1cblxuICAvLyBDaGVjayBmb3IgZHVwbGljYXRlc1xuICBjb25zdCBleGlzdHMgPSBzdGF0ZS5zaXRlUGF0dGVybnMuc29tZSgocCkgPT4gcC5wYXR0ZXJuID09PSBwYXR0ZXJuLnBhdHRlcm4pO1xuICBpZiAoZXhpc3RzKSB7XG4gICAgcmV0dXJuIHsgLi4uc3RhdGUsIGVycm9yczogWydUaGlzIHBhdHRlcm4gYWxyZWFkeSBleGlzdHMuJ10gfTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgLi4uc3RhdGUsXG4gICAgc2l0ZVBhdHRlcm5zOiBbLi4uc3RhdGUuc2l0ZVBhdHRlcm5zLCBwYXR0ZXJuXSxcbiAgICBlcnJvcnM6IFtdLFxuICB9O1xufVxuXG4vKipcbiAqIFJlbW92ZSBhIHNpdGUgcGF0dGVybiBieSBpbmRleC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZVNpdGVQYXR0ZXJuKHN0YXRlOiBXaXphcmRTdGF0ZSwgaW5kZXg6IG51bWJlcik6IFdpemFyZFN0YXRlIHtcbiAgY29uc3Qgc2l0ZVBhdHRlcm5zID0gc3RhdGUuc2l0ZVBhdHRlcm5zLmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpO1xuICByZXR1cm4geyAuLi5zdGF0ZSwgc2l0ZVBhdHRlcm5zLCBlcnJvcnM6IFtdIH07XG59XG5cbi8qKlxuICogU2V0IHRoZSB0aW1lIGR1cmF0aW9uIGZvciB0aGUgbGltaXRlZCBwcmVzZXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXREdXJhdGlvbihzdGF0ZTogV2l6YXJkU3RhdGUsIG1pbnV0ZXM6IG51bWJlcik6IFdpemFyZFN0YXRlIHtcbiAgY29uc3QgdmFsaWQgPSBUSU1FX0RVUkFUSU9OX09QVElPTlMuc29tZSgob3B0KSA9PiBvcHQubWludXRlcyA9PT0gbWludXRlcyk7XG4gIGlmICghdmFsaWQpIHtcbiAgICByZXR1cm4geyAuLi5zdGF0ZSwgZXJyb3JzOiBbJ0ludmFsaWQgZHVyYXRpb24uIENob29zZSAxNSBtaW51dGVzLCAxIGhvdXIsIG9yIDQgaG91cnMuJ10gfTtcbiAgfVxuICByZXR1cm4geyAuLi5zdGF0ZSwgZHVyYXRpb25NaW51dGVzOiBtaW51dGVzLCBlcnJvcnM6IFtdIH07XG59XG5cbi8qKlxuICogQWR2YW5jZSB0byB0aGUgbmV4dCB3aXphcmQgc3RlcC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5leHRTdGVwKHN0YXRlOiBXaXphcmRTdGF0ZSk6IFdpemFyZFN0YXRlIHtcbiAgc3dpdGNoIChzdGF0ZS5jdXJyZW50U3RlcCkge1xuICAgIGNhc2UgJ3ByZXNldCc6XG4gICAgICBpZiAoIXN0YXRlLnNlbGVjdGVkUHJlc2V0KSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBlcnJvcnM6IFsnU2VsZWN0IGEgZGVsZWdhdGlvbiBwcmVzZXQuJ10gfTtcbiAgICAgIH1cbiAgICAgIGlmIChzdGF0ZS5zZWxlY3RlZFByZXNldCA9PT0gJ2xpbWl0ZWQnKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjdXJyZW50U3RlcDogJ3NpdGVzJywgZXJyb3JzOiBbXSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGN1cnJlbnRTdGVwOiAnY29uZmlybScsIGVycm9yczogW10gfTtcblxuICAgIGNhc2UgJ3NpdGVzJzpcbiAgICAgIGlmIChzdGF0ZS5zaXRlUGF0dGVybnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBlcnJvcnM6IFsnQWRkIGF0IGxlYXN0IG9uZSBzaXRlIHBhdHRlcm4uJ10gfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjdXJyZW50U3RlcDogJ3RpbWUnLCBlcnJvcnM6IFtdIH07XG5cbiAgICBjYXNlICd0aW1lJzpcbiAgICAgIGlmIChzdGF0ZS5kdXJhdGlvbk1pbnV0ZXMgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGVycm9yczogWydTZWxlY3QgYSB0aW1lIGR1cmF0aW9uLiddIH07XG4gICAgICB9XG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgY3VycmVudFN0ZXA6ICdjb25maXJtJywgZXJyb3JzOiBbXSB9O1xuXG4gICAgY2FzZSAnY29uZmlybSc6XG4gICAgICByZXR1cm4gc3RhdGU7XG5cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHN0YXRlO1xuICB9XG59XG5cbi8qKlxuICogR28gYmFjayB0byB0aGUgcHJldmlvdXMgd2l6YXJkIHN0ZXAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcmV2aW91c1N0ZXAoc3RhdGU6IFdpemFyZFN0YXRlKTogV2l6YXJkU3RhdGUge1xuICBjb25zdCBzdGVwT3JkZXI6IFdpemFyZFN0ZXBbXSA9IFsncHJlc2V0JywgJ3NpdGVzJywgJ3RpbWUnLCAnY29uZmlybSddO1xuICBjb25zdCBjdXJyZW50SW5kZXggPSBzdGVwT3JkZXIuaW5kZXhPZihzdGF0ZS5jdXJyZW50U3RlcCk7XG5cbiAgaWYgKGN1cnJlbnRJbmRleCA8PSAwKSByZXR1cm4gc3RhdGU7XG5cbiAgLy8gRm9yIHJlYWRPbmx5L2Z1bGxBY2Nlc3MsIGdvIGJhY2sgZnJvbSBjb25maXJtIHRvIHByZXNldFxuICBpZiAoc3RhdGUuY3VycmVudFN0ZXAgPT09ICdjb25maXJtJyAmJiBzdGF0ZS5zZWxlY3RlZFByZXNldCAhPT0gJ2xpbWl0ZWQnKSB7XG4gICAgcmV0dXJuIHsgLi4uc3RhdGUsIGN1cnJlbnRTdGVwOiAncHJlc2V0JywgZXJyb3JzOiBbXSB9O1xuICB9XG5cbiAgcmV0dXJuIHsgLi4uc3RhdGUsIGN1cnJlbnRTdGVwOiBzdGVwT3JkZXJbY3VycmVudEluZGV4IC0gMV0sIGVycm9yczogW10gfTtcbn1cblxuLyoqXG4gKiBGaW5hbGl6ZSB0aGUgd2l6YXJkIGFuZCBjcmVhdGUgYSBkZWxlZ2F0aW9uIHJ1bGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaW5hbGl6ZVdpemFyZChzdGF0ZTogV2l6YXJkU3RhdGUpOiBEZWxlZ2F0aW9uUnVsZSB8IG51bGwge1xuICBpZiAoIXN0YXRlLnNlbGVjdGVkUHJlc2V0KSByZXR1cm4gbnVsbDtcblxuICBpZiAoc3RhdGUuc2VsZWN0ZWRQcmVzZXQgPT09ICdsaW1pdGVkJykge1xuICAgIGlmIChzdGF0ZS5zaXRlUGF0dGVybnMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgICBpZiAoc3RhdGUuZHVyYXRpb25NaW51dGVzID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiBjcmVhdGVSdWxlRnJvbVByZXNldChzdGF0ZS5zZWxlY3RlZFByZXNldCwge1xuICAgIHNpdGVQYXR0ZXJuczogc3RhdGUuc2l0ZVBhdHRlcm5zLFxuICAgIGR1cmF0aW9uTWludXRlczogc3RhdGUuZHVyYXRpb25NaW51dGVzID8/IHVuZGVmaW5lZCxcbiAgICBsYWJlbDogc3RhdGUubGFiZWwgfHwgdW5kZWZpbmVkLFxuICB9KTtcbn1cblxuY29uc3QgUFJFU0VUX0RFU0NSSVBUSU9OUzogUmVjb3JkPERlbGVnYXRpb25QcmVzZXQsIHsgdGl0bGU6IHN0cmluZzsgZGVzY3JpcHRpb246IHN0cmluZyB9PiA9IHtcbiAgcmVhZE9ubHk6IHtcbiAgICB0aXRsZTogJ1JlYWQtT25seScsXG4gICAgZGVzY3JpcHRpb246ICdBZ2VudCBjYW4gbmF2aWdhdGUgYW5kIHJlYWQgcGFnZSBjb250ZW50LiBDYW5ub3QgY2xpY2ssIHR5cGUsIG9yIHN1Ym1pdCBmb3Jtcy4nLFxuICB9LFxuICBsaW1pdGVkOiB7XG4gICAgdGl0bGU6ICdMaW1pdGVkIEFjY2VzcycsXG4gICAgZGVzY3JpcHRpb246ICdBZ2VudCBjYW4gaW50ZXJhY3Qgd2l0aCBzcGVjaWZpYyBzaXRlcyB5b3UgY2hvb3NlLCB3aXRoIGEgdGltZSBsaW1pdC4nLFxuICB9LFxuICBmdWxsQWNjZXNzOiB7XG4gICAgdGl0bGU6ICdGdWxsIEFjY2VzcycsXG4gICAgZGVzY3JpcHRpb246ICdBZ2VudCBjYW4gcGVyZm9ybSBhbnkgYWN0aW9uLiBBbGwgYWN0aXZpdHkgaXMgbG9nZ2VkIHdpdGggYm91bmRhcnkgYWxlcnRzLicsXG4gIH0sXG59O1xuXG4vKipcbiAqIFJlbmRlciB0aGUgd2l6YXJkIFVJIGludG8gYSBjb250YWluZXIgZWxlbWVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbmRlcldpemFyZChcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkXG4pOiB2b2lkIHtcbiAgY29udGFpbmVyLmlubmVySFRNTCA9ICcnO1xuXG4gIC8vIEVycm9yIGRpc3BsYXlcbiAgaWYgKHN0YXRlLmVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgZXJyb3JEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBlcnJvckRpdi5jbGFzc05hbWUgPSAnd2l6YXJkLWVycm9ycyc7XG4gICAgZXJyb3JEaXYuc3R5bGUuY3NzVGV4dCA9ICdjb2xvcjogdmFyKC0tZGFuZ2VyKTsgZm9udC1zaXplOiAxMnB4OyBtYXJnaW4tYm90dG9tOiA4cHg7JztcbiAgICBlcnJvckRpdi50ZXh0Q29udGVudCA9IHN0YXRlLmVycm9ycy5qb2luKCcgJyk7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGVycm9yRGl2KTtcbiAgfVxuXG4gIHN3aXRjaCAoc3RhdGUuY3VycmVudFN0ZXApIHtcbiAgICBjYXNlICdwcmVzZXQnOlxuICAgICAgcmVuZGVyUHJlc2V0U3RlcChjb250YWluZXIsIHN0YXRlLCBvblN0YXRlQ2hhbmdlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3NpdGVzJzpcbiAgICAgIHJlbmRlclNpdGVzU3RlcChjb250YWluZXIsIHN0YXRlLCBvblN0YXRlQ2hhbmdlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3RpbWUnOlxuICAgICAgcmVuZGVyVGltZVN0ZXAoY29udGFpbmVyLCBzdGF0ZSwgb25TdGF0ZUNoYW5nZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjb25maXJtJzpcbiAgICAgIHJlbmRlckNvbmZpcm1TdGVwKGNvbnRhaW5lciwgc3RhdGUsIG9uU3RhdGVDaGFuZ2UpO1xuICAgICAgYnJlYWs7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyUHJlc2V0U3RlcChcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkXG4pOiB2b2lkIHtcbiAgY29uc3QgcHJlc2V0czogRGVsZWdhdGlvblByZXNldFtdID0gWydyZWFkT25seScsICdsaW1pdGVkJywgJ2Z1bGxBY2Nlc3MnXTtcbiAgZm9yIChjb25zdCBwcmVzZXQgb2YgcHJlc2V0cykge1xuICAgIGNvbnN0IGluZm8gPSBQUkVTRVRfREVTQ1JJUFRJT05TW3ByZXNldF07XG4gICAgY29uc3QgY2FyZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGNhcmQuY2xhc3NOYW1lID0gYHByZXNldC1jYXJkJHtzdGF0ZS5zZWxlY3RlZFByZXNldCA9PT0gcHJlc2V0ID8gJyBzZWxlY3RlZCcgOiAnJ31gO1xuICAgIGNhcmQuaW5uZXJIVE1MID0gYFxuICAgICAgPHN0cm9uZz4ke2luZm8udGl0bGV9PC9zdHJvbmc+XG4gICAgICA8cCBzdHlsZT1cIm1hcmdpbjogNHB4IDAgMDsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogdmFyKC0tdGV4dC1zZWNvbmRhcnkpO1wiPiR7aW5mby5kZXNjcmlwdGlvbn08L3A+XG4gICAgYDtcbiAgICBjYXJkLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgb25TdGF0ZUNoYW5nZShzZWxlY3RQcmVzZXQoc3RhdGUsIHByZXNldCkpO1xuICAgIH0pO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChjYXJkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJTaXRlc1N0ZXAoXG4gIGNvbnRhaW5lcjogSFRNTEVsZW1lbnQsXG4gIHN0YXRlOiBXaXphcmRTdGF0ZSxcbiAgb25TdGF0ZUNoYW5nZTogKG5ld1N0YXRlOiBXaXphcmRTdGF0ZSkgPT4gdm9pZFxuKTogdm9pZCB7XG4gIGNvbnN0IGhlYWRpbmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XG4gIGhlYWRpbmcuc3R5bGUuY3NzVGV4dCA9ICdmb250LXNpemU6IDEycHg7IGNvbG9yOiB2YXIoLS10ZXh0LXNlY29uZGFyeSk7IG1hcmdpbi1ib3R0b206IDhweDsnO1xuICBoZWFkaW5nLnRleHRDb250ZW50ID0gJ0FkZCBzaXRlcyB0aGUgYWdlbnQgY2FuIGFjY2VzcyAoZ2xvYiBwYXR0ZXJucyk6JztcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGhlYWRpbmcpO1xuXG4gIC8vIElucHV0IHJvd1xuICBjb25zdCBpbnB1dFJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBpbnB1dFJvdy5zdHlsZS5jc3NUZXh0ID0gJ2Rpc3BsYXk6IGZsZXg7IGdhcDogNnB4OyBtYXJnaW4tYm90dG9tOiA4cHg7JztcblxuICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jyk7XG4gIGlucHV0LnR5cGUgPSAndGV4dCc7XG4gIGlucHV0LnBsYWNlaG9sZGVyID0gJ2UuZy4sICouZXhhbXBsZS5jb20nO1xuICBpbnB1dC5jbGFzc05hbWUgPSAnZm9ybS1pbnB1dCc7XG4gIGlucHV0LnN0eWxlLmNzc1RleHQgPSAnZmxleDogMTsnO1xuXG4gIGNvbnN0IGFkZEJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICBhZGRCdG4uY2xhc3NOYW1lID0gJ2J0biBidG4tcHJpbWFyeSc7XG4gIGFkZEJ0bi50ZXh0Q29udGVudCA9ICdBZGQnO1xuICBhZGRCdG4uc3R5bGUuY3NzVGV4dCA9ICdwYWRkaW5nOiA0cHggMTJweDsgZm9udC1zaXplOiAxMnB4Oyc7XG4gIGFkZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IGlucHV0LnZhbHVlLnRyaW0oKTtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIG9uU3RhdGVDaGFuZ2UoYWRkU2l0ZVBhdHRlcm4oc3RhdGUsIHsgcGF0dGVybjogdmFsdWUsIGFjdGlvbjogJ2FsbG93JyB9KSk7XG4gICAgICBpbnB1dC52YWx1ZSA9ICcnO1xuICAgIH1cbiAgfSk7XG5cbiAgaW5wdXRSb3cuYXBwZW5kQ2hpbGQoaW5wdXQpO1xuICBpbnB1dFJvdy5hcHBlbmRDaGlsZChhZGRCdG4pO1xuICBjb250YWluZXIuYXBwZW5kQ2hpbGQoaW5wdXRSb3cpO1xuXG4gIC8vIFBhdHRlcm4gbGlzdFxuICBmb3IgKGxldCBpID0gMDsgaSA8IHN0YXRlLnNpdGVQYXR0ZXJucy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHAgPSBzdGF0ZS5zaXRlUGF0dGVybnNbaV07XG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgcm93LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBhbGlnbi1pdGVtczogY2VudGVyOyBwYWRkaW5nOiA0cHggMDsgZm9udC1zaXplOiAxMnB4Oyc7XG4gICAgcm93LmlubmVySFRNTCA9IGA8c3BhbiBzdHlsZT1cImNvbG9yOiB2YXIoLS10ZXh0LXByaW1hcnkpO1wiPiR7cC5wYXR0ZXJufSAoJHtwLmFjdGlvbn0pPC9zcGFuPmA7XG4gICAgY29uc3QgcmVtb3ZlQnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgcmVtb3ZlQnRuLmNsYXNzTmFtZSA9ICdidG4gYnRuLXNlY29uZGFyeSc7XG4gICAgcmVtb3ZlQnRuLnRleHRDb250ZW50ID0gJ1JlbW92ZSc7XG4gICAgcmVtb3ZlQnRuLnN0eWxlLmNzc1RleHQgPSAncGFkZGluZzogMnB4IDhweDsgZm9udC1zaXplOiAxMXB4Oyc7XG4gICAgcmVtb3ZlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4gb25TdGF0ZUNoYW5nZShyZW1vdmVTaXRlUGF0dGVybihzdGF0ZSwgaSkpKTtcbiAgICByb3cuYXBwZW5kQ2hpbGQocmVtb3ZlQnRuKTtcbiAgICBjb250YWluZXIuYXBwZW5kQ2hpbGQocm93KTtcbiAgfVxuXG4gIC8vIE5hdiBidXR0b25zXG4gIHJlbmRlck5hdkJ1dHRvbnMoY29udGFpbmVyLCBzdGF0ZSwgb25TdGF0ZUNoYW5nZSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclRpbWVTdGVwKFxuICBjb250YWluZXI6IEhUTUxFbGVtZW50LFxuICBzdGF0ZTogV2l6YXJkU3RhdGUsXG4gIG9uU3RhdGVDaGFuZ2U6IChuZXdTdGF0ZTogV2l6YXJkU3RhdGUpID0+IHZvaWRcbik6IHZvaWQge1xuICBjb25zdCBoZWFkaW5nID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xuICBoZWFkaW5nLnN0eWxlLmNzc1RleHQgPSAnZm9udC1zaXplOiAxMnB4OyBjb2xvcjogdmFyKC0tdGV4dC1zZWNvbmRhcnkpOyBtYXJnaW4tYm90dG9tOiA4cHg7JztcbiAgaGVhZGluZy50ZXh0Q29udGVudCA9ICdIb3cgbG9uZyBzaG91bGQgdGhlIGRlbGVnYXRpb24gbGFzdD8nO1xuICBjb250YWluZXIuYXBwZW5kQ2hpbGQoaGVhZGluZyk7XG5cbiAgZm9yIChjb25zdCBvcHRpb24gb2YgVElNRV9EVVJBVElPTl9PUFRJT05TKSB7XG4gICAgY29uc3QgYnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgYnRuLmNsYXNzTmFtZSA9IGBidG4gJHtzdGF0ZS5kdXJhdGlvbk1pbnV0ZXMgPT09IG9wdGlvbi5taW51dGVzID8gJ2J0bi1wcmltYXJ5JyA6ICdidG4tc2Vjb25kYXJ5J31gO1xuICAgIGJ0bi50ZXh0Q29udGVudCA9IG9wdGlvbi5sYWJlbDtcbiAgICBidG4uc3R5bGUuY3NzVGV4dCA9ICdkaXNwbGF5OiBibG9jazsgd2lkdGg6IDEwMCU7IG1hcmdpbi1ib3R0b206IDZweDsnO1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBzZXREdXJhdGlvbihzdGF0ZSwgb3B0aW9uLm1pbnV0ZXMpO1xuICAgICAgb25TdGF0ZUNoYW5nZShuZXh0U3RlcCh1cGRhdGVkKSk7XG4gICAgfSk7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGJ0bik7XG4gIH1cblxuICByZW5kZXJOYXZCdXR0b25zKGNvbnRhaW5lciwgc3RhdGUsIG9uU3RhdGVDaGFuZ2UsIHRydWUpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25maXJtU3RlcChcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudCxcbiAgc3RhdGU6IFdpemFyZFN0YXRlLFxuICBvblN0YXRlQ2hhbmdlOiAobmV3U3RhdGU6IFdpemFyZFN0YXRlKSA9PiB2b2lkXG4pOiB2b2lkIHtcbiAgY29uc3QgcHJlc2V0ID0gc3RhdGUuc2VsZWN0ZWRQcmVzZXQ7XG4gIGlmICghcHJlc2V0KSByZXR1cm47XG5cbiAgY29uc3QgaW5mbyA9IFBSRVNFVF9ERVNDUklQVElPTlNbcHJlc2V0XTtcbiAgY29uc3Qgc3VtbWFyeSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBzdW1tYXJ5LnN0eWxlLmNzc1RleHQgPSAnZm9udC1zaXplOiAxMnB4OyBjb2xvcjogdmFyKC0tdGV4dC1zZWNvbmRhcnkpOyc7XG5cbiAgbGV0IGh0bWwgPSBgPHA+PHN0cm9uZz5QcmVzZXQ6PC9zdHJvbmc+ICR7aW5mby50aXRsZX08L3A+YDtcbiAgaWYgKHN0YXRlLnNpdGVQYXR0ZXJucy5sZW5ndGggPiAwKSB7XG4gICAgaHRtbCArPSBgPHA+PHN0cm9uZz5TaXRlczo8L3N0cm9uZz4gJHtzdGF0ZS5zaXRlUGF0dGVybnMubWFwKChwKSA9PiBwLnBhdHRlcm4pLmpvaW4oJywgJyl9PC9wPmA7XG4gIH1cbiAgaWYgKHN0YXRlLmR1cmF0aW9uTWludXRlcykge1xuICAgIGNvbnN0IG9wdCA9IFRJTUVfRFVSQVRJT05fT1BUSU9OUy5maW5kKChvKSA9PiBvLm1pbnV0ZXMgPT09IHN0YXRlLmR1cmF0aW9uTWludXRlcyk7XG4gICAgaHRtbCArPSBgPHA+PHN0cm9uZz5EdXJhdGlvbjo8L3N0cm9uZz4gJHtvcHQ/LmxhYmVsID8/IHN0YXRlLmR1cmF0aW9uTWludXRlcyArICcgbWludXRlcyd9PC9wPmA7XG4gIH1cbiAgc3VtbWFyeS5pbm5lckhUTUwgPSBodG1sO1xuICBjb250YWluZXIuYXBwZW5kQ2hpbGQoc3VtbWFyeSk7XG5cbiAgLy8gTGFiZWwgaW5wdXRcbiAgY29uc3QgbGFiZWxJbnB1dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jyk7XG4gIGxhYmVsSW5wdXQudHlwZSA9ICd0ZXh0JztcbiAgbGFiZWxJbnB1dC5wbGFjZWhvbGRlciA9ICdMYWJlbCAob3B0aW9uYWwpJztcbiAgbGFiZWxJbnB1dC5jbGFzc05hbWUgPSAnZm9ybS1pbnB1dCc7XG4gIGxhYmVsSW5wdXQudmFsdWUgPSBzdGF0ZS5sYWJlbDtcbiAgbGFiZWxJbnB1dC5zdHlsZS5jc3NUZXh0ID0gJ3dpZHRoOiAxMDAlOyBtYXJnaW46IDhweCAwOyc7XG4gIGxhYmVsSW5wdXQuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gICAgc3RhdGUubGFiZWwgPSBsYWJlbElucHV0LnZhbHVlO1xuICB9KTtcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGxhYmVsSW5wdXQpO1xuXG4gIC8vIEFjdGl2YXRlIGJ1dHRvblxuICBjb25zdCBhY3RpdmF0ZUJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICBhY3RpdmF0ZUJ0bi5jbGFzc05hbWUgPSAnYnRuIGJ0bi1wcmltYXJ5JztcbiAgYWN0aXZhdGVCdG4udGV4dENvbnRlbnQgPSAnQWN0aXZhdGUgRGVsZWdhdGlvbic7XG4gIGFjdGl2YXRlQnRuLnN0eWxlLmNzc1RleHQgPSAnd2lkdGg6IDEwMCU7IG1hcmdpbi10b3A6IDhweDsnO1xuICBhY3RpdmF0ZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBjb25zdCBydWxlID0gZmluYWxpemVXaXphcmQoc3RhdGUpO1xuICAgIGlmIChydWxlKSB7XG4gICAgICAvLyBEaXNwYXRjaCBjdXN0b20gZXZlbnQgZm9yIHBvcHVwIHRvIHBpY2sgdXBcbiAgICAgIGNvbnRhaW5lci5kaXNwYXRjaEV2ZW50KFxuICAgICAgICBuZXcgQ3VzdG9tRXZlbnQoJ2RlbGVnYXRpb24tYWN0aXZhdGVkJywgeyBkZXRhaWw6IHJ1bGUsIGJ1YmJsZXM6IHRydWUgfSlcbiAgICAgICk7XG4gICAgfVxuICB9KTtcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGFjdGl2YXRlQnRuKTtcblxuICByZW5kZXJOYXZCdXR0b25zKGNvbnRhaW5lciwgc3RhdGUsIG9uU3RhdGVDaGFuZ2UsIHRydWUpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJOYXZCdXR0b25zKFxuICBjb250YWluZXI6IEhUTUxFbGVtZW50LFxuICBzdGF0ZTogV2l6YXJkU3RhdGUsXG4gIG9uU3RhdGVDaGFuZ2U6IChuZXdTdGF0ZTogV2l6YXJkU3RhdGUpID0+IHZvaWQsXG4gIHNob3dCYWNrID0gZmFsc2Vcbik6IHZvaWQge1xuICBjb25zdCBuYXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgbmF2LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBtYXJnaW4tdG9wOiA4cHg7JztcblxuICBpZiAoc2hvd0JhY2spIHtcbiAgICBjb25zdCBiYWNrQnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgYmFja0J0bi5jbGFzc05hbWUgPSAnYnRuIGJ0bi1zZWNvbmRhcnknO1xuICAgIGJhY2tCdG4udGV4dENvbnRlbnQgPSAnQmFjayc7XG4gICAgYmFja0J0bi5zdHlsZS5jc3NUZXh0ID0gJ2ZvbnQtc2l6ZTogMTFweDsnO1xuICAgIGJhY2tCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiBvblN0YXRlQ2hhbmdlKHByZXZpb3VzU3RlcChzdGF0ZSkpKTtcbiAgICBuYXYuYXBwZW5kQ2hpbGQoYmFja0J0bik7XG4gIH1cblxuICBpZiAoc3RhdGUuY3VycmVudFN0ZXAgPT09ICdzaXRlcycpIHtcbiAgICBjb25zdCBuZXh0QnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgbmV4dEJ0bi5jbGFzc05hbWUgPSAnYnRuIGJ0bi1wcmltYXJ5JztcbiAgICBuZXh0QnRuLnRleHRDb250ZW50ID0gJ05leHQnO1xuICAgIG5leHRCdG4uc3R5bGUuY3NzVGV4dCA9ICdmb250LXNpemU6IDExcHg7IG1hcmdpbi1sZWZ0OiBhdXRvOyc7XG4gICAgbmV4dEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IG9uU3RhdGVDaGFuZ2UobmV4dFN0ZXAoc3RhdGUpKSk7XG4gICAgbmF2LmFwcGVuZENoaWxkKG5leHRCdG4pO1xuICB9XG5cbiAgaWYgKG5hdi5jaGlsZHJlbi5sZW5ndGggPiAwKSB7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKG5hdik7XG4gIH1cbn1cbiIsIi8qKlxuICogUG9wdXAgc2NyaXB0IGZvciBBSSBCcm93c2VyIEd1YXJkLlxuICpcbiAqIENvbnRyb2xzIHRoZSBleHRlbnNpb24gcG9wdXAgVUkuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBNZXNzYWdlUGF5bG9hZCwgTWVzc2FnZVR5cGUgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudElkZW50aXR5IH0gZnJvbSAnLi4vdHlwZXMvYWdlbnQnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uUnVsZSB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudFNlc3Npb24gfSBmcm9tICcuLi9zZXNzaW9uL3R5cGVzJztcbmltcG9ydCB0eXBlIHsgQm91bmRhcnlBbGVydCB9IGZyb20gJy4uL2FsZXJ0cy9ib3VuZGFyeSc7XG5pbXBvcnQgeyBjcmVhdGVJbml0aWFsV2l6YXJkU3RhdGUsIHJlbmRlcldpemFyZCwgZmluYWxpemVXaXphcmQgfSBmcm9tICcuLi9kZWxlZ2F0aW9uL3dpemFyZCc7XG5pbXBvcnQgdHlwZSB7IFdpemFyZFN0YXRlIH0gZnJvbSAnLi4vZGVsZWdhdGlvbi93aXphcmQnO1xuXG5pbnRlcmZhY2UgUG9wdXBTdGF0ZSB7XG4gIGRldGVjdGVkQWdlbnRzOiBBZ2VudElkZW50aXR5W107XG4gIGFjdGl2ZURlbGVnYXRpb246IERlbGVnYXRpb25SdWxlIHwgbnVsbDtcbiAga2lsbFN3aXRjaEFjdGl2ZTogYm9vbGVhbjtcbiAgcmVjZW50VmlvbGF0aW9uczogQm91bmRhcnlBbGVydFtdO1xuICBzZXNzaW9uczogQWdlbnRTZXNzaW9uW107XG4gIHdpemFyZFN0YXRlOiBXaXphcmRTdGF0ZSB8IG51bGw7XG4gIGxvYWRpbmc6IGJvb2xlYW47XG59XG5cbmxldCBwb3B1cFN0YXRlOiBQb3B1cFN0YXRlID0ge1xuICBkZXRlY3RlZEFnZW50czogW10sXG4gIGFjdGl2ZURlbGVnYXRpb246IG51bGwsXG4gIGtpbGxTd2l0Y2hBY3RpdmU6IGZhbHNlLFxuICByZWNlbnRWaW9sYXRpb25zOiBbXSxcbiAgc2Vzc2lvbnM6IFtdLFxuICB3aXphcmRTdGF0ZTogbnVsbCxcbiAgbG9hZGluZzogdHJ1ZSxcbn07XG5cbmZ1bmN0aW9uIGluaXRpYWxpemUoKTogdm9pZCB7XG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCAoKSA9PiB7XG4gICAgc2V0dXBFdmVudExpc3RlbmVycygpO1xuICAgIHF1ZXJ5QmFja2dyb3VuZFN0YXR1cygpO1xuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcXVlcnlCYWNrZ3JvdW5kU3RhdHVzKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZCgnU1RBVFVTX1FVRVJZJywge30pO1xuICAgIGlmIChyZXNwb25zZSAmJiB0eXBlb2YgcmVzcG9uc2UgPT09ICdvYmplY3QnKSB7XG4gICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UgYXMge1xuICAgICAgICBkZXRlY3RlZEFnZW50cz86IEFnZW50SWRlbnRpdHlbXTtcbiAgICAgICAgYWN0aXZlRGVsZWdhdGlvbj86IERlbGVnYXRpb25SdWxlIHwgbnVsbDtcbiAgICAgICAga2lsbFN3aXRjaEFjdGl2ZT86IGJvb2xlYW47XG4gICAgICAgIHJlY2VudFZpb2xhdGlvbnM/OiBCb3VuZGFyeUFsZXJ0W107XG4gICAgICB9O1xuICAgICAgcG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cyA9IGRhdGEuZGV0ZWN0ZWRBZ2VudHMgPz8gW107XG4gICAgICBwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb24gPSBkYXRhLmFjdGl2ZURlbGVnYXRpb24gPz8gbnVsbDtcbiAgICAgIHBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZSA9IGRhdGEua2lsbFN3aXRjaEFjdGl2ZSA/PyBmYWxzZTtcbiAgICAgIHBvcHVwU3RhdGUucmVjZW50VmlvbGF0aW9ucyA9IGRhdGEucmVjZW50VmlvbGF0aW9ucyA/PyBbXTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIEJhY2tncm91bmQgbWF5IG5vdCBiZSBhdmFpbGFibGVcbiAgfVxuXG4gIC8vIEFsc28gZmV0Y2ggc2Vzc2lvbnNcbiAgdHJ5IHtcbiAgICBjb25zdCBzZXNzaW9uUmVzcG9uc2UgPSBhd2FpdCBzZW5kVG9CYWNrZ3JvdW5kKCdTRVNTSU9OX1FVRVJZJywge30pO1xuICAgIGlmIChzZXNzaW9uUmVzcG9uc2UgJiYgdHlwZW9mIHNlc3Npb25SZXNwb25zZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBzZXNzaW9uUmVzcG9uc2UgYXMgeyBzZXNzaW9ucz86IEFnZW50U2Vzc2lvbltdIH07XG4gICAgICBwb3B1cFN0YXRlLnNlc3Npb25zID0gZGF0YS5zZXNzaW9ucyA/PyBbXTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIElnbm9yZVxuICB9XG5cbiAgcG9wdXBTdGF0ZS5sb2FkaW5nID0gZmFsc2U7XG4gIHJlbmRlckFsbCgpO1xufVxuXG5mdW5jdGlvbiBzZXR1cEV2ZW50TGlzdGVuZXJzKCk6IHZvaWQge1xuICBjb25zdCBraWxsU3dpdGNoQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2tpbGwtc3dpdGNoLWJ0bicpO1xuICBpZiAoa2lsbFN3aXRjaEJ0bikge1xuICAgIGtpbGxTd2l0Y2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbktpbGxTd2l0Y2hDbGljayk7XG4gIH1cblxuICBjb25zdCB3aXphcmRCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGVsZWdhdGlvbi13aXphcmQtYnRuJyk7XG4gIGlmICh3aXphcmRCdG4pIHtcbiAgICB3aXphcmRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbkRlbGVnYXRpb25XaXphcmRDbGljayk7XG4gIH1cblxuICAvLyBMaXN0ZW4gZm9yIGxpdmUgdXBkYXRlcyBmcm9tIGJhY2tncm91bmRcbiAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtZXNzYWdlOiBNZXNzYWdlUGF5bG9hZCkgPT4ge1xuICAgIGlmICghbWVzc2FnZSB8fCAhbWVzc2FnZS50eXBlKSByZXR1cm47XG5cbiAgICBzd2l0Y2ggKG1lc3NhZ2UudHlwZSkge1xuICAgICAgY2FzZSAnREVURUNUSU9OX1JFU1VMVCc6XG4gICAgICAgIHF1ZXJ5QmFja2dyb3VuZFN0YXR1cygpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ0tJTExfU1dJVENIX1JFU1VMVCc6XG4gICAgICAgIHBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHJlbmRlckFsbCgpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ0RFTEVHQVRJT05fVVBEQVRFJzpcbiAgICAgICAgcXVlcnlCYWNrZ3JvdW5kU3RhdHVzKCk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gTGlzdGVuIGZvciBkZWxlZ2F0aW9uIGFjdGl2YXRpb24gZnJvbSB3aXphcmRcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignZGVsZWdhdGlvbi1hY3RpdmF0ZWQnLCAoKGU6IEN1c3RvbUV2ZW50PERlbGVnYXRpb25SdWxlPikgPT4ge1xuICAgIGNvbnN0IHJ1bGUgPSBlLmRldGFpbDtcbiAgICBzZW5kVG9CYWNrZ3JvdW5kKCdERUxFR0FUSU9OX1VQREFURScsIHJ1bGUpLnRoZW4oKCkgPT4ge1xuICAgICAgcG9wdXBTdGF0ZS5hY3RpdmVEZWxlZ2F0aW9uID0gcnVsZTtcbiAgICAgIHBvcHVwU3RhdGUud2l6YXJkU3RhdGUgPSBudWxsO1xuICAgICAgY29uc3Qgd2l6YXJkQ29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dpemFyZC1jb250YWluZXInKTtcbiAgICAgIGlmICh3aXphcmRDb250YWluZXIpIHtcbiAgICAgICAgd2l6YXJkQ29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgICAgICB3aXphcmRDb250YWluZXIuaW5uZXJIVE1MID0gJyc7XG4gICAgICB9XG4gICAgICByZW5kZXJBbGwoKTtcbiAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAvLyBTaG93IGVycm9yXG4gICAgfSk7XG4gIH0pIGFzIEV2ZW50TGlzdGVuZXIpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBvbktpbGxTd2l0Y2hDbGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2tpbGwtc3dpdGNoLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50IHwgbnVsbDtcbiAgaWYgKGJ0bikgYnRuLmRpc2FibGVkID0gdHJ1ZTtcblxuICB0cnkge1xuICAgIGF3YWl0IHNlbmRUb0JhY2tncm91bmQoJ0tJTExfU1dJVENIX0FDVElWQVRFJywgeyB0cmlnZ2VyOiAnYnV0dG9uJyB9KTtcbiAgICBwb3B1cFN0YXRlLmtpbGxTd2l0Y2hBY3RpdmUgPSB0cnVlO1xuICAgIHBvcHVwU3RhdGUuZGV0ZWN0ZWRBZ2VudHMgPSBbXTtcbiAgICBwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb24gPSBudWxsO1xuICAgIHJlbmRlckFsbCgpO1xuICB9IGNhdGNoIHtcbiAgICBpZiAoYnRuKSBidG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBvbkRlbGVnYXRpb25XaXphcmRDbGljaygpOiB2b2lkIHtcbiAgY29uc3Qgd2l6YXJkQ29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dpemFyZC1jb250YWluZXInKTtcbiAgaWYgKCF3aXphcmRDb250YWluZXIpIHJldHVybjtcblxuICBpZiAod2l6YXJkQ29udGFpbmVyLmNsYXNzTGlzdC5jb250YWlucygnaGlkZGVuJykpIHtcbiAgICB3aXphcmRDb250YWluZXIuY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG4gICAgcG9wdXBTdGF0ZS53aXphcmRTdGF0ZSA9IGNyZWF0ZUluaXRpYWxXaXphcmRTdGF0ZSgpO1xuICAgIHJlbmRlcldpemFyZFVJKCk7XG4gIH0gZWxzZSB7XG4gICAgd2l6YXJkQ29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgIHdpemFyZENvbnRhaW5lci5pbm5lckhUTUwgPSAnJztcbiAgICBwb3B1cFN0YXRlLndpemFyZFN0YXRlID0gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJXaXphcmRVSSgpOiB2b2lkIHtcbiAgY29uc3Qgd2l6YXJkQ29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dpemFyZC1jb250YWluZXInKTtcbiAgaWYgKCF3aXphcmRDb250YWluZXIgfHwgIXBvcHVwU3RhdGUud2l6YXJkU3RhdGUpIHJldHVybjtcblxuICByZW5kZXJXaXphcmQod2l6YXJkQ29udGFpbmVyLCBwb3B1cFN0YXRlLndpemFyZFN0YXRlLCAobmV3U3RhdGUpID0+IHtcbiAgICBwb3B1cFN0YXRlLndpemFyZFN0YXRlID0gbmV3U3RhdGU7XG4gICAgcmVuZGVyV2l6YXJkVUkoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFsbCgpOiB2b2lkIHtcbiAgcmVuZGVyRGV0ZWN0aW9uUGFuZWwoKTtcbiAgcmVuZGVyS2lsbFN3aXRjaFBhbmVsKCk7XG4gIHJlbmRlckRlbGVnYXRpb25QYW5lbCgpO1xuICByZW5kZXJWaW9sYXRpb25zUGFuZWwoKTtcbiAgcmVuZGVyVGltZWxpbmVQYW5lbCgpO1xuICByZW5kZXJTdGF0dXNCYWRnZSgpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJEZXRlY3Rpb25QYW5lbCgpOiB2b2lkIHtcbiAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RldGVjdGlvbi1jb250ZW50Jyk7XG4gIGlmICghY29udGFpbmVyKSByZXR1cm47XG5cbiAgaWYgKHBvcHVwU3RhdGUubG9hZGluZykge1xuICAgIGNvbnRhaW5lci5pbm5lckhUTUwgPSAnPHAgY2xhc3M9XCJwbGFjZWhvbGRlci10ZXh0LWlubGluZVwiPkxvYWRpbmcuLi48L3A+JztcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAocG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb250YWluZXIuaW5uZXJIVE1MID0gJzxwIGNsYXNzPVwicGxhY2Vob2xkZXItdGV4dC1pbmxpbmVcIj5ObyBhZ2VudHMgZGV0ZWN0ZWQ8L3A+JztcbiAgICByZXR1cm47XG4gIH1cblxuICBjb250YWluZXIuaW5uZXJIVE1MID0gJyc7XG4gIGZvciAoY29uc3QgYWdlbnQgb2YgcG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cykge1xuICAgIGNvbnN0IGNhcmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBjYXJkLmNsYXNzTmFtZSA9ICdkZXRlY3Rpb24tY2FyZCc7XG4gICAgY2FyZC5pbm5lckhUTUwgPSBgXG4gICAgICA8ZGl2IHN0eWxlPVwiZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBhbGlnbi1pdGVtczogY2VudGVyOyBtYXJnaW4tYm90dG9tOiAycHg7XCI+XG4gICAgICAgIDxzdHJvbmc+JHtmb3JtYXRBZ2VudFR5cGUoYWdlbnQudHlwZSl9PC9zdHJvbmc+XG4gICAgICAgIDxzcGFuIGNsYXNzPVwic2V2ZXJpdHktYmFkZ2Ugc2V2ZXJpdHktYmFkZ2UtaGlnaFwiPiR7YWdlbnQuY29uZmlkZW5jZX08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDEycHg7IGNvbG9yOiB2YXIoLS10ZXh0LXNlY29uZGFyeSk7IGZvbnQtd2VpZ2h0OiA1MDA7XCI+XG4gICAgICAgICR7Zm9ybWF0VGltZXN0YW1wKGFnZW50LmRldGVjdGVkQXQpfVxuICAgICAgICAke2FnZW50LmRldGVjdGlvbk1ldGhvZHMubWFwKChtKSA9PiBgPHNwYW4gY2xhc3M9XCJtZXRob2QtdGFnXCI+JHttfTwvc3Bhbj5gKS5qb2luKCcgJyl9XG4gICAgICA8L2Rpdj5cbiAgICBgO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChjYXJkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJLaWxsU3dpdGNoUGFuZWwoKTogdm9pZCB7XG4gIGNvbnN0IGJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdraWxsLXN3aXRjaC1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudCB8IG51bGw7XG4gIGlmICghYnRuKSByZXR1cm47XG5cbiAgYnRuLmRpc2FibGVkID0gcG9wdXBTdGF0ZS5kZXRlY3RlZEFnZW50cy5sZW5ndGggPT09IDAgJiYgIXBvcHVwU3RhdGUua2lsbFN3aXRjaEFjdGl2ZTtcblxuICBpZiAocG9wdXBTdGF0ZS5raWxsU3dpdGNoQWN0aXZlKSB7XG4gICAgYnRuLnRleHRDb250ZW50ID0gJ0tpbGxlZCc7XG4gICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgfSBlbHNlIHtcbiAgICBidG4udGV4dENvbnRlbnQgPSAnS2lsbCBTd2l0Y2gnO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckRlbGVnYXRpb25QYW5lbCgpOiB2b2lkIHtcbiAgY29uc3QgY29udGVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZWxlZ2F0aW9uLWNvbnRlbnQnKTtcbiAgaWYgKCFjb250ZW50KSByZXR1cm47XG5cbiAgaWYgKHBvcHVwU3RhdGUuYWN0aXZlRGVsZWdhdGlvbikge1xuICAgIGNvbnN0IHJ1bGUgPSBwb3B1cFN0YXRlLmFjdGl2ZURlbGVnYXRpb247XG4gICAgY29uc3QgcHJlc2V0TmFtZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgICByZWFkT25seTogJ1JlYWQtT25seScsXG4gICAgICBsaW1pdGVkOiAnTGltaXRlZCcsXG4gICAgICBmdWxsQWNjZXNzOiAnRnVsbCBBY2Nlc3MnLFxuICAgIH07XG5cbiAgICBsZXQgdGltZUluZm8gPSAnJztcbiAgICBpZiAocnVsZS5zY29wZS50aW1lQm91bmQpIHtcbiAgICAgIGNvbnN0IHJlbWFpbmluZyA9IG5ldyBEYXRlKHJ1bGUuc2NvcGUudGltZUJvdW5kLmV4cGlyZXNBdCkuZ2V0VGltZSgpIC0gRGF0ZS5ub3coKTtcbiAgICAgIGlmIChyZW1haW5pbmcgPiAwKSB7XG4gICAgICAgIGNvbnN0IG1pbnMgPSBNYXRoLmNlaWwocmVtYWluaW5nIC8gNjAwMDApO1xuICAgICAgICB0aW1lSW5mbyA9IGA8c3BhbiBzdHlsZT1cImZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6IHZhcigtLWNvbG9yLXdhcm5pbmcpO1wiPiAoJHttaW5zfW0gbGVmdCk8L3NwYW4+YDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRpbWVJbmZvID0gJzxzcGFuIHN0eWxlPVwiZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogdmFyKC0tY29sb3ItZGFuZ2VyKTtcIj4gKGV4cGlyZWQpPC9zcGFuPic7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwiZGVsZWdhdGlvbi1lbXB0eVwiPlxuICAgICAgICA8c3Bhbj48c3Ryb25nPiR7cHJlc2V0TmFtZXNbcnVsZS5wcmVzZXRdID8/IHJ1bGUucHJlc2V0fTwvc3Ryb25nPiR7dGltZUluZm99PC9zcGFuPlxuICAgICAgICA8YnV0dG9uIGlkPVwiZGVsZWdhdGlvbi13aXphcmQtYnRuXCIgY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIj5DaGFuZ2U8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIGA7XG5cbiAgICBjb25zdCB3aXphcmRCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGVsZWdhdGlvbi13aXphcmQtYnRuJyk7XG4gICAgaWYgKHdpemFyZEJ0bikge1xuICAgICAgd2l6YXJkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgb25EZWxlZ2F0aW9uV2l6YXJkQ2xpY2spO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICAgIDxkaXYgY2xhc3M9XCJkZWxlZ2F0aW9uLWVtcHR5XCI+XG4gICAgICAgIDxzcGFuIGNsYXNzPVwicGxhY2Vob2xkZXItdGV4dC1pbmxpbmVcIj5ObyBkZWxlZ2F0aW9uIGFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgPGJ1dHRvbiBpZD1cImRlbGVnYXRpb24td2l6YXJkLWJ0blwiIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiPkNvbmZpZ3VyZTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgYDtcbiAgICBjb25zdCB3aXphcmRCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZGVsZWdhdGlvbi13aXphcmQtYnRuJyk7XG4gICAgaWYgKHdpemFyZEJ0bikge1xuICAgICAgd2l6YXJkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgb25EZWxlZ2F0aW9uV2l6YXJkQ2xpY2spO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJWaW9sYXRpb25zUGFuZWwoKTogdm9pZCB7XG4gIGNvbnN0IHBhbmVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Zpb2xhdGlvbnMtcGFuZWwnKTtcbiAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Zpb2xhdGlvbnMtbGlzdCcpO1xuICBpZiAoIWNvbnRhaW5lciB8fCAhcGFuZWwpIHJldHVybjtcblxuICBpZiAocG9wdXBTdGF0ZS5yZWNlbnRWaW9sYXRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgIHBhbmVsLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICBjb250YWluZXIuaW5uZXJIVE1MID0gJyc7XG4gIGZvciAoY29uc3QgYWxlcnQgb2YgcG9wdXBTdGF0ZS5yZWNlbnRWaW9sYXRpb25zLnNsaWNlKC0xMCkucmV2ZXJzZSgpKSB7XG4gICAgY29uc3QgaXRlbSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGl0ZW0uY2xhc3NOYW1lID0gJ2V2ZW50LWl0ZW0nO1xuICAgIGl0ZW0uaW5uZXJIVE1MID0gYFxuICAgICAgPGRpdiBjbGFzcz1cImV2ZW50LW91dGNvbWUgb3V0Y29tZS1ibG9ja2VkXCI+PC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPVwiZmxleDogMTsgbWluLXdpZHRoOiAwO1wiPlxuICAgICAgICA8ZGl2IHN0eWxlPVwiZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1wiPlxuICAgICAgICAgIDxzcGFuIHN0eWxlPVwiZm9udC1zaXplOiAxM3B4OyBmb250LXdlaWdodDogNjAwO1wiPiR7YWxlcnQudGl0bGV9PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwic2V2ZXJpdHktYmFkZ2Ugc2V2ZXJpdHktJHthbGVydC5zZXZlcml0eX1cIj4ke2FsZXJ0LnNldmVyaXR5fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDEycHg7IGNvbG9yOiB2YXIoLS10ZXh0LXNlY29uZGFyeSk7IGZvbnQtd2VpZ2h0OiA1MDA7IG92ZXJmbG93OiBoaWRkZW47IHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzOyB3aGl0ZS1zcGFjZTogbm93cmFwO1wiPlxuICAgICAgICAgICR7dHJ1bmNhdGVVcmwoYWxlcnQudmlvbGF0aW9uLnVybCl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMXB4OyBjb2xvcjogdmFyKC0tdGV4dC1zZWNvbmRhcnkpOyBmb250LXdlaWdodDogNTAwO1wiPlxuICAgICAgICAgICR7Zm9ybWF0VGltZXN0YW1wKGFsZXJ0LnZpb2xhdGlvbi50aW1lc3RhbXApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIGA7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGl0ZW0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlclRpbWVsaW5lUGFuZWwoKTogdm9pZCB7XG4gIGNvbnN0IHBhbmVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RpbWVsaW5lLXBhbmVsJyk7XG4gIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0aW1lbGluZS1saXN0Jyk7XG4gIGlmICghY29udGFpbmVyIHx8ICFwYW5lbCkgcmV0dXJuO1xuXG4gIGNvbnN0IGxhdGVzdFNlc3Npb24gPSBwb3B1cFN0YXRlLnNlc3Npb25zWzBdO1xuICBpZiAoIWxhdGVzdFNlc3Npb24gfHwgbGF0ZXN0U2Vzc2lvbi5ldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgcGFuZWwuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG4gIGNvbnRhaW5lci5pbm5lckhUTUwgPSAnJztcbiAgY29uc3QgcmVjZW50RXZlbnRzID0gbGF0ZXN0U2Vzc2lvbi5ldmVudHMuc2xpY2UoLTE1KS5yZXZlcnNlKCk7XG4gIGZvciAoY29uc3QgZXZlbnQgb2YgcmVjZW50RXZlbnRzKSB7XG4gICAgY29uc3QgaXRlbSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGl0ZW0uY2xhc3NOYW1lID0gJ2V2ZW50LWl0ZW0nO1xuICAgIGNvbnN0IG91dGNvbWVDbGFzcyA9IGV2ZW50Lm91dGNvbWUgPT09ICdhbGxvd2VkJyA/ICdvdXRjb21lLWFsbG93ZWQnXG4gICAgICA6IGV2ZW50Lm91dGNvbWUgPT09ICdibG9ja2VkJyA/ICdvdXRjb21lLWJsb2NrZWQnXG4gICAgICA6ICdvdXRjb21lLWluZm8nO1xuXG4gICAgaXRlbS5pbm5lckhUTUwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwiZXZlbnQtb3V0Y29tZSAke291dGNvbWVDbGFzc31cIj48L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9XCJmbGV4OiAxOyBtaW4td2lkdGg6IDA7XCI+XG4gICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDEzcHg7IGZvbnQtd2VpZ2h0OiA1MDA7XCI+JHtldmVudC5kZXNjcmlwdGlvbn08L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZTogMTJweDsgY29sb3I6IHZhcigtLXRleHQtc2Vjb25kYXJ5KTsgZm9udC13ZWlnaHQ6IDUwMDtcIj5cbiAgICAgICAgICAke2Zvcm1hdFRpbWVzdGFtcChldmVudC50aW1lc3RhbXApfSB8ICR7dHJ1bmNhdGVVcmwoZXZlbnQudXJsLCAzMCl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgYDtcbiAgICBjb250YWluZXIuYXBwZW5kQ2hpbGQoaXRlbSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyU3RhdHVzQmFkZ2UoKTogdm9pZCB7XG4gIGNvbnN0IGluZGljYXRvciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXMtaW5kaWNhdG9yJyk7XG4gIGNvbnN0IHN0YXR1c1RleHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzLXRleHQnKTtcbiAgaWYgKCFpbmRpY2F0b3IgfHwgIXN0YXR1c1RleHQpIHJldHVybjtcblxuICBpbmRpY2F0b3IuY2xhc3NMaXN0LnJlbW92ZSgnc3RhdHVzLWlkbGUnLCAnc3RhdHVzLWRldGVjdGVkJywgJ3N0YXR1cy1raWxsZWQnLCAnc3RhdHVzLWRlbGVnYXRlZCcpO1xuXG4gIGlmIChwb3B1cFN0YXRlLmtpbGxTd2l0Y2hBY3RpdmUpIHtcbiAgICBpbmRpY2F0b3IuY2xhc3NMaXN0LmFkZCgnc3RhdHVzLWtpbGxlZCcpO1xuICAgIHN0YXR1c1RleHQudGV4dENvbnRlbnQgPSAnS2lsbGVkJztcbiAgfSBlbHNlIGlmIChwb3B1cFN0YXRlLmRldGVjdGVkQWdlbnRzLmxlbmd0aCA+IDApIHtcbiAgICBpbmRpY2F0b3IuY2xhc3NMaXN0LmFkZCgnc3RhdHVzLWRldGVjdGVkJyk7XG4gICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9IGAke3BvcHVwU3RhdGUuZGV0ZWN0ZWRBZ2VudHMubGVuZ3RofSBBZ2VudChzKSBEZXRlY3RlZGA7XG4gIH0gZWxzZSBpZiAocG9wdXBTdGF0ZS5hY3RpdmVEZWxlZ2F0aW9uKSB7XG4gICAgaW5kaWNhdG9yLmNsYXNzTGlzdC5hZGQoJ3N0YXR1cy1kZWxlZ2F0ZWQnKTtcbiAgICBzdGF0dXNUZXh0LnRleHRDb250ZW50ID0gJ0RlbGVnYXRlZCc7XG4gIH0gZWxzZSB7XG4gICAgaW5kaWNhdG9yLmNsYXNzTGlzdC5hZGQoJ3N0YXR1cy1pZGxlJyk7XG4gICAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9ICdNb25pdG9yaW5nJztcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzZW5kVG9CYWNrZ3JvdW5kKHR5cGU6IE1lc3NhZ2VUeXBlLCBkYXRhOiB1bmtub3duKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIGNvbnN0IG1lc3NhZ2U6IE1lc3NhZ2VQYXlsb2FkID0ge1xuICAgIHR5cGUsXG4gICAgZGF0YSxcbiAgICBzZW50QXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfTtcblxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1lc3NhZ2UsIChyZXNwb25zZSkgPT4ge1xuICAgICAgaWYgKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdFRpbWVzdGFtcChpc29UaW1lc3RhbXA6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShpc29UaW1lc3RhbXApO1xuICByZXR1cm4gZGF0ZS50b0xvY2FsZVRpbWVTdHJpbmcodW5kZWZpbmVkLCB7XG4gICAgaG91cjogJzItZGlnaXQnLFxuICAgIG1pbnV0ZTogJzItZGlnaXQnLFxuICAgIHNlY29uZDogJzItZGlnaXQnLFxuICB9KTtcbn1cblxuZnVuY3Rpb24gZm9ybWF0QWdlbnRUeXBlKHR5cGU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG5hbWVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgIHBsYXl3cmlnaHQ6ICdQbGF5d3JpZ2h0JyxcbiAgICBwdXBwZXRlZXI6ICdQdXBwZXRlZXInLFxuICAgIHNlbGVuaXVtOiAnU2VsZW5pdW0nLFxuICAgICdhbnRocm9waWMtY29tcHV0ZXItdXNlJzogJ0FudGhyb3BpYyBDb21wdXRlciBVc2UnLFxuICAgICdvcGVuYWktb3BlcmF0b3InOiAnT3BlbkFJIE9wZXJhdG9yJyxcbiAgICAnY2RwLWdlbmVyaWMnOiAnQ0RQIEFnZW50JyxcbiAgICAnd2ViZHJpdmVyLWdlbmVyaWMnOiAnV2ViRHJpdmVyIEFnZW50JyxcbiAgICB1bmtub3duOiAnVW5rbm93biBBZ2VudCcsXG4gIH07XG4gIHJldHVybiBuYW1lc1t0eXBlXSA/PyB0eXBlO1xufVxuXG5mdW5jdGlvbiB0cnVuY2F0ZVVybCh1cmw6IHN0cmluZywgbWF4TGVuZ3RoOiBudW1iZXIgPSA0MCk6IHN0cmluZyB7XG4gIGlmICh1cmwubGVuZ3RoIDw9IG1heExlbmd0aCkgcmV0dXJuIHVybDtcbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHVybCk7XG4gICAgY29uc3QgaG9zdCA9IHBhcnNlZC5ob3N0bmFtZTtcbiAgICBjb25zdCBwYXRoID0gcGFyc2VkLnBhdGhuYW1lO1xuICAgIGNvbnN0IGF2YWlsYWJsZSA9IG1heExlbmd0aCAtIGhvc3QubGVuZ3RoIC0gMztcbiAgICBpZiAoYXZhaWxhYmxlIDw9IDApIHJldHVybiBob3N0LnN1YnN0cmluZygwLCBtYXhMZW5ndGggLSAzKSArICcuLi4nO1xuICAgIHJldHVybiBob3N0ICsgcGF0aC5zdWJzdHJpbmcoMCwgYXZhaWxhYmxlKSArICcuLi4nO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gdXJsLnN1YnN0cmluZygwLCBtYXhMZW5ndGggLSAzKSArICcuLi4nO1xuICB9XG59XG5cbmluaXRpYWxpemUoKTtcbiJdLCJuYW1lcyI6WyJuZXh0U3RlcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxTQUFTLGFBQXFCO0FBQzVCLFNBQU8sT0FBTyxXQUFBO0FBQ2hCO0FBRUEsTUFBTSx5QkFBNEMsQ0FBQyxZQUFZLFVBQVU7QUFDekUsTUFBTSx1QkFBMEMsQ0FBQyxZQUFZLFlBQVksU0FBUyxXQUFXO0FBQzdGLE1BQU0sbUJBQXNDO0FBQUEsRUFDMUM7QUFBQSxFQUFZO0FBQUEsRUFBWTtBQUFBLEVBQVM7QUFBQSxFQUFhO0FBQUEsRUFDOUM7QUFBQSxFQUFpQjtBQUFBLEVBQVk7QUFBQSxFQUFhO0FBQUEsRUFDMUM7QUFBQSxFQUFrQjtBQUNwQjtBQUVBLFNBQVMsd0JBQXdCLFNBQWlEO0FBQ2hGLFNBQU8saUJBQWlCLElBQUksQ0FBQyxTQUFTO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osUUFBUSxRQUFRLFNBQVMsR0FBRyxJQUFJLFVBQW1CO0FBQUEsRUFBQSxFQUNuRDtBQUNKO0FBS08sU0FBUyxxQkFDZCxRQUNBLFNBS2dCO0FBQ2hCLFFBQU0sMEJBQVUsS0FBQTtBQUNoQixNQUFJO0FBRUosVUFBUSxRQUFBO0FBQUEsSUFDTixLQUFLO0FBQ0gsY0FBUTtBQUFBLFFBQ04sY0FBYyxDQUFBO0FBQUEsUUFDZCxvQkFBb0Isd0JBQXdCLHNCQUFzQjtBQUFBLFFBQ2xFLFdBQVc7QUFBQSxNQUFBO0FBRWI7QUFBQSxJQUVGLEtBQUssV0FBVztBQUNkLFlBQU0sa0JBQWtCLFNBQVMsbUJBQW1CO0FBQ3BELFlBQU0sWUFBWSxJQUFJLEtBQUssSUFBSSxRQUFBLElBQVksa0JBQWtCLEdBQUs7QUFDbEUsWUFBTSxZQUF1QjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxXQUFXLElBQUksWUFBQTtBQUFBLFFBQ2YsV0FBVyxVQUFVLFlBQUE7QUFBQSxNQUFZO0FBRW5DLGNBQVE7QUFBQSxRQUNOLGNBQWMsU0FBUyxnQkFBZ0IsQ0FBQTtBQUFBLFFBQ3ZDLG9CQUFvQix3QkFBd0Isb0JBQW9CO0FBQUEsUUFDaEU7QUFBQSxNQUFBO0FBRUY7QUFBQSxJQUNGO0FBQUEsSUFFQSxLQUFLO0FBQ0gsY0FBUTtBQUFBLFFBQ04sY0FBYyxDQUFBO0FBQUEsUUFDZCxvQkFBb0Isd0JBQXdCLGdCQUFnQjtBQUFBLFFBQzVELFdBQVc7QUFBQSxNQUFBO0FBRWI7QUFBQSxFQUFBO0FBR0osU0FBTztBQUFBLElBQ0wsSUFBSSxXQUFBO0FBQUEsSUFDSjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVcsSUFBSSxZQUFBO0FBQUEsSUFDZixVQUFVO0FBQUEsSUFDVixPQUFPLFNBQVM7QUFBQSxFQUFBO0FBRXBCO0FDMUVPLE1BQU0sd0JBQXdCO0FBQUEsRUFDbkMsRUFBRSxPQUFPLGNBQWMsU0FBUyxHQUFBO0FBQUEsRUFDaEMsRUFBRSxPQUFPLFVBQVUsU0FBUyxHQUFBO0FBQUEsRUFDNUIsRUFBRSxPQUFPLFdBQVcsU0FBUyxJQUFBO0FBQy9CO0FBRU8sU0FBUywyQkFBd0M7QUFDdEQsU0FBTztBQUFBLElBQ0wsYUFBYTtBQUFBLElBQ2IsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYyxDQUFBO0FBQUEsSUFDZCxpQkFBaUI7QUFBQSxJQUNqQixPQUFPO0FBQUEsSUFDUCxRQUFRLENBQUE7QUFBQSxFQUFDO0FBRWI7QUFLTyxTQUFTLGFBQWEsT0FBb0IsUUFBdUM7QUFDdEYsUUFBTUEsWUFBdUIsV0FBVyxZQUFZLFVBQVU7QUFDOUQsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0gsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYUE7QUFBQUEsSUFDYixRQUFRLENBQUE7QUFBQSxFQUFDO0FBRWI7QUFLTyxTQUFTLGVBQWUsT0FBb0IsU0FBbUM7QUFDcEYsTUFBSSxDQUFDLFFBQVEsUUFBUSxRQUFRO0FBQzNCLFdBQU8sRUFBRSxHQUFHLE9BQU8sUUFBUSxDQUFDLDBCQUEwQixFQUFBO0FBQUEsRUFDeEQ7QUFHQSxRQUFNLFNBQVMsTUFBTSxhQUFhLEtBQUssQ0FBQyxNQUFNLEVBQUUsWUFBWSxRQUFRLE9BQU87QUFDM0UsTUFBSSxRQUFRO0FBQ1YsV0FBTyxFQUFFLEdBQUcsT0FBTyxRQUFRLENBQUMsOEJBQThCLEVBQUE7QUFBQSxFQUM1RDtBQUVBLFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILGNBQWMsQ0FBQyxHQUFHLE1BQU0sY0FBYyxPQUFPO0FBQUEsSUFDN0MsUUFBUSxDQUFBO0FBQUEsRUFBQztBQUViO0FBS08sU0FBUyxrQkFBa0IsT0FBb0IsT0FBNEI7QUFDaEYsUUFBTSxlQUFlLE1BQU0sYUFBYSxPQUFPLENBQUMsR0FBRyxNQUFNLE1BQU0sS0FBSztBQUNwRSxTQUFPLEVBQUUsR0FBRyxPQUFPLGNBQWMsUUFBUSxDQUFBLEVBQUM7QUFDNUM7QUFLTyxTQUFTLFlBQVksT0FBb0IsU0FBOEI7QUFDNUUsUUFBTSxRQUFRLHNCQUFzQixLQUFLLENBQUMsUUFBUSxJQUFJLFlBQVksT0FBTztBQUN6RSxNQUFJLENBQUMsT0FBTztBQUNWLFdBQU8sRUFBRSxHQUFHLE9BQU8sUUFBUSxDQUFDLDBEQUEwRCxFQUFBO0FBQUEsRUFDeEY7QUFDQSxTQUFPLEVBQUUsR0FBRyxPQUFPLGlCQUFpQixTQUFTLFFBQVEsQ0FBQSxFQUFDO0FBQ3hEO0FBS08sU0FBUyxTQUFTLE9BQWlDO0FBQ3hELFVBQVEsTUFBTSxhQUFBO0FBQUEsSUFDWixLQUFLO0FBQ0gsVUFBSSxDQUFDLE1BQU0sZ0JBQWdCO0FBQ3pCLGVBQU8sRUFBRSxHQUFHLE9BQU8sUUFBUSxDQUFDLDZCQUE2QixFQUFBO0FBQUEsTUFDM0Q7QUFDQSxVQUFJLE1BQU0sbUJBQW1CLFdBQVc7QUFDdEMsZUFBTyxFQUFFLEdBQUcsT0FBTyxhQUFhLFNBQVMsUUFBUSxDQUFBLEVBQUM7QUFBQSxNQUNwRDtBQUNBLGFBQU8sRUFBRSxHQUFHLE9BQU8sYUFBYSxXQUFXLFFBQVEsQ0FBQSxFQUFDO0FBQUEsSUFFdEQsS0FBSztBQUNILFVBQUksTUFBTSxhQUFhLFdBQVcsR0FBRztBQUNuQyxlQUFPLEVBQUUsR0FBRyxPQUFPLFFBQVEsQ0FBQyxnQ0FBZ0MsRUFBQTtBQUFBLE1BQzlEO0FBQ0EsYUFBTyxFQUFFLEdBQUcsT0FBTyxhQUFhLFFBQVEsUUFBUSxDQUFBLEVBQUM7QUFBQSxJQUVuRCxLQUFLO0FBQ0gsVUFBSSxNQUFNLG9CQUFvQixNQUFNO0FBQ2xDLGVBQU8sRUFBRSxHQUFHLE9BQU8sUUFBUSxDQUFDLHlCQUF5QixFQUFBO0FBQUEsTUFDdkQ7QUFDQSxhQUFPLEVBQUUsR0FBRyxPQUFPLGFBQWEsV0FBVyxRQUFRLENBQUEsRUFBQztBQUFBLElBRXRELEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFFVDtBQUNFLGFBQU87QUFBQSxFQUFBO0FBRWI7QUFLTyxTQUFTLGFBQWEsT0FBaUM7QUFDNUQsUUFBTSxZQUEwQixDQUFDLFVBQVUsU0FBUyxRQUFRLFNBQVM7QUFDckUsUUFBTSxlQUFlLFVBQVUsUUFBUSxNQUFNLFdBQVc7QUFFeEQsTUFBSSxnQkFBZ0IsRUFBRyxRQUFPO0FBRzlCLE1BQUksTUFBTSxnQkFBZ0IsYUFBYSxNQUFNLG1CQUFtQixXQUFXO0FBQ3pFLFdBQU8sRUFBRSxHQUFHLE9BQU8sYUFBYSxVQUFVLFFBQVEsQ0FBQSxFQUFDO0FBQUEsRUFDckQ7QUFFQSxTQUFPLEVBQUUsR0FBRyxPQUFPLGFBQWEsVUFBVSxlQUFlLENBQUMsR0FBRyxRQUFRLEdBQUM7QUFDeEU7QUFLTyxTQUFTLGVBQWUsT0FBMkM7QUFDeEUsTUFBSSxDQUFDLE1BQU0sZUFBZ0IsUUFBTztBQUVsQyxNQUFJLE1BQU0sbUJBQW1CLFdBQVc7QUFDdEMsUUFBSSxNQUFNLGFBQWEsV0FBVyxFQUFHLFFBQU87QUFDNUMsUUFBSSxNQUFNLG9CQUFvQixLQUFNLFFBQU87QUFBQSxFQUM3QztBQUVBLFNBQU8scUJBQXFCLE1BQU0sZ0JBQWdCO0FBQUEsSUFDaEQsY0FBYyxNQUFNO0FBQUEsSUFDcEIsaUJBQWlCLE1BQU0sbUJBQW1CO0FBQUEsSUFDMUMsT0FBTyxNQUFNLFNBQVM7QUFBQSxFQUFBLENBQ3ZCO0FBQ0g7QUFFQSxNQUFNLHNCQUF3RjtBQUFBLEVBQzVGLFVBQVU7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLGFBQWE7QUFBQSxFQUFBO0FBQUEsRUFFZixTQUFTO0FBQUEsSUFDUCxPQUFPO0FBQUEsSUFDUCxhQUFhO0FBQUEsRUFBQTtBQUFBLEVBRWYsWUFBWTtBQUFBLElBQ1YsT0FBTztBQUFBLElBQ1AsYUFBYTtBQUFBLEVBQUE7QUFFakI7QUFLTyxTQUFTLGFBQ2QsV0FDQSxPQUNBLGVBQ007QUFDTixZQUFVLFlBQVk7QUFHdEIsTUFBSSxNQUFNLE9BQU8sU0FBUyxHQUFHO0FBQzNCLFVBQU0sV0FBVyxTQUFTLGNBQWMsS0FBSztBQUM3QyxhQUFTLFlBQVk7QUFDckIsYUFBUyxNQUFNLFVBQVU7QUFDekIsYUFBUyxjQUFjLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFDNUMsY0FBVSxZQUFZLFFBQVE7QUFBQSxFQUNoQztBQUVBLFVBQVEsTUFBTSxhQUFBO0FBQUEsSUFDWixLQUFLO0FBQ0gsdUJBQWlCLFdBQVcsT0FBTyxhQUFhO0FBQ2hEO0FBQUEsSUFDRixLQUFLO0FBQ0gsc0JBQWdCLFdBQVcsT0FBTyxhQUFhO0FBQy9DO0FBQUEsSUFDRixLQUFLO0FBQ0gscUJBQWUsV0FBVyxPQUFPLGFBQWE7QUFDOUM7QUFBQSxJQUNGLEtBQUs7QUFDSCx3QkFBa0IsV0FBVyxPQUFPLGFBQWE7QUFDakQ7QUFBQSxFQUFBO0FBRU47QUFFQSxTQUFTLGlCQUNQLFdBQ0EsT0FDQSxlQUNNO0FBQ04sUUFBTSxVQUE4QixDQUFDLFlBQVksV0FBVyxZQUFZO0FBQ3hFLGFBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQU0sT0FBTyxvQkFBb0IsTUFBTTtBQUN2QyxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZLGNBQWMsTUFBTSxtQkFBbUIsU0FBUyxjQUFjLEVBQUU7QUFDakYsU0FBSyxZQUFZO0FBQUEsZ0JBQ0wsS0FBSyxLQUFLO0FBQUEsbUZBQ3lELEtBQUssV0FBVztBQUFBO0FBRS9GLFNBQUssaUJBQWlCLFNBQVMsTUFBTTtBQUNuQyxvQkFBYyxhQUFhLE9BQU8sTUFBTSxDQUFDO0FBQUEsSUFDM0MsQ0FBQztBQUNELGNBQVUsWUFBWSxJQUFJO0FBQUEsRUFDNUI7QUFDRjtBQUVBLFNBQVMsZ0JBQ1AsV0FDQSxPQUNBLGVBQ007QUFDTixRQUFNLFVBQVUsU0FBUyxjQUFjLEdBQUc7QUFDMUMsVUFBUSxNQUFNLFVBQVU7QUFDeEIsVUFBUSxjQUFjO0FBQ3RCLFlBQVUsWUFBWSxPQUFPO0FBRzdCLFFBQU0sV0FBVyxTQUFTLGNBQWMsS0FBSztBQUM3QyxXQUFTLE1BQU0sVUFBVTtBQUV6QixRQUFNLFFBQVEsU0FBUyxjQUFjLE9BQU87QUFDNUMsUUFBTSxPQUFPO0FBQ2IsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNsQixRQUFNLE1BQU0sVUFBVTtBQUV0QixRQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFDOUMsU0FBTyxZQUFZO0FBQ25CLFNBQU8sY0FBYztBQUNyQixTQUFPLE1BQU0sVUFBVTtBQUN2QixTQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsVUFBTSxRQUFRLE1BQU0sTUFBTSxLQUFBO0FBQzFCLFFBQUksT0FBTztBQUNULG9CQUFjLGVBQWUsT0FBTyxFQUFFLFNBQVMsT0FBTyxRQUFRLFFBQUEsQ0FBUyxDQUFDO0FBQ3hFLFlBQU0sUUFBUTtBQUFBLElBQ2hCO0FBQUEsRUFDRixDQUFDO0FBRUQsV0FBUyxZQUFZLEtBQUs7QUFDMUIsV0FBUyxZQUFZLE1BQU07QUFDM0IsWUFBVSxZQUFZLFFBQVE7QUFHOUIsV0FBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLGFBQWEsUUFBUSxLQUFLO0FBQ2xELFVBQU0sSUFBSSxNQUFNLGFBQWEsQ0FBQztBQUM5QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxNQUFNLFVBQVU7QUFDcEIsUUFBSSxZQUFZLDZDQUE2QyxFQUFFLE9BQU8sS0FBSyxFQUFFLE1BQU07QUFDbkYsVUFBTSxZQUFZLFNBQVMsY0FBYyxRQUFRO0FBQ2pELGNBQVUsWUFBWTtBQUN0QixjQUFVLGNBQWM7QUFDeEIsY0FBVSxNQUFNLFVBQVU7QUFDMUIsY0FBVSxpQkFBaUIsU0FBUyxNQUFNLGNBQWMsa0JBQWtCLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDcEYsUUFBSSxZQUFZLFNBQVM7QUFDekIsY0FBVSxZQUFZLEdBQUc7QUFBQSxFQUMzQjtBQUdBLG1CQUFpQixXQUFXLE9BQU8sYUFBYTtBQUNsRDtBQUVBLFNBQVMsZUFDUCxXQUNBLE9BQ0EsZUFDTTtBQUNOLFFBQU0sVUFBVSxTQUFTLGNBQWMsR0FBRztBQUMxQyxVQUFRLE1BQU0sVUFBVTtBQUN4QixVQUFRLGNBQWM7QUFDdEIsWUFBVSxZQUFZLE9BQU87QUFFN0IsYUFBVyxVQUFVLHVCQUF1QjtBQUMxQyxVQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsUUFBSSxZQUFZLE9BQU8sTUFBTSxvQkFBb0IsT0FBTyxVQUFVLGdCQUFnQixlQUFlO0FBQ2pHLFFBQUksY0FBYyxPQUFPO0FBQ3pCLFFBQUksTUFBTSxVQUFVO0FBQ3BCLFFBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUNsQyxZQUFNLFVBQVUsWUFBWSxPQUFPLE9BQU8sT0FBTztBQUNqRCxvQkFBYyxTQUFTLE9BQU8sQ0FBQztBQUFBLElBQ2pDLENBQUM7QUFDRCxjQUFVLFlBQVksR0FBRztBQUFBLEVBQzNCO0FBRUEsbUJBQWlCLFdBQVcsT0FBTyxlQUFlLElBQUk7QUFDeEQ7QUFFQSxTQUFTLGtCQUNQLFdBQ0EsT0FDQSxlQUNNO0FBQ04sUUFBTSxTQUFTLE1BQU07QUFDckIsTUFBSSxDQUFDLE9BQVE7QUFFYixRQUFNLE9BQU8sb0JBQW9CLE1BQU07QUFDdkMsUUFBTSxVQUFVLFNBQVMsY0FBYyxLQUFLO0FBQzVDLFVBQVEsTUFBTSxVQUFVO0FBRXhCLE1BQUksT0FBTywrQkFBK0IsS0FBSyxLQUFLO0FBQ3BELE1BQUksTUFBTSxhQUFhLFNBQVMsR0FBRztBQUNqQyxZQUFRLDhCQUE4QixNQUFNLGFBQWEsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxFQUMzRjtBQUNBLE1BQUksTUFBTSxpQkFBaUI7QUFDekIsVUFBTSxNQUFNLHNCQUFzQixLQUFLLENBQUMsTUFBTSxFQUFFLFlBQVksTUFBTSxlQUFlO0FBQ2pGLFlBQVEsaUNBQWlDLEtBQUssU0FBUyxNQUFNLGtCQUFrQixVQUFVO0FBQUEsRUFDM0Y7QUFDQSxVQUFRLFlBQVk7QUFDcEIsWUFBVSxZQUFZLE9BQU87QUFHN0IsUUFBTSxhQUFhLFNBQVMsY0FBYyxPQUFPO0FBQ2pELGFBQVcsT0FBTztBQUNsQixhQUFXLGNBQWM7QUFDekIsYUFBVyxZQUFZO0FBQ3ZCLGFBQVcsUUFBUSxNQUFNO0FBQ3pCLGFBQVcsTUFBTSxVQUFVO0FBQzNCLGFBQVcsaUJBQWlCLFNBQVMsTUFBTTtBQUN6QyxVQUFNLFFBQVEsV0FBVztBQUFBLEVBQzNCLENBQUM7QUFDRCxZQUFVLFlBQVksVUFBVTtBQUdoQyxRQUFNLGNBQWMsU0FBUyxjQUFjLFFBQVE7QUFDbkQsY0FBWSxZQUFZO0FBQ3hCLGNBQVksY0FBYztBQUMxQixjQUFZLE1BQU0sVUFBVTtBQUM1QixjQUFZLGlCQUFpQixTQUFTLE1BQU07QUFDMUMsVUFBTSxPQUFPLGVBQWUsS0FBSztBQUNqQyxRQUFJLE1BQU07QUFFUixnQkFBVTtBQUFBLFFBQ1IsSUFBSSxZQUFZLHdCQUF3QixFQUFFLFFBQVEsTUFBTSxTQUFTLE1BQU07QUFBQSxNQUFBO0FBQUEsSUFFM0U7QUFBQSxFQUNGLENBQUM7QUFDRCxZQUFVLFlBQVksV0FBVztBQUVqQyxtQkFBaUIsV0FBVyxPQUFPLGVBQWUsSUFBSTtBQUN4RDtBQUVBLFNBQVMsaUJBQ1AsV0FDQSxPQUNBLGVBQ0EsV0FBVyxPQUNMO0FBQ04sUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksTUFBTSxVQUFVO0FBRXBCLE1BQUksVUFBVTtBQUNaLFVBQU0sVUFBVSxTQUFTLGNBQWMsUUFBUTtBQUMvQyxZQUFRLFlBQVk7QUFDcEIsWUFBUSxjQUFjO0FBQ3RCLFlBQVEsTUFBTSxVQUFVO0FBQ3hCLFlBQVEsaUJBQWlCLFNBQVMsTUFBTSxjQUFjLGFBQWEsS0FBSyxDQUFDLENBQUM7QUFDMUUsUUFBSSxZQUFZLE9BQU87QUFBQSxFQUN6QjtBQUVBLE1BQUksTUFBTSxnQkFBZ0IsU0FBUztBQUNqQyxVQUFNLFVBQVUsU0FBUyxjQUFjLFFBQVE7QUFDL0MsWUFBUSxZQUFZO0FBQ3BCLFlBQVEsY0FBYztBQUN0QixZQUFRLE1BQU0sVUFBVTtBQUN4QixZQUFRLGlCQUFpQixTQUFTLE1BQU0sY0FBYyxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQ3RFLFFBQUksWUFBWSxPQUFPO0FBQUEsRUFDekI7QUFFQSxNQUFJLElBQUksU0FBUyxTQUFTLEdBQUc7QUFDM0IsY0FBVSxZQUFZLEdBQUc7QUFBQSxFQUMzQjtBQUNGO0FDbFhBLElBQUksYUFBeUI7QUFBQSxFQUMzQixnQkFBZ0IsQ0FBQTtBQUFBLEVBQ2hCLGtCQUFrQjtBQUFBLEVBQ2xCLGtCQUFrQjtBQUFBLEVBQ2xCLGtCQUFrQixDQUFBO0FBQUEsRUFDbEIsVUFBVSxDQUFBO0FBQUEsRUFDVixhQUFhO0FBQUEsRUFDYixTQUFTO0FBQ1g7QUFFQSxTQUFTLGFBQW1CO0FBQzFCLFdBQVMsaUJBQWlCLG9CQUFvQixNQUFNO0FBQ2xELHdCQUFBO0FBQ0EsMEJBQUE7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLGVBQWUsd0JBQXVDO0FBQ3BELE1BQUk7QUFDRixVQUFNLFdBQVcsTUFBTSxpQkFBaUIsZ0JBQWdCLENBQUEsQ0FBRTtBQUMxRCxRQUFJLFlBQVksT0FBTyxhQUFhLFVBQVU7QUFDNUMsWUFBTSxPQUFPO0FBTWIsaUJBQVcsaUJBQWlCLEtBQUssa0JBQWtCLENBQUE7QUFDbkQsaUJBQVcsbUJBQW1CLEtBQUssb0JBQW9CO0FBQ3ZELGlCQUFXLG1CQUFtQixLQUFLLG9CQUFvQjtBQUN2RCxpQkFBVyxtQkFBbUIsS0FBSyxvQkFBb0IsQ0FBQTtBQUFBLElBQ3pEO0FBQUEsRUFDRixRQUFRO0FBQUEsRUFFUjtBQUdBLE1BQUk7QUFDRixVQUFNLGtCQUFrQixNQUFNLGlCQUFpQixpQkFBaUIsQ0FBQSxDQUFFO0FBQ2xFLFFBQUksbUJBQW1CLE9BQU8sb0JBQW9CLFVBQVU7QUFDMUQsWUFBTSxPQUFPO0FBQ2IsaUJBQVcsV0FBVyxLQUFLLFlBQVksQ0FBQTtBQUFBLElBQ3pDO0FBQUEsRUFDRixRQUFRO0FBQUEsRUFFUjtBQUVBLGFBQVcsVUFBVTtBQUNyQixZQUFBO0FBQ0Y7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxRQUFNLGdCQUFnQixTQUFTLGVBQWUsaUJBQWlCO0FBQy9ELE1BQUksZUFBZTtBQUNqQixrQkFBYyxpQkFBaUIsU0FBUyxpQkFBaUI7QUFBQSxFQUMzRDtBQUVBLFFBQU0sWUFBWSxTQUFTLGVBQWUsdUJBQXVCO0FBQ2pFLE1BQUksV0FBVztBQUNiLGNBQVUsaUJBQWlCLFNBQVMsdUJBQXVCO0FBQUEsRUFDN0Q7QUFHQSxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsWUFBNEI7QUFDaEUsUUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQU07QUFFL0IsWUFBUSxRQUFRLE1BQUE7QUFBQSxNQUNkLEtBQUs7QUFDSCw4QkFBQTtBQUNBO0FBQUEsTUFDRixLQUFLO0FBQ0gsbUJBQVcsbUJBQW1CO0FBQzlCLGtCQUFBO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCw4QkFBQTtBQUNBO0FBQUEsSUFBQTtBQUFBLEVBRU4sQ0FBQztBQUdELFdBQVMsaUJBQWlCLHdCQUF5QixDQUFDLE1BQW1DO0FBQ3JGLFVBQU0sT0FBTyxFQUFFO0FBQ2YscUJBQWlCLHFCQUFxQixJQUFJLEVBQUUsS0FBSyxNQUFNO0FBQ3JELGlCQUFXLG1CQUFtQjtBQUM5QixpQkFBVyxjQUFjO0FBQ3pCLFlBQU0sa0JBQWtCLFNBQVMsZUFBZSxrQkFBa0I7QUFDbEUsVUFBSSxpQkFBaUI7QUFDbkIsd0JBQWdCLFVBQVUsSUFBSSxRQUFRO0FBQ3RDLHdCQUFnQixZQUFZO0FBQUEsTUFDOUI7QUFDQSxnQkFBQTtBQUFBLElBQ0YsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLElBRWYsQ0FBQztBQUFBLEVBQ0gsQ0FBbUI7QUFDckI7QUFFQSxlQUFlLG9CQUFtQztBQUNoRCxRQUFNLE1BQU0sU0FBUyxlQUFlLGlCQUFpQjtBQUNyRCxNQUFJLFNBQVMsV0FBVztBQUV4QixNQUFJO0FBQ0YsVUFBTSxpQkFBaUIsd0JBQXdCLEVBQUUsU0FBUyxVQUFVO0FBQ3BFLGVBQVcsbUJBQW1CO0FBQzlCLGVBQVcsaUJBQWlCLENBQUE7QUFDNUIsZUFBVyxtQkFBbUI7QUFDOUIsY0FBQTtBQUFBLEVBQ0YsUUFBUTtBQUNOLFFBQUksU0FBUyxXQUFXO0FBQUEsRUFDMUI7QUFDRjtBQUVBLFNBQVMsMEJBQWdDO0FBQ3ZDLFFBQU0sa0JBQWtCLFNBQVMsZUFBZSxrQkFBa0I7QUFDbEUsTUFBSSxDQUFDLGdCQUFpQjtBQUV0QixNQUFJLGdCQUFnQixVQUFVLFNBQVMsUUFBUSxHQUFHO0FBQ2hELG9CQUFnQixVQUFVLE9BQU8sUUFBUTtBQUN6QyxlQUFXLGNBQWMseUJBQUE7QUFDekIsbUJBQUE7QUFBQSxFQUNGLE9BQU87QUFDTCxvQkFBZ0IsVUFBVSxJQUFJLFFBQVE7QUFDdEMsb0JBQWdCLFlBQVk7QUFDNUIsZUFBVyxjQUFjO0FBQUEsRUFDM0I7QUFDRjtBQUVBLFNBQVMsaUJBQXVCO0FBQzlCLFFBQU0sa0JBQWtCLFNBQVMsZUFBZSxrQkFBa0I7QUFDbEUsTUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsWUFBYTtBQUVqRCxlQUFhLGlCQUFpQixXQUFXLGFBQWEsQ0FBQyxhQUFhO0FBQ2xFLGVBQVcsY0FBYztBQUN6QixtQkFBQTtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyxZQUFrQjtBQUN6Qix1QkFBQTtBQUNBLHdCQUFBO0FBQ0Esd0JBQUE7QUFDQSx3QkFBQTtBQUNBLHNCQUFBO0FBQ0Esb0JBQUE7QUFDRjtBQUVBLFNBQVMsdUJBQTZCO0FBQ3BDLFFBQU0sWUFBWSxTQUFTLGVBQWUsbUJBQW1CO0FBQzdELE1BQUksQ0FBQyxVQUFXO0FBRWhCLE1BQUksV0FBVyxTQUFTO0FBQ3RCLGNBQVUsWUFBWTtBQUN0QjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLFdBQVcsZUFBZSxXQUFXLEdBQUc7QUFDMUMsY0FBVSxZQUFZO0FBQ3RCO0FBQUEsRUFDRjtBQUVBLFlBQVUsWUFBWTtBQUN0QixhQUFXLFNBQVMsV0FBVyxnQkFBZ0I7QUFDN0MsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLFlBQVk7QUFBQTtBQUFBLGtCQUVILGdCQUFnQixNQUFNLElBQUksQ0FBQztBQUFBLDJEQUNjLE1BQU0sVUFBVTtBQUFBO0FBQUE7QUFBQSxVQUdqRSxnQkFBZ0IsTUFBTSxVQUFVLENBQUM7QUFBQSxVQUNqQyxNQUFNLGlCQUFpQixJQUFJLENBQUMsTUFBTSw0QkFBNEIsQ0FBQyxTQUFTLEVBQUUsS0FBSyxHQUFHLENBQUM7QUFBQTtBQUFBO0FBR3pGLGNBQVUsWUFBWSxJQUFJO0FBQUEsRUFDNUI7QUFDRjtBQUVBLFNBQVMsd0JBQThCO0FBQ3JDLFFBQU0sTUFBTSxTQUFTLGVBQWUsaUJBQWlCO0FBQ3JELE1BQUksQ0FBQyxJQUFLO0FBRVYsTUFBSSxXQUFXLFdBQVcsZUFBZSxXQUFXLEtBQUssQ0FBQyxXQUFXO0FBRXJFLE1BQUksV0FBVyxrQkFBa0I7QUFDL0IsUUFBSSxjQUFjO0FBQ2xCLFFBQUksV0FBVztBQUFBLEVBQ2pCLE9BQU87QUFDTCxRQUFJLGNBQWM7QUFBQSxFQUNwQjtBQUNGO0FBRUEsU0FBUyx3QkFBOEI7QUFDckMsUUFBTSxVQUFVLFNBQVMsZUFBZSxvQkFBb0I7QUFDNUQsTUFBSSxDQUFDLFFBQVM7QUFFZCxNQUFJLFdBQVcsa0JBQWtCO0FBQy9CLFVBQU0sT0FBTyxXQUFXO0FBQ3hCLFVBQU0sY0FBc0M7QUFBQSxNQUMxQyxVQUFVO0FBQUEsTUFDVixTQUFTO0FBQUEsTUFDVCxZQUFZO0FBQUEsSUFBQTtBQUdkLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxNQUFNLFdBQVc7QUFDeEIsWUFBTSxZQUFZLElBQUksS0FBSyxLQUFLLE1BQU0sVUFBVSxTQUFTLEVBQUUsWUFBWSxLQUFLLElBQUE7QUFDNUUsVUFBSSxZQUFZLEdBQUc7QUFDakIsY0FBTSxPQUFPLEtBQUssS0FBSyxZQUFZLEdBQUs7QUFDeEMsbUJBQVcsbUZBQW1GLElBQUk7QUFBQSxNQUNwRyxPQUFPO0FBQ0wsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRjtBQUVBLFlBQVEsWUFBWTtBQUFBO0FBQUEsd0JBRUEsWUFBWSxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sWUFBWSxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBSy9FLFVBQU0sWUFBWSxTQUFTLGVBQWUsdUJBQXVCO0FBQ2pFLFFBQUksV0FBVztBQUNiLGdCQUFVLGlCQUFpQixTQUFTLHVCQUF1QjtBQUFBLElBQzdEO0FBQUEsRUFDRixPQUFPO0FBQ0wsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU1wQixVQUFNLFlBQVksU0FBUyxlQUFlLHVCQUF1QjtBQUNqRSxRQUFJLFdBQVc7QUFDYixnQkFBVSxpQkFBaUIsU0FBUyx1QkFBdUI7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQThCO0FBQ3JDLFFBQU0sUUFBUSxTQUFTLGVBQWUsa0JBQWtCO0FBQ3hELFFBQU0sWUFBWSxTQUFTLGVBQWUsaUJBQWlCO0FBQzNELE1BQUksQ0FBQyxhQUFhLENBQUMsTUFBTztBQUUxQixNQUFJLFdBQVcsaUJBQWlCLFdBQVcsR0FBRztBQUM1QyxVQUFNLFVBQVUsSUFBSSxRQUFRO0FBQzVCO0FBQUEsRUFDRjtBQUVBLFFBQU0sVUFBVSxPQUFPLFFBQVE7QUFDL0IsWUFBVSxZQUFZO0FBQ3RCLGFBQVcsU0FBUyxXQUFXLGlCQUFpQixNQUFNLEdBQUcsRUFBRSxXQUFXO0FBQ3BFLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkRBSXdDLE1BQU0sS0FBSztBQUFBLGlEQUN2QixNQUFNLFFBQVEsS0FBSyxNQUFNLFFBQVE7QUFBQTtBQUFBO0FBQUEsWUFHdEUsWUFBWSxNQUFNLFVBQVUsR0FBRyxDQUFDO0FBQUE7QUFBQTtBQUFBLFlBR2hDLGdCQUFnQixNQUFNLFVBQVUsU0FBUyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBSWxELGNBQVUsWUFBWSxJQUFJO0FBQUEsRUFDNUI7QUFDRjtBQUVBLFNBQVMsc0JBQTRCO0FBQ25DLFFBQU0sUUFBUSxTQUFTLGVBQWUsZ0JBQWdCO0FBQ3RELFFBQU0sWUFBWSxTQUFTLGVBQWUsZUFBZTtBQUN6RCxNQUFJLENBQUMsYUFBYSxDQUFDLE1BQU87QUFFMUIsUUFBTSxnQkFBZ0IsV0FBVyxTQUFTLENBQUM7QUFDM0MsTUFBSSxDQUFDLGlCQUFpQixjQUFjLE9BQU8sV0FBVyxHQUFHO0FBQ3ZELFVBQU0sVUFBVSxJQUFJLFFBQVE7QUFDNUI7QUFBQSxFQUNGO0FBRUEsUUFBTSxVQUFVLE9BQU8sUUFBUTtBQUMvQixZQUFVLFlBQVk7QUFDdEIsUUFBTSxlQUFlLGNBQWMsT0FBTyxNQUFNLEdBQUcsRUFBRSxRQUFBO0FBQ3JELGFBQVcsU0FBUyxjQUFjO0FBQ2hDLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxlQUFlLE1BQU0sWUFBWSxZQUFZLG9CQUMvQyxNQUFNLFlBQVksWUFBWSxvQkFDOUI7QUFFSixTQUFLLFlBQVk7QUFBQSxrQ0FDYSxZQUFZO0FBQUE7QUFBQSwwREFFWSxNQUFNLFdBQVc7QUFBQTtBQUFBLFlBRS9ELGdCQUFnQixNQUFNLFNBQVMsQ0FBQyxNQUFNLFlBQVksTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUl4RSxjQUFVLFlBQVksSUFBSTtBQUFBLEVBQzVCO0FBQ0Y7QUFFQSxTQUFTLG9CQUEwQjtBQUNqQyxRQUFNLFlBQVksU0FBUyxlQUFlLGtCQUFrQjtBQUM1RCxRQUFNLGFBQWEsU0FBUyxlQUFlLGFBQWE7QUFDeEQsTUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFZO0FBRS9CLFlBQVUsVUFBVSxPQUFPLGVBQWUsbUJBQW1CLGlCQUFpQixrQkFBa0I7QUFFaEcsTUFBSSxXQUFXLGtCQUFrQjtBQUMvQixjQUFVLFVBQVUsSUFBSSxlQUFlO0FBQ3ZDLGVBQVcsY0FBYztBQUFBLEVBQzNCLFdBQVcsV0FBVyxlQUFlLFNBQVMsR0FBRztBQUMvQyxjQUFVLFVBQVUsSUFBSSxpQkFBaUI7QUFDekMsZUFBVyxjQUFjLEdBQUcsV0FBVyxlQUFlLE1BQU07QUFBQSxFQUM5RCxXQUFXLFdBQVcsa0JBQWtCO0FBQ3RDLGNBQVUsVUFBVSxJQUFJLGtCQUFrQjtBQUMxQyxlQUFXLGNBQWM7QUFBQSxFQUMzQixPQUFPO0FBQ0wsY0FBVSxVQUFVLElBQUksYUFBYTtBQUNyQyxlQUFXLGNBQWM7QUFBQSxFQUMzQjtBQUNGO0FBRUEsZUFBZSxpQkFBaUIsTUFBbUIsTUFBaUM7QUFDbEYsUUFBTSxVQUEwQjtBQUFBLElBQzlCO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUSxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLEVBQVk7QUFHakMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsV0FBTyxRQUFRLFlBQVksU0FBUyxDQUFDLGFBQWE7QUFDaEQsVUFBSSxPQUFPLFFBQVEsV0FBVztBQUM1QixlQUFPLElBQUksTUFBTSxPQUFPLFFBQVEsVUFBVSxPQUFPLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsZ0JBQVEsUUFBUTtBQUFBLE1BQ2xCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBQ0g7QUFFQSxTQUFTLGdCQUFnQixjQUE4QjtBQUNyRCxRQUFNLE9BQU8sSUFBSSxLQUFLLFlBQVk7QUFDbEMsU0FBTyxLQUFLLG1CQUFtQixRQUFXO0FBQUEsSUFDeEMsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLEVBQUEsQ0FDVDtBQUNIO0FBRUEsU0FBUyxnQkFBZ0IsTUFBc0I7QUFDN0MsUUFBTSxRQUFnQztBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLFVBQVU7QUFBQSxJQUNWLDBCQUEwQjtBQUFBLElBQzFCLG1CQUFtQjtBQUFBLElBQ25CLGVBQWU7QUFBQSxJQUNmLHFCQUFxQjtBQUFBLElBQ3JCLFNBQVM7QUFBQSxFQUFBO0FBRVgsU0FBTyxNQUFNLElBQUksS0FBSztBQUN4QjtBQUVBLFNBQVMsWUFBWSxLQUFhLFlBQW9CLElBQVk7QUFDaEUsTUFBSSxJQUFJLFVBQVUsVUFBVyxRQUFPO0FBQ3BDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLEdBQUc7QUFDMUIsVUFBTSxPQUFPLE9BQU87QUFDcEIsVUFBTSxPQUFPLE9BQU87QUFDcEIsVUFBTSxZQUFZLFlBQVksS0FBSyxTQUFTO0FBQzVDLFFBQUksYUFBYSxFQUFHLFFBQU8sS0FBSyxVQUFVLEdBQUcsWUFBWSxDQUFDLElBQUk7QUFDOUQsV0FBTyxPQUFPLEtBQUssVUFBVSxHQUFHLFNBQVMsSUFBSTtBQUFBLEVBQy9DLFFBQVE7QUFDTixXQUFPLElBQUksVUFBVSxHQUFHLFlBQVksQ0FBQyxJQUFJO0FBQUEsRUFDM0M7QUFDRjtBQUVBLFdBQUE7In0=
