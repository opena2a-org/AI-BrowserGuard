const DEFAULT_SETTINGS = {
  detectionEnabled: true,
  notificationsEnabled: true,
  killSwitchShortcut: "Ctrl+Shift+K",
  maxSessions: 5,
  maxDetectionLogEntries: 100,
  autoBlockUnknownAgents: false
};
const DEFAULT_STORAGE = {
  sessions: [],
  delegationRules: [],
  settings: DEFAULT_SETTINGS,
  detectionLog: []
};
async function getStorageState() {
  try {
    const result = await chrome.storage.local.get(
      Object.keys(DEFAULT_STORAGE)
    );
    return {
      sessions: result.sessions ?? DEFAULT_STORAGE.sessions,
      delegationRules: result.delegationRules ?? DEFAULT_STORAGE.delegationRules,
      settings: { ...DEFAULT_SETTINGS, ...result.settings ?? {} },
      detectionLog: result.detectionLog ?? DEFAULT_STORAGE.detectionLog
    };
  } catch (err) {
    console.error("[AI Browser Guard] Storage read error:", err);
    return { ...DEFAULT_STORAGE };
  }
}
async function saveSession(session) {
  try {
    const state2 = await getStorageState();
    const sessions = [session, ...state2.sessions];
    const maxSessions = state2.settings.maxSessions ?? 5;
    if (sessions.length > maxSessions) {
      sessions.length = maxSessions;
    }
    await chrome.storage.local.set({ sessions });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to save session:", err);
  }
}
async function updateSession(sessionId, updater) {
  try {
    const state2 = await getStorageState();
    const index = state2.sessions.findIndex((s) => s.id === sessionId);
    if (index === -1) {
      console.warn("[AI Browser Guard] Session not found:", sessionId);
      return;
    }
    state2.sessions[index] = updater(state2.sessions[index]);
    await chrome.storage.local.set({ sessions: state2.sessions });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to update session:", err);
  }
}
async function saveDelegationRules(rules) {
  try {
    await chrome.storage.local.set({ delegationRules: rules });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to save delegation rules:", err);
  }
}
async function appendDetectionLog(event) {
  try {
    const state2 = await getStorageState();
    const log = [...state2.detectionLog, event];
    const maxEntries = state2.settings.maxDetectionLogEntries ?? 100;
    if (log.length > maxEntries) {
      log.splice(0, log.length - maxEntries);
    }
    await chrome.storage.local.set({ detectionLog: log });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to append detection log:", err);
  }
}
async function getSettings() {
  const state2 = await getStorageState();
  return state2.settings;
}
async function updateSettings(updates) {
  try {
    const current = await getSettings();
    const merged = { ...current, ...updates };
    await chrome.storage.local.set({ settings: merged });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to update settings:", err);
  }
}
function generateId() {
  return crypto.randomUUID();
}
function createTimelineEvent(type, url, description, options) {
  return {
    id: generateId(),
    type,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    url,
    description,
    outcome: options?.outcome ?? "informational",
    targetSelector: options?.targetSelector,
    attemptedAction: options?.attemptedAction,
    ruleId: options?.ruleId
  };
}
function appendEventToSession(session, event) {
  const events = [...session.events, event];
  const summary = computeSessionSummary(events, session.startedAt);
  return { ...session, events, summary };
}
function computeSessionSummary(events, startedAt) {
  let totalActions = 0;
  let allowedActions = 0;
  let blockedActions = 0;
  let violations = 0;
  const urlCounts = /* @__PURE__ */ new Map();
  for (const event of events) {
    if (event.outcome === "allowed") {
      totalActions++;
      allowedActions++;
    } else if (event.outcome === "blocked") {
      totalActions++;
      blockedActions++;
    }
    if (event.type === "boundary-violation") {
      violations++;
    }
    if (event.url) {
      urlCounts.set(event.url, (urlCounts.get(event.url) ?? 0) + 1);
    }
  }
  const topUrls = [...urlCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([url]) => url);
  let durationSeconds = null;
  if (events.length > 0) {
    const lastEvent = events[events.length - 1];
    const start = new Date(startedAt).getTime();
    const end = new Date(lastEvent.timestamp).getTime();
    durationSeconds = Math.round((end - start) / 1e3);
  }
  return {
    totalActions,
    allowedActions,
    blockedActions,
    violations,
    topUrls,
    durationSeconds
  };
}
function isTimeBoundExpired(timeBound) {
  if (timeBound === null) return false;
  return (/* @__PURE__ */ new Date()).getTime() > new Date(timeBound.expiresAt).getTime();
}
function revokeToken(token) {
  return { ...token, revoked: true };
}
async function executeBackgroundKillSwitch(trigger, activeAgentIds, activeTokens) {
  const revokedTokenIds = [];
  for (const token of activeTokens) {
    revokeToken(token);
    revokedTokenIds.push(token.tokenId);
  }
  let cdpTerminated = false;
  let automationFlagsCleared = false;
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.id === void 0) continue;
      try {
        await chrome.tabs.sendMessage(tab.id, {
          type: "KILL_SWITCH_ACTIVATE",
          data: {},
          sentAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      } catch {
      }
    }
    cdpTerminated = true;
    automationFlagsCleared = true;
  } catch {
  }
  const event = {
    id: crypto.randomUUID(),
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    trigger,
    terminatedAgentIds: [...activeAgentIds],
    revokedTokenIds,
    cdpTerminated,
    automationFlagsCleared
  };
  showKillSwitchNotification(activeAgentIds.length);
  return event;
}
function showKillSwitchNotification(agentCount) {
  try {
    chrome.notifications.create(`abg-killswitch-${Date.now()}`, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title: "AI Browser Guard - Kill Switch Activated",
      message: `Terminated ${agentCount} agent session(s). All delegations revoked.`,
      priority: 2
    });
    setTimeout(() => {
      try {
        chrome.notifications.getAll((notifications) => {
          for (const id of Object.keys(notifications)) {
            if (id.startsWith("abg-killswitch-")) {
              chrome.notifications.clear(id);
            }
          }
        });
      } catch {
      }
    }, 5e3);
  } catch {
  }
}
function createInitialKillSwitchState() {
  return {
    isActive: false,
    lastEvent: null,
    lastActivatedAt: null
  };
}
function setupNotificationHandlers(onAllowOnce) {
  const handler = (notificationId, buttonIndex) => {
    if (buttonIndex === 0) {
      onAllowOnce(notificationId);
    }
    try {
      chrome.notifications.clear(notificationId);
    } catch {
    }
  };
  chrome.notifications.onButtonClicked.addListener(handler);
  return () => {
    chrome.notifications.onButtonClicked.removeListener(handler);
  };
}
async function clearAllNotifications() {
  return new Promise((resolve) => {
    try {
      chrome.notifications.getAll((notifications) => {
        for (const id of Object.keys(notifications)) {
          chrome.notifications.clear(id);
        }
        resolve();
      });
    } catch {
      resolve();
    }
  });
}
const SENSITIVE_URL_PATTERNS = [
  /\.bank\./i,
  /\.gov\./i,
  /paypal/i,
  /stripe/i,
  /\.financial/i,
  /healthcare/i,
  /\.mil\./i
];
function createBoundaryAlert(violation, rule) {
  const severity = classifyViolationSeverity(violation.attemptedAction, violation.url);
  const title = generateAlertTitle(violation.attemptedAction);
  const message = generateAlertMessage(violation, rule.label ?? rule.preset);
  return {
    violation,
    severity,
    title,
    message,
    allowOneTimeOverride: severity === "medium" || severity === "low",
    acknowledged: false
  };
}
function classifyViolationSeverity(capability, url) {
  const baseSeverityMap = {
    "submit-form": "critical",
    "execute-script": "critical",
    "download-file": "high",
    "modify-dom": "high",
    click: "high",
    "type-text": "medium",
    navigate: "medium",
    "open-tab": "low",
    "close-tab": "low",
    "read-dom": "low",
    screenshot: "low"
  };
  let severity = baseSeverityMap[capability] ?? "medium";
  const isSensitive = SENSITIVE_URL_PATTERNS.some((pattern) => pattern.test(url));
  if (isSensitive) {
    const upgrade = {
      low: "medium",
      medium: "high",
      high: "critical",
      critical: "critical"
    };
    severity = upgrade[severity];
  }
  return severity;
}
function generateAlertTitle(capability) {
  const titles = {
    navigate: "Navigation blocked",
    "read-dom": "Page read blocked",
    click: "Click interaction blocked",
    "type-text": "Text input blocked",
    "submit-form": "Form submission blocked",
    "download-file": "File download blocked",
    "open-tab": "New tab blocked",
    "close-tab": "Tab closure blocked",
    screenshot: "Screenshot blocked",
    "execute-script": "Script execution blocked",
    "modify-dom": "DOM modification blocked"
  };
  return titles[capability] || "Action blocked";
}
function generateAlertMessage(violation, ruleName) {
  const lines = [
    `An agent attempted to perform "${violation.attemptedAction}" on:`,
    violation.url,
    "",
    `Blocked by rule: ${ruleName}`,
    `Reason: ${violation.reason}`
  ];
  if (violation.targetSelector) {
    lines.push(`Target element: ${violation.targetSelector}`);
  }
  return lines.join("\n");
}
const state = {
  activeAgents: /* @__PURE__ */ new Map(),
  activeSessions: /* @__PURE__ */ new Map(),
  delegationRules: [],
  killSwitch: createInitialKillSwitchState(),
  recentAlerts: []
};
function initialize() {
  loadPersistedState().then(() => {
    updateBadge();
  }).catch((err) => {
    console.error("[AI Browser Guard] Failed to load state:", err);
  });
  chrome.runtime.onMessage.addListener(handleMessage);
  chrome.tabs.onRemoved.addListener((tabId) => {
    handleTabRemoved(tabId).catch(() => {
    });
  });
  chrome.alarms.create("delegation-check", { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "delegation-check") {
      checkDelegationExpiration().catch(() => {
      });
    }
  });
  registerKeyboardShortcut();
  setupNotificationHandlers((notificationId) => {
    console.log("[AI Browser Guard] Override requested for notification:", notificationId);
  });
  console.log("[AI Browser Guard] Background service worker initialized");
}
async function loadPersistedState() {
  const stored = await getStorageState();
  state.delegationRules = stored.delegationRules;
  for (const session of stored.sessions) {
    if (!session.endedAt) {
      await updateSession(session.id, (s) => ({
        ...s,
        endedAt: (/* @__PURE__ */ new Date()).toISOString(),
        endReason: "agent-disconnected"
      }));
    }
  }
}
function handleMessage(message, sender, sendResponse) {
  if (!message || !message.type) return false;
  const tabId = sender.tab?.id;
  switch (message.type) {
    case "DETECTION_RESULT": {
      if (tabId !== void 0) {
        handleDetection(tabId, message.data).then(() => {
          sendResponse({ success: true });
        }).catch(() => {
          sendResponse({ success: false });
        });
        return true;
      }
      return false;
    }
    case "AGENT_ACTION": {
      if (tabId !== void 0) {
        handleAgentAction(tabId, message.data);
      }
      sendResponse({ success: true });
      return false;
    }
    case "BOUNDARY_CHECK_REQUEST": {
      const violation = message.data;
      handleBoundaryViolation(tabId, violation);
      sendResponse({ success: true });
      return false;
    }
    case "KILL_SWITCH_ACTIVATE": {
      executeKillSwitch(
        message.data?.trigger ?? "button"
      ).then((event) => {
        sendResponse({ success: true, event });
      }).catch(() => {
        sendResponse({ success: false });
      });
      return true;
    }
    case "DELEGATION_UPDATE": {
      const rule = message.data;
      handleDelegationUpdate(rule).then(() => {
        sendResponse({ success: true });
      }).catch(() => {
        sendResponse({ success: false });
      });
      return true;
    }
    case "SESSION_QUERY": {
      getStorageState().then((stored) => {
        sendResponse({ sessions: stored.sessions });
      }).catch(() => {
        sendResponse({ sessions: [] });
      });
      return true;
    }
    case "STATUS_QUERY": {
      const agents = Array.from(state.activeAgents.values());
      const activeRule = state.delegationRules.find((r) => r.isActive) ?? null;
      sendResponse({
        detectedAgents: agents,
        activeDelegation: activeRule,
        killSwitchActive: state.killSwitch.isActive,
        recentViolations: state.recentAlerts,
        delegationRules: state.delegationRules
      });
      return false;
    }
    case "SETTINGS_UPDATE": {
      const updates = message.data;
      updateSettings(updates).then(() => {
        sendResponse({ success: true });
      }).catch(() => {
        sendResponse({ success: false });
      });
      return true;
    }
    default:
      return false;
  }
}
async function handleDetection(tabId, event) {
  if (!event.agent) return;
  state.activeAgents.set(tabId, event.agent);
  const session = {
    id: crypto.randomUUID(),
    agent: event.agent,
    delegationRule: state.delegationRules.find((r) => r.isActive) ?? null,
    events: [],
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    endedAt: null,
    endReason: null,
    summary: {
      totalActions: 0,
      allowedActions: 0,
      blockedActions: 0,
      violations: 0,
      topUrls: [],
      durationSeconds: null
    }
  };
  const timelineEvent = createTimelineEvent("detection", event.url, `Agent detected: ${event.agent.type}`, {
    outcome: "informational"
  });
  const updatedSession = appendEventToSession(session, timelineEvent);
  await saveSession(updatedSession);
  state.activeSessions.set(tabId, updatedSession.id);
  await appendDetectionLog(event);
  updateBadge();
}
function handleAgentAction(tabId, event) {
  const sessionId = state.activeSessions.get(tabId);
  if (!sessionId) return;
  updateSession(sessionId, (session) => appendEventToSession(session, event)).catch(() => {
  });
}
function handleBoundaryViolation(tabId, violation) {
  const activeRule = state.delegationRules.find((r) => r.isActive);
  if (!activeRule) return;
  const alert = createBoundaryAlert(violation, activeRule);
  state.recentAlerts.push(alert);
  if (state.recentAlerts.length > 20) {
    state.recentAlerts.shift();
  }
  if (tabId !== void 0) {
    const sessionId = state.activeSessions.get(tabId);
    if (sessionId) {
      const event = createTimelineEvent(
        "boundary-violation",
        violation.url,
        `Violation: ${violation.attemptedAction} blocked`,
        {
          attemptedAction: violation.attemptedAction,
          outcome: "blocked",
          ruleId: violation.blockingRuleId,
          targetSelector: violation.targetSelector
        }
      );
      updateSession(sessionId, (session) => appendEventToSession(session, event)).catch(() => {
      });
    }
  }
}
async function handleDelegationUpdate(rule) {
  for (const r of state.delegationRules) {
    r.isActive = false;
  }
  const existingIndex = state.delegationRules.findIndex((r) => r.id === rule.id);
  if (existingIndex >= 0) {
    state.delegationRules[existingIndex] = rule;
  } else {
    state.delegationRules.push(rule);
  }
  await saveDelegationRules(state.delegationRules);
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.id === void 0) continue;
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: "DELEGATION_UPDATE",
        data: rule,
        sentAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch {
    }
  }
  updateBadge();
}
async function executeKillSwitch(trigger) {
  const agentIds = Array.from(state.activeAgents.values()).map((a) => a.id);
  const event = await executeBackgroundKillSwitch(trigger, agentIds, []);
  state.killSwitch.isActive = true;
  state.killSwitch.lastEvent = event;
  state.killSwitch.lastActivatedAt = event.timestamp;
  state.activeAgents.clear();
  for (const rule of state.delegationRules) {
    rule.isActive = false;
  }
  await saveDelegationRules(state.delegationRules);
  for (const [tabId, sessionId] of state.activeSessions.entries()) {
    await updateSession(sessionId, (session) => ({
      ...session,
      endedAt: (/* @__PURE__ */ new Date()).toISOString(),
      endReason: "kill-switch"
    }));
    state.activeSessions.delete(tabId);
  }
  await clearAllNotifications();
  updateBadge();
  return event;
}
function updateBadge() {
  try {
    if (state.killSwitch.isActive) {
      chrome.action.setBadgeText({ text: "X" });
      chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
      return;
    }
    const agentCount = state.activeAgents.size;
    if (agentCount > 0) {
      chrome.action.setBadgeText({ text: String(agentCount) });
      chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
      return;
    }
    const hasActiveDelegation = state.delegationRules.some((r) => r.isActive);
    if (hasActiveDelegation) {
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setBadgeBackgroundColor({ color: "#22c55e" });
      return;
    }
    chrome.action.setBadgeText({ text: "" });
  } catch {
  }
}
async function handleTabRemoved(tabId) {
  const sessionId = state.activeSessions.get(tabId);
  if (sessionId) {
    await updateSession(sessionId, (session) => ({
      ...session,
      endedAt: (/* @__PURE__ */ new Date()).toISOString(),
      endReason: "page-unload"
    }));
    state.activeSessions.delete(tabId);
  }
  state.activeAgents.delete(tabId);
  updateBadge();
}
async function checkDelegationExpiration() {
  let changed = false;
  for (const rule of state.delegationRules) {
    if (rule.isActive && isTimeBoundExpired(rule.scope.timeBound)) {
      rule.isActive = false;
      changed = true;
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        if (tab.id === void 0) continue;
        try {
          await chrome.tabs.sendMessage(tab.id, {
            type: "DELEGATION_UPDATE",
            data: null,
            sentAt: (/* @__PURE__ */ new Date()).toISOString()
          });
        } catch {
        }
      }
    }
  }
  if (changed) {
    await saveDelegationRules(state.delegationRules);
    updateBadge();
  }
}
function registerKeyboardShortcut() {
  try {
    chrome.commands.onCommand.addListener((command) => {
      if (command === "kill-switch") {
        executeKillSwitch("keyboard-shortcut").catch(() => {
        });
      }
    });
  } catch {
  }
}
initialize();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXNzaW9uL3R5cGVzLnRzIiwiLi4vLi4vc3JjL3Nlc3Npb24vc3RvcmFnZS50cyIsIi4uLy4uL3NyYy9zZXNzaW9uL3RpbWVsaW5lLnRzIiwiLi4vLi4vc3JjL2RlbGVnYXRpb24vcnVsZXMudHMiLCIuLi8uLi9zcmMva2lsbHN3aXRjaC9pbmRleC50cyIsIi4uLy4uL3NyYy9hbGVydHMvbm90aWZpY2F0aW9uLnRzIiwiLi4vLi4vc3JjL2FsZXJ0cy9ib3VuZGFyeS50cyIsIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogU2Vzc2lvbiB0eXBlcyBmb3IgdHJhY2tpbmcgYWdlbnQgYWN0aXZpdHkgb3ZlciB0aW1lLlxuICpcbiAqIEEgc2Vzc2lvbiByZXByZXNlbnRzIGEgc2luZ2xlIHBlcmlvZCBvZiBhZ2VudCBhY3Rpdml0eSBpbiB0aGUgYnJvd3NlcixcbiAqIGZyb20gZGV0ZWN0aW9uIHRvIHRlcm1pbmF0aW9uIChvciBwYWdlIHVubG9hZCkuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBBZ2VudElkZW50aXR5IH0gZnJvbSAnLi4vdHlwZXMvYWdlbnQnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudEV2ZW50IH0gZnJvbSAnLi4vdHlwZXMvZXZlbnRzJztcbmltcG9ydCB0eXBlIHsgRGVsZWdhdGlvblJ1bGUgfSBmcm9tICcuLi90eXBlcy9kZWxlZ2F0aW9uJztcblxuLyoqXG4gKiBBIGNvbXBsZXRlIGFnZW50IHNlc3Npb24gd2l0aCB0aW1lbGluZSBvZiBldmVudHMuXG4gKiBTdG9yZXMgdXAgdG8gNSBzZXNzaW9ucyBpbiBjaHJvbWUuc3RvcmFnZS5sb2NhbC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBZ2VudFNlc3Npb24ge1xuICAvKiogVW5pcXVlIHNlc3Npb24gaWRlbnRpZmllciAoVVVJRCB2NCkuICovXG4gIGlkOiBzdHJpbmc7XG5cbiAgLyoqIFRoZSBkZXRlY3RlZCBhZ2VudCBhc3NvY2lhdGVkIHdpdGggdGhpcyBzZXNzaW9uLiAqL1xuICBhZ2VudDogQWdlbnRJZGVudGl0eTtcblxuICAvKiogVGhlIGRlbGVnYXRpb24gcnVsZSB0aGF0IHdhcyBhY3RpdmUgZHVyaW5nIHRoaXMgc2Vzc2lvbiwgaWYgYW55LiAqL1xuICBkZWxlZ2F0aW9uUnVsZTogRGVsZWdhdGlvblJ1bGUgfCBudWxsO1xuXG4gIC8qKiBDaHJvbm9sb2dpY2FsIGxpc3Qgb2YgZXZlbnRzIHRoYXQgb2NjdXJyZWQgZHVyaW5nIHRoaXMgc2Vzc2lvbi4gKi9cbiAgZXZlbnRzOiBBZ2VudEV2ZW50W107XG5cbiAgLyoqIElTTyA4NjAxIHRpbWVzdGFtcCB3aGVuIHRoZSBzZXNzaW9uIHN0YXJ0ZWQgKGFnZW50IGZpcnN0IGRldGVjdGVkKS4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG5cbiAgLyoqIElTTyA4NjAxIHRpbWVzdGFtcCB3aGVuIHRoZSBzZXNzaW9uIGVuZGVkLiBOdWxsIGlmIHNlc3Npb24gaXMgYWN0aXZlLiAqL1xuICBlbmRlZEF0OiBzdHJpbmcgfCBudWxsO1xuXG4gIC8qKiBIb3cgdGhlIHNlc3Npb24gZW5kZWQuICovXG4gIGVuZFJlYXNvbjogJ2tpbGwtc3dpdGNoJyB8ICdkZWxlZ2F0aW9uLWV4cGlyZWQnIHwgJ2FnZW50LWRpc2Nvbm5lY3RlZCcgfCAncGFnZS11bmxvYWQnIHwgbnVsbDtcblxuICAvKiogU3VtbWFyeSBzdGF0aXN0aWNzIGZvciBxdWljayBkaXNwbGF5IGluIHBvcHVwLiAqL1xuICBzdW1tYXJ5OiBTZXNzaW9uU3VtbWFyeTtcbn1cblxuLyoqXG4gKiBTdW1tYXJ5IHN0YXRpc3RpY3MgZm9yIGEgc2Vzc2lvbi5cbiAqIFByZS1jb21wdXRlZCBmb3IgZWZmaWNpZW50IHJlbmRlcmluZyBpbiB0aGUgcG9wdXAgdGltZWxpbmUgdmlldy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBTZXNzaW9uU3VtbWFyeSB7XG4gIC8qKiBUb3RhbCBudW1iZXIgb2YgYWN0aW9ucyB0aGUgYWdlbnQgcGVyZm9ybWVkLiAqL1xuICB0b3RhbEFjdGlvbnM6IG51bWJlcjtcblxuICAvKiogTnVtYmVyIG9mIGFjdGlvbnMgdGhhdCB3ZXJlIGFsbG93ZWQuICovXG4gIGFsbG93ZWRBY3Rpb25zOiBudW1iZXI7XG5cbiAgLyoqIE51bWJlciBvZiBhY3Rpb25zIHRoYXQgd2VyZSBibG9ja2VkLiAqL1xuICBibG9ja2VkQWN0aW9uczogbnVtYmVyO1xuXG4gIC8qKiBOdW1iZXIgb2YgYm91bmRhcnkgdmlvbGF0aW9ucy4gKi9cbiAgdmlvbGF0aW9uczogbnVtYmVyO1xuXG4gIC8qKiBUaGUgbW9zdC12aXNpdGVkIFVSTHMgZHVyaW5nIHRoaXMgc2Vzc2lvbiAodG9wIDUpLiAqL1xuICB0b3BVcmxzOiBzdHJpbmdbXTtcblxuICAvKiogRHVyYXRpb24gb2YgdGhlIHNlc3Npb24gaW4gc2Vjb25kcy4gTnVsbCBpZiBzZXNzaW9uIGlzIHN0aWxsIGFjdGl2ZS4gKi9cbiAgZHVyYXRpb25TZWNvbmRzOiBudW1iZXIgfCBudWxsO1xufVxuXG4vKipcbiAqIEFnZ3JlZ2F0ZSBzdG9yYWdlIHNjaGVtYSBmb3IgY2hyb21lLnN0b3JhZ2UubG9jYWwuXG4gKiBUaGlzIGlzIHRoZSB0b3AtbGV2ZWwgc2hhcGUgb2YgYWxsIHBlcnNpc3RlZCBkYXRhLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0b3JhZ2VTY2hlbWEge1xuICAvKiogTGFzdCA1IGFnZW50IHNlc3Npb25zLCBuZXdlc3QgZmlyc3QuICovXG4gIHNlc3Npb25zOiBBZ2VudFNlc3Npb25bXTtcblxuICAvKiogQ3VycmVudGx5IGFjdGl2ZSBkZWxlZ2F0aW9uIHJ1bGVzLiAqL1xuICBkZWxlZ2F0aW9uUnVsZXM6IERlbGVnYXRpb25SdWxlW107XG5cbiAgLyoqIFVzZXIgcHJlZmVyZW5jZXMgYW5kIHNldHRpbmdzLiAqL1xuICBzZXR0aW5nczogVXNlclNldHRpbmdzO1xuXG4gIC8qKiBSZWNlbnQgZGV0ZWN0aW9uIGV2ZW50cyBmb3IgZGVidWdnaW5nIChsYXN0IDEwMCkuICovXG4gIGRldGVjdGlvbkxvZzogaW1wb3J0KCcuLi90eXBlcy9ldmVudHMnKS5EZXRlY3Rpb25FdmVudFtdO1xufVxuXG4vKipcbiAqIFVzZXItY29uZmlndXJhYmxlIHNldHRpbmdzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFVzZXJTZXR0aW5ncyB7XG4gIC8qKiBXaGV0aGVyIGRldGVjdGlvbiBpcyBlbmFibGVkLiBEZWZhdWx0OiB0cnVlLiAqL1xuICBkZXRlY3Rpb25FbmFibGVkOiBib29sZWFuO1xuXG4gIC8qKiBXaGV0aGVyIGJvdW5kYXJ5IGFsZXJ0cyBzaG93IENocm9tZSBub3RpZmljYXRpb25zLiBEZWZhdWx0OiB0cnVlLiAqL1xuICBub3RpZmljYXRpb25zRW5hYmxlZDogYm9vbGVhbjtcblxuICAvKiogS2lsbCBzd2l0Y2gga2V5Ym9hcmQgc2hvcnRjdXQuIERlZmF1bHQ6IFwiQ3RybCtTaGlmdCtLXCIgLyBcIkNtZCtTaGlmdCtLXCIuICovXG4gIGtpbGxTd2l0Y2hTaG9ydGN1dDogc3RyaW5nO1xuXG4gIC8qKiBNYXhpbXVtIHNlc3Npb25zIHRvIHJldGFpbi4gRGVmYXVsdDogNS4gKi9cbiAgbWF4U2Vzc2lvbnM6IG51bWJlcjtcblxuICAvKiogTWF4aW11bSBkZXRlY3Rpb24gbG9nIGVudHJpZXMuIERlZmF1bHQ6IDEwMC4gKi9cbiAgbWF4RGV0ZWN0aW9uTG9nRW50cmllczogbnVtYmVyO1xuXG4gIC8qKiBXaGV0aGVyIHRvIGF1dG9tYXRpY2FsbHkgYmxvY2sgdW5pZGVudGlmaWVkIGFnZW50cy4gRGVmYXVsdDogZmFsc2UuICovXG4gIGF1dG9CbG9ja1Vua25vd25BZ2VudHM6IGJvb2xlYW47XG59XG5cbi8qKlxuICogRGVmYXVsdCB1c2VyIHNldHRpbmdzIGFwcGxpZWQgb24gZmlyc3QgaW5zdGFsbC5cbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFVzZXJTZXR0aW5ncyA9IHtcbiAgZGV0ZWN0aW9uRW5hYmxlZDogdHJ1ZSxcbiAgbm90aWZpY2F0aW9uc0VuYWJsZWQ6IHRydWUsXG4gIGtpbGxTd2l0Y2hTaG9ydGN1dDogJ0N0cmwrU2hpZnQrSycsXG4gIG1heFNlc3Npb25zOiA1LFxuICBtYXhEZXRlY3Rpb25Mb2dFbnRyaWVzOiAxMDAsXG4gIGF1dG9CbG9ja1Vua25vd25BZ2VudHM6IGZhbHNlLFxufTtcbiIsIi8qKlxuICogU2Vzc2lvbiBwZXJzaXN0ZW5jZSBsYXllciB1c2luZyBjaHJvbWUuc3RvcmFnZS5sb2NhbC5cbiAqXG4gKiBNYW5hZ2VzIHJlYWRpbmcgYW5kIHdyaXRpbmcgb2Ygc2Vzc2lvbnMsIGRlbGVnYXRpb24gcnVsZXMsIHNldHRpbmdzLFxuICogYW5kIGRldGVjdGlvbiBsb2dzLiBFbmZvcmNlcyBzZXNzaW9uIGxpbWl0cyAoNSBzZXNzaW9ucywgMTAwIGxvZyBlbnRyaWVzKS5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEFnZW50U2Vzc2lvbiwgU3RvcmFnZVNjaGVtYSwgVXNlclNldHRpbmdzIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgdHlwZSB7IERlbGVnYXRpb25SdWxlIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5pbXBvcnQgdHlwZSB7IERldGVjdGlvbkV2ZW50IH0gZnJvbSAnLi4vdHlwZXMvZXZlbnRzJztcblxuY29uc3QgREVGQVVMVF9TVE9SQUdFOiBTdG9yYWdlU2NoZW1hID0ge1xuICBzZXNzaW9uczogW10sXG4gIGRlbGVnYXRpb25SdWxlczogW10sXG4gIHNldHRpbmdzOiBERUZBVUxUX1NFVFRJTkdTLFxuICBkZXRlY3Rpb25Mb2c6IFtdLFxufTtcblxuLyoqXG4gKiBSZXRyaWV2ZSB0aGUgZnVsbCBzdG9yYWdlIHNjaGVtYSBmcm9tIGNocm9tZS5zdG9yYWdlLmxvY2FsLlxuICogUmV0dXJucyBkZWZhdWx0IHZhbHVlcyBmb3IgYW55IG1pc3Npbmcga2V5cy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN0b3JhZ2VTdGF0ZSgpOiBQcm9taXNlPFN0b3JhZ2VTY2hlbWE+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXG4gICAgICBPYmplY3Qua2V5cyhERUZBVUxUX1NUT1JBR0UpXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgc2Vzc2lvbnM6IHJlc3VsdC5zZXNzaW9ucyA/PyBERUZBVUxUX1NUT1JBR0Uuc2Vzc2lvbnMsXG4gICAgICBkZWxlZ2F0aW9uUnVsZXM6IHJlc3VsdC5kZWxlZ2F0aW9uUnVsZXMgPz8gREVGQVVMVF9TVE9SQUdFLmRlbGVnYXRpb25SdWxlcyxcbiAgICAgIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLihyZXN1bHQuc2V0dGluZ3MgPz8ge30pIH0sXG4gICAgICBkZXRlY3Rpb25Mb2c6IHJlc3VsdC5kZXRlY3Rpb25Mb2cgPz8gREVGQVVMVF9TVE9SQUdFLmRldGVjdGlvbkxvZyxcbiAgICB9O1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gU3RvcmFnZSByZWFkIGVycm9yOicsIGVycik7XG4gICAgcmV0dXJuIHsgLi4uREVGQVVMVF9TVE9SQUdFIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTYXZlIGEgbmV3IGFnZW50IHNlc3Npb24gdG8gc3RvcmFnZS5cbiAqIEVuZm9yY2VzIHRoZSBsaW1pdCBvZiA1IHNlc3Npb25zIGJ5IGV2aWN0aW5nIHRoZSBvbGRlc3QuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlU2Vzc2lvbihzZXNzaW9uOiBBZ2VudFNlc3Npb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFN0b3JhZ2VTdGF0ZSgpO1xuICAgIGNvbnN0IHNlc3Npb25zID0gW3Nlc3Npb24sIC4uLnN0YXRlLnNlc3Npb25zXTtcbiAgICBjb25zdCBtYXhTZXNzaW9ucyA9IHN0YXRlLnNldHRpbmdzLm1heFNlc3Npb25zID8/IDU7XG4gICAgaWYgKHNlc3Npb25zLmxlbmd0aCA+IG1heFNlc3Npb25zKSB7XG4gICAgICBzZXNzaW9ucy5sZW5ndGggPSBtYXhTZXNzaW9ucztcbiAgICB9XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc2Vzc2lvbnMgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gc2F2ZSBzZXNzaW9uOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBVcGRhdGUgYW4gZXhpc3Rpbmcgc2Vzc2lvbiBpbiBzdG9yYWdlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2Vzc2lvbihcbiAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gIHVwZGF0ZXI6IChzZXNzaW9uOiBBZ2VudFNlc3Npb24pID0+IEFnZW50U2Vzc2lvblxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRTdG9yYWdlU3RhdGUoKTtcbiAgICBjb25zdCBpbmRleCA9IHN0YXRlLnNlc3Npb25zLmZpbmRJbmRleCgocykgPT4gcy5pZCA9PT0gc2Vzc2lvbklkKTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ1tBSSBCcm93c2VyIEd1YXJkXSBTZXNzaW9uIG5vdCBmb3VuZDonLCBzZXNzaW9uSWQpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdGF0ZS5zZXNzaW9uc1tpbmRleF0gPSB1cGRhdGVyKHN0YXRlLnNlc3Npb25zW2luZGV4XSk7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc2Vzc2lvbnM6IHN0YXRlLnNlc3Npb25zIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIHVwZGF0ZSBzZXNzaW9uOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSBhbGwgc3RvcmVkIHNlc3Npb25zLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2Vzc2lvbnMoKTogUHJvbWlzZTxBZ2VudFNlc3Npb25bXT4ge1xuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFN0b3JhZ2VTdGF0ZSgpO1xuICByZXR1cm4gc3RhdGUuc2Vzc2lvbnM7XG59XG5cbi8qKlxuICogU2F2ZSBvciB1cGRhdGUgZGVsZWdhdGlvbiBydWxlcyBpbiBzdG9yYWdlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2F2ZURlbGVnYXRpb25SdWxlcyhydWxlczogRGVsZWdhdGlvblJ1bGVbXSk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGRlbGVnYXRpb25SdWxlczogcnVsZXMgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gc2F2ZSBkZWxlZ2F0aW9uIHJ1bGVzOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSBhbGwgZGVsZWdhdGlvbiBydWxlcyBmcm9tIHN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXREZWxlZ2F0aW9uUnVsZXMoKTogUHJvbWlzZTxEZWxlZ2F0aW9uUnVsZVtdPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0U3RvcmFnZVN0YXRlKCk7XG4gIHJldHVybiBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXM7XG59XG5cbi8qKlxuICogQXBwZW5kIGEgZGV0ZWN0aW9uIGV2ZW50IHRvIHRoZSBsb2cuXG4gKiBFbmZvcmNlcyB0aGUgbGltaXQgb2YgMTAwIGxvZyBlbnRyaWVzIGJ5IGV2aWN0aW5nIHRoZSBvbGRlc3QuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmREZXRlY3Rpb25Mb2coZXZlbnQ6IERldGVjdGlvbkV2ZW50KTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRTdG9yYWdlU3RhdGUoKTtcbiAgICBjb25zdCBsb2cgPSBbLi4uc3RhdGUuZGV0ZWN0aW9uTG9nLCBldmVudF07XG4gICAgY29uc3QgbWF4RW50cmllcyA9IHN0YXRlLnNldHRpbmdzLm1heERldGVjdGlvbkxvZ0VudHJpZXMgPz8gMTAwO1xuICAgIGlmIChsb2cubGVuZ3RoID4gbWF4RW50cmllcykge1xuICAgICAgbG9nLnNwbGljZSgwLCBsb2cubGVuZ3RoIC0gbWF4RW50cmllcyk7XG4gICAgfVxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGRldGVjdGlvbkxvZzogbG9nIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIGFwcGVuZCBkZXRlY3Rpb24gbG9nOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSB1c2VyIHNldHRpbmdzIGZyb20gc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8VXNlclNldHRpbmdzPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0U3RvcmFnZVN0YXRlKCk7XG4gIHJldHVybiBzdGF0ZS5zZXR0aW5ncztcbn1cblxuLyoqXG4gKiBVcGRhdGUgdXNlciBzZXR0aW5ncyBpbiBzdG9yYWdlIChwYXJ0aWFsIG1lcmdlKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHVwZGF0ZXM6IFBhcnRpYWw8VXNlclNldHRpbmdzPik6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IGN1cnJlbnQgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgIGNvbnN0IG1lcmdlZCA9IHsgLi4uY3VycmVudCwgLi4udXBkYXRlcyB9O1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IHNldHRpbmdzOiBtZXJnZWQgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gdXBkYXRlIHNldHRpbmdzOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBDbGVhciBhbGwgc3RvcmVkIGRhdGEuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbFN0b3JhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcignW0FJIEJyb3dzZXIgR3VhcmRdIEZhaWxlZCB0byBjbGVhciBzdG9yYWdlOicsIGVycik7XG4gIH1cbn1cbiIsIi8qKlxuICogU2Vzc2lvbiB0aW1lbGluZSBtYW5hZ2VtZW50LlxuICpcbiAqIE1haW50YWlucyBhIGNocm9ub2xvZ2ljYWwgbG9nIG9mIGFnZW50IGFjdGlvbnMgcGVyIHNlc3Npb24uXG4gKiBFYWNoIGVudHJ5IHJlY29yZHMgd2hhdCBoYXBwZW5lZCwgd2hlcmUsIGFuZCB3aGV0aGVyIGl0IHdhcyBhbGxvd2VkLlxuICovXG5cbmltcG9ydCB0eXBlIHsgQWdlbnRFdmVudCwgQWdlbnRFdmVudFR5cGUgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5pbXBvcnQgdHlwZSB7IEFnZW50U2Vzc2lvbiwgU2Vzc2lvblN1bW1hcnkgfSBmcm9tICcuL3R5cGVzJztcblxuZnVuY3Rpb24gZ2VuZXJhdGVJZCgpOiBzdHJpbmcge1xuICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbn1cblxuLyoqXG4gKiBDcmVhdGUgYSBuZXcgdGltZWxpbmUgZXZlbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUaW1lbGluZUV2ZW50KFxuICB0eXBlOiBBZ2VudEV2ZW50VHlwZSxcbiAgdXJsOiBzdHJpbmcsXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmcsXG4gIG9wdGlvbnM/OiB7XG4gICAgdGFyZ2V0U2VsZWN0b3I/OiBzdHJpbmc7XG4gICAgYXR0ZW1wdGVkQWN0aW9uPzogQWdlbnRDYXBhYmlsaXR5O1xuICAgIG91dGNvbWU/OiAnYWxsb3dlZCcgfCAnYmxvY2tlZCcgfCAnaW5mb3JtYXRpb25hbCc7XG4gICAgcnVsZUlkPzogc3RyaW5nO1xuICB9XG4pOiBBZ2VudEV2ZW50IHtcbiAgcmV0dXJuIHtcbiAgICBpZDogZ2VuZXJhdGVJZCgpLFxuICAgIHR5cGUsXG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdXJsLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIG91dGNvbWU6IG9wdGlvbnM/Lm91dGNvbWUgPz8gJ2luZm9ybWF0aW9uYWwnLFxuICAgIHRhcmdldFNlbGVjdG9yOiBvcHRpb25zPy50YXJnZXRTZWxlY3RvcixcbiAgICBhdHRlbXB0ZWRBY3Rpb246IG9wdGlvbnM/LmF0dGVtcHRlZEFjdGlvbixcbiAgICBydWxlSWQ6IG9wdGlvbnM/LnJ1bGVJZCxcbiAgfTtcbn1cblxuLyoqXG4gKiBBcHBlbmQgYW4gZXZlbnQgdG8gYSBzZXNzaW9uJ3MgdGltZWxpbmUgYW5kIHJlY2FsY3VsYXRlIHN1bW1hcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhcHBlbmRFdmVudFRvU2Vzc2lvbihcbiAgc2Vzc2lvbjogQWdlbnRTZXNzaW9uLFxuICBldmVudDogQWdlbnRFdmVudFxuKTogQWdlbnRTZXNzaW9uIHtcbiAgY29uc3QgZXZlbnRzID0gWy4uLnNlc3Npb24uZXZlbnRzLCBldmVudF07XG4gIGNvbnN0IHN1bW1hcnkgPSBjb21wdXRlU2Vzc2lvblN1bW1hcnkoZXZlbnRzLCBzZXNzaW9uLnN0YXJ0ZWRBdCk7XG4gIHJldHVybiB7IC4uLnNlc3Npb24sIGV2ZW50cywgc3VtbWFyeSB9O1xufVxuXG4vKipcbiAqIENvbXB1dGUgc3VtbWFyeSBzdGF0aXN0aWNzIGZyb20gYSBzZXNzaW9uJ3MgZXZlbnQgdGltZWxpbmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21wdXRlU2Vzc2lvblN1bW1hcnkoXG4gIGV2ZW50czogQWdlbnRFdmVudFtdLFxuICBzdGFydGVkQXQ6IHN0cmluZ1xuKTogU2Vzc2lvblN1bW1hcnkge1xuICBsZXQgdG90YWxBY3Rpb25zID0gMDtcbiAgbGV0IGFsbG93ZWRBY3Rpb25zID0gMDtcbiAgbGV0IGJsb2NrZWRBY3Rpb25zID0gMDtcbiAgbGV0IHZpb2xhdGlvbnMgPSAwO1xuICBjb25zdCB1cmxDb3VudHMgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpO1xuXG4gIGZvciAoY29uc3QgZXZlbnQgb2YgZXZlbnRzKSB7XG4gICAgaWYgKGV2ZW50Lm91dGNvbWUgPT09ICdhbGxvd2VkJykge1xuICAgICAgdG90YWxBY3Rpb25zKys7XG4gICAgICBhbGxvd2VkQWN0aW9ucysrO1xuICAgIH0gZWxzZSBpZiAoZXZlbnQub3V0Y29tZSA9PT0gJ2Jsb2NrZWQnKSB7XG4gICAgICB0b3RhbEFjdGlvbnMrKztcbiAgICAgIGJsb2NrZWRBY3Rpb25zKys7XG4gICAgfVxuICAgIGlmIChldmVudC50eXBlID09PSAnYm91bmRhcnktdmlvbGF0aW9uJykge1xuICAgICAgdmlvbGF0aW9ucysrO1xuICAgIH1cbiAgICBpZiAoZXZlbnQudXJsKSB7XG4gICAgICB1cmxDb3VudHMuc2V0KGV2ZW50LnVybCwgKHVybENvdW50cy5nZXQoZXZlbnQudXJsKSA/PyAwKSArIDEpO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRvcFVybHMgPSBbLi4udXJsQ291bnRzLmVudHJpZXMoKV1cbiAgICAuc29ydCgoYSwgYikgPT4gYlsxXSAtIGFbMV0pXG4gICAgLnNsaWNlKDAsIDUpXG4gICAgLm1hcCgoW3VybF0pID0+IHVybCk7XG5cbiAgbGV0IGR1cmF0aW9uU2Vjb25kczogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gIGlmIChldmVudHMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGxhc3RFdmVudCA9IGV2ZW50c1tldmVudHMubGVuZ3RoIC0gMV07XG4gICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZShzdGFydGVkQXQpLmdldFRpbWUoKTtcbiAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShsYXN0RXZlbnQudGltZXN0YW1wKS5nZXRUaW1lKCk7XG4gICAgZHVyYXRpb25TZWNvbmRzID0gTWF0aC5yb3VuZCgoZW5kIC0gc3RhcnQpIC8gMTAwMCk7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHRvdGFsQWN0aW9ucyxcbiAgICBhbGxvd2VkQWN0aW9ucyxcbiAgICBibG9ja2VkQWN0aW9ucyxcbiAgICB2aW9sYXRpb25zLFxuICAgIHRvcFVybHMsXG4gICAgZHVyYXRpb25TZWNvbmRzLFxuICB9O1xufVxuXG4vKipcbiAqIEZpbHRlciB0aW1lbGluZSBldmVudHMgYnkgdHlwZSwgVVJMLCBvciBvdXRjb21lLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyVGltZWxpbmVFdmVudHMoXG4gIGV2ZW50czogQWdlbnRFdmVudFtdLFxuICBmaWx0ZXJzOiB7XG4gICAgdHlwZT86IEFnZW50RXZlbnRUeXBlO1xuICAgIHVybD86IHN0cmluZztcbiAgICBvdXRjb21lPzogJ2FsbG93ZWQnIHwgJ2Jsb2NrZWQnIHwgJ2luZm9ybWF0aW9uYWwnO1xuICB9XG4pOiBBZ2VudEV2ZW50W10ge1xuICByZXR1cm4gZXZlbnRzLmZpbHRlcigoZXZlbnQpID0+IHtcbiAgICBpZiAoZmlsdGVycy50eXBlICE9PSB1bmRlZmluZWQgJiYgZXZlbnQudHlwZSAhPT0gZmlsdGVycy50eXBlKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGZpbHRlcnMudXJsICE9PSB1bmRlZmluZWQgJiYgZXZlbnQudXJsICE9PSBmaWx0ZXJzLnVybCkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChmaWx0ZXJzLm91dGNvbWUgIT09IHVuZGVmaW5lZCAmJiBldmVudC5vdXRjb21lICE9PSBmaWx0ZXJzLm91dGNvbWUpIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG59XG5cbi8qKlxuICogR2V0IHRoZSBtb3N0IHJlY2VudCBOIGV2ZW50cywgbmV3ZXN0IGZpcnN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0UmVjZW50RXZlbnRzKGV2ZW50czogQWdlbnRFdmVudFtdLCBjb3VudDogbnVtYmVyKTogQWdlbnRFdmVudFtdIHtcbiAgcmV0dXJuIGV2ZW50cy5zbGljZSgtY291bnQpLnJldmVyc2UoKTtcbn1cbiIsIi8qKlxuICogRGVsZWdhdGlvbiBydWxlIGVuZ2luZS5cbiAqXG4gKiBFdmFsdWF0ZXMgZGVsZWdhdGlvbiBydWxlcyB0byBkZXRlcm1pbmUgd2hhdCBhY3Rpb25zIGFuIGFnZW50IGlzXG4gKiBwZXJtaXR0ZWQgdG8gcGVyZm9ybS4gU3VwcG9ydHMgc2l0ZSBwYXR0ZXJucywgYWN0aW9uIHJlc3RyaWN0aW9ucyxcbiAqIGFuZCB0aW1lIGJvdW5kcy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7XG4gIERlbGVnYXRpb25SdWxlLFxuICBEZWxlZ2F0aW9uUHJlc2V0LFxuICBEZWxlZ2F0aW9uU2NvcGUsXG4gIERlbGVnYXRpb25Ub2tlbixcbiAgU2l0ZVBhdHRlcm4sXG4gIEFjdGlvblJlc3RyaWN0aW9uLFxuICBUaW1lQm91bmQsXG59IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSWQoKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKCk7XG59XG5cbmNvbnN0IFJFQURfT05MWV9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbSddO1xuY29uc3QgTElNSVRFRF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbScsICdjbGljaycsICd0eXBlLXRleHQnXTtcbmNvbnN0IEFMTF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gW1xuICAnbmF2aWdhdGUnLCAncmVhZC1kb20nLCAnY2xpY2snLCAndHlwZS10ZXh0JywgJ3N1Ym1pdC1mb3JtJyxcbiAgJ2Rvd25sb2FkLWZpbGUnLCAnb3Blbi10YWInLCAnY2xvc2UtdGFiJywgJ3NjcmVlbnNob3QnLFxuICAnZXhlY3V0ZS1zY3JpcHQnLCAnbW9kaWZ5LWRvbScsXG5dO1xuXG5mdW5jdGlvbiBidWlsZEFjdGlvblJlc3RyaWN0aW9ucyhhbGxvd2VkOiBBZ2VudENhcGFiaWxpdHlbXSk6IEFjdGlvblJlc3RyaWN0aW9uW10ge1xuICByZXR1cm4gQUxMX0NBUEFCSUxJVElFUy5tYXAoKGNhcCkgPT4gKHtcbiAgICBjYXBhYmlsaXR5OiBjYXAsXG4gICAgYWN0aW9uOiBhbGxvd2VkLmluY2x1ZGVzKGNhcCkgPyAnYWxsb3cnIGFzIGNvbnN0IDogJ2Jsb2NrJyBhcyBjb25zdCxcbiAgfSkpO1xufVxuXG4vKipcbiAqIENyZWF0ZSBhIGRlbGVnYXRpb24gcnVsZSBmcm9tIGEgcHJlc2V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUnVsZUZyb21QcmVzZXQoXG4gIHByZXNldDogRGVsZWdhdGlvblByZXNldCxcbiAgb3B0aW9ucz86IHtcbiAgICBzaXRlUGF0dGVybnM/OiBTaXRlUGF0dGVybltdO1xuICAgIGR1cmF0aW9uTWludXRlcz86IG51bWJlcjtcbiAgICBsYWJlbD86IHN0cmluZztcbiAgfVxuKTogRGVsZWdhdGlvblJ1bGUge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICBsZXQgc2NvcGU6IERlbGVnYXRpb25TY29wZTtcblxuICBzd2l0Y2ggKHByZXNldCkge1xuICAgIGNhc2UgJ3JlYWRPbmx5JzpcbiAgICAgIHNjb3BlID0ge1xuICAgICAgICBzaXRlUGF0dGVybnM6IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKFJFQURfT05MWV9DQVBBQklMSVRJRVMpLFxuICAgICAgICB0aW1lQm91bmQ6IG51bGwsXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG5cbiAgICBjYXNlICdsaW1pdGVkJzoge1xuICAgICAgY29uc3QgZHVyYXRpb25NaW51dGVzID0gb3B0aW9ucz8uZHVyYXRpb25NaW51dGVzID8/IDYwO1xuICAgICAgY29uc3QgZXhwaXJlc0F0ID0gbmV3IERhdGUobm93LmdldFRpbWUoKSArIGR1cmF0aW9uTWludXRlcyAqIDYwMDAwKTtcbiAgICAgIGNvbnN0IHRpbWVCb3VuZDogVGltZUJvdW5kID0ge1xuICAgICAgICBkdXJhdGlvbk1pbnV0ZXMsXG4gICAgICAgIGdyYW50ZWRBdDogbm93LnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGV4cGlyZXNBdDogZXhwaXJlc0F0LnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogb3B0aW9ucz8uc2l0ZVBhdHRlcm5zID8/IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKExJTUlURURfQ0FQQUJJTElUSUVTKSxcbiAgICAgICAgdGltZUJvdW5kLFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGNhc2UgJ2Z1bGxBY2Nlc3MnOlxuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogW10sXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogYnVpbGRBY3Rpb25SZXN0cmljdGlvbnMoQUxMX0NBUEFCSUxJVElFUyksXG4gICAgICAgIHRpbWVCb3VuZDogbnVsbCxcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGdlbmVyYXRlSWQoKSxcbiAgICBwcmVzZXQsXG4gICAgc2NvcGUsXG4gICAgY3JlYXRlZEF0OiBub3cudG9JU09TdHJpbmcoKSxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICBsYWJlbDogb3B0aW9ucz8ubGFiZWwsXG4gIH07XG59XG5cbi8qKlxuICogRXZhbHVhdGUgd2hldGhlciBhbiBhY3Rpb24gaXMgYWxsb3dlZCB1bmRlciBhIGRlbGVnYXRpb24gcnVsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV2YWx1YXRlUnVsZShcbiAgcnVsZTogRGVsZWdhdGlvblJ1bGUsXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICB1cmw6IHN0cmluZ1xuKTogeyBhbGxvd2VkOiBib29sZWFuOyByZWFzb246IHN0cmluZyB9IHtcbiAgaWYgKCFydWxlLmlzQWN0aXZlKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gcnVsZSBpcyBub3QgYWN0aXZlLicgfTtcbiAgfVxuXG4gIGlmIChpc1RpbWVCb3VuZEV4cGlyZWQocnVsZS5zY29wZS50aW1lQm91bmQpKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gaGFzIGV4cGlyZWQuJyB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgc2l0ZSBwYXR0ZXJuc1xuICBjb25zdCBkZWZhdWx0U2l0ZUFjdGlvbiA9IHJ1bGUucHJlc2V0ID09PSAnbGltaXRlZCcgPyAnYmxvY2snIGFzIGNvbnN0IDogJ2FsbG93JyBhcyBjb25zdDtcbiAgY29uc3Qgc2l0ZVJlc3VsdCA9IGV2YWx1YXRlU2l0ZVBhdHRlcm5zKHVybCwgcnVsZS5zY29wZS5zaXRlUGF0dGVybnMsIGRlZmF1bHRTaXRlQWN0aW9uKTtcbiAgaWYgKCFzaXRlUmVzdWx0LmFsbG93ZWQpIHtcbiAgICBjb25zdCBwYXR0ZXJuRGV0YWlsID0gc2l0ZVJlc3VsdC5tYXRjaGVkUGF0dGVyblxuICAgICAgPyBgIChtYXRjaGVkOiAke3NpdGVSZXN1bHQubWF0Y2hlZFBhdHRlcm4ucGF0dGVybn0pYFxuICAgICAgOiAnIChkZWZhdWx0IHBvbGljeSknO1xuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCByZWFzb246IGBVUkwgYmxvY2tlZCBieSBzaXRlIHBvbGljeSR7cGF0dGVybkRldGFpbH0uYCB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgYWN0aW9uIHJlc3RyaWN0aW9uc1xuICBjb25zdCBhY3Rpb25SZXN1bHQgPSBldmFsdWF0ZUFjdGlvblJlc3RyaWN0aW9ucyhhY3Rpb24sIHJ1bGUuc2NvcGUuYWN0aW9uUmVzdHJpY3Rpb25zKTtcbiAgaWYgKCFhY3Rpb25SZXN1bHQuYWxsb3dlZCkge1xuICAgIHJldHVybiB7XG4gICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgIHJlYXNvbjogYEFjdGlvbiBcIiR7YWN0aW9ufVwiIGlzIG5vdCBwZXJtaXR0ZWQgdW5kZXIgJHtydWxlLnByZXNldH0gZGVsZWdhdGlvbi5gLFxuICAgIH07XG4gIH1cblxuICByZXR1cm4geyBhbGxvd2VkOiB0cnVlLCByZWFzb246ICdBY3Rpb24gcGVybWl0dGVkIGJ5IGRlbGVnYXRpb24gcnVsZXMuJyB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgVVJMIG1hdGNoZXMgYW55IHNpdGUgcGF0dGVybiBpbiB0aGUgc2NvcGUuXG4gKiBGaXJzdCBtYXRjaCB3aW5zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVTaXRlUGF0dGVybnMoXG4gIHVybDogc3RyaW5nLFxuICBwYXR0ZXJuczogU2l0ZVBhdHRlcm5bXSxcbiAgZGVmYXVsdEFjdGlvbjogJ2FsbG93JyB8ICdibG9jaydcbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFBhdHRlcm46IFNpdGVQYXR0ZXJuIHwgbnVsbCB9IHtcbiAgZm9yIChjb25zdCBwYXR0ZXJuIG9mIHBhdHRlcm5zKSB7XG4gICAgaWYgKG1hdGNoR2xvYih1cmwsIHBhdHRlcm4ucGF0dGVybikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGFsbG93ZWQ6IHBhdHRlcm4uYWN0aW9uID09PSAnYWxsb3cnLFxuICAgICAgICBtYXRjaGVkUGF0dGVybjogcGF0dGVybixcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB7IGFsbG93ZWQ6IGRlZmF1bHRBY3Rpb24gPT09ICdhbGxvdycsIG1hdGNoZWRQYXR0ZXJuOiBudWxsIH07XG59XG5cbi8qKlxuICogTWF0Y2ggYSBVUkwgYWdhaW5zdCBhIGdsb2IgcGF0dGVybi5cbiAqL1xuZnVuY3Rpb24gbWF0Y2hHbG9iKHVybDogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgdHJ5IHtcbiAgICAvLyBJZiBwYXR0ZXJuIGRvZXNuJ3QgY29udGFpbiBwcm90b2NvbCwgbWF0Y2ggYWdhaW5zdCBob3N0bmFtZVxuICAgIGlmICghcGF0dGVybi5pbmNsdWRlcygnOi8vJykpIHtcbiAgICAgIGNvbnN0IHBhcnNlZFVybCA9IG5ldyBVUkwodXJsKTtcbiAgICAgIGNvbnN0IGhvc3RuYW1lID0gcGFyc2VkVXJsLmhvc3RuYW1lO1xuICAgICAgLy8gQ29udmVydCBnbG9iIHRvIHJlZ2V4OiAqIG1hdGNoZXMgYW55IGNoYXJhY3RlcnMgZXhjZXB0IGRvdHMgaW4gZG9tYWluIGNvbnRleHRcbiAgICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgICAucmVwbGFjZSgvXFwuL2csICdcXFxcLicpXG4gICAgICAgIC5yZXBsYWNlKC9cXCpcXCovZywgJy4qJylcbiAgICAgICAgLnJlcGxhY2UoL1xcKi9nLCAnW14uXSonKTtcbiAgICAgIHJldHVybiBuZXcgUmVnRXhwKGBeJHtyZWdleFN0cn0kYCkudGVzdChob3N0bmFtZSk7XG4gICAgfVxuXG4gICAgLy8gRnVsbCBVUkwgcGF0dGVybiBtYXRjaGluZ1xuICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgLnJlcGxhY2UoL1suK14ke30oKXxbXFxdXFxcXF0vZywgJ1xcXFwkJicpXG4gICAgICAucmVwbGFjZSgvXFxcXFxcKi9nLCAnLionKTtcbiAgICByZXR1cm4gbmV3IFJlZ0V4cChgXiR7cmVnZXhTdHJ9JGApLnRlc3QodXJsKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYW4gYWN0aW9uIGlzIGFsbG93ZWQgYnkgdGhlIGFjdGlvbiByZXN0cmljdGlvbiBsaXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVBY3Rpb25SZXN0cmljdGlvbnMoXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICByZXN0cmljdGlvbnM6IEFjdGlvblJlc3RyaWN0aW9uW11cbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFJlc3RyaWN0aW9uOiBBY3Rpb25SZXN0cmljdGlvbiB8IG51bGwgfSB7XG4gIGNvbnN0IHJlc3RyaWN0aW9uID0gcmVzdHJpY3Rpb25zLmZpbmQoKHIpID0+IHIuY2FwYWJpbGl0eSA9PT0gYWN0aW9uKTtcbiAgaWYgKCFyZXN0cmljdGlvbikge1xuICAgIC8vIERlZmF1bHQtYmxvY2sgaWYgbm90IGxpc3RlZFxuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCBtYXRjaGVkUmVzdHJpY3Rpb246IG51bGwgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGFsbG93ZWQ6IHJlc3RyaWN0aW9uLmFjdGlvbiA9PT0gJ2FsbG93JyxcbiAgICBtYXRjaGVkUmVzdHJpY3Rpb246IHJlc3RyaWN0aW9uLFxuICB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgdGltZSBib3VuZCBoYXMgZXhwaXJlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzVGltZUJvdW5kRXhwaXJlZCh0aW1lQm91bmQ6IFRpbWVCb3VuZCB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKHRpbWVCb3VuZCA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCkgPiBuZXcgRGF0ZSh0aW1lQm91bmQuZXhwaXJlc0F0KS5nZXRUaW1lKCk7XG59XG5cbi8qKlxuICogSXNzdWUgYSBkZWxlZ2F0aW9uIHRva2VuIGZvciBhbiBhZ2VudCBzZXNzaW9uIChsb2NhbC1vbmx5LCBsb2NhbC1vbmx5LCB1bnNpZ25lZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc3N1ZVRva2VuKFxuICBydWxlSWQ6IHN0cmluZyxcbiAgYWdlbnRJZDogc3RyaW5nLFxuICBzY29wZTogRGVsZWdhdGlvblNjb3BlLFxuICBleHBpcmVzQXQ6IHN0cmluZ1xuKTogRGVsZWdhdGlvblRva2VuIHtcbiAgcmV0dXJuIHtcbiAgICB0b2tlbklkOiBnZW5lcmF0ZUlkKCksXG4gICAgcnVsZUlkLFxuICAgIGFnZW50SWQsXG4gICAgc2NvcGUsXG4gICAgaXNzdWVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBleHBpcmVzQXQsXG4gICAgcmV2b2tlZDogZmFsc2UsXG4gIH07XG59XG5cbi8qKlxuICogUmV2b2tlIGEgZGVsZWdhdGlvbiB0b2tlbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJldm9rZVRva2VuKHRva2VuOiBEZWxlZ2F0aW9uVG9rZW4pOiBEZWxlZ2F0aW9uVG9rZW4ge1xuICByZXR1cm4geyAuLi50b2tlbiwgcmV2b2tlZDogdHJ1ZSB9O1xufVxuIiwiLyoqXG4gKiBFbWVyZ2VuY3kga2lsbCBzd2l0Y2ggbW9kdWxlLlxuICpcbiAqIFByb3ZpZGVzIG9uZS1jbGljayByZXZvY2F0aW9uIG9mIGFsbCBhZ2VudCBhY2Nlc3MuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBLaWxsU3dpdGNoRXZlbnQgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uVG9rZW4gfSBmcm9tICcuLi90eXBlcy9kZWxlZ2F0aW9uJztcbmltcG9ydCB7IHJldm9rZVRva2VuIH0gZnJvbSAnLi4vZGVsZWdhdGlvbi9ydWxlcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgS2lsbFN3aXRjaFN0YXRlIHtcbiAgaXNBY3RpdmU6IGJvb2xlYW47XG4gIGxhc3RFdmVudDogS2lsbFN3aXRjaEV2ZW50IHwgbnVsbDtcbiAgbGFzdEFjdGl2YXRlZEF0OiBzdHJpbmcgfCBudWxsO1xufVxuXG4vLyBUcmFjayBjbGVhbnVwIGZ1bmN0aW9ucyByZWdpc3RlcmVkIGJ5IGNvbnRlbnQtc2lkZSBtb2R1bGVzXG5jb25zdCByZWdpc3RlcmVkQ2xlYW51cHM6IEFycmF5PCgpID0+IHZvaWQ+ID0gW107XG5cbi8qKlxuICogUmVnaXN0ZXIgYSBjbGVhbnVwIGZ1bmN0aW9uIHRvIGJlIGNhbGxlZCBkdXJpbmcga2lsbCBzd2l0Y2ggZXhlY3V0aW9uLlxuICogVXNlZCBieSBkZXRlY3RvciBhbmQgbW9uaXRvciBtb2R1bGVzIHRvIHJlZ2lzdGVyIHRoZWlyIHRlYXJkb3duIGxvZ2ljLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJDbGVhbnVwKGNsZWFudXA6ICgpID0+IHZvaWQpOiB2b2lkIHtcbiAgcmVnaXN0ZXJlZENsZWFudXBzLnB1c2goY2xlYW51cCk7XG59XG5cbi8qKlxuICogRXhlY3V0ZSB0aGUga2lsbCBzd2l0Y2ggZnJvbSB0aGUgY29udGVudCBzY3JpcHQgc2lkZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4ZWN1dGVDb250ZW50S2lsbFN3aXRjaCgpOiB7XG4gIGxpc3RlbmVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgb2JzZXJ2ZXJzRGlzY29ubmVjdGVkOiBudW1iZXI7XG4gIGJpbmRpbmdzQ2xlYXJlZDogc3RyaW5nW107XG59IHtcbiAgbGV0IGxpc3RlbmVyc1JlbW92ZWQgPSAwO1xuICBsZXQgb2JzZXJ2ZXJzRGlzY29ubmVjdGVkID0gMDtcblxuICAvLyBDYWxsIGFsbCByZWdpc3RlcmVkIGNsZWFudXAgZnVuY3Rpb25zXG4gIGZvciAoY29uc3QgY2xlYW51cCBvZiByZWdpc3RlcmVkQ2xlYW51cHMpIHtcbiAgICB0cnkge1xuICAgICAgY2xlYW51cCgpO1xuICAgICAgbGlzdGVuZXJzUmVtb3ZlZCsrO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gQmVzdCBlZmZvcnRcbiAgICB9XG4gIH1cbiAgcmVnaXN0ZXJlZENsZWFudXBzLmxlbmd0aCA9IDA7XG5cbiAgLy8gQ2xlYXIgYXV0b21hdGlvbiBiaW5kaW5nc1xuICBjb25zdCBiaW5kaW5nc0NsZWFyZWQgPSBjbGVhckF1dG9tYXRpb25GbGFncygpO1xuXG4gIC8vIEF0dGVtcHQgQ0RQIHRlcm1pbmF0aW9uXG4gIHRlcm1pbmF0ZUNkcENvbm5lY3Rpb25zKCk7XG5cbiAgcmV0dXJuIHsgbGlzdGVuZXJzUmVtb3ZlZCwgb2JzZXJ2ZXJzRGlzY29ubmVjdGVkLCBiaW5kaW5nc0NsZWFyZWQgfTtcbn1cblxuLyoqXG4gKiBFeGVjdXRlIHRoZSBraWxsIHN3aXRjaCBmcm9tIHRoZSBiYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIHNpZGUuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleGVjdXRlQmFja2dyb3VuZEtpbGxTd2l0Y2goXG4gIHRyaWdnZXI6ICdidXR0b24nIHwgJ2tleWJvYXJkLXNob3J0Y3V0JyB8ICdhcGknLFxuICBhY3RpdmVBZ2VudElkczogc3RyaW5nW10sXG4gIGFjdGl2ZVRva2VuczogRGVsZWdhdGlvblRva2VuW11cbik6IFByb21pc2U8S2lsbFN3aXRjaEV2ZW50PiB7XG4gIGNvbnN0IHJldm9rZWRUb2tlbklkczogc3RyaW5nW10gPSBbXTtcblxuICAvLyBSZXZva2UgYWxsIHRva2Vuc1xuICBmb3IgKGNvbnN0IHRva2VuIG9mIGFjdGl2ZVRva2Vucykge1xuICAgIHJldm9rZVRva2VuKHRva2VuKTtcbiAgICByZXZva2VkVG9rZW5JZHMucHVzaCh0b2tlbi50b2tlbklkKTtcbiAgfVxuXG4gIC8vIFNlbmQga2lsbCBjb21tYW5kIHRvIGFsbCB0YWJzXG4gIGxldCBjZHBUZXJtaW5hdGVkID0gZmFsc2U7XG4gIGxldCBhdXRvbWF0aW9uRmxhZ3NDbGVhcmVkID0gZmFsc2U7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHt9KTtcbiAgICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgICBpZiAodGFiLmlkID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgdHlwZTogJ0tJTExfU1dJVENIX0FDVElWQVRFJyxcbiAgICAgICAgICBkYXRhOiB7fSxcbiAgICAgICAgICBzZW50QXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gVGFiIG1heSBub3QgaGF2ZSBjb250ZW50IHNjcmlwdFxuICAgICAgfVxuICAgIH1cbiAgICBjZHBUZXJtaW5hdGVkID0gdHJ1ZTtcbiAgICBhdXRvbWF0aW9uRmxhZ3NDbGVhcmVkID0gdHJ1ZTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gQmVzdCBlZmZvcnRcbiAgfVxuXG4gIGNvbnN0IGV2ZW50OiBLaWxsU3dpdGNoRXZlbnQgPSB7XG4gICAgaWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdHJpZ2dlcixcbiAgICB0ZXJtaW5hdGVkQWdlbnRJZHM6IFsuLi5hY3RpdmVBZ2VudElkc10sXG4gICAgcmV2b2tlZFRva2VuSWRzLFxuICAgIGNkcFRlcm1pbmF0ZWQsXG4gICAgYXV0b21hdGlvbkZsYWdzQ2xlYXJlZCxcbiAgfTtcblxuICAvLyBTaG93IG5vdGlmaWNhdGlvblxuICBzaG93S2lsbFN3aXRjaE5vdGlmaWNhdGlvbihhY3RpdmVBZ2VudElkcy5sZW5ndGgpO1xuXG4gIHJldHVybiBldmVudDtcbn1cblxuLyoqXG4gKiBBdHRlbXB0IHRvIHRlcm1pbmF0ZSBDRFAgY29ubmVjdGlvbnMgKGJlc3QtZWZmb3J0IGZyb20gY29udGVudCBzY3JpcHQpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdGVybWluYXRlQ2RwQ29ubmVjdGlvbnMoKTogYm9vbGVhbiB7XG4gIHRyeSB7XG4gICAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gICAgbGV0IGZvdW5kID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBrZXkgb2Ygd2luZG93S2V5cykge1xuICAgICAgaWYgKFxuICAgICAgICBrZXkuc3RhcnRzV2l0aCgnX19jZHBfJykgfHxcbiAgICAgICAga2V5LnN0YXJ0c1dpdGgoJ19fY2hyb21pdW1fJylcbiAgICAgICkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGRlbGV0ZSAod2luZG93IGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW2tleV07XG4gICAgICAgICAgZm91bmQgPSB0cnVlO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvLyBQcm9wZXJ0eSBtYXkgbm90IGJlIGRlbGV0YWJsZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmb3VuZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ2xlYXIgYXV0b21hdGlvbiBmbGFncyBmcm9tIHRoZSBjdXJyZW50IHBhZ2UgY29udGV4dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyQXV0b21hdGlvbkZsYWdzKCk6IHN0cmluZ1tdIHtcbiAgY29uc3QgY2xlYXJlZDogc3RyaW5nW10gPSBbXTtcblxuICAvLyBUcnkgdG8gY2xlYXIgbmF2aWdhdG9yLndlYmRyaXZlclxuICB0cnkge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShuYXZpZ2F0b3IsICd3ZWJkcml2ZXInLCB7XG4gICAgICBnZXQ6ICgpID0+IGZhbHNlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIH0pO1xuICAgIGNsZWFyZWQucHVzaCgnbmF2aWdhdG9yLndlYmRyaXZlcicpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBNYXkgbm90IGJlIHdyaXRhYmxlXG4gIH1cblxuICAvLyBDbGVhciBTZWxlbml1bSBtYXJrZXJzXG4gIGNvbnN0IGRvY0tleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhkb2N1bWVudCk7XG4gIGZvciAoY29uc3Qga2V5IG9mIGRvY0tleXMpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJyRjZGNfJykgfHwga2V5LnN0YXJ0c1dpdGgoJyR3ZGNfJykpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGRlbGV0ZSAoZG9jdW1lbnQgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilba2V5XTtcbiAgICAgICAgY2xlYXJlZC5wdXNoKGtleSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gQmVzdCBlZmZvcnRcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBDbGVhciBQbGF5d3JpZ2h0IGFuZCBQdXBwZXRlZXIgYmluZGluZ3NcbiAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gIGNvbnN0IGF1dG9tYXRpb25QcmVmaXhlcyA9IFsnX19wbGF5d3JpZ2h0JywgJ19fcHVwcGV0ZWVyJywgJ19fcHdfJ107XG4gIGZvciAoY29uc3Qga2V5IG9mIHdpbmRvd0tleXMpIHtcbiAgICBpZiAoYXV0b21hdGlvblByZWZpeGVzLnNvbWUoKHByZWZpeCkgPT4ga2V5LnN0YXJ0c1dpdGgocHJlZml4KSkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGRlbGV0ZSAod2luZG93IGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW2tleV07XG4gICAgICAgIGNsZWFyZWQucHVzaChrZXkpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIEJlc3QgZWZmb3J0XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNsZWFyZWQ7XG59XG5cbi8qKlxuICogU2hvdyBhIENocm9tZSBub3RpZmljYXRpb24gY29uZmlybWluZyBraWxsIHN3aXRjaCBhY3RpdmF0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2hvd0tpbGxTd2l0Y2hOb3RpZmljYXRpb24oYWdlbnRDb3VudDogbnVtYmVyKTogdm9pZCB7XG4gIHRyeSB7XG4gICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY3JlYXRlKGBhYmcta2lsbHN3aXRjaC0ke0RhdGUubm93KCl9YCwge1xuICAgICAgdHlwZTogJ2Jhc2ljJyxcbiAgICAgIGljb25Vcmw6IGNocm9tZS5ydW50aW1lLmdldFVSTCgnaWNvbnMvaWNvbjEyOC5wbmcnKSxcbiAgICAgIHRpdGxlOiAnQUkgQnJvd3NlciBHdWFyZCAtIEtpbGwgU3dpdGNoIEFjdGl2YXRlZCcsXG4gICAgICBtZXNzYWdlOiBgVGVybWluYXRlZCAke2FnZW50Q291bnR9IGFnZW50IHNlc3Npb24ocykuIEFsbCBkZWxlZ2F0aW9ucyByZXZva2VkLmAsXG4gICAgICBwcmlvcml0eTogMixcbiAgICB9KTtcblxuICAgIC8vIEF1dG8tZGlzbWlzcyBhZnRlciA1IHNlY29uZHNcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNocm9tZS5ub3RpZmljYXRpb25zLmdldEFsbCgobm90aWZpY2F0aW9ucykgPT4ge1xuICAgICAgICAgIGZvciAoY29uc3QgaWQgb2YgT2JqZWN0LmtleXMobm90aWZpY2F0aW9ucykpIHtcbiAgICAgICAgICAgIGlmIChpZC5zdGFydHNXaXRoKCdhYmcta2lsbHN3aXRjaC0nKSkge1xuICAgICAgICAgICAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jbGVhcihpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBJZ25vcmVcbiAgICAgIH1cbiAgICB9LCA1MDAwKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gTm90aWZpY2F0aW9ucyBtYXkgbm90IGJlIGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdCBjb250ZXh0XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGUgdGhlIGluaXRpYWwga2lsbCBzd2l0Y2ggc3RhdGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVJbml0aWFsS2lsbFN3aXRjaFN0YXRlKCk6IEtpbGxTd2l0Y2hTdGF0ZSB7XG4gIHJldHVybiB7XG4gICAgaXNBY3RpdmU6IGZhbHNlLFxuICAgIGxhc3RFdmVudDogbnVsbCxcbiAgICBsYXN0QWN0aXZhdGVkQXQ6IG51bGwsXG4gIH07XG59XG4iLCIvKipcbiAqIENocm9tZSBub3RpZmljYXRpb24gaW50ZWdyYXRpb24gZm9yIGJvdW5kYXJ5IGFsZXJ0cy5cbiAqXG4gKiBEZWxpdmVycyBzeXN0ZW0tbGV2ZWwgbm90aWZpY2F0aW9ucyB3aGVuIGFnZW50cyB2aW9sYXRlIGRlbGVnYXRpb25cbiAqIGJvdW5kYXJpZXMuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBCb3VuZGFyeUFsZXJ0LCBBbGVydFNldmVyaXR5IH0gZnJvbSAnLi9ib3VuZGFyeSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTm90aWZpY2F0aW9uQ29uZmlnIHtcbiAgZW5hYmxlZDogYm9vbGVhbjtcbiAgbWluaW11bVNldmVyaXR5OiBBbGVydFNldmVyaXR5O1xuICBwbGF5U291bmQ6IGJvb2xlYW47XG4gIGF1dG9EaXNtaXNzTXM6IG51bWJlcjtcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfTk9USUZJQ0FUSU9OX0NPTkZJRzogTm90aWZpY2F0aW9uQ29uZmlnID0ge1xuICBlbmFibGVkOiB0cnVlLFxuICBtaW5pbXVtU2V2ZXJpdHk6ICdtZWRpdW0nLFxuICBwbGF5U291bmQ6IHRydWUsXG4gIGF1dG9EaXNtaXNzTXM6IDEwMDAwLFxufTtcblxuLyoqXG4gKiBTaG93IGEgQ2hyb21lIG5vdGlmaWNhdGlvbiBmb3IgYSBib3VuZGFyeSBhbGVydC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNob3dCb3VuZGFyeU5vdGlmaWNhdGlvbihcbiAgYWxlcnQ6IEJvdW5kYXJ5QWxlcnQsXG4gIGNvbmZpZz86IFBhcnRpYWw8Tm90aWZpY2F0aW9uQ29uZmlnPlxuKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IG1lcmdlZENvbmZpZyA9IHsgLi4uREVGQVVMVF9OT1RJRklDQVRJT05fQ09ORklHLCAuLi5jb25maWcgfTtcblxuICBpZiAoIW1lcmdlZENvbmZpZy5lbmFibGVkKSByZXR1cm4gbnVsbDtcbiAgaWYgKCFtZWV0c1NldmVyaXR5VGhyZXNob2xkKGFsZXJ0LnNldmVyaXR5LCBtZXJnZWRDb25maWcubWluaW11bVNldmVyaXR5KSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgbm90aWZpY2F0aW9uSWQgPSBgYWJnLWFsZXJ0LSR7RGF0ZS5ub3coKX1gO1xuXG4gIHRyeSB7XG4gICAgY29uc3Qgb3B0aW9uczogY2hyb21lLm5vdGlmaWNhdGlvbnMuTm90aWZpY2F0aW9uT3B0aW9uczx0cnVlPiA9IHtcbiAgICAgIHR5cGU6ICdiYXNpYycgYXMgY29uc3QsXG4gICAgICBpY29uVXJsOiBjaHJvbWUucnVudGltZS5nZXRVUkwoJ2ljb25zL2ljb24xMjgucG5nJyksXG4gICAgICB0aXRsZTogYEFJIEJyb3dzZXIgR3VhcmQgLSAke2FsZXJ0LnRpdGxlfWAsXG4gICAgICBtZXNzYWdlOiBhbGVydC5tZXNzYWdlLFxuICAgICAgcHJpb3JpdHk6IHNldmVyaXR5VG9Qcmlvcml0eShhbGVydC5zZXZlcml0eSksXG4gICAgICByZXF1aXJlSW50ZXJhY3Rpb246IGFsZXJ0LnNldmVyaXR5ID09PSAnY3JpdGljYWwnLFxuICAgIH07XG5cbiAgICBpZiAoYWxlcnQuYWxsb3dPbmVUaW1lT3ZlcnJpZGUpIHtcbiAgICAgIG9wdGlvbnMuYnV0dG9ucyA9IFtcbiAgICAgICAgeyB0aXRsZTogJ0FsbG93IG9uY2UnIH0sXG4gICAgICAgIHsgdGl0bGU6ICdEaXNtaXNzJyB9LFxuICAgICAgXTtcbiAgICB9XG5cbiAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jcmVhdGUobm90aWZpY2F0aW9uSWQsIG9wdGlvbnMpO1xuXG4gICAgaWYgKG1lcmdlZENvbmZpZy5hdXRvRGlzbWlzc01zID4gMCAmJiBhbGVydC5zZXZlcml0eSAhPT0gJ2NyaXRpY2FsJykge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY2xlYXIobm90aWZpY2F0aW9uSWQpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvLyBOb3RpZmljYXRpb24gbWF5IGFscmVhZHkgYmUgY2xlYXJlZFxuICAgICAgICB9XG4gICAgICB9LCBtZXJnZWRDb25maWcuYXV0b0Rpc21pc3NNcyk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIGNyZWF0ZSBub3RpZmljYXRpb246JywgZXJyKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiBub3RpZmljYXRpb25JZDtcbn1cblxuLyoqXG4gKiBNYXAgYWxlcnQgc2V2ZXJpdHkgdG8gbm90aWZpY2F0aW9uIHByaW9yaXR5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V2ZXJpdHlUb1ByaW9yaXR5KHNldmVyaXR5OiBBbGVydFNldmVyaXR5KTogbnVtYmVyIHtcbiAgY29uc3QgcHJpb3JpdHlNYXA6IFJlY29yZDxBbGVydFNldmVyaXR5LCBudW1iZXI+ID0ge1xuICAgIGNyaXRpY2FsOiAyLFxuICAgIGhpZ2g6IDEsXG4gICAgbWVkaXVtOiAwLFxuICAgIGxvdzogMCxcbiAgfTtcbiAgcmV0dXJuIHByaW9yaXR5TWFwW3NldmVyaXR5XTtcbn1cblxuLyoqXG4gKiBDaGVjayBpZiBhIHNldmVyaXR5IG1lZXRzIHRoZSBtaW5pbXVtIHRocmVzaG9sZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lZXRzU2V2ZXJpdHlUaHJlc2hvbGQoXG4gIHNldmVyaXR5OiBBbGVydFNldmVyaXR5LFxuICBtaW5pbXVtOiBBbGVydFNldmVyaXR5XG4pOiBib29sZWFuIHtcbiAgY29uc3Qgb3JkZXI6IEFsZXJ0U2V2ZXJpdHlbXSA9IFsnbG93JywgJ21lZGl1bScsICdoaWdoJywgJ2NyaXRpY2FsJ107XG4gIHJldHVybiBvcmRlci5pbmRleE9mKHNldmVyaXR5KSA+PSBvcmRlci5pbmRleE9mKG1pbmltdW0pO1xufVxuXG4vKipcbiAqIFNldCB1cCBub3RpZmljYXRpb24gYnV0dG9uIGNsaWNrIGhhbmRsZXJzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBOb3RpZmljYXRpb25IYW5kbGVycyhcbiAgb25BbGxvd09uY2U6IChub3RpZmljYXRpb25JZDogc3RyaW5nKSA9PiB2b2lkXG4pOiAoKSA9PiB2b2lkIHtcbiAgY29uc3QgaGFuZGxlciA9IChub3RpZmljYXRpb25JZDogc3RyaW5nLCBidXR0b25JbmRleDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKGJ1dHRvbkluZGV4ID09PSAwKSB7XG4gICAgICAvLyBcIkFsbG93IG9uY2VcIlxuICAgICAgb25BbGxvd09uY2Uobm90aWZpY2F0aW9uSWQpO1xuICAgIH1cbiAgICAvLyBCdXR0b24gMSA9IFwiRGlzbWlzc1wiIC0ganVzdCBjbGVhclxuICAgIHRyeSB7XG4gICAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jbGVhcihub3RpZmljYXRpb25JZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBJZ25vcmVcbiAgICB9XG4gIH07XG5cbiAgY2hyb21lLm5vdGlmaWNhdGlvbnMub25CdXR0b25DbGlja2VkLmFkZExpc3RlbmVyKGhhbmRsZXIpO1xuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgY2hyb21lLm5vdGlmaWNhdGlvbnMub25CdXR0b25DbGlja2VkLnJlbW92ZUxpc3RlbmVyKGhhbmRsZXIpO1xuICB9O1xufVxuXG4vKipcbiAqIENsZWFyIGFsbCBhY3RpdmUgbm90aWZpY2F0aW9ucy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsTm90aWZpY2F0aW9ucygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNocm9tZS5ub3RpZmljYXRpb25zLmdldEFsbCgobm90aWZpY2F0aW9ucykgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGlkIG9mIE9iamVjdC5rZXlzKG5vdGlmaWNhdGlvbnMpKSB7XG4gICAgICAgICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY2xlYXIoaWQpO1xuICAgICAgICB9XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmVzb2x2ZSgpO1xuICAgIH1cbiAgfSk7XG59XG4iLCIvKipcbiAqIENhcGFiaWxpdHkgYm91bmRhcnkgYWxlcnQgc3lzdGVtLlxuICpcbiAqIEdlbmVyYXRlcyBhbGVydHMgd2hlbiBhbiBhZ2VudCBhdHRlbXB0cyBhY3Rpb25zIHRoYXQgZXhjZWVkIGl0c1xuICogZGVsZWdhdGVkIHBlcm1pc3Npb25zLlxuICovXG5cbmltcG9ydCB0eXBlIHsgQm91bmRhcnlWaW9sYXRpb24gfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5pbXBvcnQgdHlwZSB7IERlbGVnYXRpb25SdWxlIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5cbmV4cG9ydCB0eXBlIEFsZXJ0U2V2ZXJpdHkgPSAnY3JpdGljYWwnIHwgJ2hpZ2gnIHwgJ21lZGl1bScgfCAnbG93JztcblxuZXhwb3J0IGludGVyZmFjZSBCb3VuZGFyeUFsZXJ0IHtcbiAgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvbjtcbiAgc2V2ZXJpdHk6IEFsZXJ0U2V2ZXJpdHk7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgYWxsb3dPbmVUaW1lT3ZlcnJpZGU6IGJvb2xlYW47XG4gIGFja25vd2xlZGdlZDogYm9vbGVhbjtcbn1cblxuY29uc3QgU0VOU0lUSVZFX1VSTF9QQVRURVJOUyA9IFtcbiAgL1xcLmJhbmtcXC4vaSxcbiAgL1xcLmdvdlxcLi9pLFxuICAvcGF5cGFsL2ksXG4gIC9zdHJpcGUvaSxcbiAgL1xcLmZpbmFuY2lhbC9pLFxuICAvaGVhbHRoY2FyZS9pLFxuICAvXFwubWlsXFwuL2ksXG5dO1xuXG4vKipcbiAqIENyZWF0ZSBhIGJvdW5kYXJ5IGFsZXJ0IGZyb20gYSB2aW9sYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVCb3VuZGFyeUFsZXJ0KFxuICB2aW9sYXRpb246IEJvdW5kYXJ5VmlvbGF0aW9uLFxuICBydWxlOiBEZWxlZ2F0aW9uUnVsZVxuKTogQm91bmRhcnlBbGVydCB7XG4gIGNvbnN0IHNldmVyaXR5ID0gY2xhc3NpZnlWaW9sYXRpb25TZXZlcml0eSh2aW9sYXRpb24uYXR0ZW1wdGVkQWN0aW9uLCB2aW9sYXRpb24udXJsKTtcbiAgY29uc3QgdGl0bGUgPSBnZW5lcmF0ZUFsZXJ0VGl0bGUodmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbik7XG4gIGNvbnN0IG1lc3NhZ2UgPSBnZW5lcmF0ZUFsZXJ0TWVzc2FnZSh2aW9sYXRpb24sIHJ1bGUubGFiZWwgPz8gcnVsZS5wcmVzZXQpO1xuXG4gIHJldHVybiB7XG4gICAgdmlvbGF0aW9uLFxuICAgIHNldmVyaXR5LFxuICAgIHRpdGxlLFxuICAgIG1lc3NhZ2UsXG4gICAgYWxsb3dPbmVUaW1lT3ZlcnJpZGU6IHNldmVyaXR5ID09PSAnbWVkaXVtJyB8fCBzZXZlcml0eSA9PT0gJ2xvdycsXG4gICAgYWNrbm93bGVkZ2VkOiBmYWxzZSxcbiAgfTtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgdGhlIHNldmVyaXR5IG9mIGEgY2FwYWJpbGl0eSB2aW9sYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbGFzc2lmeVZpb2xhdGlvblNldmVyaXR5KFxuICBjYXBhYmlsaXR5OiBBZ2VudENhcGFiaWxpdHksXG4gIHVybDogc3RyaW5nXG4pOiBBbGVydFNldmVyaXR5IHtcbiAgY29uc3QgYmFzZVNldmVyaXR5TWFwOiBSZWNvcmQ8QWdlbnRDYXBhYmlsaXR5LCBBbGVydFNldmVyaXR5PiA9IHtcbiAgICAnc3VibWl0LWZvcm0nOiAnY3JpdGljYWwnLFxuICAgICdleGVjdXRlLXNjcmlwdCc6ICdjcml0aWNhbCcsXG4gICAgJ2Rvd25sb2FkLWZpbGUnOiAnaGlnaCcsXG4gICAgJ21vZGlmeS1kb20nOiAnaGlnaCcsXG4gICAgY2xpY2s6ICdoaWdoJyxcbiAgICAndHlwZS10ZXh0JzogJ21lZGl1bScsXG4gICAgbmF2aWdhdGU6ICdtZWRpdW0nLFxuICAgICdvcGVuLXRhYic6ICdsb3cnLFxuICAgICdjbG9zZS10YWInOiAnbG93JyxcbiAgICAncmVhZC1kb20nOiAnbG93JyxcbiAgICBzY3JlZW5zaG90OiAnbG93JyxcbiAgfTtcblxuICBsZXQgc2V2ZXJpdHkgPSBiYXNlU2V2ZXJpdHlNYXBbY2FwYWJpbGl0eV0gPz8gJ21lZGl1bSc7XG5cbiAgLy8gVXBncmFkZSBzZXZlcml0eSBmb3Igc2Vuc2l0aXZlIFVSTHNcbiAgY29uc3QgaXNTZW5zaXRpdmUgPSBTRU5TSVRJVkVfVVJMX1BBVFRFUk5TLnNvbWUoKHBhdHRlcm4pID0+IHBhdHRlcm4udGVzdCh1cmwpKTtcbiAgaWYgKGlzU2Vuc2l0aXZlKSB7XG4gICAgY29uc3QgdXBncmFkZTogUmVjb3JkPEFsZXJ0U2V2ZXJpdHksIEFsZXJ0U2V2ZXJpdHk+ID0ge1xuICAgICAgbG93OiAnbWVkaXVtJyxcbiAgICAgIG1lZGl1bTogJ2hpZ2gnLFxuICAgICAgaGlnaDogJ2NyaXRpY2FsJyxcbiAgICAgIGNyaXRpY2FsOiAnY3JpdGljYWwnLFxuICAgIH07XG4gICAgc2V2ZXJpdHkgPSB1cGdyYWRlW3NldmVyaXR5XTtcbiAgfVxuXG4gIHJldHVybiBzZXZlcml0eTtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSBhIGh1bWFuLXJlYWRhYmxlIGFsZXJ0IHRpdGxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVBbGVydFRpdGxlKGNhcGFiaWxpdHk6IEFnZW50Q2FwYWJpbGl0eSk6IHN0cmluZyB7XG4gIGNvbnN0IHRpdGxlczogUmVjb3JkPEFnZW50Q2FwYWJpbGl0eSwgc3RyaW5nPiA9IHtcbiAgICBuYXZpZ2F0ZTogJ05hdmlnYXRpb24gYmxvY2tlZCcsXG4gICAgJ3JlYWQtZG9tJzogJ1BhZ2UgcmVhZCBibG9ja2VkJyxcbiAgICBjbGljazogJ0NsaWNrIGludGVyYWN0aW9uIGJsb2NrZWQnLFxuICAgICd0eXBlLXRleHQnOiAnVGV4dCBpbnB1dCBibG9ja2VkJyxcbiAgICAnc3VibWl0LWZvcm0nOiAnRm9ybSBzdWJtaXNzaW9uIGJsb2NrZWQnLFxuICAgICdkb3dubG9hZC1maWxlJzogJ0ZpbGUgZG93bmxvYWQgYmxvY2tlZCcsXG4gICAgJ29wZW4tdGFiJzogJ05ldyB0YWIgYmxvY2tlZCcsXG4gICAgJ2Nsb3NlLXRhYic6ICdUYWIgY2xvc3VyZSBibG9ja2VkJyxcbiAgICBzY3JlZW5zaG90OiAnU2NyZWVuc2hvdCBibG9ja2VkJyxcbiAgICAnZXhlY3V0ZS1zY3JpcHQnOiAnU2NyaXB0IGV4ZWN1dGlvbiBibG9ja2VkJyxcbiAgICAnbW9kaWZ5LWRvbSc6ICdET00gbW9kaWZpY2F0aW9uIGJsb2NrZWQnLFxuICB9O1xuICByZXR1cm4gdGl0bGVzW2NhcGFiaWxpdHldIHx8ICdBY3Rpb24gYmxvY2tlZCc7XG59XG5cbi8qKlxuICogR2VuZXJhdGUgYSBkZXRhaWxlZCBhbGVydCBtZXNzYWdlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVBbGVydE1lc3NhZ2UoXG4gIHZpb2xhdGlvbjogQm91bmRhcnlWaW9sYXRpb24sXG4gIHJ1bGVOYW1lOiBzdHJpbmdcbik6IHN0cmluZyB7XG4gIGNvbnN0IGxpbmVzID0gW1xuICAgIGBBbiBhZ2VudCBhdHRlbXB0ZWQgdG8gcGVyZm9ybSBcIiR7dmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbn1cIiBvbjpgLFxuICAgIHZpb2xhdGlvbi51cmwsXG4gICAgJycsXG4gICAgYEJsb2NrZWQgYnkgcnVsZTogJHtydWxlTmFtZX1gLFxuICAgIGBSZWFzb246ICR7dmlvbGF0aW9uLnJlYXNvbn1gLFxuICBdO1xuXG4gIGlmICh2aW9sYXRpb24udGFyZ2V0U2VsZWN0b3IpIHtcbiAgICBsaW5lcy5wdXNoKGBUYXJnZXQgZWxlbWVudDogJHt2aW9sYXRpb24udGFyZ2V0U2VsZWN0b3J9YCk7XG4gIH1cblxuICByZXR1cm4gbGluZXMuam9pbignXFxuJyk7XG59XG5cbi8qKlxuICogSGFuZGxlIGEgdXNlcidzIG9uZS10aW1lIG92ZXJyaWRlIG9mIGEgYmxvY2tlZCBhY3Rpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVPbmVUaW1lT3ZlcnJpZGUoXG4gIGFsZXJ0SWQ6IHN0cmluZyxcbiAgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvblxuKTogQm91bmRhcnlWaW9sYXRpb24ge1xuICByZXR1cm4geyAuLi52aW9sYXRpb24sIHVzZXJPdmVycmlkZTogdHJ1ZSB9O1xufVxuIiwiLyoqXG4gKiBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGVudHJ5IHBvaW50LlxuICpcbiAqIENlbnRyYWwgY29vcmRpbmF0b3IgZm9yIHRoZSBleHRlbnNpb24uXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBNZXNzYWdlUGF5bG9hZCwgRGV0ZWN0aW9uRXZlbnQsIEtpbGxTd2l0Y2hFdmVudCwgQWdlbnRFdmVudCwgQm91bmRhcnlWaW9sYXRpb24gfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudElkZW50aXR5IH0gZnJvbSAnLi4vdHlwZXMvYWdlbnQnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uUnVsZSB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudFNlc3Npb24gfSBmcm9tICcuLi9zZXNzaW9uL3R5cGVzJztcbmltcG9ydCB7IGdldFN0b3JhZ2VTdGF0ZSwgc2F2ZVNlc3Npb24sIHVwZGF0ZVNlc3Npb24sIHNhdmVEZWxlZ2F0aW9uUnVsZXMsIGFwcGVuZERldGVjdGlvbkxvZywgdXBkYXRlU2V0dGluZ3MgfSBmcm9tICcuLi9zZXNzaW9uL3N0b3JhZ2UnO1xuaW1wb3J0IHsgY3JlYXRlVGltZWxpbmVFdmVudCwgYXBwZW5kRXZlbnRUb1Nlc3Npb24gfSBmcm9tICcuLi9zZXNzaW9uL3RpbWVsaW5lJztcbmltcG9ydCB7IGV4ZWN1dGVCYWNrZ3JvdW5kS2lsbFN3aXRjaCwgY3JlYXRlSW5pdGlhbEtpbGxTd2l0Y2hTdGF0ZSB9IGZyb20gJy4uL2tpbGxzd2l0Y2gvaW5kZXgnO1xuaW1wb3J0IHR5cGUgeyBLaWxsU3dpdGNoU3RhdGUgfSBmcm9tICcuLi9raWxsc3dpdGNoL2luZGV4JztcbmltcG9ydCB7IGlzVGltZUJvdW5kRXhwaXJlZCB9IGZyb20gJy4uL2RlbGVnYXRpb24vcnVsZXMnO1xuaW1wb3J0IHsgc2V0dXBOb3RpZmljYXRpb25IYW5kbGVycywgY2xlYXJBbGxOb3RpZmljYXRpb25zIH0gZnJvbSAnLi4vYWxlcnRzL25vdGlmaWNhdGlvbic7XG5pbXBvcnQgeyBjcmVhdGVCb3VuZGFyeUFsZXJ0IH0gZnJvbSAnLi4vYWxlcnRzL2JvdW5kYXJ5JztcbmltcG9ydCB0eXBlIHsgQm91bmRhcnlBbGVydCB9IGZyb20gJy4uL2FsZXJ0cy9ib3VuZGFyeSc7XG5cbmludGVyZmFjZSBCYWNrZ3JvdW5kU3RhdGUge1xuICBhY3RpdmVBZ2VudHM6IE1hcDxudW1iZXIsIEFnZW50SWRlbnRpdHk+O1xuICBhY3RpdmVTZXNzaW9uczogTWFwPG51bWJlciwgc3RyaW5nPjsgLy8gdGFiSWQgLT4gc2Vzc2lvbklkXG4gIGRlbGVnYXRpb25SdWxlczogRGVsZWdhdGlvblJ1bGVbXTtcbiAga2lsbFN3aXRjaDogS2lsbFN3aXRjaFN0YXRlO1xuICByZWNlbnRBbGVydHM6IEJvdW5kYXJ5QWxlcnRbXTtcbn1cblxuY29uc3Qgc3RhdGU6IEJhY2tncm91bmRTdGF0ZSA9IHtcbiAgYWN0aXZlQWdlbnRzOiBuZXcgTWFwKCksXG4gIGFjdGl2ZVNlc3Npb25zOiBuZXcgTWFwKCksXG4gIGRlbGVnYXRpb25SdWxlczogW10sXG4gIGtpbGxTd2l0Y2g6IGNyZWF0ZUluaXRpYWxLaWxsU3dpdGNoU3RhdGUoKSxcbiAgcmVjZW50QWxlcnRzOiBbXSxcbn07XG5cbmZ1bmN0aW9uIGluaXRpYWxpemUoKTogdm9pZCB7XG4gIGxvYWRQZXJzaXN0ZWRTdGF0ZSgpLnRoZW4oKCkgPT4ge1xuICAgIHVwZGF0ZUJhZGdlKCk7XG4gIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIGxvYWQgc3RhdGU6JywgZXJyKTtcbiAgfSk7XG5cbiAgLy8gTWVzc2FnZSByb3V0aW5nXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihoYW5kbGVNZXNzYWdlKTtcblxuICAvLyBUYWIgbGlmZWN5Y2xlXG4gIGNocm9tZS50YWJzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcigodGFiSWQpID0+IHtcbiAgICBoYW5kbGVUYWJSZW1vdmVkKHRhYklkKS5jYXRjaCgoKSA9PiB7IC8qIGlnbm9yZSAqLyB9KTtcbiAgfSk7XG5cbiAgLy8gRGVsZWdhdGlvbiBleHBpcmF0aW9uIGFsYXJtXG4gIGNocm9tZS5hbGFybXMuY3JlYXRlKCdkZWxlZ2F0aW9uLWNoZWNrJywgeyBwZXJpb2RJbk1pbnV0ZXM6IDEgfSk7XG4gIGNocm9tZS5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgICBpZiAoYWxhcm0ubmFtZSA9PT0gJ2RlbGVnYXRpb24tY2hlY2snKSB7XG4gICAgICBjaGVja0RlbGVnYXRpb25FeHBpcmF0aW9uKCkuY2F0Y2goKCkgPT4geyAvKiBpZ25vcmUgKi8gfSk7XG4gICAgfVxuICB9KTtcblxuICAvLyBLaWxsIHN3aXRjaCBrZXlib2FyZCBzaG9ydGN1dFxuICByZWdpc3RlcktleWJvYXJkU2hvcnRjdXQoKTtcblxuICAvLyBOb3RpZmljYXRpb24gaGFuZGxlcnNcbiAgc2V0dXBOb3RpZmljYXRpb25IYW5kbGVycygobm90aWZpY2F0aW9uSWQpID0+IHtcbiAgICAvLyBIYW5kbGUgXCJBbGxvdyBvbmNlXCIgY2xpY2tzIC0gZnV0dXJlIGVuaGFuY2VtZW50XG4gICAgY29uc29sZS5sb2coJ1tBSSBCcm93c2VyIEd1YXJkXSBPdmVycmlkZSByZXF1ZXN0ZWQgZm9yIG5vdGlmaWNhdGlvbjonLCBub3RpZmljYXRpb25JZCk7XG4gIH0pO1xuXG4gIGNvbnNvbGUubG9nKCdbQUkgQnJvd3NlciBHdWFyZF0gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBpbml0aWFsaXplZCcpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBsb2FkUGVyc2lzdGVkU3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFN0b3JhZ2VTdGF0ZSgpO1xuICBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMgPSBzdG9yZWQuZGVsZWdhdGlvblJ1bGVzO1xuXG4gIC8vIENoZWNrIGZvciBhY3RpdmUgc2Vzc2lvbnMgdGhhdCBtYXkgaGF2ZSBzdXJ2aXZlZCBhIHJlc3RhcnRcbiAgZm9yIChjb25zdCBzZXNzaW9uIG9mIHN0b3JlZC5zZXNzaW9ucykge1xuICAgIGlmICghc2Vzc2lvbi5lbmRlZEF0KSB7XG4gICAgICAvLyBNYXJrIHN0YWxlIHNlc3Npb25zIGFzIGVuZGVkXG4gICAgICBhd2FpdCB1cGRhdGVTZXNzaW9uKHNlc3Npb24uaWQsIChzKSA9PiAoe1xuICAgICAgICAuLi5zLFxuICAgICAgICBlbmRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVuZFJlYXNvbjogJ2FnZW50LWRpc2Nvbm5lY3RlZCcsXG4gICAgICB9KSk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UoXG4gIG1lc3NhZ2U6IE1lc3NhZ2VQYXlsb2FkLFxuICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gIHNlbmRSZXNwb25zZTogKHJlc3BvbnNlOiB1bmtub3duKSA9PiB2b2lkXG4pOiBib29sZWFuIHtcbiAgaWYgKCFtZXNzYWdlIHx8ICFtZXNzYWdlLnR5cGUpIHJldHVybiBmYWxzZTtcblxuICBjb25zdCB0YWJJZCA9IHNlbmRlci50YWI/LmlkO1xuXG4gIHN3aXRjaCAobWVzc2FnZS50eXBlKSB7XG4gICAgY2FzZSAnREVURUNUSU9OX1JFU1VMVCc6IHtcbiAgICAgIGlmICh0YWJJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGhhbmRsZURldGVjdGlvbih0YWJJZCwgbWVzc2FnZS5kYXRhIGFzIERldGVjdGlvbkV2ZW50KS50aGVuKCgpID0+IHtcbiAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogZmFsc2UgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8gYXN5bmMgcmVzcG9uc2VcbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjYXNlICdBR0VOVF9BQ1RJT04nOiB7XG4gICAgICBpZiAodGFiSWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBoYW5kbGVBZ2VudEFjdGlvbih0YWJJZCwgbWVzc2FnZS5kYXRhIGFzIEFnZW50RXZlbnQpO1xuICAgICAgfVxuICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjYXNlICdCT1VOREFSWV9DSEVDS19SRVFVRVNUJzoge1xuICAgICAgY29uc3QgdmlvbGF0aW9uID0gbWVzc2FnZS5kYXRhIGFzIEJvdW5kYXJ5VmlvbGF0aW9uO1xuICAgICAgaGFuZGxlQm91bmRhcnlWaW9sYXRpb24odGFiSWQsIHZpb2xhdGlvbik7XG4gICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNhc2UgJ0tJTExfU1dJVENIX0FDVElWQVRFJzoge1xuICAgICAgZXhlY3V0ZUtpbGxTd2l0Y2goXG4gICAgICAgIChtZXNzYWdlLmRhdGEgYXMgeyB0cmlnZ2VyPzogc3RyaW5nIH0pPy50cmlnZ2VyIGFzICdidXR0b24nIHwgJ2tleWJvYXJkLXNob3J0Y3V0JyB8ICdhcGknID8/ICdidXR0b24nXG4gICAgICApLnRoZW4oKGV2ZW50KSA9PiB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUsIGV2ZW50IH0pO1xuICAgICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiBmYWxzZSB9KTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHRydWU7IC8vIGFzeW5jIHJlc3BvbnNlXG4gICAgfVxuXG4gICAgY2FzZSAnREVMRUdBVElPTl9VUERBVEUnOiB7XG4gICAgICBjb25zdCBydWxlID0gbWVzc2FnZS5kYXRhIGFzIERlbGVnYXRpb25SdWxlO1xuICAgICAgaGFuZGxlRGVsZWdhdGlvblVwZGF0ZShydWxlKS50aGVuKCgpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogZmFsc2UgfSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIGNhc2UgJ1NFU1NJT05fUVVFUlknOiB7XG4gICAgICBnZXRTdG9yYWdlU3RhdGUoKS50aGVuKChzdG9yZWQpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc2Vzc2lvbnM6IHN0b3JlZC5zZXNzaW9ucyB9KTtcbiAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc2Vzc2lvbnM6IFtdIH0pO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBjYXNlICdTVEFUVVNfUVVFUlknOiB7XG4gICAgICBjb25zdCBhZ2VudHMgPSBBcnJheS5mcm9tKHN0YXRlLmFjdGl2ZUFnZW50cy52YWx1ZXMoKSk7XG4gICAgICBjb25zdCBhY3RpdmVSdWxlID0gc3RhdGUuZGVsZWdhdGlvblJ1bGVzLmZpbmQoKHIpID0+IHIuaXNBY3RpdmUpID8/IG51bGw7XG4gICAgICBzZW5kUmVzcG9uc2Uoe1xuICAgICAgICBkZXRlY3RlZEFnZW50czogYWdlbnRzLFxuICAgICAgICBhY3RpdmVEZWxlZ2F0aW9uOiBhY3RpdmVSdWxlLFxuICAgICAgICBraWxsU3dpdGNoQWN0aXZlOiBzdGF0ZS5raWxsU3dpdGNoLmlzQWN0aXZlLFxuICAgICAgICByZWNlbnRWaW9sYXRpb25zOiBzdGF0ZS5yZWNlbnRBbGVydHMsXG4gICAgICAgIGRlbGVnYXRpb25SdWxlczogc3RhdGUuZGVsZWdhdGlvblJ1bGVzLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY2FzZSAnU0VUVElOR1NfVVBEQVRFJzoge1xuICAgICAgY29uc3QgdXBkYXRlcyA9IG1lc3NhZ2UuZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIHVwZGF0ZVNldHRpbmdzKHVwZGF0ZXMpLnRoZW4oKCkgPT4ge1xuICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiBmYWxzZSB9KTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVEZXRlY3Rpb24odGFiSWQ6IG51bWJlciwgZXZlbnQ6IERldGVjdGlvbkV2ZW50KTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICghZXZlbnQuYWdlbnQpIHJldHVybjtcblxuICBzdGF0ZS5hY3RpdmVBZ2VudHMuc2V0KHRhYklkLCBldmVudC5hZ2VudCk7XG5cbiAgLy8gQ3JlYXRlIGEgbmV3IHNlc3Npb25cbiAgY29uc3Qgc2Vzc2lvbjogQWdlbnRTZXNzaW9uID0ge1xuICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgIGFnZW50OiBldmVudC5hZ2VudCxcbiAgICBkZWxlZ2F0aW9uUnVsZTogc3RhdGUuZGVsZWdhdGlvblJ1bGVzLmZpbmQoKHIpID0+IHIuaXNBY3RpdmUpID8/IG51bGwsXG4gICAgZXZlbnRzOiBbXSxcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBlbmRlZEF0OiBudWxsLFxuICAgIGVuZFJlYXNvbjogbnVsbCxcbiAgICBzdW1tYXJ5OiB7XG4gICAgICB0b3RhbEFjdGlvbnM6IDAsXG4gICAgICBhbGxvd2VkQWN0aW9uczogMCxcbiAgICAgIGJsb2NrZWRBY3Rpb25zOiAwLFxuICAgICAgdmlvbGF0aW9uczogMCxcbiAgICAgIHRvcFVybHM6IFtdLFxuICAgICAgZHVyYXRpb25TZWNvbmRzOiBudWxsLFxuICAgIH0sXG4gIH07XG5cbiAgLy8gQWRkIGRldGVjdGlvbiBldmVudCB0byB0aW1lbGluZVxuICBjb25zdCB0aW1lbGluZUV2ZW50ID0gY3JlYXRlVGltZWxpbmVFdmVudCgnZGV0ZWN0aW9uJywgZXZlbnQudXJsLCBgQWdlbnQgZGV0ZWN0ZWQ6ICR7ZXZlbnQuYWdlbnQudHlwZX1gLCB7XG4gICAgb3V0Y29tZTogJ2luZm9ybWF0aW9uYWwnLFxuICB9KTtcbiAgY29uc3QgdXBkYXRlZFNlc3Npb24gPSBhcHBlbmRFdmVudFRvU2Vzc2lvbihzZXNzaW9uLCB0aW1lbGluZUV2ZW50KTtcblxuICBhd2FpdCBzYXZlU2Vzc2lvbih1cGRhdGVkU2Vzc2lvbik7XG4gIHN0YXRlLmFjdGl2ZVNlc3Npb25zLnNldCh0YWJJZCwgdXBkYXRlZFNlc3Npb24uaWQpO1xuXG4gIC8vIExvZyBkZXRlY3Rpb25cbiAgYXdhaXQgYXBwZW5kRGV0ZWN0aW9uTG9nKGV2ZW50KTtcblxuICB1cGRhdGVCYWRnZSgpO1xufVxuXG5mdW5jdGlvbiBoYW5kbGVBZ2VudEFjdGlvbih0YWJJZDogbnVtYmVyLCBldmVudDogQWdlbnRFdmVudCk6IHZvaWQge1xuICBjb25zdCBzZXNzaW9uSWQgPSBzdGF0ZS5hY3RpdmVTZXNzaW9ucy5nZXQodGFiSWQpO1xuICBpZiAoIXNlc3Npb25JZCkgcmV0dXJuO1xuXG4gIHVwZGF0ZVNlc3Npb24oc2Vzc2lvbklkLCAoc2Vzc2lvbikgPT4gYXBwZW5kRXZlbnRUb1Nlc3Npb24oc2Vzc2lvbiwgZXZlbnQpKS5jYXRjaCgoKSA9PiB7XG4gICAgLy8gSWdub3JlIHN0b3JhZ2UgZXJyb3JzIGZvciBpbmRpdmlkdWFsIGV2ZW50c1xuICB9KTtcbn1cblxuZnVuY3Rpb24gaGFuZGxlQm91bmRhcnlWaW9sYXRpb24odGFiSWQ6IG51bWJlciB8IHVuZGVmaW5lZCwgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvbik6IHZvaWQge1xuICBjb25zdCBhY3RpdmVSdWxlID0gc3RhdGUuZGVsZWdhdGlvblJ1bGVzLmZpbmQoKHIpID0+IHIuaXNBY3RpdmUpO1xuICBpZiAoIWFjdGl2ZVJ1bGUpIHJldHVybjtcblxuICBjb25zdCBhbGVydCA9IGNyZWF0ZUJvdW5kYXJ5QWxlcnQodmlvbGF0aW9uLCBhY3RpdmVSdWxlKTtcbiAgc3RhdGUucmVjZW50QWxlcnRzLnB1c2goYWxlcnQpO1xuICBpZiAoc3RhdGUucmVjZW50QWxlcnRzLmxlbmd0aCA+IDIwKSB7XG4gICAgc3RhdGUucmVjZW50QWxlcnRzLnNoaWZ0KCk7XG4gIH1cblxuICAvLyBMb2cgdGhlIHZpb2xhdGlvbiBhcyBhIHRpbWVsaW5lIGV2ZW50IGlmIHdlIGhhdmUgYSBzZXNzaW9uXG4gIGlmICh0YWJJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY29uc3Qgc2Vzc2lvbklkID0gc3RhdGUuYWN0aXZlU2Vzc2lvbnMuZ2V0KHRhYklkKTtcbiAgICBpZiAoc2Vzc2lvbklkKSB7XG4gICAgICBjb25zdCBldmVudCA9IGNyZWF0ZVRpbWVsaW5lRXZlbnQoJ2JvdW5kYXJ5LXZpb2xhdGlvbicsIHZpb2xhdGlvbi51cmwsXG4gICAgICAgIGBWaW9sYXRpb246ICR7dmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbn0gYmxvY2tlZGAsIHtcbiAgICAgICAgICBhdHRlbXB0ZWRBY3Rpb246IHZpb2xhdGlvbi5hdHRlbXB0ZWRBY3Rpb24sXG4gICAgICAgICAgb3V0Y29tZTogJ2Jsb2NrZWQnLFxuICAgICAgICAgIHJ1bGVJZDogdmlvbGF0aW9uLmJsb2NraW5nUnVsZUlkLFxuICAgICAgICAgIHRhcmdldFNlbGVjdG9yOiB2aW9sYXRpb24udGFyZ2V0U2VsZWN0b3IsXG4gICAgICAgIH0pO1xuICAgICAgdXBkYXRlU2Vzc2lvbihzZXNzaW9uSWQsIChzZXNzaW9uKSA9PiBhcHBlbmRFdmVudFRvU2Vzc2lvbihzZXNzaW9uLCBldmVudCkpLmNhdGNoKCgpID0+IHsgLyogaWdub3JlICovIH0pO1xuICAgIH1cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVEZWxlZ2F0aW9uVXBkYXRlKHJ1bGU6IERlbGVnYXRpb25SdWxlKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIERlYWN0aXZhdGUgYWxsIGV4aXN0aW5nIHJ1bGVzXG4gIGZvciAoY29uc3QgciBvZiBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpIHtcbiAgICByLmlzQWN0aXZlID0gZmFsc2U7XG4gIH1cblxuICAvLyBBZGQgb3IgdXBkYXRlIHRoZSBuZXcgcnVsZVxuICBjb25zdCBleGlzdGluZ0luZGV4ID0gc3RhdGUuZGVsZWdhdGlvblJ1bGVzLmZpbmRJbmRleCgocikgPT4gci5pZCA9PT0gcnVsZS5pZCk7XG4gIGlmIChleGlzdGluZ0luZGV4ID49IDApIHtcbiAgICBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXNbZXhpc3RpbmdJbmRleF0gPSBydWxlO1xuICB9IGVsc2Uge1xuICAgIHN0YXRlLmRlbGVnYXRpb25SdWxlcy5wdXNoKHJ1bGUpO1xuICB9XG5cbiAgYXdhaXQgc2F2ZURlbGVnYXRpb25SdWxlcyhzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpO1xuXG4gIC8vIEJyb2FkY2FzdCB0byBhbGwgY29udGVudCBzY3JpcHRzXG4gIGNvbnN0IHRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7fSk7XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodGFiLmlkID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgdHlwZTogJ0RFTEVHQVRJT05fVVBEQVRFJyxcbiAgICAgICAgZGF0YTogcnVsZSxcbiAgICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIFRhYiBtYXkgbm90IGhhdmUgY29udGVudCBzY3JpcHRcbiAgICB9XG4gIH1cblxuICB1cGRhdGVCYWRnZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBleGVjdXRlS2lsbFN3aXRjaChcbiAgdHJpZ2dlcjogJ2J1dHRvbicgfCAna2V5Ym9hcmQtc2hvcnRjdXQnIHwgJ2FwaSdcbik6IFByb21pc2U8S2lsbFN3aXRjaEV2ZW50PiB7XG4gIGNvbnN0IGFnZW50SWRzID0gQXJyYXkuZnJvbShzdGF0ZS5hY3RpdmVBZ2VudHMudmFsdWVzKCkpLm1hcCgoYSkgPT4gYS5pZCk7XG5cbiAgY29uc3QgZXZlbnQgPSBhd2FpdCBleGVjdXRlQmFja2dyb3VuZEtpbGxTd2l0Y2godHJpZ2dlciwgYWdlbnRJZHMsIFtdKTtcblxuICBzdGF0ZS5raWxsU3dpdGNoLmlzQWN0aXZlID0gdHJ1ZTtcbiAgc3RhdGUua2lsbFN3aXRjaC5sYXN0RXZlbnQgPSBldmVudDtcbiAgc3RhdGUua2lsbFN3aXRjaC5sYXN0QWN0aXZhdGVkQXQgPSBldmVudC50aW1lc3RhbXA7XG5cbiAgLy8gQ2xlYXIgYWN0aXZlIGFnZW50c1xuICBzdGF0ZS5hY3RpdmVBZ2VudHMuY2xlYXIoKTtcblxuICAvLyBEZWFjdGl2YXRlIGFsbCBkZWxlZ2F0aW9uIHJ1bGVzXG4gIGZvciAoY29uc3QgcnVsZSBvZiBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpIHtcbiAgICBydWxlLmlzQWN0aXZlID0gZmFsc2U7XG4gIH1cbiAgYXdhaXQgc2F2ZURlbGVnYXRpb25SdWxlcyhzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpO1xuXG4gIC8vIEVuZCBhbGwgYWN0aXZlIHNlc3Npb25zXG4gIGZvciAoY29uc3QgW3RhYklkLCBzZXNzaW9uSWRdIG9mIHN0YXRlLmFjdGl2ZVNlc3Npb25zLmVudHJpZXMoKSkge1xuICAgIGF3YWl0IHVwZGF0ZVNlc3Npb24oc2Vzc2lvbklkLCAoc2Vzc2lvbikgPT4gKHtcbiAgICAgIC4uLnNlc3Npb24sXG4gICAgICBlbmRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlbmRSZWFzb246ICdraWxsLXN3aXRjaCcgYXMgY29uc3QsXG4gICAgfSkpO1xuICAgIHN0YXRlLmFjdGl2ZVNlc3Npb25zLmRlbGV0ZSh0YWJJZCk7XG4gIH1cblxuICBhd2FpdCBjbGVhckFsbE5vdGlmaWNhdGlvbnMoKTtcbiAgdXBkYXRlQmFkZ2UoKTtcblxuICByZXR1cm4gZXZlbnQ7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUJhZGdlKCk6IHZvaWQge1xuICB0cnkge1xuICAgIGlmIChzdGF0ZS5raWxsU3dpdGNoLmlzQWN0aXZlKSB7XG4gICAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6ICdYJyB9KTtcbiAgICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3IoeyBjb2xvcjogJyNlZjQ0NDQnIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGFnZW50Q291bnQgPSBzdGF0ZS5hY3RpdmVBZ2VudHMuc2l6ZTtcbiAgICBpZiAoYWdlbnRDb3VudCA+IDApIHtcbiAgICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogU3RyaW5nKGFnZW50Q291bnQpIH0pO1xuICAgICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZUJhY2tncm91bmRDb2xvcih7IGNvbG9yOiAnI2Y1OWUwYicgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgaGFzQWN0aXZlRGVsZWdhdGlvbiA9IHN0YXRlLmRlbGVnYXRpb25SdWxlcy5zb21lKChyKSA9PiByLmlzQWN0aXZlKTtcbiAgICBpZiAoaGFzQWN0aXZlRGVsZWdhdGlvbikge1xuICAgICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiAnJyB9KTtcbiAgICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3IoeyBjb2xvcjogJyMyMmM1NWUnIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogJycgfSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIEJhZGdlIEFQSSBtYXkgbm90IGJlIGF2YWlsYWJsZSBpbiBhbGwgY29udGV4dHNcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVUYWJSZW1vdmVkKHRhYklkOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2Vzc2lvbklkID0gc3RhdGUuYWN0aXZlU2Vzc2lvbnMuZ2V0KHRhYklkKTtcbiAgaWYgKHNlc3Npb25JZCkge1xuICAgIGF3YWl0IHVwZGF0ZVNlc3Npb24oc2Vzc2lvbklkLCAoc2Vzc2lvbikgPT4gKHtcbiAgICAgIC4uLnNlc3Npb24sXG4gICAgICBlbmRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlbmRSZWFzb246ICdwYWdlLXVubG9hZCcgYXMgY29uc3QsXG4gICAgfSkpO1xuICAgIHN0YXRlLmFjdGl2ZVNlc3Npb25zLmRlbGV0ZSh0YWJJZCk7XG4gIH1cbiAgc3RhdGUuYWN0aXZlQWdlbnRzLmRlbGV0ZSh0YWJJZCk7XG4gIHVwZGF0ZUJhZGdlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrRGVsZWdhdGlvbkV4cGlyYXRpb24oKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBjaGFuZ2VkID0gZmFsc2U7XG4gIGZvciAoY29uc3QgcnVsZSBvZiBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpIHtcbiAgICBpZiAocnVsZS5pc0FjdGl2ZSAmJiBpc1RpbWVCb3VuZEV4cGlyZWQocnVsZS5zY29wZS50aW1lQm91bmQpKSB7XG4gICAgICBydWxlLmlzQWN0aXZlID0gZmFsc2U7XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcblxuICAgICAgLy8gTm90aWZ5IGNvbnRlbnQgc2NyaXB0c1xuICAgICAgY29uc3QgdGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHt9KTtcbiAgICAgIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICAgICAgaWYgKHRhYi5pZCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICAgIHR5cGU6ICdERUxFR0FUSU9OX1VQREFURScsXG4gICAgICAgICAgICBkYXRhOiBudWxsLFxuICAgICAgICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIFRhYiBtYXkgbm90IGhhdmUgY29udGVudCBzY3JpcHRcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGlmIChjaGFuZ2VkKSB7XG4gICAgYXdhaXQgc2F2ZURlbGVnYXRpb25SdWxlcyhzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpO1xuICAgIHVwZGF0ZUJhZGdlKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVnaXN0ZXJLZXlib2FyZFNob3J0Y3V0KCk6IHZvaWQge1xuICB0cnkge1xuICAgIGNocm9tZS5jb21tYW5kcy5vbkNvbW1hbmQuYWRkTGlzdGVuZXIoKGNvbW1hbmQpID0+IHtcbiAgICAgIGlmIChjb21tYW5kID09PSAna2lsbC1zd2l0Y2gnKSB7XG4gICAgICAgIGV4ZWN1dGVLaWxsU3dpdGNoKCdrZXlib2FyZC1zaG9ydGN1dCcpLmNhdGNoKCgpID0+IHsgLyogaWdub3JlICovIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9IGNhdGNoIHtcbiAgICAvLyBDb21tYW5kcyBBUEkgbWF5IG5vdCBiZSBhdmFpbGFibGVcbiAgfVxufVxuXG5pbml0aWFsaXplKCk7XG4iXSwibmFtZXMiOlsic3RhdGUiXSwibWFwcGluZ3MiOiJBQTZHTyxNQUFNLG1CQUFpQztBQUFBLEVBQzVDLGtCQUFrQjtBQUFBLEVBQ2xCLHNCQUFzQjtBQUFBLEVBQ3RCLG9CQUFvQjtBQUFBLEVBQ3BCLGFBQWE7QUFBQSxFQUNiLHdCQUF3QjtBQUFBLEVBQ3hCLHdCQUF3QjtBQUMxQjtBQ3hHQSxNQUFNLGtCQUFpQztBQUFBLEVBQ3JDLFVBQVUsQ0FBQTtBQUFBLEVBQ1YsaUJBQWlCLENBQUE7QUFBQSxFQUNqQixVQUFVO0FBQUEsRUFDVixjQUFjLENBQUE7QUFDaEI7QUFNQSxlQUFzQixrQkFBMEM7QUFDOUQsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDeEMsT0FBTyxLQUFLLGVBQWU7QUFBQSxJQUFBO0FBRTdCLFdBQU87QUFBQSxNQUNMLFVBQVUsT0FBTyxZQUFZLGdCQUFnQjtBQUFBLE1BQzdDLGlCQUFpQixPQUFPLG1CQUFtQixnQkFBZ0I7QUFBQSxNQUMzRCxVQUFVLEVBQUUsR0FBRyxrQkFBa0IsR0FBSSxPQUFPLFlBQVksQ0FBQSxFQUFDO0FBQUEsTUFDekQsY0FBYyxPQUFPLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUFBO0FBQUEsRUFFekQsU0FBUyxLQUFLO0FBQ1osWUFBUSxNQUFNLDBDQUEwQyxHQUFHO0FBQzNELFdBQU8sRUFBRSxHQUFHLGdCQUFBO0FBQUEsRUFDZDtBQUNGO0FBTUEsZUFBc0IsWUFBWSxTQUFzQztBQUN0RSxNQUFJO0FBQ0YsVUFBTUEsU0FBUSxNQUFNLGdCQUFBO0FBQ3BCLFVBQU0sV0FBVyxDQUFDLFNBQVMsR0FBR0EsT0FBTSxRQUFRO0FBQzVDLFVBQU0sY0FBY0EsT0FBTSxTQUFTLGVBQWU7QUFDbEQsUUFBSSxTQUFTLFNBQVMsYUFBYTtBQUNqQyxlQUFTLFNBQVM7QUFBQSxJQUNwQjtBQUNBLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLFVBQVU7QUFBQSxFQUM3QyxTQUFTLEtBQUs7QUFDWixZQUFRLE1BQU0sOENBQThDLEdBQUc7QUFBQSxFQUNqRTtBQUNGO0FBS0EsZUFBc0IsY0FDcEIsV0FDQSxTQUNlO0FBQ2YsTUFBSTtBQUNGLFVBQU1BLFNBQVEsTUFBTSxnQkFBQTtBQUNwQixVQUFNLFFBQVFBLE9BQU0sU0FBUyxVQUFVLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUztBQUNoRSxRQUFJLFVBQVUsSUFBSTtBQUNoQixjQUFRLEtBQUsseUNBQXlDLFNBQVM7QUFDL0Q7QUFBQSxJQUNGO0FBQ0EsSUFBQUEsT0FBTSxTQUFTLEtBQUssSUFBSSxRQUFRQSxPQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3JELFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLFVBQVVBLE9BQU0sVUFBVTtBQUFBLEVBQzdELFNBQVMsS0FBSztBQUNaLFlBQVEsTUFBTSxnREFBZ0QsR0FBRztBQUFBLEVBQ25FO0FBQ0Y7QUFhQSxlQUFzQixvQkFBb0IsT0FBd0M7QUFDaEYsTUFBSTtBQUNGLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLGlCQUFpQixPQUFPO0FBQUEsRUFDM0QsU0FBUyxLQUFLO0FBQ1osWUFBUSxNQUFNLHVEQUF1RCxHQUFHO0FBQUEsRUFDMUU7QUFDRjtBQWNBLGVBQXNCLG1CQUFtQixPQUFzQztBQUM3RSxNQUFJO0FBQ0YsVUFBTUEsU0FBUSxNQUFNLGdCQUFBO0FBQ3BCLFVBQU0sTUFBTSxDQUFDLEdBQUdBLE9BQU0sY0FBYyxLQUFLO0FBQ3pDLFVBQU0sYUFBYUEsT0FBTSxTQUFTLDBCQUEwQjtBQUM1RCxRQUFJLElBQUksU0FBUyxZQUFZO0FBQzNCLFVBQUksT0FBTyxHQUFHLElBQUksU0FBUyxVQUFVO0FBQUEsSUFDdkM7QUFDQSxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxjQUFjLEtBQUs7QUFBQSxFQUN0RCxTQUFTLEtBQUs7QUFDWixZQUFRLE1BQU0sc0RBQXNELEdBQUc7QUFBQSxFQUN6RTtBQUNGO0FBS0EsZUFBc0IsY0FBcUM7QUFDekQsUUFBTUEsU0FBUSxNQUFNLGdCQUFBO0FBQ3BCLFNBQU9BLE9BQU07QUFDZjtBQUtBLGVBQXNCLGVBQWUsU0FBK0M7QUFDbEYsTUFBSTtBQUNGLFVBQU0sVUFBVSxNQUFNLFlBQUE7QUFDdEIsVUFBTSxTQUFTLEVBQUUsR0FBRyxTQUFTLEdBQUcsUUFBQTtBQUNoQyxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxVQUFVLFFBQVE7QUFBQSxFQUNyRCxTQUFTLEtBQUs7QUFDWixZQUFRLE1BQU0saURBQWlELEdBQUc7QUFBQSxFQUNwRTtBQUNGO0FDcElBLFNBQVMsYUFBcUI7QUFDNUIsU0FBTyxPQUFPLFdBQUE7QUFDaEI7QUFLTyxTQUFTLG9CQUNkLE1BQ0EsS0FDQSxhQUNBLFNBTVk7QUFDWixTQUFPO0FBQUEsSUFDTCxJQUFJLFdBQUE7QUFBQSxJQUNKO0FBQUEsSUFDQSxZQUFXLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsSUFDdEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxTQUFTLFNBQVMsV0FBVztBQUFBLElBQzdCLGdCQUFnQixTQUFTO0FBQUEsSUFDekIsaUJBQWlCLFNBQVM7QUFBQSxJQUMxQixRQUFRLFNBQVM7QUFBQSxFQUFBO0FBRXJCO0FBS08sU0FBUyxxQkFDZCxTQUNBLE9BQ2M7QUFDZCxRQUFNLFNBQVMsQ0FBQyxHQUFHLFFBQVEsUUFBUSxLQUFLO0FBQ3hDLFFBQU0sVUFBVSxzQkFBc0IsUUFBUSxRQUFRLFNBQVM7QUFDL0QsU0FBTyxFQUFFLEdBQUcsU0FBUyxRQUFRLFFBQUE7QUFDL0I7QUFLTyxTQUFTLHNCQUNkLFFBQ0EsV0FDZ0I7QUFDaEIsTUFBSSxlQUFlO0FBQ25CLE1BQUksaUJBQWlCO0FBQ3JCLE1BQUksaUJBQWlCO0FBQ3JCLE1BQUksYUFBYTtBQUNqQixRQUFNLGdDQUFnQixJQUFBO0FBRXRCLGFBQVcsU0FBUyxRQUFRO0FBQzFCLFFBQUksTUFBTSxZQUFZLFdBQVc7QUFDL0I7QUFDQTtBQUFBLElBQ0YsV0FBVyxNQUFNLFlBQVksV0FBVztBQUN0QztBQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBTSxTQUFTLHNCQUFzQjtBQUN2QztBQUFBLElBQ0Y7QUFDQSxRQUFJLE1BQU0sS0FBSztBQUNiLGdCQUFVLElBQUksTUFBTSxNQUFNLFVBQVUsSUFBSSxNQUFNLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFBQSxJQUM5RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFVBQVUsQ0FBQyxHQUFHLFVBQVUsUUFBQSxDQUFTLEVBQ3BDLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFDMUIsTUFBTSxHQUFHLENBQUMsRUFDVixJQUFJLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRztBQUVyQixNQUFJLGtCQUFpQztBQUNyQyxNQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ3JCLFVBQU0sWUFBWSxPQUFPLE9BQU8sU0FBUyxDQUFDO0FBQzFDLFVBQU0sUUFBUSxJQUFJLEtBQUssU0FBUyxFQUFFLFFBQUE7QUFDbEMsVUFBTSxNQUFNLElBQUksS0FBSyxVQUFVLFNBQVMsRUFBRSxRQUFBO0FBQzFDLHNCQUFrQixLQUFLLE9BQU8sTUFBTSxTQUFTLEdBQUk7QUFBQSxFQUNuRDtBQUVBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFBO0FBRUo7QUNrR08sU0FBUyxtQkFBbUIsV0FBc0M7QUFDdkUsTUFBSSxjQUFjLEtBQU0sUUFBTztBQUMvQixVQUFPLG9CQUFJLEtBQUEsR0FBTyxRQUFBLElBQVksSUFBSSxLQUFLLFVBQVUsU0FBUyxFQUFFLFFBQUE7QUFDOUQ7QUF5Qk8sU0FBUyxZQUFZLE9BQXlDO0FBQ25FLFNBQU8sRUFBRSxHQUFHLE9BQU8sU0FBUyxLQUFBO0FBQzlCO0FDM0tBLGVBQXNCLDRCQUNwQixTQUNBLGdCQUNBLGNBQzBCO0FBQzFCLFFBQU0sa0JBQTRCLENBQUE7QUFHbEMsYUFBVyxTQUFTLGNBQWM7QUFDaEMsZ0JBQVksS0FBSztBQUNqQixvQkFBZ0IsS0FBSyxNQUFNLE9BQU87QUFBQSxFQUNwQztBQUdBLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUkseUJBQXlCO0FBQzdCLE1BQUk7QUFDRixVQUFNLE9BQU8sTUFBTSxPQUFPLEtBQUssTUFBTSxDQUFBLENBQUU7QUFDdkMsZUFBVyxPQUFPLE1BQU07QUFDdEIsVUFBSSxJQUFJLE9BQU8sT0FBVztBQUMxQixVQUFJO0FBQ0YsY0FBTSxPQUFPLEtBQUssWUFBWSxJQUFJLElBQUk7QUFBQSxVQUNwQyxNQUFNO0FBQUEsVUFDTixNQUFNLENBQUE7QUFBQSxVQUNOLFNBQVEsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxRQUFZLENBQ2hDO0FBQUEsTUFDSCxRQUFRO0FBQUEsTUFFUjtBQUFBLElBQ0Y7QUFDQSxvQkFBZ0I7QUFDaEIsNkJBQXlCO0FBQUEsRUFDM0IsUUFBUTtBQUFBLEVBRVI7QUFFQSxRQUFNLFFBQXlCO0FBQUEsSUFDN0IsSUFBSSxPQUFPLFdBQUE7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxJQUN0QjtBQUFBLElBQ0Esb0JBQW9CLENBQUMsR0FBRyxjQUFjO0FBQUEsSUFDdEM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQUE7QUFJRiw2QkFBMkIsZUFBZSxNQUFNO0FBRWhELFNBQU87QUFDVDtBQThFTyxTQUFTLDJCQUEyQixZQUEwQjtBQUNuRSxNQUFJO0FBQ0YsV0FBTyxjQUFjLE9BQU8sa0JBQWtCLEtBQUssSUFBQSxDQUFLLElBQUk7QUFBQSxNQUMxRCxNQUFNO0FBQUEsTUFDTixTQUFTLE9BQU8sUUFBUSxPQUFPLG1CQUFtQjtBQUFBLE1BQ2xELE9BQU87QUFBQSxNQUNQLFNBQVMsY0FBYyxVQUFVO0FBQUEsTUFDakMsVUFBVTtBQUFBLElBQUEsQ0FDWDtBQUdELGVBQVcsTUFBTTtBQUNmLFVBQUk7QUFDRixlQUFPLGNBQWMsT0FBTyxDQUFDLGtCQUFrQjtBQUM3QyxxQkFBVyxNQUFNLE9BQU8sS0FBSyxhQUFhLEdBQUc7QUFDM0MsZ0JBQUksR0FBRyxXQUFXLGlCQUFpQixHQUFHO0FBQ3BDLHFCQUFPLGNBQWMsTUFBTSxFQUFFO0FBQUEsWUFDL0I7QUFBQSxVQUNGO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxRQUFRO0FBQUEsTUFFUjtBQUFBLElBQ0YsR0FBRyxHQUFJO0FBQUEsRUFDVCxRQUFRO0FBQUEsRUFFUjtBQUNGO0FBS08sU0FBUywrQkFBZ0Q7QUFDOUQsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsV0FBVztBQUFBLElBQ1gsaUJBQWlCO0FBQUEsRUFBQTtBQUVyQjtBQy9ITyxTQUFTLDBCQUNkLGFBQ1k7QUFDWixRQUFNLFVBQVUsQ0FBQyxnQkFBd0IsZ0JBQXdCO0FBQy9ELFFBQUksZ0JBQWdCLEdBQUc7QUFFckIsa0JBQVksY0FBYztBQUFBLElBQzVCO0FBRUEsUUFBSTtBQUNGLGFBQU8sY0FBYyxNQUFNLGNBQWM7QUFBQSxJQUMzQyxRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFFQSxTQUFPLGNBQWMsZ0JBQWdCLFlBQVksT0FBTztBQUV4RCxTQUFPLE1BQU07QUFDWCxXQUFPLGNBQWMsZ0JBQWdCLGVBQWUsT0FBTztBQUFBLEVBQzdEO0FBQ0Y7QUFLQSxlQUFzQix3QkFBdUM7QUFDM0QsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFZO0FBQ3BDLFFBQUk7QUFDRixhQUFPLGNBQWMsT0FBTyxDQUFDLGtCQUFrQjtBQUM3QyxtQkFBVyxNQUFNLE9BQU8sS0FBSyxhQUFhLEdBQUc7QUFDM0MsaUJBQU8sY0FBYyxNQUFNLEVBQUU7QUFBQSxRQUMvQjtBQUNBLGdCQUFBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxRQUFRO0FBQ04sY0FBQTtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDSDtBQ3JIQSxNQUFNLHlCQUF5QjtBQUFBLEVBQzdCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0Y7QUFLTyxTQUFTLG9CQUNkLFdBQ0EsTUFDZTtBQUNmLFFBQU0sV0FBVywwQkFBMEIsVUFBVSxpQkFBaUIsVUFBVSxHQUFHO0FBQ25GLFFBQU0sUUFBUSxtQkFBbUIsVUFBVSxlQUFlO0FBQzFELFFBQU0sVUFBVSxxQkFBcUIsV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBRXpFLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxzQkFBc0IsYUFBYSxZQUFZLGFBQWE7QUFBQSxJQUM1RCxjQUFjO0FBQUEsRUFBQTtBQUVsQjtBQUtPLFNBQVMsMEJBQ2QsWUFDQSxLQUNlO0FBQ2YsUUFBTSxrQkFBMEQ7QUFBQSxJQUM5RCxlQUFlO0FBQUEsSUFDZixrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxJQUNqQixjQUFjO0FBQUEsSUFDZCxPQUFPO0FBQUEsSUFDUCxhQUFhO0FBQUEsSUFDYixVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWixhQUFhO0FBQUEsSUFDYixZQUFZO0FBQUEsSUFDWixZQUFZO0FBQUEsRUFBQTtBQUdkLE1BQUksV0FBVyxnQkFBZ0IsVUFBVSxLQUFLO0FBRzlDLFFBQU0sY0FBYyx1QkFBdUIsS0FBSyxDQUFDLFlBQVksUUFBUSxLQUFLLEdBQUcsQ0FBQztBQUM5RSxNQUFJLGFBQWE7QUFDZixVQUFNLFVBQWdEO0FBQUEsTUFDcEQsS0FBSztBQUFBLE1BQ0wsUUFBUTtBQUFBLE1BQ1IsTUFBTTtBQUFBLE1BQ04sVUFBVTtBQUFBLElBQUE7QUFFWixlQUFXLFFBQVEsUUFBUTtBQUFBLEVBQzdCO0FBRUEsU0FBTztBQUNUO0FBS08sU0FBUyxtQkFBbUIsWUFBcUM7QUFDdEUsUUFBTSxTQUEwQztBQUFBLElBQzlDLFVBQVU7QUFBQSxJQUNWLFlBQVk7QUFBQSxJQUNaLE9BQU87QUFBQSxJQUNQLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGlCQUFpQjtBQUFBLElBQ2pCLFlBQVk7QUFBQSxJQUNaLGFBQWE7QUFBQSxJQUNiLFlBQVk7QUFBQSxJQUNaLGtCQUFrQjtBQUFBLElBQ2xCLGNBQWM7QUFBQSxFQUFBO0FBRWhCLFNBQU8sT0FBTyxVQUFVLEtBQUs7QUFDL0I7QUFLTyxTQUFTLHFCQUNkLFdBQ0EsVUFDUTtBQUNSLFFBQU0sUUFBUTtBQUFBLElBQ1osa0NBQWtDLFVBQVUsZUFBZTtBQUFBLElBQzNELFVBQVU7QUFBQSxJQUNWO0FBQUEsSUFDQSxvQkFBb0IsUUFBUTtBQUFBLElBQzVCLFdBQVcsVUFBVSxNQUFNO0FBQUEsRUFBQTtBQUc3QixNQUFJLFVBQVUsZ0JBQWdCO0FBQzVCLFVBQU0sS0FBSyxtQkFBbUIsVUFBVSxjQUFjLEVBQUU7QUFBQSxFQUMxRDtBQUVBLFNBQU8sTUFBTSxLQUFLLElBQUk7QUFDeEI7QUN4R0EsTUFBTSxRQUF5QjtBQUFBLEVBQzdCLGtDQUFrQixJQUFBO0FBQUEsRUFDbEIsb0NBQW9CLElBQUE7QUFBQSxFQUNwQixpQkFBaUIsQ0FBQTtBQUFBLEVBQ2pCLFlBQVksNkJBQUE7QUFBQSxFQUNaLGNBQWMsQ0FBQTtBQUNoQjtBQUVBLFNBQVMsYUFBbUI7QUFDMUIscUJBQUEsRUFBcUIsS0FBSyxNQUFNO0FBQzlCLGdCQUFBO0FBQUEsRUFDRixDQUFDLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEIsWUFBUSxNQUFNLDRDQUE0QyxHQUFHO0FBQUEsRUFDL0QsQ0FBQztBQUdELFNBQU8sUUFBUSxVQUFVLFlBQVksYUFBYTtBQUdsRCxTQUFPLEtBQUssVUFBVSxZQUFZLENBQUMsVUFBVTtBQUMzQyxxQkFBaUIsS0FBSyxFQUFFLE1BQU0sTUFBTTtBQUFBLElBQWUsQ0FBQztBQUFBLEVBQ3RELENBQUM7QUFHRCxTQUFPLE9BQU8sT0FBTyxvQkFBb0IsRUFBRSxpQkFBaUIsR0FBRztBQUMvRCxTQUFPLE9BQU8sUUFBUSxZQUFZLENBQUMsVUFBVTtBQUMzQyxRQUFJLE1BQU0sU0FBUyxvQkFBb0I7QUFDckMsZ0NBQUEsRUFBNEIsTUFBTSxNQUFNO0FBQUEsTUFBZSxDQUFDO0FBQUEsSUFDMUQ7QUFBQSxFQUNGLENBQUM7QUFHRCwyQkFBQTtBQUdBLDRCQUEwQixDQUFDLG1CQUFtQjtBQUU1QyxZQUFRLElBQUksMkRBQTJELGNBQWM7QUFBQSxFQUN2RixDQUFDO0FBRUQsVUFBUSxJQUFJLDBEQUEwRDtBQUN4RTtBQUVBLGVBQWUscUJBQW9DO0FBQ2pELFFBQU0sU0FBUyxNQUFNLGdCQUFBO0FBQ3JCLFFBQU0sa0JBQWtCLE9BQU87QUFHL0IsYUFBVyxXQUFXLE9BQU8sVUFBVTtBQUNyQyxRQUFJLENBQUMsUUFBUSxTQUFTO0FBRXBCLFlBQU0sY0FBYyxRQUFRLElBQUksQ0FBQyxPQUFPO0FBQUEsUUFDdEMsR0FBRztBQUFBLFFBQ0gsVUFBUyxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLFFBQ3BCLFdBQVc7QUFBQSxNQUFBLEVBQ1g7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxjQUNQLFNBQ0EsUUFDQSxjQUNTO0FBQ1QsTUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQU0sUUFBTztBQUV0QyxRQUFNLFFBQVEsT0FBTyxLQUFLO0FBRTFCLFVBQVEsUUFBUSxNQUFBO0FBQUEsSUFDZCxLQUFLLG9CQUFvQjtBQUN2QixVQUFJLFVBQVUsUUFBVztBQUN2Qix3QkFBZ0IsT0FBTyxRQUFRLElBQXNCLEVBQUUsS0FBSyxNQUFNO0FBQ2hFLHVCQUFhLEVBQUUsU0FBUyxNQUFNO0FBQUEsUUFDaEMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHVCQUFhLEVBQUUsU0FBUyxPQUFPO0FBQUEsUUFDakMsQ0FBQztBQUNELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUVBLEtBQUssZ0JBQWdCO0FBQ25CLFVBQUksVUFBVSxRQUFXO0FBQ3ZCLDBCQUFrQixPQUFPLFFBQVEsSUFBa0I7QUFBQSxNQUNyRDtBQUNBLG1CQUFhLEVBQUUsU0FBUyxNQUFNO0FBQzlCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLDBCQUEwQjtBQUM3QixZQUFNLFlBQVksUUFBUTtBQUMxQiw4QkFBd0IsT0FBTyxTQUFTO0FBQ3hDLG1CQUFhLEVBQUUsU0FBUyxNQUFNO0FBQzlCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLHdCQUF3QjtBQUMzQjtBQUFBLFFBQ0csUUFBUSxNQUErQixXQUFxRDtBQUFBLE1BQUEsRUFDN0YsS0FBSyxDQUFDLFVBQVU7QUFDaEIscUJBQWEsRUFBRSxTQUFTLE1BQU0sTUFBQSxDQUFPO0FBQUEsTUFDdkMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHFCQUFhLEVBQUUsU0FBUyxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLHFCQUFxQjtBQUN4QixZQUFNLE9BQU8sUUFBUTtBQUNyQiw2QkFBdUIsSUFBSSxFQUFFLEtBQUssTUFBTTtBQUN0QyxxQkFBYSxFQUFFLFNBQVMsTUFBTTtBQUFBLE1BQ2hDLENBQUMsRUFBRSxNQUFNLE1BQU07QUFDYixxQkFBYSxFQUFFLFNBQVMsT0FBTztBQUFBLE1BQ2pDLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBRUEsS0FBSyxpQkFBaUI7QUFDcEIsc0JBQUEsRUFBa0IsS0FBSyxDQUFDLFdBQVc7QUFDakMscUJBQWEsRUFBRSxVQUFVLE9BQU8sU0FBQSxDQUFVO0FBQUEsTUFDNUMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHFCQUFhLEVBQUUsVUFBVSxDQUFBLEdBQUk7QUFBQSxNQUMvQixDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUVBLEtBQUssZ0JBQWdCO0FBQ25CLFlBQU0sU0FBUyxNQUFNLEtBQUssTUFBTSxhQUFhLFFBQVE7QUFDckQsWUFBTSxhQUFhLE1BQU0sZ0JBQWdCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxLQUFLO0FBQ3BFLG1CQUFhO0FBQUEsUUFDWCxnQkFBZ0I7QUFBQSxRQUNoQixrQkFBa0I7QUFBQSxRQUNsQixrQkFBa0IsTUFBTSxXQUFXO0FBQUEsUUFDbkMsa0JBQWtCLE1BQU07QUFBQSxRQUN4QixpQkFBaUIsTUFBTTtBQUFBLE1BQUEsQ0FDeEI7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBRUEsS0FBSyxtQkFBbUI7QUFDdEIsWUFBTSxVQUFVLFFBQVE7QUFDeEIscUJBQWUsT0FBTyxFQUFFLEtBQUssTUFBTTtBQUNqQyxxQkFBYSxFQUFFLFNBQVMsTUFBTTtBQUFBLE1BQ2hDLENBQUMsRUFBRSxNQUFNLE1BQU07QUFDYixxQkFBYSxFQUFFLFNBQVMsT0FBTztBQUFBLE1BQ2pDLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBRUE7QUFDRSxhQUFPO0FBQUEsRUFBQTtBQUViO0FBRUEsZUFBZSxnQkFBZ0IsT0FBZSxPQUFzQztBQUNsRixNQUFJLENBQUMsTUFBTSxNQUFPO0FBRWxCLFFBQU0sYUFBYSxJQUFJLE9BQU8sTUFBTSxLQUFLO0FBR3pDLFFBQU0sVUFBd0I7QUFBQSxJQUM1QixJQUFJLE9BQU8sV0FBQTtBQUFBLElBQ1gsT0FBTyxNQUFNO0FBQUEsSUFDYixnQkFBZ0IsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLEtBQUs7QUFBQSxJQUNqRSxRQUFRLENBQUE7QUFBQSxJQUNSLFlBQVcsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxJQUN0QixTQUFTO0FBQUEsSUFDVCxXQUFXO0FBQUEsSUFDWCxTQUFTO0FBQUEsTUFDUCxjQUFjO0FBQUEsTUFDZCxnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixTQUFTLENBQUE7QUFBQSxNQUNULGlCQUFpQjtBQUFBLElBQUE7QUFBQSxFQUNuQjtBQUlGLFFBQU0sZ0JBQWdCLG9CQUFvQixhQUFhLE1BQU0sS0FBSyxtQkFBbUIsTUFBTSxNQUFNLElBQUksSUFBSTtBQUFBLElBQ3ZHLFNBQVM7QUFBQSxFQUFBLENBQ1Y7QUFDRCxRQUFNLGlCQUFpQixxQkFBcUIsU0FBUyxhQUFhO0FBRWxFLFFBQU0sWUFBWSxjQUFjO0FBQ2hDLFFBQU0sZUFBZSxJQUFJLE9BQU8sZUFBZSxFQUFFO0FBR2pELFFBQU0sbUJBQW1CLEtBQUs7QUFFOUIsY0FBQTtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsT0FBZSxPQUF5QjtBQUNqRSxRQUFNLFlBQVksTUFBTSxlQUFlLElBQUksS0FBSztBQUNoRCxNQUFJLENBQUMsVUFBVztBQUVoQixnQkFBYyxXQUFXLENBQUMsWUFBWSxxQkFBcUIsU0FBUyxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUV4RixDQUFDO0FBQ0g7QUFFQSxTQUFTLHdCQUF3QixPQUEyQixXQUFvQztBQUM5RixRQUFNLGFBQWEsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRO0FBQy9ELE1BQUksQ0FBQyxXQUFZO0FBRWpCLFFBQU0sUUFBUSxvQkFBb0IsV0FBVyxVQUFVO0FBQ3ZELFFBQU0sYUFBYSxLQUFLLEtBQUs7QUFDN0IsTUFBSSxNQUFNLGFBQWEsU0FBUyxJQUFJO0FBQ2xDLFVBQU0sYUFBYSxNQUFBO0FBQUEsRUFDckI7QUFHQSxNQUFJLFVBQVUsUUFBVztBQUN2QixVQUFNLFlBQVksTUFBTSxlQUFlLElBQUksS0FBSztBQUNoRCxRQUFJLFdBQVc7QUFDYixZQUFNLFFBQVE7QUFBQSxRQUFvQjtBQUFBLFFBQXNCLFVBQVU7QUFBQSxRQUNoRSxjQUFjLFVBQVUsZUFBZTtBQUFBLFFBQVk7QUFBQSxVQUNqRCxpQkFBaUIsVUFBVTtBQUFBLFVBQzNCLFNBQVM7QUFBQSxVQUNULFFBQVEsVUFBVTtBQUFBLFVBQ2xCLGdCQUFnQixVQUFVO0FBQUEsUUFBQTtBQUFBLE1BQzVCO0FBQ0Ysb0JBQWMsV0FBVyxDQUFDLFlBQVkscUJBQXFCLFNBQVMsS0FBSyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsTUFBZSxDQUFDO0FBQUEsSUFDMUc7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLHVCQUF1QixNQUFxQztBQUV6RSxhQUFXLEtBQUssTUFBTSxpQkFBaUI7QUFDckMsTUFBRSxXQUFXO0FBQUEsRUFDZjtBQUdBLFFBQU0sZ0JBQWdCLE1BQU0sZ0JBQWdCLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUU7QUFDN0UsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLGdCQUFnQixhQUFhLElBQUk7QUFBQSxFQUN6QyxPQUFPO0FBQ0wsVUFBTSxnQkFBZ0IsS0FBSyxJQUFJO0FBQUEsRUFDakM7QUFFQSxRQUFNLG9CQUFvQixNQUFNLGVBQWU7QUFHL0MsUUFBTSxPQUFPLE1BQU0sT0FBTyxLQUFLLE1BQU0sQ0FBQSxDQUFFO0FBQ3ZDLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksSUFBSSxPQUFPLE9BQVc7QUFDMUIsUUFBSTtBQUNGLFlBQU0sT0FBTyxLQUFLLFlBQVksSUFBSSxJQUFJO0FBQUEsUUFDcEMsTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLFFBQ04sU0FBUSxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLE1BQVksQ0FDaEM7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUVBLGNBQUE7QUFDRjtBQUVBLGVBQWUsa0JBQ2IsU0FDMEI7QUFDMUIsUUFBTSxXQUFXLE1BQU0sS0FBSyxNQUFNLGFBQWEsT0FBQSxDQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFO0FBRXhFLFFBQU0sUUFBUSxNQUFNLDRCQUE0QixTQUFTLFVBQVUsQ0FBQSxDQUFFO0FBRXJFLFFBQU0sV0FBVyxXQUFXO0FBQzVCLFFBQU0sV0FBVyxZQUFZO0FBQzdCLFFBQU0sV0FBVyxrQkFBa0IsTUFBTTtBQUd6QyxRQUFNLGFBQWEsTUFBQTtBQUduQixhQUFXLFFBQVEsTUFBTSxpQkFBaUI7QUFDeEMsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFDQSxRQUFNLG9CQUFvQixNQUFNLGVBQWU7QUFHL0MsYUFBVyxDQUFDLE9BQU8sU0FBUyxLQUFLLE1BQU0sZUFBZSxXQUFXO0FBQy9ELFVBQU0sY0FBYyxXQUFXLENBQUMsYUFBYTtBQUFBLE1BQzNDLEdBQUc7QUFBQSxNQUNILFVBQVMsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxNQUNwQixXQUFXO0FBQUEsSUFBQSxFQUNYO0FBQ0YsVUFBTSxlQUFlLE9BQU8sS0FBSztBQUFBLEVBQ25DO0FBRUEsUUFBTSxzQkFBQTtBQUNOLGNBQUE7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGNBQW9CO0FBQzNCLE1BQUk7QUFDRixRQUFJLE1BQU0sV0FBVyxVQUFVO0FBQzdCLGFBQU8sT0FBTyxhQUFhLEVBQUUsTUFBTSxLQUFLO0FBQ3hDLGFBQU8sT0FBTyx3QkFBd0IsRUFBRSxPQUFPLFdBQVc7QUFDMUQ7QUFBQSxJQUNGO0FBRUEsVUFBTSxhQUFhLE1BQU0sYUFBYTtBQUN0QyxRQUFJLGFBQWEsR0FBRztBQUNsQixhQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sT0FBTyxVQUFVLEdBQUc7QUFDdkQsYUFBTyxPQUFPLHdCQUF3QixFQUFFLE9BQU8sV0FBVztBQUMxRDtBQUFBLElBQ0Y7QUFFQSxVQUFNLHNCQUFzQixNQUFNLGdCQUFnQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVE7QUFDeEUsUUFBSSxxQkFBcUI7QUFDdkIsYUFBTyxPQUFPLGFBQWEsRUFBRSxNQUFNLElBQUk7QUFDdkMsYUFBTyxPQUFPLHdCQUF3QixFQUFFLE9BQU8sV0FBVztBQUMxRDtBQUFBLElBQ0Y7QUFFQSxXQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sSUFBSTtBQUFBLEVBQ3pDLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFQSxlQUFlLGlCQUFpQixPQUE4QjtBQUM1RCxRQUFNLFlBQVksTUFBTSxlQUFlLElBQUksS0FBSztBQUNoRCxNQUFJLFdBQVc7QUFDYixVQUFNLGNBQWMsV0FBVyxDQUFDLGFBQWE7QUFBQSxNQUMzQyxHQUFHO0FBQUEsTUFDSCxVQUFTLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsTUFDcEIsV0FBVztBQUFBLElBQUEsRUFDWDtBQUNGLFVBQU0sZUFBZSxPQUFPLEtBQUs7QUFBQSxFQUNuQztBQUNBLFFBQU0sYUFBYSxPQUFPLEtBQUs7QUFDL0IsY0FBQTtBQUNGO0FBRUEsZUFBZSw0QkFBMkM7QUFDeEQsTUFBSSxVQUFVO0FBQ2QsYUFBVyxRQUFRLE1BQU0saUJBQWlCO0FBQ3hDLFFBQUksS0FBSyxZQUFZLG1CQUFtQixLQUFLLE1BQU0sU0FBUyxHQUFHO0FBQzdELFdBQUssV0FBVztBQUNoQixnQkFBVTtBQUdWLFlBQU0sT0FBTyxNQUFNLE9BQU8sS0FBSyxNQUFNLENBQUEsQ0FBRTtBQUN2QyxpQkFBVyxPQUFPLE1BQU07QUFDdEIsWUFBSSxJQUFJLE9BQU8sT0FBVztBQUMxQixZQUFJO0FBQ0YsZ0JBQU0sT0FBTyxLQUFLLFlBQVksSUFBSSxJQUFJO0FBQUEsWUFDcEMsTUFBTTtBQUFBLFlBQ04sTUFBTTtBQUFBLFlBQ04sU0FBUSxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLFVBQVksQ0FDaEM7QUFBQSxRQUNILFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBSSxTQUFTO0FBQ1gsVUFBTSxvQkFBb0IsTUFBTSxlQUFlO0FBQy9DLGdCQUFBO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUywyQkFBaUM7QUFDeEMsTUFBSTtBQUNGLFdBQU8sU0FBUyxVQUFVLFlBQVksQ0FBQyxZQUFZO0FBQ2pELFVBQUksWUFBWSxlQUFlO0FBQzdCLDBCQUFrQixtQkFBbUIsRUFBRSxNQUFNLE1BQU07QUFBQSxRQUFlLENBQUM7QUFBQSxNQUNyRTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsUUFBUTtBQUFBLEVBRVI7QUFDRjtBQUVBLFdBQUE7In0=
