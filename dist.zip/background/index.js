const DEFAULT_LIFETIME_STATS = {
  firstActiveAt: null,
  totalSessions: 0,
  totalActionsBlocked: 0,
  agentTypesDetected: {}
};
const DEFAULT_SETTINGS = {
  detectionEnabled: true,
  notificationsEnabled: true,
  killSwitchShortcut: "Ctrl+Shift+K",
  maxSessions: 5,
  maxDetectionLogEntries: 100,
  autoBlockUnknownAgents: false
};
const DEFAULT_STORAGE = {
  sessions: [],
  delegationRules: [],
  settings: DEFAULT_SETTINGS,
  detectionLog: []
};
async function getStorageState() {
  try {
    const result = await chrome.storage.local.get(
      Object.keys(DEFAULT_STORAGE)
    );
    return {
      sessions: result.sessions ?? DEFAULT_STORAGE.sessions,
      delegationRules: result.delegationRules ?? DEFAULT_STORAGE.delegationRules,
      settings: { ...DEFAULT_SETTINGS, ...result.settings ?? {} },
      detectionLog: result.detectionLog ?? DEFAULT_STORAGE.detectionLog
    };
  } catch (err) {
    console.error("[AI Browser Guard] Storage read error:", err);
    return { ...DEFAULT_STORAGE };
  }
}
async function saveSession(session) {
  try {
    const state2 = await getStorageState();
    const sessions = [session, ...state2.sessions];
    const maxSessions = state2.settings.maxSessions ?? 5;
    if (sessions.length > maxSessions) {
      sessions.length = maxSessions;
    }
    await chrome.storage.local.set({ sessions });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to save session:", err);
  }
}
async function updateSession(sessionId, updater) {
  try {
    const state2 = await getStorageState();
    const index = state2.sessions.findIndex((s) => s.id === sessionId);
    if (index === -1) {
      console.warn("[AI Browser Guard] Session not found:", sessionId);
      return;
    }
    state2.sessions[index] = updater(state2.sessions[index]);
    await chrome.storage.local.set({ sessions: state2.sessions });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to update session:", err);
  }
}
async function saveDelegationRules(rules) {
  try {
    await chrome.storage.local.set({ delegationRules: rules });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to save delegation rules:", err);
  }
}
async function appendDetectionLog(event) {
  try {
    const state2 = await getStorageState();
    const log = [...state2.detectionLog, event];
    const maxEntries = state2.settings.maxDetectionLogEntries ?? 100;
    if (log.length > maxEntries) {
      log.splice(0, log.length - maxEntries);
    }
    await chrome.storage.local.set({ detectionLog: log });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to append detection log:", err);
  }
}
async function getSettings() {
  const state2 = await getStorageState();
  return state2.settings;
}
async function updateSettings(updates) {
  try {
    const current = await getSettings();
    const merged = { ...current, ...updates };
    await chrome.storage.local.set({ settings: merged });
  } catch (err) {
    console.error("[AI Browser Guard] Failed to update settings:", err);
  }
}
async function getLifetimeStats() {
  try {
    const result = await chrome.storage.local.get("lifetimeStats");
    return { ...DEFAULT_LIFETIME_STATS, ...result.lifetimeStats ?? {} };
  } catch {
    return { ...DEFAULT_LIFETIME_STATS };
  }
}
async function updateLifetimeStats(updater) {
  try {
    const current = await getLifetimeStats();
    const updated = updater(current);
    await chrome.storage.local.set({ lifetimeStats: updated });
  } catch {
  }
}
function generateId() {
  return crypto.randomUUID();
}
function createTimelineEvent(type, url, description, options) {
  return {
    id: generateId(),
    type,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    url,
    description,
    outcome: options?.outcome ?? "informational",
    targetSelector: options?.targetSelector,
    attemptedAction: options?.attemptedAction,
    ruleId: options?.ruleId
  };
}
function appendEventToSession(session, event) {
  const events = [...session.events, event];
  const summary = computeSessionSummary(events, session.startedAt);
  return { ...session, events, summary };
}
function computeSessionSummary(events, startedAt) {
  let totalActions = 0;
  let allowedActions = 0;
  let blockedActions = 0;
  let violations = 0;
  const urlCounts = /* @__PURE__ */ new Map();
  for (const event of events) {
    if (event.outcome === "allowed") {
      totalActions++;
      allowedActions++;
    } else if (event.outcome === "blocked") {
      totalActions++;
      blockedActions++;
    }
    if (event.type === "boundary-violation") {
      violations++;
    }
    if (event.url) {
      urlCounts.set(event.url, (urlCounts.get(event.url) ?? 0) + 1);
    }
  }
  const topUrls = [...urlCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([url]) => url);
  let durationSeconds = null;
  if (events.length > 0) {
    const lastEvent = events[events.length - 1];
    const start = new Date(startedAt).getTime();
    const end = new Date(lastEvent.timestamp).getTime();
    durationSeconds = Math.round((end - start) / 1e3);
  }
  return {
    totalActions,
    allowedActions,
    blockedActions,
    violations,
    topUrls,
    durationSeconds
  };
}
function isTimeBoundExpired(timeBound) {
  if (timeBound === null) return false;
  return (/* @__PURE__ */ new Date()).getTime() > new Date(timeBound.expiresAt).getTime();
}
function revokeToken(token) {
  return { ...token, revoked: true };
}
async function executeBackgroundKillSwitch(trigger, activeAgentIds, activeTokens) {
  const revokedTokenIds = [];
  for (const token of activeTokens) {
    revokeToken(token);
    revokedTokenIds.push(token.tokenId);
  }
  let cdpTerminated = false;
  let automationFlagsCleared = false;
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.id === void 0) continue;
      try {
        await chrome.tabs.sendMessage(tab.id, {
          type: "KILL_SWITCH_ACTIVATE",
          data: {},
          sentAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      } catch {
      }
    }
    cdpTerminated = true;
    automationFlagsCleared = true;
  } catch {
  }
  const event = {
    id: crypto.randomUUID(),
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    trigger,
    terminatedAgentIds: [...activeAgentIds],
    revokedTokenIds,
    cdpTerminated,
    automationFlagsCleared
  };
  showKillSwitchNotification(activeAgentIds.length);
  return event;
}
function showKillSwitchNotification(agentCount) {
  try {
    chrome.notifications.create(`abg-killswitch-${Date.now()}`, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title: "AI Browser Guard - Kill Switch Activated",
      message: `Terminated ${agentCount} agent session(s). All delegations revoked.`,
      priority: 2
    });
    setTimeout(() => {
      try {
        chrome.notifications.getAll((notifications) => {
          for (const id of Object.keys(notifications)) {
            if (id.startsWith("abg-killswitch-")) {
              chrome.notifications.clear(id);
            }
          }
        });
      } catch {
      }
    }, 5e3);
  } catch {
  }
}
function createInitialKillSwitchState() {
  return {
    isActive: false,
    lastEvent: null,
    lastActivatedAt: null
  };
}
const DEFAULT_NOTIFICATION_CONFIG = {
  enabled: true,
  minimumSeverity: "medium",
  playSound: true,
  autoDismissMs: 1e4
};
function showBoundaryNotification(alert, config) {
  const mergedConfig = { ...DEFAULT_NOTIFICATION_CONFIG, ...config };
  if (!mergedConfig.enabled) return null;
  if (!meetsSeverityThreshold(alert.severity, mergedConfig.minimumSeverity)) return null;
  const notificationId = `abg-alert-${Date.now()}`;
  try {
    const options = {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title: `AI Browser Guard - ${alert.title}`,
      message: alert.message,
      priority: severityToPriority(alert.severity),
      requireInteraction: alert.severity === "critical"
    };
    if (alert.allowOneTimeOverride) {
      options.buttons = [
        { title: "Allow once" },
        { title: "Dismiss" }
      ];
    }
    chrome.notifications.create(notificationId, options);
    if (mergedConfig.autoDismissMs > 0 && alert.severity !== "critical") {
      setTimeout(() => {
        try {
          chrome.notifications.clear(notificationId);
        } catch {
        }
      }, mergedConfig.autoDismissMs);
    }
  } catch (err) {
    console.error("[AI Browser Guard] Failed to create notification:", err);
    return null;
  }
  return notificationId;
}
function severityToPriority(severity) {
  const priorityMap = {
    critical: 2,
    high: 1,
    medium: 0,
    low: 0
  };
  return priorityMap[severity];
}
function meetsSeverityThreshold(severity, minimum) {
  const order = ["low", "medium", "high", "critical"];
  return order.indexOf(severity) >= order.indexOf(minimum);
}
function setupNotificationHandlers(onAllowOnce) {
  const handler = (notificationId, buttonIndex) => {
    if (buttonIndex === 0) {
      onAllowOnce(notificationId);
    }
    try {
      chrome.notifications.clear(notificationId);
    } catch {
    }
  };
  chrome.notifications.onButtonClicked.addListener(handler);
  return () => {
    chrome.notifications.onButtonClicked.removeListener(handler);
  };
}
async function clearAllNotifications() {
  return new Promise((resolve) => {
    try {
      chrome.notifications.getAll((notifications) => {
        for (const id of Object.keys(notifications)) {
          chrome.notifications.clear(id);
        }
        resolve();
      });
    } catch {
      resolve();
    }
  });
}
const SENSITIVE_URL_PATTERNS = [
  /\.bank\./i,
  /\.gov\./i,
  /paypal/i,
  /stripe/i,
  /\.financial/i,
  /healthcare/i,
  /\.mil\./i
];
function createBoundaryAlert(violation, rule) {
  const severity = classifyViolationSeverity(violation.attemptedAction, violation.url);
  const title = generateAlertTitle(violation.attemptedAction);
  const message = generateAlertMessage(violation, rule.label ?? rule.preset);
  return {
    violation,
    severity,
    title,
    message,
    allowOneTimeOverride: severity === "medium" || severity === "low",
    acknowledged: false
  };
}
function classifyViolationSeverity(capability, url) {
  const baseSeverityMap = {
    "submit-form": "critical",
    "execute-script": "critical",
    "download-file": "high",
    "modify-dom": "high",
    click: "high",
    "type-text": "medium",
    navigate: "medium",
    "open-tab": "low",
    "close-tab": "low",
    "read-dom": "low",
    screenshot: "low"
  };
  let severity = baseSeverityMap[capability] ?? "medium";
  const isSensitive = SENSITIVE_URL_PATTERNS.some((pattern) => pattern.test(url));
  if (isSensitive) {
    const upgrade = {
      low: "medium",
      medium: "high",
      high: "critical",
      critical: "critical"
    };
    severity = upgrade[severity];
  }
  return severity;
}
function generateAlertTitle(capability) {
  const titles = {
    navigate: "Navigation blocked",
    "read-dom": "Page read blocked",
    click: "Click interaction blocked",
    "type-text": "Text input blocked",
    "submit-form": "Form submission blocked",
    "download-file": "File download blocked",
    "open-tab": "New tab blocked",
    "close-tab": "Tab closure blocked",
    screenshot: "Screenshot blocked",
    "execute-script": "Script execution blocked",
    "modify-dom": "DOM modification blocked"
  };
  return titles[capability] || "Action blocked";
}
function generateAlertMessage(violation, ruleName) {
  const lines = [
    `An agent attempted to perform "${violation.attemptedAction}" on:`,
    violation.url,
    "",
    `Blocked by rule: ${ruleName}`,
    `Reason: ${violation.reason}`
  ];
  if (violation.targetSelector) {
    lines.push(`Target element: ${violation.targetSelector}`);
  }
  return lines.join("\n");
}
const pendingOverrides = /* @__PURE__ */ new Map();
function processBoundaryViolation(tabId, violation, activeRule, activeSessions) {
  const alert = createBoundaryAlert(violation, activeRule);
  const notificationId = showBoundaryNotification(alert);
  if (notificationId !== null && tabId !== void 0) {
    pendingOverrides.set(notificationId, {
      tabId,
      capability: violation.attemptedAction,
      url: violation.url
    });
  }
  if (tabId !== void 0) {
    const sessionId = activeSessions.get(tabId);
    if (sessionId) {
      const event = createTimelineEvent(
        "boundary-violation",
        violation.url,
        `Violation: ${violation.attemptedAction} blocked`,
        {
          attemptedAction: violation.attemptedAction,
          outcome: "blocked",
          ruleId: violation.blockingRuleId,
          targetSelector: violation.targetSelector
        }
      );
      updateSession(sessionId, (session) => appendEventToSession(session, event)).catch(
        () => {
        }
      );
    }
  }
  return alert;
}
async function handleAllowOnce(notificationId) {
  const override = pendingOverrides.get(notificationId);
  if (!override) return false;
  pendingOverrides.delete(notificationId);
  try {
    await chrome.tabs.sendMessage(override.tabId, {
      type: "ALLOW_ONCE",
      data: { capability: override.capability, url: override.url },
      sentAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch {
  }
  try {
    chrome.notifications.clear(notificationId);
  } catch {
  }
  return true;
}
const state = {
  activeAgents: /* @__PURE__ */ new Map(),
  activeSessions: /* @__PURE__ */ new Map(),
  delegationRules: [],
  killSwitch: createInitialKillSwitchState(),
  recentAlerts: [],
  lifetimeStats: { ...DEFAULT_LIFETIME_STATS }
};
function initialize() {
  loadPersistedState().then(() => {
    updateBadge();
  }).catch((err) => {
    console.error("[AI Browser Guard] Failed to load state:", err);
  });
  chrome.runtime.onMessage.addListener(handleMessage);
  chrome.tabs.onRemoved.addListener((tabId) => {
    handleTabRemoved(tabId).catch(() => {
    });
  });
  chrome.alarms.create("delegation-check", { periodInMinutes: 1 });
  chrome.alarms.create("keepalive-ping", { periodInMinutes: 0.4 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "delegation-check") {
      checkDelegationExpiration().catch(() => {
      });
    }
  });
  registerKeyboardShortcut();
  setupNotificationHandlers((notificationId) => {
    handleAllowOnce(notificationId).catch(() => {
    });
  });
  console.log("[AI Browser Guard] Background service worker initialized");
}
async function loadPersistedState() {
  const stored = await getStorageState();
  state.delegationRules = stored.delegationRules;
  state.lifetimeStats = await getLifetimeStats();
  for (const session of stored.sessions) {
    if (!session.endedAt) {
      await updateSession(session.id, (s) => ({
        ...s,
        endedAt: (/* @__PURE__ */ new Date()).toISOString(),
        endReason: "agent-disconnected"
      }));
    }
  }
}
function handleMessage(message, sender, sendResponse) {
  if (!message || !message.type) return false;
  const tabId = sender.tab?.id;
  switch (message.type) {
    case "DETECTION_RESULT": {
      if (tabId !== void 0) {
        handleDetection(tabId, message.data).then(() => {
          sendResponse({ success: true });
        }).catch(() => {
          sendResponse({ success: false });
        });
        return true;
      }
      return false;
    }
    case "AGENT_ACTION": {
      if (tabId !== void 0) {
        handleAgentAction(tabId, message.data);
      }
      sendResponse({ success: true });
      return false;
    }
    case "BOUNDARY_CHECK_REQUEST": {
      const violation = message.data;
      handleBoundaryViolation(tabId, violation);
      sendResponse({ success: true });
      return false;
    }
    case "KILL_SWITCH_ACTIVATE": {
      executeKillSwitch(
        message.data?.trigger ?? "button"
      ).then((event) => {
        sendResponse({ success: true, event });
      }).catch(() => {
        sendResponse({ success: false });
      });
      return true;
    }
    case "KILL_SWITCH_RESET": {
      state.killSwitch.isActive = false;
      state.killSwitch.lastEvent = null;
      state.killSwitch.lastActivatedAt = null;
      updateBadge();
      sendResponse({ success: true });
      return false;
    }
    case "DELEGATION_UPDATE": {
      const rule = message.data;
      handleDelegationUpdate(rule).then(() => {
        sendResponse({ success: true });
      }).catch(() => {
        sendResponse({ success: false });
      });
      return true;
    }
    case "SESSION_QUERY": {
      getStorageState().then((stored) => {
        sendResponse({ sessions: stored.sessions });
      }).catch(() => {
        sendResponse({ sessions: [] });
      });
      return true;
    }
    case "STATUS_QUERY": {
      const agents = Array.from(state.activeAgents.values());
      const activeRule = state.delegationRules.find((r) => r.isActive) ?? null;
      sendResponse({
        detectedAgents: agents,
        activeDelegation: activeRule,
        killSwitchActive: state.killSwitch.isActive,
        recentViolations: state.recentAlerts,
        delegationRules: state.delegationRules,
        lifetimeStats: state.lifetimeStats
      });
      return false;
    }
    case "SETTINGS_UPDATE": {
      const updates = message.data;
      updateSettings(updates).then(() => {
        sendResponse({ success: true });
      }).catch(() => {
        sendResponse({ success: false });
      });
      return true;
    }
    default:
      return false;
  }
}
async function handleDetection(tabId, event) {
  if (!event.agent) return;
  state.activeAgents.set(tabId, event.agent);
  const session = {
    id: crypto.randomUUID(),
    agent: event.agent,
    delegationRule: state.delegationRules.find((r) => r.isActive) ?? null,
    events: [],
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    endedAt: null,
    endReason: null,
    summary: {
      totalActions: 0,
      allowedActions: 0,
      blockedActions: 0,
      violations: 0,
      topUrls: [],
      durationSeconds: null
    }
  };
  const agentDisplayNames = {
    playwright: "Playwright",
    puppeteer: "Puppeteer",
    selenium: "Selenium",
    "anthropic-computer-use": "Anthropic Computer Use",
    "openai-operator": "OpenAI Operator",
    "cdp-generic": "CDP Agent",
    "webdriver-generic": "WebDriver Agent",
    unknown: "Unknown Agent"
  };
  const agentDisplayName = agentDisplayNames[event.agent.type] ?? event.agent.type;
  const timelineEvent = createTimelineEvent("detection", event.url, `Agent detected: ${agentDisplayName}`, {
    outcome: "informational"
  });
  const updatedSession = appendEventToSession(session, timelineEvent);
  await saveSession(updatedSession);
  state.activeSessions.set(tabId, updatedSession.id);
  await appendDetectionLog(event);
  const agentType = event.agent.type;
  const updatedTypes = { ...state.lifetimeStats.agentTypesDetected };
  updatedTypes[agentType] = (updatedTypes[agentType] ?? 0) + 1;
  state.lifetimeStats = {
    ...state.lifetimeStats,
    firstActiveAt: state.lifetimeStats.firstActiveAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    totalSessions: state.lifetimeStats.totalSessions + 1,
    agentTypesDetected: updatedTypes
  };
  updateLifetimeStats(() => state.lifetimeStats).catch(() => {
  });
  updateBadge();
}
function handleAgentAction(tabId, event) {
  const sessionId = state.activeSessions.get(tabId);
  if (!sessionId) return;
  updateSession(sessionId, (session) => appendEventToSession(session, event)).catch(() => {
  });
}
function handleBoundaryViolation(tabId, violation) {
  const activeRule = state.delegationRules.find((r) => r.isActive);
  if (!activeRule) return;
  const alert = processBoundaryViolation(tabId, violation, activeRule, state.activeSessions);
  state.recentAlerts.push(alert);
  if (state.recentAlerts.length > 20) {
    state.recentAlerts.shift();
  }
  state.lifetimeStats = {
    ...state.lifetimeStats,
    totalActionsBlocked: state.lifetimeStats.totalActionsBlocked + 1
  };
  updateLifetimeStats(() => state.lifetimeStats).catch(() => {
  });
}
async function handleDelegationUpdate(rule) {
  const existingIndex = state.delegationRules.findIndex((r) => r.id === rule.id);
  if (existingIndex >= 0) {
    state.delegationRules[existingIndex] = rule;
  } else {
    state.delegationRules.push(rule);
  }
  for (const r of state.delegationRules) {
    if (r.id !== rule.id) {
      r.isActive = false;
    }
  }
  await saveDelegationRules(state.delegationRules);
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.id === void 0) continue;
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: "DELEGATION_UPDATE",
        data: rule,
        sentAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch {
    }
  }
  updateBadge();
}
async function executeKillSwitch(trigger) {
  const agentIds = Array.from(state.activeAgents.values()).map((a) => a.id);
  const event = await executeBackgroundKillSwitch(trigger, agentIds, []);
  state.killSwitch.isActive = true;
  state.killSwitch.lastEvent = event;
  state.killSwitch.lastActivatedAt = event.timestamp;
  state.activeAgents.clear();
  for (const rule of state.delegationRules) {
    rule.isActive = false;
  }
  await saveDelegationRules(state.delegationRules);
  for (const [tabId, sessionId] of state.activeSessions.entries()) {
    await updateSession(sessionId, (session) => ({
      ...session,
      endedAt: (/* @__PURE__ */ new Date()).toISOString(),
      endReason: "kill-switch"
    }));
    state.activeSessions.delete(tabId);
  }
  await clearAllNotifications();
  updateBadge();
  return event;
}
function updateBadge() {
  try {
    if (state.killSwitch.isActive) {
      chrome.action.setBadgeText({ text: "X" });
      chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
      return;
    }
    const agentCount = state.activeAgents.size;
    if (agentCount > 0) {
      chrome.action.setBadgeText({ text: String(agentCount) });
      chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
      return;
    }
    const hasActiveDelegation = state.delegationRules.some((r) => r.isActive);
    if (hasActiveDelegation) {
      chrome.action.setBadgeText({ text: "" });
      chrome.action.setBadgeBackgroundColor({ color: "#22c55e" });
      return;
    }
    chrome.action.setBadgeText({ text: "" });
  } catch {
  }
}
async function handleTabRemoved(tabId) {
  const sessionId = state.activeSessions.get(tabId);
  if (sessionId) {
    await updateSession(sessionId, (session) => ({
      ...session,
      endedAt: (/* @__PURE__ */ new Date()).toISOString(),
      endReason: "page-unload"
    }));
    state.activeSessions.delete(tabId);
  }
  state.activeAgents.delete(tabId);
  updateBadge();
}
async function checkDelegationExpiration() {
  let changed = false;
  for (const rule of state.delegationRules) {
    if (rule.isActive && isTimeBoundExpired(rule.scope.timeBound)) {
      rule.isActive = false;
      changed = true;
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        if (tab.id === void 0) continue;
        try {
          await chrome.tabs.sendMessage(tab.id, {
            type: "DELEGATION_UPDATE",
            data: null,
            sentAt: (/* @__PURE__ */ new Date()).toISOString()
          });
        } catch {
        }
      }
    }
  }
  if (changed) {
    await saveDelegationRules(state.delegationRules);
    updateBadge();
  }
}
function registerKeyboardShortcut() {
  try {
    chrome.commands.onCommand.addListener((command) => {
      if (command === "kill-switch") {
        executeKillSwitch("keyboard-shortcut").catch(() => {
        });
      }
    });
  } catch {
  }
}
initialize();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXNzaW9uL3R5cGVzLnRzIiwiLi4vLi4vc3JjL3Nlc3Npb24vc3RvcmFnZS50cyIsIi4uLy4uL3NyYy9zZXNzaW9uL3RpbWVsaW5lLnRzIiwiLi4vLi4vc3JjL2RlbGVnYXRpb24vcnVsZXMudHMiLCIuLi8uLi9zcmMva2lsbHN3aXRjaC9pbmRleC50cyIsIi4uLy4uL3NyYy9hbGVydHMvbm90aWZpY2F0aW9uLnRzIiwiLi4vLi4vc3JjL2FsZXJ0cy9ib3VuZGFyeS50cyIsIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL2hhbmRsZXJzLnRzIiwiLi4vLi4vc3JjL2JhY2tncm91bmQvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBTZXNzaW9uIHR5cGVzIGZvciB0cmFja2luZyBhZ2VudCBhY3Rpdml0eSBvdmVyIHRpbWUuXG4gKlxuICogQSBzZXNzaW9uIHJlcHJlc2VudHMgYSBzaW5nbGUgcGVyaW9kIG9mIGFnZW50IGFjdGl2aXR5IGluIHRoZSBicm93c2VyLFxuICogZnJvbSBkZXRlY3Rpb24gdG8gdGVybWluYXRpb24gKG9yIHBhZ2UgdW5sb2FkKS5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEFnZW50SWRlbnRpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5pbXBvcnQgdHlwZSB7IEFnZW50RXZlbnQgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uUnVsZSB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuXG4vKipcbiAqIEEgY29tcGxldGUgYWdlbnQgc2Vzc2lvbiB3aXRoIHRpbWVsaW5lIG9mIGV2ZW50cy5cbiAqIFN0b3JlcyB1cCB0byA1IHNlc3Npb25zIGluIGNocm9tZS5zdG9yYWdlLmxvY2FsLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50U2Vzc2lvbiB7XG4gIC8qKiBVbmlxdWUgc2Vzc2lvbiBpZGVudGlmaWVyIChVVUlEIHY0KS4gKi9cbiAgaWQ6IHN0cmluZztcblxuICAvKiogVGhlIGRldGVjdGVkIGFnZW50IGFzc29jaWF0ZWQgd2l0aCB0aGlzIHNlc3Npb24uICovXG4gIGFnZW50OiBBZ2VudElkZW50aXR5O1xuXG4gIC8qKiBUaGUgZGVsZWdhdGlvbiBydWxlIHRoYXQgd2FzIGFjdGl2ZSBkdXJpbmcgdGhpcyBzZXNzaW9uLCBpZiBhbnkuICovXG4gIGRlbGVnYXRpb25SdWxlOiBEZWxlZ2F0aW9uUnVsZSB8IG51bGw7XG5cbiAgLyoqIENocm9ub2xvZ2ljYWwgbGlzdCBvZiBldmVudHMgdGhhdCBvY2N1cnJlZCBkdXJpbmcgdGhpcyBzZXNzaW9uLiAqL1xuICBldmVudHM6IEFnZW50RXZlbnRbXTtcblxuICAvKiogSVNPIDg2MDEgdGltZXN0YW1wIHdoZW4gdGhlIHNlc3Npb24gc3RhcnRlZCAoYWdlbnQgZmlyc3QgZGV0ZWN0ZWQpLiAqL1xuICBzdGFydGVkQXQ6IHN0cmluZztcblxuICAvKiogSVNPIDg2MDEgdGltZXN0YW1wIHdoZW4gdGhlIHNlc3Npb24gZW5kZWQuIE51bGwgaWYgc2Vzc2lvbiBpcyBhY3RpdmUuICovXG4gIGVuZGVkQXQ6IHN0cmluZyB8IG51bGw7XG5cbiAgLyoqIEhvdyB0aGUgc2Vzc2lvbiBlbmRlZC4gKi9cbiAgZW5kUmVhc29uOiAna2lsbC1zd2l0Y2gnIHwgJ2RlbGVnYXRpb24tZXhwaXJlZCcgfCAnYWdlbnQtZGlzY29ubmVjdGVkJyB8ICdwYWdlLXVubG9hZCcgfCBudWxsO1xuXG4gIC8qKiBTdW1tYXJ5IHN0YXRpc3RpY3MgZm9yIHF1aWNrIGRpc3BsYXkgaW4gcG9wdXAuICovXG4gIHN1bW1hcnk6IFNlc3Npb25TdW1tYXJ5O1xufVxuXG4vKipcbiAqIFN1bW1hcnkgc3RhdGlzdGljcyBmb3IgYSBzZXNzaW9uLlxuICogUHJlLWNvbXB1dGVkIGZvciBlZmZpY2llbnQgcmVuZGVyaW5nIGluIHRoZSBwb3B1cCB0aW1lbGluZSB2aWV3LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFNlc3Npb25TdW1tYXJ5IHtcbiAgLyoqIFRvdGFsIG51bWJlciBvZiBhY3Rpb25zIHRoZSBhZ2VudCBwZXJmb3JtZWQuICovXG4gIHRvdGFsQWN0aW9uczogbnVtYmVyO1xuXG4gIC8qKiBOdW1iZXIgb2YgYWN0aW9ucyB0aGF0IHdlcmUgYWxsb3dlZC4gKi9cbiAgYWxsb3dlZEFjdGlvbnM6IG51bWJlcjtcblxuICAvKiogTnVtYmVyIG9mIGFjdGlvbnMgdGhhdCB3ZXJlIGJsb2NrZWQuICovXG4gIGJsb2NrZWRBY3Rpb25zOiBudW1iZXI7XG5cbiAgLyoqIE51bWJlciBvZiBib3VuZGFyeSB2aW9sYXRpb25zLiAqL1xuICB2aW9sYXRpb25zOiBudW1iZXI7XG5cbiAgLyoqIFRoZSBtb3N0LXZpc2l0ZWQgVVJMcyBkdXJpbmcgdGhpcyBzZXNzaW9uICh0b3AgNSkuICovXG4gIHRvcFVybHM6IHN0cmluZ1tdO1xuXG4gIC8qKiBEdXJhdGlvbiBvZiB0aGUgc2Vzc2lvbiBpbiBzZWNvbmRzLiBOdWxsIGlmIHNlc3Npb24gaXMgc3RpbGwgYWN0aXZlLiAqL1xuICBkdXJhdGlvblNlY29uZHM6IG51bWJlciB8IG51bGw7XG59XG5cbi8qKlxuICogQWdncmVnYXRlIHN0b3JhZ2Ugc2NoZW1hIGZvciBjaHJvbWUuc3RvcmFnZS5sb2NhbC5cbiAqIFRoaXMgaXMgdGhlIHRvcC1sZXZlbCBzaGFwZSBvZiBhbGwgcGVyc2lzdGVkIGRhdGEuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RvcmFnZVNjaGVtYSB7XG4gIC8qKiBMYXN0IDUgYWdlbnQgc2Vzc2lvbnMsIG5ld2VzdCBmaXJzdC4gKi9cbiAgc2Vzc2lvbnM6IEFnZW50U2Vzc2lvbltdO1xuXG4gIC8qKiBDdXJyZW50bHkgYWN0aXZlIGRlbGVnYXRpb24gcnVsZXMuICovXG4gIGRlbGVnYXRpb25SdWxlczogRGVsZWdhdGlvblJ1bGVbXTtcblxuICAvKiogVXNlciBwcmVmZXJlbmNlcyBhbmQgc2V0dGluZ3MuICovXG4gIHNldHRpbmdzOiBVc2VyU2V0dGluZ3M7XG5cbiAgLyoqIFJlY2VudCBkZXRlY3Rpb24gZXZlbnRzIGZvciBkZWJ1Z2dpbmcgKGxhc3QgMTAwKS4gKi9cbiAgZGV0ZWN0aW9uTG9nOiBpbXBvcnQoJy4uL3R5cGVzL2V2ZW50cycpLkRldGVjdGlvbkV2ZW50W107XG59XG5cbi8qKlxuICogVXNlci1jb25maWd1cmFibGUgc2V0dGluZ3MuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVXNlclNldHRpbmdzIHtcbiAgLyoqIFdoZXRoZXIgZGV0ZWN0aW9uIGlzIGVuYWJsZWQuIERlZmF1bHQ6IHRydWUuICovXG4gIGRldGVjdGlvbkVuYWJsZWQ6IGJvb2xlYW47XG5cbiAgLyoqIFdoZXRoZXIgYm91bmRhcnkgYWxlcnRzIHNob3cgQ2hyb21lIG5vdGlmaWNhdGlvbnMuIERlZmF1bHQ6IHRydWUuICovXG4gIG5vdGlmaWNhdGlvbnNFbmFibGVkOiBib29sZWFuO1xuXG4gIC8qKiBLaWxsIHN3aXRjaCBrZXlib2FyZCBzaG9ydGN1dC4gRGVmYXVsdDogXCJDdHJsK1NoaWZ0K0tcIiAvIFwiQ21kK1NoaWZ0K0tcIi4gKi9cbiAga2lsbFN3aXRjaFNob3J0Y3V0OiBzdHJpbmc7XG5cbiAgLyoqIE1heGltdW0gc2Vzc2lvbnMgdG8gcmV0YWluLiBEZWZhdWx0OiA1LiAqL1xuICBtYXhTZXNzaW9uczogbnVtYmVyO1xuXG4gIC8qKiBNYXhpbXVtIGRldGVjdGlvbiBsb2cgZW50cmllcy4gRGVmYXVsdDogMTAwLiAqL1xuICBtYXhEZXRlY3Rpb25Mb2dFbnRyaWVzOiBudW1iZXI7XG5cbiAgLyoqIFdoZXRoZXIgdG8gYXV0b21hdGljYWxseSBibG9jayB1bmlkZW50aWZpZWQgYWdlbnRzLiBEZWZhdWx0OiBmYWxzZS4gKi9cbiAgYXV0b0Jsb2NrVW5rbm93bkFnZW50czogYm9vbGVhbjtcbn1cblxuLyoqXG4gKiBDdW11bGF0aXZlIGxpZmV0aW1lIHByb3RlY3Rpb24gc3RhdGlzdGljcy5cbiAqIE5ldmVyIGV2aWN0ZWQg4oCUIGdyb3dzIGFjcm9zcyBhbGwgc2Vzc2lvbnMgYW5kIHBhZ2UgbG9hZHMuXG4gKiBVc2VkIHRvIGRlbW9uc3RyYXRlIGFjdGl2ZSBwcm90ZWN0aW9uIGluIHRoZSBwb3B1cCBzdW1tYXJ5IHBhbmVsLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIExpZmV0aW1lU3RhdHMge1xuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgZmlyc3QgZGV0ZWN0ZWQgYWdlbnQgc2Vzc2lvbi4gKi9cbiAgZmlyc3RBY3RpdmVBdDogc3RyaW5nIHwgbnVsbDtcblxuICAvKiogVG90YWwgYWdlbnQgc2Vzc2lvbnMgZGV0ZWN0ZWQgYWNyb3NzIGFsbCB0aW1lLiAqL1xuICB0b3RhbFNlc3Npb25zOiBudW1iZXI7XG5cbiAgLyoqIFRvdGFsIGFjdGlvbnMgYmxvY2tlZCBieSBkZWxlZ2F0aW9uIHJ1bGVzIGFjcm9zcyBhbGwgdGltZS4gKi9cbiAgdG90YWxBY3Rpb25zQmxvY2tlZDogbnVtYmVyO1xuXG4gIC8qKiBDb3VudCBvZiBlYWNoIGFnZW50IHR5cGUgZGV0ZWN0ZWQuIEtleXMgYXJlIGFnZW50IHR5cGUgc3RyaW5ncy4gKi9cbiAgYWdlbnRUeXBlc0RldGVjdGVkOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+O1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9MSUZFVElNRV9TVEFUUzogTGlmZXRpbWVTdGF0cyA9IHtcbiAgZmlyc3RBY3RpdmVBdDogbnVsbCxcbiAgdG90YWxTZXNzaW9uczogMCxcbiAgdG90YWxBY3Rpb25zQmxvY2tlZDogMCxcbiAgYWdlbnRUeXBlc0RldGVjdGVkOiB7fSxcbn07XG5cbi8qKlxuICogRGVmYXVsdCB1c2VyIHNldHRpbmdzIGFwcGxpZWQgb24gZmlyc3QgaW5zdGFsbC5cbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFVzZXJTZXR0aW5ncyA9IHtcbiAgZGV0ZWN0aW9uRW5hYmxlZDogdHJ1ZSxcbiAgbm90aWZpY2F0aW9uc0VuYWJsZWQ6IHRydWUsXG4gIGtpbGxTd2l0Y2hTaG9ydGN1dDogJ0N0cmwrU2hpZnQrSycsXG4gIG1heFNlc3Npb25zOiA1LFxuICBtYXhEZXRlY3Rpb25Mb2dFbnRyaWVzOiAxMDAsXG4gIGF1dG9CbG9ja1Vua25vd25BZ2VudHM6IGZhbHNlLFxufTtcbiIsIi8qKlxuICogU2Vzc2lvbiBwZXJzaXN0ZW5jZSBsYXllciB1c2luZyBjaHJvbWUuc3RvcmFnZS5sb2NhbC5cbiAqXG4gKiBNYW5hZ2VzIHJlYWRpbmcgYW5kIHdyaXRpbmcgb2Ygc2Vzc2lvbnMsIGRlbGVnYXRpb24gcnVsZXMsIHNldHRpbmdzLFxuICogYW5kIGRldGVjdGlvbiBsb2dzLiBFbmZvcmNlcyBzZXNzaW9uIGxpbWl0cyAoNSBzZXNzaW9ucywgMTAwIGxvZyBlbnRyaWVzKS5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEFnZW50U2Vzc2lvbiwgU3RvcmFnZVNjaGVtYSwgVXNlclNldHRpbmdzLCBMaWZldGltZVN0YXRzIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTLCBERUZBVUxUX0xJRkVUSU1FX1NUQVRTIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgdHlwZSB7IERlbGVnYXRpb25SdWxlIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5pbXBvcnQgdHlwZSB7IERldGVjdGlvbkV2ZW50IH0gZnJvbSAnLi4vdHlwZXMvZXZlbnRzJztcblxuY29uc3QgREVGQVVMVF9TVE9SQUdFOiBTdG9yYWdlU2NoZW1hID0ge1xuICBzZXNzaW9uczogW10sXG4gIGRlbGVnYXRpb25SdWxlczogW10sXG4gIHNldHRpbmdzOiBERUZBVUxUX1NFVFRJTkdTLFxuICBkZXRlY3Rpb25Mb2c6IFtdLFxufTtcblxuLyoqXG4gKiBSZXRyaWV2ZSB0aGUgZnVsbCBzdG9yYWdlIHNjaGVtYSBmcm9tIGNocm9tZS5zdG9yYWdlLmxvY2FsLlxuICogUmV0dXJucyBkZWZhdWx0IHZhbHVlcyBmb3IgYW55IG1pc3Npbmcga2V5cy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN0b3JhZ2VTdGF0ZSgpOiBQcm9taXNlPFN0b3JhZ2VTY2hlbWE+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXG4gICAgICBPYmplY3Qua2V5cyhERUZBVUxUX1NUT1JBR0UpXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgc2Vzc2lvbnM6IHJlc3VsdC5zZXNzaW9ucyA/PyBERUZBVUxUX1NUT1JBR0Uuc2Vzc2lvbnMsXG4gICAgICBkZWxlZ2F0aW9uUnVsZXM6IHJlc3VsdC5kZWxlZ2F0aW9uUnVsZXMgPz8gREVGQVVMVF9TVE9SQUdFLmRlbGVnYXRpb25SdWxlcyxcbiAgICAgIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLihyZXN1bHQuc2V0dGluZ3MgPz8ge30pIH0sXG4gICAgICBkZXRlY3Rpb25Mb2c6IHJlc3VsdC5kZXRlY3Rpb25Mb2cgPz8gREVGQVVMVF9TVE9SQUdFLmRldGVjdGlvbkxvZyxcbiAgICB9O1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gU3RvcmFnZSByZWFkIGVycm9yOicsIGVycik7XG4gICAgcmV0dXJuIHsgLi4uREVGQVVMVF9TVE9SQUdFIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTYXZlIGEgbmV3IGFnZW50IHNlc3Npb24gdG8gc3RvcmFnZS5cbiAqIEVuZm9yY2VzIHRoZSBsaW1pdCBvZiA1IHNlc3Npb25zIGJ5IGV2aWN0aW5nIHRoZSBvbGRlc3QuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlU2Vzc2lvbihzZXNzaW9uOiBBZ2VudFNlc3Npb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFN0b3JhZ2VTdGF0ZSgpO1xuICAgIGNvbnN0IHNlc3Npb25zID0gW3Nlc3Npb24sIC4uLnN0YXRlLnNlc3Npb25zXTtcbiAgICBjb25zdCBtYXhTZXNzaW9ucyA9IHN0YXRlLnNldHRpbmdzLm1heFNlc3Npb25zID8/IDU7XG4gICAgaWYgKHNlc3Npb25zLmxlbmd0aCA+IG1heFNlc3Npb25zKSB7XG4gICAgICBzZXNzaW9ucy5sZW5ndGggPSBtYXhTZXNzaW9ucztcbiAgICB9XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc2Vzc2lvbnMgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gc2F2ZSBzZXNzaW9uOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBVcGRhdGUgYW4gZXhpc3Rpbmcgc2Vzc2lvbiBpbiBzdG9yYWdlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2Vzc2lvbihcbiAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gIHVwZGF0ZXI6IChzZXNzaW9uOiBBZ2VudFNlc3Npb24pID0+IEFnZW50U2Vzc2lvblxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRTdG9yYWdlU3RhdGUoKTtcbiAgICBjb25zdCBpbmRleCA9IHN0YXRlLnNlc3Npb25zLmZpbmRJbmRleCgocykgPT4gcy5pZCA9PT0gc2Vzc2lvbklkKTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ1tBSSBCcm93c2VyIEd1YXJkXSBTZXNzaW9uIG5vdCBmb3VuZDonLCBzZXNzaW9uSWQpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdGF0ZS5zZXNzaW9uc1tpbmRleF0gPSB1cGRhdGVyKHN0YXRlLnNlc3Npb25zW2luZGV4XSk7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc2Vzc2lvbnM6IHN0YXRlLnNlc3Npb25zIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIHVwZGF0ZSBzZXNzaW9uOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSBhbGwgc3RvcmVkIHNlc3Npb25zLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2Vzc2lvbnMoKTogUHJvbWlzZTxBZ2VudFNlc3Npb25bXT4ge1xuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFN0b3JhZ2VTdGF0ZSgpO1xuICByZXR1cm4gc3RhdGUuc2Vzc2lvbnM7XG59XG5cbi8qKlxuICogU2F2ZSBvciB1cGRhdGUgZGVsZWdhdGlvbiBydWxlcyBpbiBzdG9yYWdlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2F2ZURlbGVnYXRpb25SdWxlcyhydWxlczogRGVsZWdhdGlvblJ1bGVbXSk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGRlbGVnYXRpb25SdWxlczogcnVsZXMgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gc2F2ZSBkZWxlZ2F0aW9uIHJ1bGVzOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSBhbGwgZGVsZWdhdGlvbiBydWxlcyBmcm9tIHN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXREZWxlZ2F0aW9uUnVsZXMoKTogUHJvbWlzZTxEZWxlZ2F0aW9uUnVsZVtdPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0U3RvcmFnZVN0YXRlKCk7XG4gIHJldHVybiBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXM7XG59XG5cbi8qKlxuICogQXBwZW5kIGEgZGV0ZWN0aW9uIGV2ZW50IHRvIHRoZSBsb2cuXG4gKiBFbmZvcmNlcyB0aGUgbGltaXQgb2YgMTAwIGxvZyBlbnRyaWVzIGJ5IGV2aWN0aW5nIHRoZSBvbGRlc3QuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmREZXRlY3Rpb25Mb2coZXZlbnQ6IERldGVjdGlvbkV2ZW50KTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRTdG9yYWdlU3RhdGUoKTtcbiAgICBjb25zdCBsb2cgPSBbLi4uc3RhdGUuZGV0ZWN0aW9uTG9nLCBldmVudF07XG4gICAgY29uc3QgbWF4RW50cmllcyA9IHN0YXRlLnNldHRpbmdzLm1heERldGVjdGlvbkxvZ0VudHJpZXMgPz8gMTAwO1xuICAgIGlmIChsb2cubGVuZ3RoID4gbWF4RW50cmllcykge1xuICAgICAgbG9nLnNwbGljZSgwLCBsb2cubGVuZ3RoIC0gbWF4RW50cmllcyk7XG4gICAgfVxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGRldGVjdGlvbkxvZzogbG9nIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIGFwcGVuZCBkZXRlY3Rpb24gbG9nOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSB1c2VyIHNldHRpbmdzIGZyb20gc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8VXNlclNldHRpbmdzPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0U3RvcmFnZVN0YXRlKCk7XG4gIHJldHVybiBzdGF0ZS5zZXR0aW5ncztcbn1cblxuLyoqXG4gKiBVcGRhdGUgdXNlciBzZXR0aW5ncyBpbiBzdG9yYWdlIChwYXJ0aWFsIG1lcmdlKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHVwZGF0ZXM6IFBhcnRpYWw8VXNlclNldHRpbmdzPik6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IGN1cnJlbnQgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgIGNvbnN0IG1lcmdlZCA9IHsgLi4uY3VycmVudCwgLi4udXBkYXRlcyB9O1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IHNldHRpbmdzOiBtZXJnZWQgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gdXBkYXRlIHNldHRpbmdzOicsIGVycik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSBsaWZldGltZSBwcm90ZWN0aW9uIHN0YXRzIGZyb20gc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExpZmV0aW1lU3RhdHMoKTogUHJvbWlzZTxMaWZldGltZVN0YXRzPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KCdsaWZldGltZVN0YXRzJyk7XG4gICAgcmV0dXJuIHsgLi4uREVGQVVMVF9MSUZFVElNRV9TVEFUUywgLi4uKHJlc3VsdC5saWZldGltZVN0YXRzID8/IHt9KSB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyAuLi5ERUZBVUxUX0xJRkVUSU1FX1NUQVRTIH07XG4gIH1cbn1cblxuLyoqXG4gKiBVcGRhdGUgbGlmZXRpbWUgc3RhdHMgd2l0aCBhbiB1cGRhdGVyIGZ1bmN0aW9uLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTGlmZXRpbWVTdGF0cyhcbiAgdXBkYXRlcjogKHN0YXRzOiBMaWZldGltZVN0YXRzKSA9PiBMaWZldGltZVN0YXRzXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0TGlmZXRpbWVTdGF0cygpO1xuICAgIGNvbnN0IHVwZGF0ZWQgPSB1cGRhdGVyKGN1cnJlbnQpO1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGxpZmV0aW1lU3RhdHM6IHVwZGF0ZWQgfSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIEJlc3QgZWZmb3J0IOKAlCBzdGF0cyBhcmUgbm9uLWNyaXRpY2FsXG4gIH1cbn1cblxuLyoqXG4gKiBDbGVhciBhbGwgc3RvcmVkIGRhdGEuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbFN0b3JhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcignW0FJIEJyb3dzZXIgR3VhcmRdIEZhaWxlZCB0byBjbGVhciBzdG9yYWdlOicsIGVycik7XG4gIH1cbn1cbiIsIi8qKlxuICogU2Vzc2lvbiB0aW1lbGluZSBtYW5hZ2VtZW50LlxuICpcbiAqIE1haW50YWlucyBhIGNocm9ub2xvZ2ljYWwgbG9nIG9mIGFnZW50IGFjdGlvbnMgcGVyIHNlc3Npb24uXG4gKiBFYWNoIGVudHJ5IHJlY29yZHMgd2hhdCBoYXBwZW5lZCwgd2hlcmUsIGFuZCB3aGV0aGVyIGl0IHdhcyBhbGxvd2VkLlxuICovXG5cbmltcG9ydCB0eXBlIHsgQWdlbnRFdmVudCwgQWdlbnRFdmVudFR5cGUgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5pbXBvcnQgdHlwZSB7IEFnZW50U2Vzc2lvbiwgU2Vzc2lvblN1bW1hcnkgfSBmcm9tICcuL3R5cGVzJztcblxuZnVuY3Rpb24gZ2VuZXJhdGVJZCgpOiBzdHJpbmcge1xuICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbn1cblxuLyoqXG4gKiBDcmVhdGUgYSBuZXcgdGltZWxpbmUgZXZlbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUaW1lbGluZUV2ZW50KFxuICB0eXBlOiBBZ2VudEV2ZW50VHlwZSxcbiAgdXJsOiBzdHJpbmcsXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmcsXG4gIG9wdGlvbnM/OiB7XG4gICAgdGFyZ2V0U2VsZWN0b3I/OiBzdHJpbmc7XG4gICAgYXR0ZW1wdGVkQWN0aW9uPzogQWdlbnRDYXBhYmlsaXR5O1xuICAgIG91dGNvbWU/OiAnYWxsb3dlZCcgfCAnYmxvY2tlZCcgfCAnaW5mb3JtYXRpb25hbCc7XG4gICAgcnVsZUlkPzogc3RyaW5nO1xuICB9XG4pOiBBZ2VudEV2ZW50IHtcbiAgcmV0dXJuIHtcbiAgICBpZDogZ2VuZXJhdGVJZCgpLFxuICAgIHR5cGUsXG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdXJsLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIG91dGNvbWU6IG9wdGlvbnM/Lm91dGNvbWUgPz8gJ2luZm9ybWF0aW9uYWwnLFxuICAgIHRhcmdldFNlbGVjdG9yOiBvcHRpb25zPy50YXJnZXRTZWxlY3RvcixcbiAgICBhdHRlbXB0ZWRBY3Rpb246IG9wdGlvbnM/LmF0dGVtcHRlZEFjdGlvbixcbiAgICBydWxlSWQ6IG9wdGlvbnM/LnJ1bGVJZCxcbiAgfTtcbn1cblxuLyoqXG4gKiBBcHBlbmQgYW4gZXZlbnQgdG8gYSBzZXNzaW9uJ3MgdGltZWxpbmUgYW5kIHJlY2FsY3VsYXRlIHN1bW1hcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhcHBlbmRFdmVudFRvU2Vzc2lvbihcbiAgc2Vzc2lvbjogQWdlbnRTZXNzaW9uLFxuICBldmVudDogQWdlbnRFdmVudFxuKTogQWdlbnRTZXNzaW9uIHtcbiAgY29uc3QgZXZlbnRzID0gWy4uLnNlc3Npb24uZXZlbnRzLCBldmVudF07XG4gIGNvbnN0IHN1bW1hcnkgPSBjb21wdXRlU2Vzc2lvblN1bW1hcnkoZXZlbnRzLCBzZXNzaW9uLnN0YXJ0ZWRBdCk7XG4gIHJldHVybiB7IC4uLnNlc3Npb24sIGV2ZW50cywgc3VtbWFyeSB9O1xufVxuXG4vKipcbiAqIENvbXB1dGUgc3VtbWFyeSBzdGF0aXN0aWNzIGZyb20gYSBzZXNzaW9uJ3MgZXZlbnQgdGltZWxpbmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21wdXRlU2Vzc2lvblN1bW1hcnkoXG4gIGV2ZW50czogQWdlbnRFdmVudFtdLFxuICBzdGFydGVkQXQ6IHN0cmluZ1xuKTogU2Vzc2lvblN1bW1hcnkge1xuICBsZXQgdG90YWxBY3Rpb25zID0gMDtcbiAgbGV0IGFsbG93ZWRBY3Rpb25zID0gMDtcbiAgbGV0IGJsb2NrZWRBY3Rpb25zID0gMDtcbiAgbGV0IHZpb2xhdGlvbnMgPSAwO1xuICBjb25zdCB1cmxDb3VudHMgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpO1xuXG4gIGZvciAoY29uc3QgZXZlbnQgb2YgZXZlbnRzKSB7XG4gICAgaWYgKGV2ZW50Lm91dGNvbWUgPT09ICdhbGxvd2VkJykge1xuICAgICAgdG90YWxBY3Rpb25zKys7XG4gICAgICBhbGxvd2VkQWN0aW9ucysrO1xuICAgIH0gZWxzZSBpZiAoZXZlbnQub3V0Y29tZSA9PT0gJ2Jsb2NrZWQnKSB7XG4gICAgICB0b3RhbEFjdGlvbnMrKztcbiAgICAgIGJsb2NrZWRBY3Rpb25zKys7XG4gICAgfVxuICAgIGlmIChldmVudC50eXBlID09PSAnYm91bmRhcnktdmlvbGF0aW9uJykge1xuICAgICAgdmlvbGF0aW9ucysrO1xuICAgIH1cbiAgICBpZiAoZXZlbnQudXJsKSB7XG4gICAgICB1cmxDb3VudHMuc2V0KGV2ZW50LnVybCwgKHVybENvdW50cy5nZXQoZXZlbnQudXJsKSA/PyAwKSArIDEpO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRvcFVybHMgPSBbLi4udXJsQ291bnRzLmVudHJpZXMoKV1cbiAgICAuc29ydCgoYSwgYikgPT4gYlsxXSAtIGFbMV0pXG4gICAgLnNsaWNlKDAsIDUpXG4gICAgLm1hcCgoW3VybF0pID0+IHVybCk7XG5cbiAgbGV0IGR1cmF0aW9uU2Vjb25kczogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gIGlmIChldmVudHMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGxhc3RFdmVudCA9IGV2ZW50c1tldmVudHMubGVuZ3RoIC0gMV07XG4gICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZShzdGFydGVkQXQpLmdldFRpbWUoKTtcbiAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShsYXN0RXZlbnQudGltZXN0YW1wKS5nZXRUaW1lKCk7XG4gICAgZHVyYXRpb25TZWNvbmRzID0gTWF0aC5yb3VuZCgoZW5kIC0gc3RhcnQpIC8gMTAwMCk7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHRvdGFsQWN0aW9ucyxcbiAgICBhbGxvd2VkQWN0aW9ucyxcbiAgICBibG9ja2VkQWN0aW9ucyxcbiAgICB2aW9sYXRpb25zLFxuICAgIHRvcFVybHMsXG4gICAgZHVyYXRpb25TZWNvbmRzLFxuICB9O1xufVxuXG4vKipcbiAqIEZpbHRlciB0aW1lbGluZSBldmVudHMgYnkgdHlwZSwgVVJMLCBvciBvdXRjb21lLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyVGltZWxpbmVFdmVudHMoXG4gIGV2ZW50czogQWdlbnRFdmVudFtdLFxuICBmaWx0ZXJzOiB7XG4gICAgdHlwZT86IEFnZW50RXZlbnRUeXBlO1xuICAgIHVybD86IHN0cmluZztcbiAgICBvdXRjb21lPzogJ2FsbG93ZWQnIHwgJ2Jsb2NrZWQnIHwgJ2luZm9ybWF0aW9uYWwnO1xuICB9XG4pOiBBZ2VudEV2ZW50W10ge1xuICByZXR1cm4gZXZlbnRzLmZpbHRlcigoZXZlbnQpID0+IHtcbiAgICBpZiAoZmlsdGVycy50eXBlICE9PSB1bmRlZmluZWQgJiYgZXZlbnQudHlwZSAhPT0gZmlsdGVycy50eXBlKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGZpbHRlcnMudXJsICE9PSB1bmRlZmluZWQgJiYgZXZlbnQudXJsICE9PSBmaWx0ZXJzLnVybCkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChmaWx0ZXJzLm91dGNvbWUgIT09IHVuZGVmaW5lZCAmJiBldmVudC5vdXRjb21lICE9PSBmaWx0ZXJzLm91dGNvbWUpIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG59XG5cbi8qKlxuICogR2V0IHRoZSBtb3N0IHJlY2VudCBOIGV2ZW50cywgbmV3ZXN0IGZpcnN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0UmVjZW50RXZlbnRzKGV2ZW50czogQWdlbnRFdmVudFtdLCBjb3VudDogbnVtYmVyKTogQWdlbnRFdmVudFtdIHtcbiAgcmV0dXJuIGV2ZW50cy5zbGljZSgtY291bnQpLnJldmVyc2UoKTtcbn1cbiIsIi8qKlxuICogRGVsZWdhdGlvbiBydWxlIGVuZ2luZS5cbiAqXG4gKiBFdmFsdWF0ZXMgZGVsZWdhdGlvbiBydWxlcyB0byBkZXRlcm1pbmUgd2hhdCBhY3Rpb25zIGFuIGFnZW50IGlzXG4gKiBwZXJtaXR0ZWQgdG8gcGVyZm9ybS4gU3VwcG9ydHMgc2l0ZSBwYXR0ZXJucywgYWN0aW9uIHJlc3RyaWN0aW9ucyxcbiAqIGFuZCB0aW1lIGJvdW5kcy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7XG4gIERlbGVnYXRpb25SdWxlLFxuICBEZWxlZ2F0aW9uUHJlc2V0LFxuICBEZWxlZ2F0aW9uU2NvcGUsXG4gIERlbGVnYXRpb25Ub2tlbixcbiAgU2l0ZVBhdHRlcm4sXG4gIEFjdGlvblJlc3RyaWN0aW9uLFxuICBUaW1lQm91bmQsXG59IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSWQoKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKCk7XG59XG5cbmNvbnN0IFJFQURfT05MWV9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbSddO1xuY29uc3QgTElNSVRFRF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gWyduYXZpZ2F0ZScsICdyZWFkLWRvbScsICdjbGljaycsICd0eXBlLXRleHQnXTtcbmNvbnN0IEFMTF9DQVBBQklMSVRJRVM6IEFnZW50Q2FwYWJpbGl0eVtdID0gW1xuICAnbmF2aWdhdGUnLCAncmVhZC1kb20nLCAnY2xpY2snLCAndHlwZS10ZXh0JywgJ3N1Ym1pdC1mb3JtJyxcbiAgJ2Rvd25sb2FkLWZpbGUnLCAnb3Blbi10YWInLCAnY2xvc2UtdGFiJywgJ3NjcmVlbnNob3QnLFxuICAnZXhlY3V0ZS1zY3JpcHQnLCAnbW9kaWZ5LWRvbScsXG5dO1xuXG5mdW5jdGlvbiBidWlsZEFjdGlvblJlc3RyaWN0aW9ucyhhbGxvd2VkOiBBZ2VudENhcGFiaWxpdHlbXSk6IEFjdGlvblJlc3RyaWN0aW9uW10ge1xuICByZXR1cm4gQUxMX0NBUEFCSUxJVElFUy5tYXAoKGNhcCkgPT4gKHtcbiAgICBjYXBhYmlsaXR5OiBjYXAsXG4gICAgYWN0aW9uOiBhbGxvd2VkLmluY2x1ZGVzKGNhcCkgPyAnYWxsb3cnIGFzIGNvbnN0IDogJ2Jsb2NrJyBhcyBjb25zdCxcbiAgfSkpO1xufVxuXG4vKipcbiAqIENyZWF0ZSBhIGRlbGVnYXRpb24gcnVsZSBmcm9tIGEgcHJlc2V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUnVsZUZyb21QcmVzZXQoXG4gIHByZXNldDogRGVsZWdhdGlvblByZXNldCxcbiAgb3B0aW9ucz86IHtcbiAgICBzaXRlUGF0dGVybnM/OiBTaXRlUGF0dGVybltdO1xuICAgIGR1cmF0aW9uTWludXRlcz86IG51bWJlcjtcbiAgICBsYWJlbD86IHN0cmluZztcbiAgfVxuKTogRGVsZWdhdGlvblJ1bGUge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICBsZXQgc2NvcGU6IERlbGVnYXRpb25TY29wZTtcblxuICBzd2l0Y2ggKHByZXNldCkge1xuICAgIGNhc2UgJ3JlYWRPbmx5JzpcbiAgICAgIHNjb3BlID0ge1xuICAgICAgICBzaXRlUGF0dGVybnM6IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKFJFQURfT05MWV9DQVBBQklMSVRJRVMpLFxuICAgICAgICB0aW1lQm91bmQ6IG51bGwsXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG5cbiAgICBjYXNlICdsaW1pdGVkJzoge1xuICAgICAgY29uc3QgZHVyYXRpb25NaW51dGVzID0gb3B0aW9ucz8uZHVyYXRpb25NaW51dGVzID8/IDYwO1xuICAgICAgY29uc3QgZXhwaXJlc0F0ID0gbmV3IERhdGUobm93LmdldFRpbWUoKSArIGR1cmF0aW9uTWludXRlcyAqIDYwMDAwKTtcbiAgICAgIGNvbnN0IHRpbWVCb3VuZDogVGltZUJvdW5kID0ge1xuICAgICAgICBkdXJhdGlvbk1pbnV0ZXMsXG4gICAgICAgIGdyYW50ZWRBdDogbm93LnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGV4cGlyZXNBdDogZXhwaXJlc0F0LnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogb3B0aW9ucz8uc2l0ZVBhdHRlcm5zID8/IFtdLFxuICAgICAgICBhY3Rpb25SZXN0cmljdGlvbnM6IGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKExJTUlURURfQ0FQQUJJTElUSUVTKSxcbiAgICAgICAgdGltZUJvdW5kLFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGNhc2UgJ2Z1bGxBY2Nlc3MnOlxuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogW10sXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogYnVpbGRBY3Rpb25SZXN0cmljdGlvbnMoQUxMX0NBUEFCSUxJVElFUyksXG4gICAgICAgIHRpbWVCb3VuZDogbnVsbCxcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGdlbmVyYXRlSWQoKSxcbiAgICBwcmVzZXQsXG4gICAgc2NvcGUsXG4gICAgY3JlYXRlZEF0OiBub3cudG9JU09TdHJpbmcoKSxcbiAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICBsYWJlbDogb3B0aW9ucz8ubGFiZWwsXG4gIH07XG59XG5cbi8qKlxuICogRXZhbHVhdGUgd2hldGhlciBhbiBhY3Rpb24gaXMgYWxsb3dlZCB1bmRlciBhIGRlbGVnYXRpb24gcnVsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV2YWx1YXRlUnVsZShcbiAgcnVsZTogRGVsZWdhdGlvblJ1bGUsXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICB1cmw6IHN0cmluZ1xuKTogeyBhbGxvd2VkOiBib29sZWFuOyByZWFzb246IHN0cmluZyB9IHtcbiAgaWYgKCFydWxlLmlzQWN0aXZlKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gcnVsZSBpcyBub3QgYWN0aXZlLicgfTtcbiAgfVxuXG4gIGlmIChpc1RpbWVCb3VuZEV4cGlyZWQocnVsZS5zY29wZS50aW1lQm91bmQpKSB7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogJ0RlbGVnYXRpb24gaGFzIGV4cGlyZWQuJyB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgc2l0ZSBwYXR0ZXJuc1xuICBjb25zdCBkZWZhdWx0U2l0ZUFjdGlvbiA9IHJ1bGUucHJlc2V0ID09PSAnbGltaXRlZCcgPyAnYmxvY2snIGFzIGNvbnN0IDogJ2FsbG93JyBhcyBjb25zdDtcbiAgY29uc3Qgc2l0ZVJlc3VsdCA9IGV2YWx1YXRlU2l0ZVBhdHRlcm5zKHVybCwgcnVsZS5zY29wZS5zaXRlUGF0dGVybnMsIGRlZmF1bHRTaXRlQWN0aW9uKTtcbiAgaWYgKCFzaXRlUmVzdWx0LmFsbG93ZWQpIHtcbiAgICBjb25zdCBwYXR0ZXJuRGV0YWlsID0gc2l0ZVJlc3VsdC5tYXRjaGVkUGF0dGVyblxuICAgICAgPyBgIChtYXRjaGVkOiAke3NpdGVSZXN1bHQubWF0Y2hlZFBhdHRlcm4ucGF0dGVybn0pYFxuICAgICAgOiAnIChkZWZhdWx0IHBvbGljeSknO1xuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCByZWFzb246IGBVUkwgYmxvY2tlZCBieSBzaXRlIHBvbGljeSR7cGF0dGVybkRldGFpbH0uYCB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgYWN0aW9uIHJlc3RyaWN0aW9uc1xuICBjb25zdCBhY3Rpb25SZXN1bHQgPSBldmFsdWF0ZUFjdGlvblJlc3RyaWN0aW9ucyhhY3Rpb24sIHJ1bGUuc2NvcGUuYWN0aW9uUmVzdHJpY3Rpb25zKTtcbiAgaWYgKCFhY3Rpb25SZXN1bHQuYWxsb3dlZCkge1xuICAgIHJldHVybiB7XG4gICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgIHJlYXNvbjogYEFjdGlvbiBcIiR7YWN0aW9ufVwiIGlzIG5vdCBwZXJtaXR0ZWQgdW5kZXIgJHtydWxlLnByZXNldH0gZGVsZWdhdGlvbi5gLFxuICAgIH07XG4gIH1cblxuICByZXR1cm4geyBhbGxvd2VkOiB0cnVlLCByZWFzb246ICdBY3Rpb24gcGVybWl0dGVkIGJ5IGRlbGVnYXRpb24gcnVsZXMuJyB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgVVJMIG1hdGNoZXMgYW55IHNpdGUgcGF0dGVybiBpbiB0aGUgc2NvcGUuXG4gKiBGaXJzdCBtYXRjaCB3aW5zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVTaXRlUGF0dGVybnMoXG4gIHVybDogc3RyaW5nLFxuICBwYXR0ZXJuczogU2l0ZVBhdHRlcm5bXSxcbiAgZGVmYXVsdEFjdGlvbjogJ2FsbG93JyB8ICdibG9jaydcbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFBhdHRlcm46IFNpdGVQYXR0ZXJuIHwgbnVsbCB9IHtcbiAgZm9yIChjb25zdCBwYXR0ZXJuIG9mIHBhdHRlcm5zKSB7XG4gICAgaWYgKG1hdGNoR2xvYih1cmwsIHBhdHRlcm4ucGF0dGVybikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGFsbG93ZWQ6IHBhdHRlcm4uYWN0aW9uID09PSAnYWxsb3cnLFxuICAgICAgICBtYXRjaGVkUGF0dGVybjogcGF0dGVybixcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB7IGFsbG93ZWQ6IGRlZmF1bHRBY3Rpb24gPT09ICdhbGxvdycsIG1hdGNoZWRQYXR0ZXJuOiBudWxsIH07XG59XG5cbi8qKlxuICogTWF0Y2ggYSBVUkwgYWdhaW5zdCBhIGdsb2IgcGF0dGVybi5cbiAqL1xuZnVuY3Rpb24gbWF0Y2hHbG9iKHVybDogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgdHJ5IHtcbiAgICAvLyBJZiBwYXR0ZXJuIGRvZXNuJ3QgY29udGFpbiBwcm90b2NvbCwgbWF0Y2ggYWdhaW5zdCBob3N0bmFtZVxuICAgIGlmICghcGF0dGVybi5pbmNsdWRlcygnOi8vJykpIHtcbiAgICAgIGNvbnN0IHBhcnNlZFVybCA9IG5ldyBVUkwodXJsKTtcbiAgICAgIGNvbnN0IGhvc3RuYW1lID0gcGFyc2VkVXJsLmhvc3RuYW1lO1xuICAgICAgLy8gQ29udmVydCBnbG9iIHRvIHJlZ2V4OiAqIG1hdGNoZXMgYW55IGNoYXJhY3RlcnMgZXhjZXB0IGRvdHMgaW4gZG9tYWluIGNvbnRleHRcbiAgICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgICAucmVwbGFjZSgvXFwuL2csICdcXFxcLicpXG4gICAgICAgIC5yZXBsYWNlKC9cXCpcXCovZywgJy4qJylcbiAgICAgICAgLnJlcGxhY2UoL1xcKi9nLCAnW14uXSonKTtcbiAgICAgIHJldHVybiBuZXcgUmVnRXhwKGBeJHtyZWdleFN0cn0kYCkudGVzdChob3N0bmFtZSk7XG4gICAgfVxuXG4gICAgLy8gRnVsbCBVUkwgcGF0dGVybiBtYXRjaGluZ1xuICAgIGNvbnN0IHJlZ2V4U3RyID0gcGF0dGVyblxuICAgICAgLnJlcGxhY2UoL1suK14ke30oKXxbXFxdXFxcXF0vZywgJ1xcXFwkJicpXG4gICAgICAucmVwbGFjZSgvXFxcXFxcKi9nLCAnLionKTtcbiAgICByZXR1cm4gbmV3IFJlZ0V4cChgXiR7cmVnZXhTdHJ9JGApLnRlc3QodXJsKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYW4gYWN0aW9uIGlzIGFsbG93ZWQgYnkgdGhlIGFjdGlvbiByZXN0cmljdGlvbiBsaXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVBY3Rpb25SZXN0cmljdGlvbnMoXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICByZXN0cmljdGlvbnM6IEFjdGlvblJlc3RyaWN0aW9uW11cbik6IHsgYWxsb3dlZDogYm9vbGVhbjsgbWF0Y2hlZFJlc3RyaWN0aW9uOiBBY3Rpb25SZXN0cmljdGlvbiB8IG51bGwgfSB7XG4gIGNvbnN0IHJlc3RyaWN0aW9uID0gcmVzdHJpY3Rpb25zLmZpbmQoKHIpID0+IHIuY2FwYWJpbGl0eSA9PT0gYWN0aW9uKTtcbiAgaWYgKCFyZXN0cmljdGlvbikge1xuICAgIC8vIERlZmF1bHQtYmxvY2sgaWYgbm90IGxpc3RlZFxuICAgIHJldHVybiB7IGFsbG93ZWQ6IGZhbHNlLCBtYXRjaGVkUmVzdHJpY3Rpb246IG51bGwgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGFsbG93ZWQ6IHJlc3RyaWN0aW9uLmFjdGlvbiA9PT0gJ2FsbG93JyxcbiAgICBtYXRjaGVkUmVzdHJpY3Rpb246IHJlc3RyaWN0aW9uLFxuICB9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIGEgdGltZSBib3VuZCBoYXMgZXhwaXJlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzVGltZUJvdW5kRXhwaXJlZCh0aW1lQm91bmQ6IFRpbWVCb3VuZCB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKHRpbWVCb3VuZCA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCkgPiBuZXcgRGF0ZSh0aW1lQm91bmQuZXhwaXJlc0F0KS5nZXRUaW1lKCk7XG59XG5cbi8qKlxuICogSXNzdWUgYSBkZWxlZ2F0aW9uIHRva2VuIGZvciBhbiBhZ2VudCBzZXNzaW9uIChsb2NhbC1vbmx5LCBsb2NhbC1vbmx5LCB1bnNpZ25lZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc3N1ZVRva2VuKFxuICBydWxlSWQ6IHN0cmluZyxcbiAgYWdlbnRJZDogc3RyaW5nLFxuICBzY29wZTogRGVsZWdhdGlvblNjb3BlLFxuICBleHBpcmVzQXQ6IHN0cmluZ1xuKTogRGVsZWdhdGlvblRva2VuIHtcbiAgcmV0dXJuIHtcbiAgICB0b2tlbklkOiBnZW5lcmF0ZUlkKCksXG4gICAgcnVsZUlkLFxuICAgIGFnZW50SWQsXG4gICAgc2NvcGUsXG4gICAgaXNzdWVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBleHBpcmVzQXQsXG4gICAgcmV2b2tlZDogZmFsc2UsXG4gIH07XG59XG5cbi8qKlxuICogUmV2b2tlIGEgZGVsZWdhdGlvbiB0b2tlbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJldm9rZVRva2VuKHRva2VuOiBEZWxlZ2F0aW9uVG9rZW4pOiBEZWxlZ2F0aW9uVG9rZW4ge1xuICByZXR1cm4geyAuLi50b2tlbiwgcmV2b2tlZDogdHJ1ZSB9O1xufVxuIiwiLyoqXG4gKiBFbWVyZ2VuY3kga2lsbCBzd2l0Y2ggbW9kdWxlLlxuICpcbiAqIFByb3ZpZGVzIG9uZS1jbGljayByZXZvY2F0aW9uIG9mIGFsbCBhZ2VudCBhY2Nlc3MuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBLaWxsU3dpdGNoRXZlbnQgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uVG9rZW4gfSBmcm9tICcuLi90eXBlcy9kZWxlZ2F0aW9uJztcbmltcG9ydCB7IHJldm9rZVRva2VuIH0gZnJvbSAnLi4vZGVsZWdhdGlvbi9ydWxlcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgS2lsbFN3aXRjaFN0YXRlIHtcbiAgaXNBY3RpdmU6IGJvb2xlYW47XG4gIGxhc3RFdmVudDogS2lsbFN3aXRjaEV2ZW50IHwgbnVsbDtcbiAgbGFzdEFjdGl2YXRlZEF0OiBzdHJpbmcgfCBudWxsO1xufVxuXG4vLyBUcmFjayBjbGVhbnVwIGZ1bmN0aW9ucyByZWdpc3RlcmVkIGJ5IGNvbnRlbnQtc2lkZSBtb2R1bGVzXG5jb25zdCByZWdpc3RlcmVkQ2xlYW51cHM6IEFycmF5PCgpID0+IHZvaWQ+ID0gW107XG5cbi8qKlxuICogUmVnaXN0ZXIgYSBjbGVhbnVwIGZ1bmN0aW9uIHRvIGJlIGNhbGxlZCBkdXJpbmcga2lsbCBzd2l0Y2ggZXhlY3V0aW9uLlxuICogVXNlZCBieSBkZXRlY3RvciBhbmQgbW9uaXRvciBtb2R1bGVzIHRvIHJlZ2lzdGVyIHRoZWlyIHRlYXJkb3duIGxvZ2ljLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJDbGVhbnVwKGNsZWFudXA6ICgpID0+IHZvaWQpOiB2b2lkIHtcbiAgcmVnaXN0ZXJlZENsZWFudXBzLnB1c2goY2xlYW51cCk7XG59XG5cbi8qKlxuICogRXhlY3V0ZSB0aGUga2lsbCBzd2l0Y2ggZnJvbSB0aGUgY29udGVudCBzY3JpcHQgc2lkZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4ZWN1dGVDb250ZW50S2lsbFN3aXRjaCgpOiB7XG4gIGxpc3RlbmVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgb2JzZXJ2ZXJzRGlzY29ubmVjdGVkOiBudW1iZXI7XG4gIGJpbmRpbmdzQ2xlYXJlZDogc3RyaW5nW107XG59IHtcbiAgbGV0IGxpc3RlbmVyc1JlbW92ZWQgPSAwO1xuICBsZXQgb2JzZXJ2ZXJzRGlzY29ubmVjdGVkID0gMDtcblxuICAvLyBDYWxsIGFsbCByZWdpc3RlcmVkIGNsZWFudXAgZnVuY3Rpb25zXG4gIGZvciAoY29uc3QgY2xlYW51cCBvZiByZWdpc3RlcmVkQ2xlYW51cHMpIHtcbiAgICB0cnkge1xuICAgICAgY2xlYW51cCgpO1xuICAgICAgbGlzdGVuZXJzUmVtb3ZlZCsrO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gQmVzdCBlZmZvcnRcbiAgICB9XG4gIH1cbiAgcmVnaXN0ZXJlZENsZWFudXBzLmxlbmd0aCA9IDA7XG5cbiAgLy8gQ2xlYXIgYXV0b21hdGlvbiBiaW5kaW5nc1xuICBjb25zdCBiaW5kaW5nc0NsZWFyZWQgPSBjbGVhckF1dG9tYXRpb25GbGFncygpO1xuXG4gIC8vIEF0dGVtcHQgQ0RQIHRlcm1pbmF0aW9uXG4gIHRlcm1pbmF0ZUNkcENvbm5lY3Rpb25zKCk7XG5cbiAgcmV0dXJuIHsgbGlzdGVuZXJzUmVtb3ZlZCwgb2JzZXJ2ZXJzRGlzY29ubmVjdGVkLCBiaW5kaW5nc0NsZWFyZWQgfTtcbn1cblxuLyoqXG4gKiBFeGVjdXRlIHRoZSBraWxsIHN3aXRjaCBmcm9tIHRoZSBiYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIHNpZGUuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleGVjdXRlQmFja2dyb3VuZEtpbGxTd2l0Y2goXG4gIHRyaWdnZXI6ICdidXR0b24nIHwgJ2tleWJvYXJkLXNob3J0Y3V0JyB8ICdhcGknLFxuICBhY3RpdmVBZ2VudElkczogc3RyaW5nW10sXG4gIGFjdGl2ZVRva2VuczogRGVsZWdhdGlvblRva2VuW11cbik6IFByb21pc2U8S2lsbFN3aXRjaEV2ZW50PiB7XG4gIGNvbnN0IHJldm9rZWRUb2tlbklkczogc3RyaW5nW10gPSBbXTtcblxuICAvLyBSZXZva2UgYWxsIHRva2Vuc1xuICBmb3IgKGNvbnN0IHRva2VuIG9mIGFjdGl2ZVRva2Vucykge1xuICAgIHJldm9rZVRva2VuKHRva2VuKTtcbiAgICByZXZva2VkVG9rZW5JZHMucHVzaCh0b2tlbi50b2tlbklkKTtcbiAgfVxuXG4gIC8vIFNlbmQga2lsbCBjb21tYW5kIHRvIGFsbCB0YWJzXG4gIGxldCBjZHBUZXJtaW5hdGVkID0gZmFsc2U7XG4gIGxldCBhdXRvbWF0aW9uRmxhZ3NDbGVhcmVkID0gZmFsc2U7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHt9KTtcbiAgICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgICBpZiAodGFiLmlkID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgdHlwZTogJ0tJTExfU1dJVENIX0FDVElWQVRFJyxcbiAgICAgICAgICBkYXRhOiB7fSxcbiAgICAgICAgICBzZW50QXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gVGFiIG1heSBub3QgaGF2ZSBjb250ZW50IHNjcmlwdFxuICAgICAgfVxuICAgIH1cbiAgICBjZHBUZXJtaW5hdGVkID0gdHJ1ZTtcbiAgICBhdXRvbWF0aW9uRmxhZ3NDbGVhcmVkID0gdHJ1ZTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gQmVzdCBlZmZvcnRcbiAgfVxuXG4gIGNvbnN0IGV2ZW50OiBLaWxsU3dpdGNoRXZlbnQgPSB7XG4gICAgaWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdHJpZ2dlcixcbiAgICB0ZXJtaW5hdGVkQWdlbnRJZHM6IFsuLi5hY3RpdmVBZ2VudElkc10sXG4gICAgcmV2b2tlZFRva2VuSWRzLFxuICAgIGNkcFRlcm1pbmF0ZWQsXG4gICAgYXV0b21hdGlvbkZsYWdzQ2xlYXJlZCxcbiAgfTtcblxuICAvLyBTaG93IG5vdGlmaWNhdGlvblxuICBzaG93S2lsbFN3aXRjaE5vdGlmaWNhdGlvbihhY3RpdmVBZ2VudElkcy5sZW5ndGgpO1xuXG4gIHJldHVybiBldmVudDtcbn1cblxuLyoqXG4gKiBBdHRlbXB0IHRvIHRlcm1pbmF0ZSBDRFAgY29ubmVjdGlvbnMgKGJlc3QtZWZmb3J0IGZyb20gY29udGVudCBzY3JpcHQpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdGVybWluYXRlQ2RwQ29ubmVjdGlvbnMoKTogYm9vbGVhbiB7XG4gIHRyeSB7XG4gICAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gICAgbGV0IGZvdW5kID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBrZXkgb2Ygd2luZG93S2V5cykge1xuICAgICAgaWYgKFxuICAgICAgICBrZXkuc3RhcnRzV2l0aCgnX19jZHBfJykgfHxcbiAgICAgICAga2V5LnN0YXJ0c1dpdGgoJ19fY2hyb21pdW1fJylcbiAgICAgICkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGRlbGV0ZSAod2luZG93IGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW2tleV07XG4gICAgICAgICAgZm91bmQgPSB0cnVlO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvLyBQcm9wZXJ0eSBtYXkgbm90IGJlIGRlbGV0YWJsZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmb3VuZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKlxuICogQ2xlYXIgYXV0b21hdGlvbiBmbGFncyBmcm9tIHRoZSBjdXJyZW50IHBhZ2UgY29udGV4dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyQXV0b21hdGlvbkZsYWdzKCk6IHN0cmluZ1tdIHtcbiAgY29uc3QgY2xlYXJlZDogc3RyaW5nW10gPSBbXTtcblxuICAvLyBUcnkgdG8gY2xlYXIgbmF2aWdhdG9yLndlYmRyaXZlclxuICB0cnkge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShuYXZpZ2F0b3IsICd3ZWJkcml2ZXInLCB7XG4gICAgICBnZXQ6ICgpID0+IGZhbHNlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIH0pO1xuICAgIGNsZWFyZWQucHVzaCgnbmF2aWdhdG9yLndlYmRyaXZlcicpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBNYXkgbm90IGJlIHdyaXRhYmxlXG4gIH1cblxuICAvLyBDbGVhciBTZWxlbml1bSBtYXJrZXJzXG4gIGNvbnN0IGRvY0tleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhkb2N1bWVudCk7XG4gIGZvciAoY29uc3Qga2V5IG9mIGRvY0tleXMpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJyRjZGNfJykgfHwga2V5LnN0YXJ0c1dpdGgoJyR3ZGNfJykpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGRlbGV0ZSAoZG9jdW1lbnQgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilba2V5XTtcbiAgICAgICAgY2xlYXJlZC5wdXNoKGtleSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gQmVzdCBlZmZvcnRcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBDbGVhciBQbGF5d3JpZ2h0IGFuZCBQdXBwZXRlZXIgYmluZGluZ3NcbiAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gIGNvbnN0IGF1dG9tYXRpb25QcmVmaXhlcyA9IFsnX19wbGF5d3JpZ2h0JywgJ19fcHVwcGV0ZWVyJywgJ19fcHdfJ107XG4gIGZvciAoY29uc3Qga2V5IG9mIHdpbmRvd0tleXMpIHtcbiAgICBpZiAoYXV0b21hdGlvblByZWZpeGVzLnNvbWUoKHByZWZpeCkgPT4ga2V5LnN0YXJ0c1dpdGgocHJlZml4KSkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGRlbGV0ZSAod2luZG93IGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW2tleV07XG4gICAgICAgIGNsZWFyZWQucHVzaChrZXkpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIEJlc3QgZWZmb3J0XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNsZWFyZWQ7XG59XG5cbi8qKlxuICogU2hvdyBhIENocm9tZSBub3RpZmljYXRpb24gY29uZmlybWluZyBraWxsIHN3aXRjaCBhY3RpdmF0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2hvd0tpbGxTd2l0Y2hOb3RpZmljYXRpb24oYWdlbnRDb3VudDogbnVtYmVyKTogdm9pZCB7XG4gIHRyeSB7XG4gICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY3JlYXRlKGBhYmcta2lsbHN3aXRjaC0ke0RhdGUubm93KCl9YCwge1xuICAgICAgdHlwZTogJ2Jhc2ljJyxcbiAgICAgIGljb25Vcmw6IGNocm9tZS5ydW50aW1lLmdldFVSTCgnaWNvbnMvaWNvbjEyOC5wbmcnKSxcbiAgICAgIHRpdGxlOiAnQUkgQnJvd3NlciBHdWFyZCAtIEtpbGwgU3dpdGNoIEFjdGl2YXRlZCcsXG4gICAgICBtZXNzYWdlOiBgVGVybWluYXRlZCAke2FnZW50Q291bnR9IGFnZW50IHNlc3Npb24ocykuIEFsbCBkZWxlZ2F0aW9ucyByZXZva2VkLmAsXG4gICAgICBwcmlvcml0eTogMixcbiAgICB9KTtcblxuICAgIC8vIEF1dG8tZGlzbWlzcyBhZnRlciA1IHNlY29uZHNcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNocm9tZS5ub3RpZmljYXRpb25zLmdldEFsbCgobm90aWZpY2F0aW9ucykgPT4ge1xuICAgICAgICAgIGZvciAoY29uc3QgaWQgb2YgT2JqZWN0LmtleXMobm90aWZpY2F0aW9ucykpIHtcbiAgICAgICAgICAgIGlmIChpZC5zdGFydHNXaXRoKCdhYmcta2lsbHN3aXRjaC0nKSkge1xuICAgICAgICAgICAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jbGVhcihpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBJZ25vcmVcbiAgICAgIH1cbiAgICB9LCA1MDAwKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gTm90aWZpY2F0aW9ucyBtYXkgbm90IGJlIGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdCBjb250ZXh0XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGUgdGhlIGluaXRpYWwga2lsbCBzd2l0Y2ggc3RhdGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVJbml0aWFsS2lsbFN3aXRjaFN0YXRlKCk6IEtpbGxTd2l0Y2hTdGF0ZSB7XG4gIHJldHVybiB7XG4gICAgaXNBY3RpdmU6IGZhbHNlLFxuICAgIGxhc3RFdmVudDogbnVsbCxcbiAgICBsYXN0QWN0aXZhdGVkQXQ6IG51bGwsXG4gIH07XG59XG4iLCIvKipcbiAqIENocm9tZSBub3RpZmljYXRpb24gaW50ZWdyYXRpb24gZm9yIGJvdW5kYXJ5IGFsZXJ0cy5cbiAqXG4gKiBEZWxpdmVycyBzeXN0ZW0tbGV2ZWwgbm90aWZpY2F0aW9ucyB3aGVuIGFnZW50cyB2aW9sYXRlIGRlbGVnYXRpb25cbiAqIGJvdW5kYXJpZXMuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBCb3VuZGFyeUFsZXJ0LCBBbGVydFNldmVyaXR5IH0gZnJvbSAnLi9ib3VuZGFyeSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTm90aWZpY2F0aW9uQ29uZmlnIHtcbiAgZW5hYmxlZDogYm9vbGVhbjtcbiAgbWluaW11bVNldmVyaXR5OiBBbGVydFNldmVyaXR5O1xuICBwbGF5U291bmQ6IGJvb2xlYW47XG4gIGF1dG9EaXNtaXNzTXM6IG51bWJlcjtcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfTk9USUZJQ0FUSU9OX0NPTkZJRzogTm90aWZpY2F0aW9uQ29uZmlnID0ge1xuICBlbmFibGVkOiB0cnVlLFxuICBtaW5pbXVtU2V2ZXJpdHk6ICdtZWRpdW0nLFxuICBwbGF5U291bmQ6IHRydWUsXG4gIGF1dG9EaXNtaXNzTXM6IDEwMDAwLFxufTtcblxuLyoqXG4gKiBTaG93IGEgQ2hyb21lIG5vdGlmaWNhdGlvbiBmb3IgYSBib3VuZGFyeSBhbGVydC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNob3dCb3VuZGFyeU5vdGlmaWNhdGlvbihcbiAgYWxlcnQ6IEJvdW5kYXJ5QWxlcnQsXG4gIGNvbmZpZz86IFBhcnRpYWw8Tm90aWZpY2F0aW9uQ29uZmlnPlxuKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IG1lcmdlZENvbmZpZyA9IHsgLi4uREVGQVVMVF9OT1RJRklDQVRJT05fQ09ORklHLCAuLi5jb25maWcgfTtcblxuICBpZiAoIW1lcmdlZENvbmZpZy5lbmFibGVkKSByZXR1cm4gbnVsbDtcbiAgaWYgKCFtZWV0c1NldmVyaXR5VGhyZXNob2xkKGFsZXJ0LnNldmVyaXR5LCBtZXJnZWRDb25maWcubWluaW11bVNldmVyaXR5KSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgbm90aWZpY2F0aW9uSWQgPSBgYWJnLWFsZXJ0LSR7RGF0ZS5ub3coKX1gO1xuXG4gIHRyeSB7XG4gICAgY29uc3Qgb3B0aW9uczogY2hyb21lLm5vdGlmaWNhdGlvbnMuTm90aWZpY2F0aW9uT3B0aW9uczx0cnVlPiA9IHtcbiAgICAgIHR5cGU6ICdiYXNpYycgYXMgY29uc3QsXG4gICAgICBpY29uVXJsOiBjaHJvbWUucnVudGltZS5nZXRVUkwoJ2ljb25zL2ljb24xMjgucG5nJyksXG4gICAgICB0aXRsZTogYEFJIEJyb3dzZXIgR3VhcmQgLSAke2FsZXJ0LnRpdGxlfWAsXG4gICAgICBtZXNzYWdlOiBhbGVydC5tZXNzYWdlLFxuICAgICAgcHJpb3JpdHk6IHNldmVyaXR5VG9Qcmlvcml0eShhbGVydC5zZXZlcml0eSksXG4gICAgICByZXF1aXJlSW50ZXJhY3Rpb246IGFsZXJ0LnNldmVyaXR5ID09PSAnY3JpdGljYWwnLFxuICAgIH07XG5cbiAgICBpZiAoYWxlcnQuYWxsb3dPbmVUaW1lT3ZlcnJpZGUpIHtcbiAgICAgIG9wdGlvbnMuYnV0dG9ucyA9IFtcbiAgICAgICAgeyB0aXRsZTogJ0FsbG93IG9uY2UnIH0sXG4gICAgICAgIHsgdGl0bGU6ICdEaXNtaXNzJyB9LFxuICAgICAgXTtcbiAgICB9XG5cbiAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jcmVhdGUobm90aWZpY2F0aW9uSWQsIG9wdGlvbnMpO1xuXG4gICAgaWYgKG1lcmdlZENvbmZpZy5hdXRvRGlzbWlzc01zID4gMCAmJiBhbGVydC5zZXZlcml0eSAhPT0gJ2NyaXRpY2FsJykge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY2xlYXIobm90aWZpY2F0aW9uSWQpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvLyBOb3RpZmljYXRpb24gbWF5IGFscmVhZHkgYmUgY2xlYXJlZFxuICAgICAgICB9XG4gICAgICB9LCBtZXJnZWRDb25maWcuYXV0b0Rpc21pc3NNcyk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbQUkgQnJvd3NlciBHdWFyZF0gRmFpbGVkIHRvIGNyZWF0ZSBub3RpZmljYXRpb246JywgZXJyKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiBub3RpZmljYXRpb25JZDtcbn1cblxuLyoqXG4gKiBNYXAgYWxlcnQgc2V2ZXJpdHkgdG8gbm90aWZpY2F0aW9uIHByaW9yaXR5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V2ZXJpdHlUb1ByaW9yaXR5KHNldmVyaXR5OiBBbGVydFNldmVyaXR5KTogbnVtYmVyIHtcbiAgY29uc3QgcHJpb3JpdHlNYXA6IFJlY29yZDxBbGVydFNldmVyaXR5LCBudW1iZXI+ID0ge1xuICAgIGNyaXRpY2FsOiAyLFxuICAgIGhpZ2g6IDEsXG4gICAgbWVkaXVtOiAwLFxuICAgIGxvdzogMCxcbiAgfTtcbiAgcmV0dXJuIHByaW9yaXR5TWFwW3NldmVyaXR5XTtcbn1cblxuLyoqXG4gKiBDaGVjayBpZiBhIHNldmVyaXR5IG1lZXRzIHRoZSBtaW5pbXVtIHRocmVzaG9sZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lZXRzU2V2ZXJpdHlUaHJlc2hvbGQoXG4gIHNldmVyaXR5OiBBbGVydFNldmVyaXR5LFxuICBtaW5pbXVtOiBBbGVydFNldmVyaXR5XG4pOiBib29sZWFuIHtcbiAgY29uc3Qgb3JkZXI6IEFsZXJ0U2V2ZXJpdHlbXSA9IFsnbG93JywgJ21lZGl1bScsICdoaWdoJywgJ2NyaXRpY2FsJ107XG4gIHJldHVybiBvcmRlci5pbmRleE9mKHNldmVyaXR5KSA+PSBvcmRlci5pbmRleE9mKG1pbmltdW0pO1xufVxuXG4vKipcbiAqIFNldCB1cCBub3RpZmljYXRpb24gYnV0dG9uIGNsaWNrIGhhbmRsZXJzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBOb3RpZmljYXRpb25IYW5kbGVycyhcbiAgb25BbGxvd09uY2U6IChub3RpZmljYXRpb25JZDogc3RyaW5nKSA9PiB2b2lkXG4pOiAoKSA9PiB2b2lkIHtcbiAgY29uc3QgaGFuZGxlciA9IChub3RpZmljYXRpb25JZDogc3RyaW5nLCBidXR0b25JbmRleDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKGJ1dHRvbkluZGV4ID09PSAwKSB7XG4gICAgICAvLyBcIkFsbG93IG9uY2VcIlxuICAgICAgb25BbGxvd09uY2Uobm90aWZpY2F0aW9uSWQpO1xuICAgIH1cbiAgICAvLyBCdXR0b24gMSA9IFwiRGlzbWlzc1wiIC0ganVzdCBjbGVhclxuICAgIHRyeSB7XG4gICAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jbGVhcihub3RpZmljYXRpb25JZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBJZ25vcmVcbiAgICB9XG4gIH07XG5cbiAgY2hyb21lLm5vdGlmaWNhdGlvbnMub25CdXR0b25DbGlja2VkLmFkZExpc3RlbmVyKGhhbmRsZXIpO1xuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgY2hyb21lLm5vdGlmaWNhdGlvbnMub25CdXR0b25DbGlja2VkLnJlbW92ZUxpc3RlbmVyKGhhbmRsZXIpO1xuICB9O1xufVxuXG4vKipcbiAqIENsZWFyIGFsbCBhY3RpdmUgbm90aWZpY2F0aW9ucy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsTm90aWZpY2F0aW9ucygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNocm9tZS5ub3RpZmljYXRpb25zLmdldEFsbCgobm90aWZpY2F0aW9ucykgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGlkIG9mIE9iamVjdC5rZXlzKG5vdGlmaWNhdGlvbnMpKSB7XG4gICAgICAgICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY2xlYXIoaWQpO1xuICAgICAgICB9XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmVzb2x2ZSgpO1xuICAgIH1cbiAgfSk7XG59XG4iLCIvKipcbiAqIENhcGFiaWxpdHkgYm91bmRhcnkgYWxlcnQgc3lzdGVtLlxuICpcbiAqIEdlbmVyYXRlcyBhbGVydHMgd2hlbiBhbiBhZ2VudCBhdHRlbXB0cyBhY3Rpb25zIHRoYXQgZXhjZWVkIGl0c1xuICogZGVsZWdhdGVkIHBlcm1pc3Npb25zLlxuICovXG5cbmltcG9ydCB0eXBlIHsgQm91bmRhcnlWaW9sYXRpb24gfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENhcGFiaWxpdHkgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5pbXBvcnQgdHlwZSB7IERlbGVnYXRpb25SdWxlIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5cbmV4cG9ydCB0eXBlIEFsZXJ0U2V2ZXJpdHkgPSAnY3JpdGljYWwnIHwgJ2hpZ2gnIHwgJ21lZGl1bScgfCAnbG93JztcblxuZXhwb3J0IGludGVyZmFjZSBCb3VuZGFyeUFsZXJ0IHtcbiAgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvbjtcbiAgc2V2ZXJpdHk6IEFsZXJ0U2V2ZXJpdHk7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgYWxsb3dPbmVUaW1lT3ZlcnJpZGU6IGJvb2xlYW47XG4gIGFja25vd2xlZGdlZDogYm9vbGVhbjtcbn1cblxuY29uc3QgU0VOU0lUSVZFX1VSTF9QQVRURVJOUyA9IFtcbiAgL1xcLmJhbmtcXC4vaSxcbiAgL1xcLmdvdlxcLi9pLFxuICAvcGF5cGFsL2ksXG4gIC9zdHJpcGUvaSxcbiAgL1xcLmZpbmFuY2lhbC9pLFxuICAvaGVhbHRoY2FyZS9pLFxuICAvXFwubWlsXFwuL2ksXG5dO1xuXG4vKipcbiAqIENyZWF0ZSBhIGJvdW5kYXJ5IGFsZXJ0IGZyb20gYSB2aW9sYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVCb3VuZGFyeUFsZXJ0KFxuICB2aW9sYXRpb246IEJvdW5kYXJ5VmlvbGF0aW9uLFxuICBydWxlOiBEZWxlZ2F0aW9uUnVsZVxuKTogQm91bmRhcnlBbGVydCB7XG4gIGNvbnN0IHNldmVyaXR5ID0gY2xhc3NpZnlWaW9sYXRpb25TZXZlcml0eSh2aW9sYXRpb24uYXR0ZW1wdGVkQWN0aW9uLCB2aW9sYXRpb24udXJsKTtcbiAgY29uc3QgdGl0bGUgPSBnZW5lcmF0ZUFsZXJ0VGl0bGUodmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbik7XG4gIGNvbnN0IG1lc3NhZ2UgPSBnZW5lcmF0ZUFsZXJ0TWVzc2FnZSh2aW9sYXRpb24sIHJ1bGUubGFiZWwgPz8gcnVsZS5wcmVzZXQpO1xuXG4gIHJldHVybiB7XG4gICAgdmlvbGF0aW9uLFxuICAgIHNldmVyaXR5LFxuICAgIHRpdGxlLFxuICAgIG1lc3NhZ2UsXG4gICAgYWxsb3dPbmVUaW1lT3ZlcnJpZGU6IHNldmVyaXR5ID09PSAnbWVkaXVtJyB8fCBzZXZlcml0eSA9PT0gJ2xvdycsXG4gICAgYWNrbm93bGVkZ2VkOiBmYWxzZSxcbiAgfTtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgdGhlIHNldmVyaXR5IG9mIGEgY2FwYWJpbGl0eSB2aW9sYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbGFzc2lmeVZpb2xhdGlvblNldmVyaXR5KFxuICBjYXBhYmlsaXR5OiBBZ2VudENhcGFiaWxpdHksXG4gIHVybDogc3RyaW5nXG4pOiBBbGVydFNldmVyaXR5IHtcbiAgY29uc3QgYmFzZVNldmVyaXR5TWFwOiBSZWNvcmQ8QWdlbnRDYXBhYmlsaXR5LCBBbGVydFNldmVyaXR5PiA9IHtcbiAgICAnc3VibWl0LWZvcm0nOiAnY3JpdGljYWwnLFxuICAgICdleGVjdXRlLXNjcmlwdCc6ICdjcml0aWNhbCcsXG4gICAgJ2Rvd25sb2FkLWZpbGUnOiAnaGlnaCcsXG4gICAgJ21vZGlmeS1kb20nOiAnaGlnaCcsXG4gICAgY2xpY2s6ICdoaWdoJyxcbiAgICAndHlwZS10ZXh0JzogJ21lZGl1bScsXG4gICAgbmF2aWdhdGU6ICdtZWRpdW0nLFxuICAgICdvcGVuLXRhYic6ICdsb3cnLFxuICAgICdjbG9zZS10YWInOiAnbG93JyxcbiAgICAncmVhZC1kb20nOiAnbG93JyxcbiAgICBzY3JlZW5zaG90OiAnbG93JyxcbiAgfTtcblxuICBsZXQgc2V2ZXJpdHkgPSBiYXNlU2V2ZXJpdHlNYXBbY2FwYWJpbGl0eV0gPz8gJ21lZGl1bSc7XG5cbiAgLy8gVXBncmFkZSBzZXZlcml0eSBmb3Igc2Vuc2l0aXZlIFVSTHNcbiAgY29uc3QgaXNTZW5zaXRpdmUgPSBTRU5TSVRJVkVfVVJMX1BBVFRFUk5TLnNvbWUoKHBhdHRlcm4pID0+IHBhdHRlcm4udGVzdCh1cmwpKTtcbiAgaWYgKGlzU2Vuc2l0aXZlKSB7XG4gICAgY29uc3QgdXBncmFkZTogUmVjb3JkPEFsZXJ0U2V2ZXJpdHksIEFsZXJ0U2V2ZXJpdHk+ID0ge1xuICAgICAgbG93OiAnbWVkaXVtJyxcbiAgICAgIG1lZGl1bTogJ2hpZ2gnLFxuICAgICAgaGlnaDogJ2NyaXRpY2FsJyxcbiAgICAgIGNyaXRpY2FsOiAnY3JpdGljYWwnLFxuICAgIH07XG4gICAgc2V2ZXJpdHkgPSB1cGdyYWRlW3NldmVyaXR5XTtcbiAgfVxuXG4gIHJldHVybiBzZXZlcml0eTtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSBhIGh1bWFuLXJlYWRhYmxlIGFsZXJ0IHRpdGxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVBbGVydFRpdGxlKGNhcGFiaWxpdHk6IEFnZW50Q2FwYWJpbGl0eSk6IHN0cmluZyB7XG4gIGNvbnN0IHRpdGxlczogUmVjb3JkPEFnZW50Q2FwYWJpbGl0eSwgc3RyaW5nPiA9IHtcbiAgICBuYXZpZ2F0ZTogJ05hdmlnYXRpb24gYmxvY2tlZCcsXG4gICAgJ3JlYWQtZG9tJzogJ1BhZ2UgcmVhZCBibG9ja2VkJyxcbiAgICBjbGljazogJ0NsaWNrIGludGVyYWN0aW9uIGJsb2NrZWQnLFxuICAgICd0eXBlLXRleHQnOiAnVGV4dCBpbnB1dCBibG9ja2VkJyxcbiAgICAnc3VibWl0LWZvcm0nOiAnRm9ybSBzdWJtaXNzaW9uIGJsb2NrZWQnLFxuICAgICdkb3dubG9hZC1maWxlJzogJ0ZpbGUgZG93bmxvYWQgYmxvY2tlZCcsXG4gICAgJ29wZW4tdGFiJzogJ05ldyB0YWIgYmxvY2tlZCcsXG4gICAgJ2Nsb3NlLXRhYic6ICdUYWIgY2xvc3VyZSBibG9ja2VkJyxcbiAgICBzY3JlZW5zaG90OiAnU2NyZWVuc2hvdCBibG9ja2VkJyxcbiAgICAnZXhlY3V0ZS1zY3JpcHQnOiAnU2NyaXB0IGV4ZWN1dGlvbiBibG9ja2VkJyxcbiAgICAnbW9kaWZ5LWRvbSc6ICdET00gbW9kaWZpY2F0aW9uIGJsb2NrZWQnLFxuICB9O1xuICByZXR1cm4gdGl0bGVzW2NhcGFiaWxpdHldIHx8ICdBY3Rpb24gYmxvY2tlZCc7XG59XG5cbi8qKlxuICogR2VuZXJhdGUgYSBkZXRhaWxlZCBhbGVydCBtZXNzYWdlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVBbGVydE1lc3NhZ2UoXG4gIHZpb2xhdGlvbjogQm91bmRhcnlWaW9sYXRpb24sXG4gIHJ1bGVOYW1lOiBzdHJpbmdcbik6IHN0cmluZyB7XG4gIGNvbnN0IGxpbmVzID0gW1xuICAgIGBBbiBhZ2VudCBhdHRlbXB0ZWQgdG8gcGVyZm9ybSBcIiR7dmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbn1cIiBvbjpgLFxuICAgIHZpb2xhdGlvbi51cmwsXG4gICAgJycsXG4gICAgYEJsb2NrZWQgYnkgcnVsZTogJHtydWxlTmFtZX1gLFxuICAgIGBSZWFzb246ICR7dmlvbGF0aW9uLnJlYXNvbn1gLFxuICBdO1xuXG4gIGlmICh2aW9sYXRpb24udGFyZ2V0U2VsZWN0b3IpIHtcbiAgICBsaW5lcy5wdXNoKGBUYXJnZXQgZWxlbWVudDogJHt2aW9sYXRpb24udGFyZ2V0U2VsZWN0b3J9YCk7XG4gIH1cblxuICByZXR1cm4gbGluZXMuam9pbignXFxuJyk7XG59XG5cbi8qKlxuICogSGFuZGxlIGEgdXNlcidzIG9uZS10aW1lIG92ZXJyaWRlIG9mIGEgYmxvY2tlZCBhY3Rpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVPbmVUaW1lT3ZlcnJpZGUoXG4gIGFsZXJ0SWQ6IHN0cmluZyxcbiAgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvblxuKTogQm91bmRhcnlWaW9sYXRpb24ge1xuICByZXR1cm4geyAuLi52aW9sYXRpb24sIHVzZXJPdmVycmlkZTogdHJ1ZSB9O1xufVxuIiwiLyoqXG4gKiBQdXJlIGhhbmRsZXIgZnVuY3Rpb25zIGZvciB0aGUgYmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlci5cbiAqXG4gKiBFeHRyYWN0ZWQgdG8gYWxsb3cgdW5pdCB0ZXN0aW5nIHdpdGhvdXQgdGhlIHNpZGUgZWZmZWN0cyBvZiBpbmRleC50c1xuICogKGNocm9tZSBBUEkgbGlzdGVuZXIgcmVnaXN0cmF0aW9uLCBhbGFybSBjcmVhdGlvbiwgZXRjLikuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBCb3VuZGFyeVZpb2xhdGlvbiB9IGZyb20gJy4uL3R5cGVzL2V2ZW50cyc7XG5pbXBvcnQgdHlwZSB7IERlbGVnYXRpb25SdWxlIH0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5pbXBvcnQgdHlwZSB7IEJvdW5kYXJ5QWxlcnQgfSBmcm9tICcuLi9hbGVydHMvYm91bmRhcnknO1xuaW1wb3J0IHsgY3JlYXRlQm91bmRhcnlBbGVydCB9IGZyb20gJy4uL2FsZXJ0cy9ib3VuZGFyeSc7XG5pbXBvcnQgeyBzaG93Qm91bmRhcnlOb3RpZmljYXRpb24gfSBmcm9tICcuLi9hbGVydHMvbm90aWZpY2F0aW9uJztcbmltcG9ydCB7IGNyZWF0ZVRpbWVsaW5lRXZlbnQsIGFwcGVuZEV2ZW50VG9TZXNzaW9uIH0gZnJvbSAnLi4vc2Vzc2lvbi90aW1lbGluZSc7XG5pbXBvcnQgeyB1cGRhdGVTZXNzaW9uIH0gZnJvbSAnLi4vc2Vzc2lvbi9zdG9yYWdlJztcblxuLyoqXG4gKiBQZW5kaW5nIGFsbG93LW9uY2Ugb3ZlcnJpZGVzIGtleWVkIGJ5IG5vdGlmaWNhdGlvbiBJRC5cbiAqIEVhY2ggZW50cnkgaG9sZHMgdGhlIGNvbnRleHQgbmVlZGVkIHRvIHNlbmQgdGhlIGFsbG93IHNpZ25hbCB0byB0aGVcbiAqIGNvcnJlY3QgY29udGVudCBzY3JpcHQgd2hlbiB0aGUgdXNlciBjbGlja3MgXCJBbGxvdyBvbmNlXCIgaW4gdGhlIG5vdGlmaWNhdGlvbi5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQZW5kaW5nT3ZlcnJpZGUge1xuICB0YWJJZDogbnVtYmVyO1xuICBjYXBhYmlsaXR5OiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG4vKipcbiAqIFNoYXJlZCBwZW5kaW5nLW92ZXJyaWRlcyBtYXAgdXNlZCBieSBib3RoIHRoZSBiYWNrZ3JvdW5kIGVudHJ5IHBvaW50IGFuZCB0ZXN0cy5cbiAqL1xuZXhwb3J0IGNvbnN0IHBlbmRpbmdPdmVycmlkZXM6IE1hcDxzdHJpbmcsIFBlbmRpbmdPdmVycmlkZT4gPSBuZXcgTWFwKCk7XG5cbi8qKlxuICogUHJvY2VzcyBhIGJvdW5kYXJ5IHZpb2xhdGlvbjpcbiAqICAxLiBDcmVhdGUgYSBCb3VuZGFyeUFsZXJ0IGZyb20gdGhlIHZpb2xhdGlvbiBhbmQgdGhlIGFjdGl2ZSBydWxlLlxuICogIDIuIFNob3cgYSBDaHJvbWUgbm90aWZpY2F0aW9uLlxuICogIDMuIElmIHRoZSBub3RpZmljYXRpb24gd2FzIGNyZWF0ZWQgYW5kIHRhYklkIGlzIGtub3duLCBzdG9yZSBhIHBlbmRpbmcgb3ZlcnJpZGVcbiAqICAgICBzbyB0aGF0IGNsaWNraW5nIFwiQWxsb3cgb25jZVwiIGNhbiByZWxheSB0aGUgc2lnbmFsIGJhY2sgdG8gdGhlIGNvbnRlbnQgc2NyaXB0LlxuICpcbiAqIFJldHVybnMgdGhlIGNyZWF0ZWQgQm91bmRhcnlBbGVydCBzbyBjYWxsZXJzIGNhbiBhZGQgaXQgdG8gdGhlaXIgc3RhdGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcm9jZXNzQm91bmRhcnlWaW9sYXRpb24oXG4gIHRhYklkOiBudW1iZXIgfCB1bmRlZmluZWQsXG4gIHZpb2xhdGlvbjogQm91bmRhcnlWaW9sYXRpb24sXG4gIGFjdGl2ZVJ1bGU6IERlbGVnYXRpb25SdWxlLFxuICBhY3RpdmVTZXNzaW9uczogTWFwPG51bWJlciwgc3RyaW5nPlxuKTogQm91bmRhcnlBbGVydCB7XG4gIGNvbnN0IGFsZXJ0ID0gY3JlYXRlQm91bmRhcnlBbGVydCh2aW9sYXRpb24sIGFjdGl2ZVJ1bGUpO1xuXG4gIGNvbnN0IG5vdGlmaWNhdGlvbklkID0gc2hvd0JvdW5kYXJ5Tm90aWZpY2F0aW9uKGFsZXJ0KTtcblxuICAvLyBTdG9yZSB0aGUgcGVuZGluZyBvdmVycmlkZSBzbyB0aGUgbm90aWZpY2F0aW9uIGJ1dHRvbiBoYW5kbGVyIGNhbiBhY3Qgb24gaXQuXG4gIGlmIChub3RpZmljYXRpb25JZCAhPT0gbnVsbCAmJiB0YWJJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgcGVuZGluZ092ZXJyaWRlcy5zZXQobm90aWZpY2F0aW9uSWQsIHtcbiAgICAgIHRhYklkLFxuICAgICAgY2FwYWJpbGl0eTogdmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbixcbiAgICAgIHVybDogdmlvbGF0aW9uLnVybCxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIExvZyB0aGUgdmlvbGF0aW9uIGFzIGEgdGltZWxpbmUgZXZlbnQgaWYgd2UgaGF2ZSBhIHNlc3Npb24gZm9yIHRoaXMgdGFiLlxuICBpZiAodGFiSWQgIT09IHVuZGVmaW5lZCkge1xuICAgIGNvbnN0IHNlc3Npb25JZCA9IGFjdGl2ZVNlc3Npb25zLmdldCh0YWJJZCk7XG4gICAgaWYgKHNlc3Npb25JZCkge1xuICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVUaW1lbGluZUV2ZW50KFxuICAgICAgICAnYm91bmRhcnktdmlvbGF0aW9uJyxcbiAgICAgICAgdmlvbGF0aW9uLnVybCxcbiAgICAgICAgYFZpb2xhdGlvbjogJHt2aW9sYXRpb24uYXR0ZW1wdGVkQWN0aW9ufSBibG9ja2VkYCxcbiAgICAgICAge1xuICAgICAgICAgIGF0dGVtcHRlZEFjdGlvbjogdmlvbGF0aW9uLmF0dGVtcHRlZEFjdGlvbixcbiAgICAgICAgICBvdXRjb21lOiAnYmxvY2tlZCcsXG4gICAgICAgICAgcnVsZUlkOiB2aW9sYXRpb24uYmxvY2tpbmdSdWxlSWQsXG4gICAgICAgICAgdGFyZ2V0U2VsZWN0b3I6IHZpb2xhdGlvbi50YXJnZXRTZWxlY3RvcixcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICAgIHVwZGF0ZVNlc3Npb24oc2Vzc2lvbklkLCAoc2Vzc2lvbikgPT4gYXBwZW5kRXZlbnRUb1Nlc3Npb24oc2Vzc2lvbiwgZXZlbnQpKS5jYXRjaChcbiAgICAgICAgKCkgPT4geyAvKiBpZ25vcmUgKi8gfVxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gYWxlcnQ7XG59XG5cbi8qKlxuICogSGFuZGxlIGEgdXNlcidzIFwiQWxsb3cgb25jZVwiIGNsaWNrOlxuICogIDEuIExvb2sgdXAgdGhlIHBlbmRpbmcgb3ZlcnJpZGUgYnkgbm90aWZpY2F0aW9uSWQuXG4gKiAgMi4gU2VuZCBhbiBBTExPV19PTkNFIG1lc3NhZ2UgdG8gdGhlIGNvbnRlbnQgc2NyaXB0IGluIHRoZSBvcmlnaW5hdGluZyB0YWIuXG4gKiAgMy4gUmVtb3ZlIHRoZSBlbnRyeSBmcm9tIHBlbmRpbmdPdmVycmlkZXMuXG4gKlxuICogUmV0dXJucyB0cnVlIGlmIGFuIG92ZXJyaWRlIHdhcyBmb3VuZCBhbmQgdGhlIG1lc3NhZ2Ugd2FzIGRpc3BhdGNoZWQsIGZhbHNlIG90aGVyd2lzZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFsbG93T25jZShub3RpZmljYXRpb25JZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IG92ZXJyaWRlID0gcGVuZGluZ092ZXJyaWRlcy5nZXQobm90aWZpY2F0aW9uSWQpO1xuICBpZiAoIW92ZXJyaWRlKSByZXR1cm4gZmFsc2U7XG5cbiAgcGVuZGluZ092ZXJyaWRlcy5kZWxldGUobm90aWZpY2F0aW9uSWQpO1xuXG4gIHRyeSB7XG4gICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2Uob3ZlcnJpZGUudGFiSWQsIHtcbiAgICAgIHR5cGU6ICdBTExPV19PTkNFJyxcbiAgICAgIGRhdGE6IHsgY2FwYWJpbGl0eTogb3ZlcnJpZGUuY2FwYWJpbGl0eSwgdXJsOiBvdmVycmlkZS51cmwgfSxcbiAgICAgIHNlbnRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuICB9IGNhdGNoIHtcbiAgICAvLyBUaGUgdGFiIG1heSBoYXZlIGJlZW4gY2xvc2VkIGJlZm9yZSB0aGUgdXNlciBjbGlja2VkIFwiQWxsb3cgb25jZVwiLlxuICB9XG5cbiAgLy8gQ2xlYXIgdGhlIG5vdGlmaWNhdGlvbiBpdHNlbGYgc28gaXQgZGlzbWlzc2VzIGFmdGVyIHRoZSB1c2VyIGFjdHMuXG4gIHRyeSB7XG4gICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuY2xlYXIobm90aWZpY2F0aW9uSWQpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBOb3RpZmljYXRpb24gbWF5IGFscmVhZHkgYmUgZ29uZS5cbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufVxuIiwiLyoqXG4gKiBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGVudHJ5IHBvaW50LlxuICpcbiAqIENlbnRyYWwgY29vcmRpbmF0b3IgZm9yIHRoZSBleHRlbnNpb24uXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBNZXNzYWdlUGF5bG9hZCwgRGV0ZWN0aW9uRXZlbnQsIEtpbGxTd2l0Y2hFdmVudCwgQWdlbnRFdmVudCwgQm91bmRhcnlWaW9sYXRpb24gfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudElkZW50aXR5IH0gZnJvbSAnLi4vdHlwZXMvYWdlbnQnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uUnVsZSB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudFNlc3Npb24gfSBmcm9tICcuLi9zZXNzaW9uL3R5cGVzJztcbmltcG9ydCB7IGdldFN0b3JhZ2VTdGF0ZSwgc2F2ZVNlc3Npb24sIHVwZGF0ZVNlc3Npb24sIHNhdmVEZWxlZ2F0aW9uUnVsZXMsIGFwcGVuZERldGVjdGlvbkxvZywgdXBkYXRlU2V0dGluZ3MsIGdldExpZmV0aW1lU3RhdHMsIHVwZGF0ZUxpZmV0aW1lU3RhdHMgfSBmcm9tICcuLi9zZXNzaW9uL3N0b3JhZ2UnO1xuaW1wb3J0IHR5cGUgeyBMaWZldGltZVN0YXRzIH0gZnJvbSAnLi4vc2Vzc2lvbi90eXBlcyc7XG5pbXBvcnQgeyBERUZBVUxUX0xJRkVUSU1FX1NUQVRTIH0gZnJvbSAnLi4vc2Vzc2lvbi90eXBlcyc7XG5pbXBvcnQgeyBjcmVhdGVUaW1lbGluZUV2ZW50LCBhcHBlbmRFdmVudFRvU2Vzc2lvbiB9IGZyb20gJy4uL3Nlc3Npb24vdGltZWxpbmUnO1xuaW1wb3J0IHsgZXhlY3V0ZUJhY2tncm91bmRLaWxsU3dpdGNoLCBjcmVhdGVJbml0aWFsS2lsbFN3aXRjaFN0YXRlIH0gZnJvbSAnLi4va2lsbHN3aXRjaC9pbmRleCc7XG5pbXBvcnQgdHlwZSB7IEtpbGxTd2l0Y2hTdGF0ZSB9IGZyb20gJy4uL2tpbGxzd2l0Y2gvaW5kZXgnO1xuaW1wb3J0IHsgaXNUaW1lQm91bmRFeHBpcmVkIH0gZnJvbSAnLi4vZGVsZWdhdGlvbi9ydWxlcyc7XG5pbXBvcnQgeyBzZXR1cE5vdGlmaWNhdGlvbkhhbmRsZXJzLCBjbGVhckFsbE5vdGlmaWNhdGlvbnMgfSBmcm9tICcuLi9hbGVydHMvbm90aWZpY2F0aW9uJztcbmltcG9ydCB0eXBlIHsgQm91bmRhcnlBbGVydCB9IGZyb20gJy4uL2FsZXJ0cy9ib3VuZGFyeSc7XG5pbXBvcnQgeyBwcm9jZXNzQm91bmRhcnlWaW9sYXRpb24sIGhhbmRsZUFsbG93T25jZSB9IGZyb20gJy4vaGFuZGxlcnMnO1xuXG5pbnRlcmZhY2UgQmFja2dyb3VuZFN0YXRlIHtcbiAgYWN0aXZlQWdlbnRzOiBNYXA8bnVtYmVyLCBBZ2VudElkZW50aXR5PjtcbiAgYWN0aXZlU2Vzc2lvbnM6IE1hcDxudW1iZXIsIHN0cmluZz47IC8vIHRhYklkIC0+IHNlc3Npb25JZFxuICBkZWxlZ2F0aW9uUnVsZXM6IERlbGVnYXRpb25SdWxlW107XG4gIGtpbGxTd2l0Y2g6IEtpbGxTd2l0Y2hTdGF0ZTtcbiAgcmVjZW50QWxlcnRzOiBCb3VuZGFyeUFsZXJ0W107XG4gIGxpZmV0aW1lU3RhdHM6IExpZmV0aW1lU3RhdHM7XG59XG5cbmNvbnN0IHN0YXRlOiBCYWNrZ3JvdW5kU3RhdGUgPSB7XG4gIGFjdGl2ZUFnZW50czogbmV3IE1hcCgpLFxuICBhY3RpdmVTZXNzaW9uczogbmV3IE1hcCgpLFxuICBkZWxlZ2F0aW9uUnVsZXM6IFtdLFxuICBraWxsU3dpdGNoOiBjcmVhdGVJbml0aWFsS2lsbFN3aXRjaFN0YXRlKCksXG4gIHJlY2VudEFsZXJ0czogW10sXG4gIGxpZmV0aW1lU3RhdHM6IHsgLi4uREVGQVVMVF9MSUZFVElNRV9TVEFUUyB9LFxufTtcblxuZnVuY3Rpb24gaW5pdGlhbGl6ZSgpOiB2b2lkIHtcbiAgbG9hZFBlcnNpc3RlZFN0YXRlKCkudGhlbigoKSA9PiB7XG4gICAgdXBkYXRlQmFkZ2UoKTtcbiAgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tBSSBCcm93c2VyIEd1YXJkXSBGYWlsZWQgdG8gbG9hZCBzdGF0ZTonLCBlcnIpO1xuICB9KTtcblxuICAvLyBNZXNzYWdlIHJvdXRpbmdcbiAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKGhhbmRsZU1lc3NhZ2UpO1xuXG4gIC8vIFRhYiBsaWZlY3ljbGVcbiAgY2hyb21lLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKCh0YWJJZCkgPT4ge1xuICAgIGhhbmRsZVRhYlJlbW92ZWQodGFiSWQpLmNhdGNoKCgpID0+IHsgLyogaWdub3JlICovIH0pO1xuICB9KTtcblxuICAvLyBEZWxlZ2F0aW9uIGV4cGlyYXRpb24gYWxhcm1cbiAgY2hyb21lLmFsYXJtcy5jcmVhdGUoJ2RlbGVnYXRpb24tY2hlY2snLCB7IHBlcmlvZEluTWludXRlczogMSB9KTtcbiAgLy8gU2VydmljZSB3b3JrZXIga2VlcGFsaXZlIOKAlCBNVjMgd29ya2VycyB0ZXJtaW5hdGUgYWZ0ZXIgfjUgbWluIGlkbGVcbiAgY2hyb21lLmFsYXJtcy5jcmVhdGUoJ2tlZXBhbGl2ZS1waW5nJywgeyBwZXJpb2RJbk1pbnV0ZXM6IDAuNCB9KTtcbiAgY2hyb21lLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xuICAgIGlmIChhbGFybS5uYW1lID09PSAnZGVsZWdhdGlvbi1jaGVjaycpIHtcbiAgICAgIGNoZWNrRGVsZWdhdGlvbkV4cGlyYXRpb24oKS5jYXRjaCgoKSA9PiB7IC8qIGlnbm9yZSAqLyB9KTtcbiAgICB9XG4gICAgLy8ga2VlcGFsaXZlLXBpbmcgcmVxdWlyZXMgbm8gYWN0aW9uIOKAlCB0aGUgYWxhcm0gZmlyaW5nIGlzIHN1ZmZpY2llbnQgdG8ga2VlcCB0aGUgU1cgYWxpdmVcbiAgfSk7XG5cbiAgLy8gS2lsbCBzd2l0Y2gga2V5Ym9hcmQgc2hvcnRjdXRcbiAgcmVnaXN0ZXJLZXlib2FyZFNob3J0Y3V0KCk7XG5cbiAgLy8gTm90aWZpY2F0aW9uIGhhbmRsZXJzXG4gIHNldHVwTm90aWZpY2F0aW9uSGFuZGxlcnMoKG5vdGlmaWNhdGlvbklkKSA9PiB7XG4gICAgaGFuZGxlQWxsb3dPbmNlKG5vdGlmaWNhdGlvbklkKS5jYXRjaCgoKSA9PiB7IC8qIGlnbm9yZSAqLyB9KTtcbiAgfSk7XG5cbiAgY29uc29sZS5sb2coJ1tBSSBCcm93c2VyIEd1YXJkXSBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGluaXRpYWxpemVkJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRQZXJzaXN0ZWRTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgZ2V0U3RvcmFnZVN0YXRlKCk7XG4gIHN0YXRlLmRlbGVnYXRpb25SdWxlcyA9IHN0b3JlZC5kZWxlZ2F0aW9uUnVsZXM7XG4gIHN0YXRlLmxpZmV0aW1lU3RhdHMgPSBhd2FpdCBnZXRMaWZldGltZVN0YXRzKCk7XG5cbiAgLy8gQ2hlY2sgZm9yIGFjdGl2ZSBzZXNzaW9ucyB0aGF0IG1heSBoYXZlIHN1cnZpdmVkIGEgcmVzdGFydFxuICBmb3IgKGNvbnN0IHNlc3Npb24gb2Ygc3RvcmVkLnNlc3Npb25zKSB7XG4gICAgaWYgKCFzZXNzaW9uLmVuZGVkQXQpIHtcbiAgICAgIC8vIE1hcmsgc3RhbGUgc2Vzc2lvbnMgYXMgZW5kZWRcbiAgICAgIGF3YWl0IHVwZGF0ZVNlc3Npb24oc2Vzc2lvbi5pZCwgKHMpID0+ICh7XG4gICAgICAgIC4uLnMsXG4gICAgICAgIGVuZGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZW5kUmVhc29uOiAnYWdlbnQtZGlzY29ubmVjdGVkJyxcbiAgICAgIH0pKTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShcbiAgbWVzc2FnZTogTWVzc2FnZVBheWxvYWQsXG4gIHNlbmRlcjogY2hyb21lLnJ1bnRpbWUuTWVzc2FnZVNlbmRlcixcbiAgc2VuZFJlc3BvbnNlOiAocmVzcG9uc2U6IHVua25vd24pID0+IHZvaWRcbik6IGJvb2xlYW4ge1xuICBpZiAoIW1lc3NhZ2UgfHwgIW1lc3NhZ2UudHlwZSkgcmV0dXJuIGZhbHNlO1xuXG4gIGNvbnN0IHRhYklkID0gc2VuZGVyLnRhYj8uaWQ7XG5cbiAgc3dpdGNoIChtZXNzYWdlLnR5cGUpIHtcbiAgICBjYXNlICdERVRFQ1RJT05fUkVTVUxUJzoge1xuICAgICAgaWYgKHRhYklkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaGFuZGxlRGV0ZWN0aW9uKHRhYklkLCBtZXNzYWdlLmRhdGEgYXMgRGV0ZWN0aW9uRXZlbnQpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUgfSk7XG4gICAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiBmYWxzZSB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlOyAvLyBhc3luYyByZXNwb25zZVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNhc2UgJ0FHRU5UX0FDVElPTic6IHtcbiAgICAgIGlmICh0YWJJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGhhbmRsZUFnZW50QWN0aW9uKHRhYklkLCBtZXNzYWdlLmRhdGEgYXMgQWdlbnRFdmVudCk7XG4gICAgICB9XG4gICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNhc2UgJ0JPVU5EQVJZX0NIRUNLX1JFUVVFU1QnOiB7XG4gICAgICBjb25zdCB2aW9sYXRpb24gPSBtZXNzYWdlLmRhdGEgYXMgQm91bmRhcnlWaW9sYXRpb247XG4gICAgICBoYW5kbGVCb3VuZGFyeVZpb2xhdGlvbih0YWJJZCwgdmlvbGF0aW9uKTtcbiAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUgfSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY2FzZSAnS0lMTF9TV0lUQ0hfQUNUSVZBVEUnOiB7XG4gICAgICBleGVjdXRlS2lsbFN3aXRjaChcbiAgICAgICAgKG1lc3NhZ2UuZGF0YSBhcyB7IHRyaWdnZXI/OiBzdHJpbmcgfSk/LnRyaWdnZXIgYXMgJ2J1dHRvbicgfCAna2V5Ym9hcmQtc2hvcnRjdXQnIHwgJ2FwaScgPz8gJ2J1dHRvbidcbiAgICAgICkudGhlbigoZXZlbnQpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSwgZXZlbnQgfSk7XG4gICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IGZhbHNlIH0pO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gdHJ1ZTsgLy8gYXN5bmMgcmVzcG9uc2VcbiAgICB9XG5cbiAgICBjYXNlICdLSUxMX1NXSVRDSF9SRVNFVCc6IHtcbiAgICAgIHN0YXRlLmtpbGxTd2l0Y2guaXNBY3RpdmUgPSBmYWxzZTtcbiAgICAgIHN0YXRlLmtpbGxTd2l0Y2gubGFzdEV2ZW50ID0gbnVsbDtcbiAgICAgIHN0YXRlLmtpbGxTd2l0Y2gubGFzdEFjdGl2YXRlZEF0ID0gbnVsbDtcbiAgICAgIHVwZGF0ZUJhZGdlKCk7XG4gICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNhc2UgJ0RFTEVHQVRJT05fVVBEQVRFJzoge1xuICAgICAgY29uc3QgcnVsZSA9IG1lc3NhZ2UuZGF0YSBhcyBEZWxlZ2F0aW9uUnVsZTtcbiAgICAgIGhhbmRsZURlbGVnYXRpb25VcGRhdGUocnVsZSkudGhlbigoKSA9PiB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUgfSk7XG4gICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IGZhbHNlIH0pO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBjYXNlICdTRVNTSU9OX1FVRVJZJzoge1xuICAgICAgZ2V0U3RvcmFnZVN0YXRlKCkudGhlbigoc3RvcmVkKSA9PiB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHNlc3Npb25zOiBzdG9yZWQuc2Vzc2lvbnMgfSk7XG4gICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHNlc3Npb25zOiBbXSB9KTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgY2FzZSAnU1RBVFVTX1FVRVJZJzoge1xuICAgICAgY29uc3QgYWdlbnRzID0gQXJyYXkuZnJvbShzdGF0ZS5hY3RpdmVBZ2VudHMudmFsdWVzKCkpO1xuICAgICAgY29uc3QgYWN0aXZlUnVsZSA9IHN0YXRlLmRlbGVnYXRpb25SdWxlcy5maW5kKChyKSA9PiByLmlzQWN0aXZlKSA/PyBudWxsO1xuICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgZGV0ZWN0ZWRBZ2VudHM6IGFnZW50cyxcbiAgICAgICAgYWN0aXZlRGVsZWdhdGlvbjogYWN0aXZlUnVsZSxcbiAgICAgICAga2lsbFN3aXRjaEFjdGl2ZTogc3RhdGUua2lsbFN3aXRjaC5pc0FjdGl2ZSxcbiAgICAgICAgcmVjZW50VmlvbGF0aW9uczogc3RhdGUucmVjZW50QWxlcnRzLFxuICAgICAgICBkZWxlZ2F0aW9uUnVsZXM6IHN0YXRlLmRlbGVnYXRpb25SdWxlcyxcbiAgICAgICAgbGlmZXRpbWVTdGF0czogc3RhdGUubGlmZXRpbWVTdGF0cyxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNhc2UgJ1NFVFRJTkdTX1VQREFURSc6IHtcbiAgICAgIGNvbnN0IHVwZGF0ZXMgPSBtZXNzYWdlLmRhdGEgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICB1cGRhdGVTZXR0aW5ncyh1cGRhdGVzKS50aGVuKCgpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogZmFsc2UgfSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlRGV0ZWN0aW9uKHRhYklkOiBudW1iZXIsIGV2ZW50OiBEZXRlY3Rpb25FdmVudCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoIWV2ZW50LmFnZW50KSByZXR1cm47XG5cbiAgc3RhdGUuYWN0aXZlQWdlbnRzLnNldCh0YWJJZCwgZXZlbnQuYWdlbnQpO1xuXG4gIC8vIENyZWF0ZSBhIG5ldyBzZXNzaW9uXG4gIGNvbnN0IHNlc3Npb246IEFnZW50U2Vzc2lvbiA9IHtcbiAgICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICBhZ2VudDogZXZlbnQuYWdlbnQsXG4gICAgZGVsZWdhdGlvblJ1bGU6IHN0YXRlLmRlbGVnYXRpb25SdWxlcy5maW5kKChyKSA9PiByLmlzQWN0aXZlKSA/PyBudWxsLFxuICAgIGV2ZW50czogW10sXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgZW5kZWRBdDogbnVsbCxcbiAgICBlbmRSZWFzb246IG51bGwsXG4gICAgc3VtbWFyeToge1xuICAgICAgdG90YWxBY3Rpb25zOiAwLFxuICAgICAgYWxsb3dlZEFjdGlvbnM6IDAsXG4gICAgICBibG9ja2VkQWN0aW9uczogMCxcbiAgICAgIHZpb2xhdGlvbnM6IDAsXG4gICAgICB0b3BVcmxzOiBbXSxcbiAgICAgIGR1cmF0aW9uU2Vjb25kczogbnVsbCxcbiAgICB9LFxuICB9O1xuXG4gIC8vIEFkZCBkZXRlY3Rpb24gZXZlbnQgdG8gdGltZWxpbmVcbiAgY29uc3QgYWdlbnREaXNwbGF5TmFtZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgcGxheXdyaWdodDogJ1BsYXl3cmlnaHQnLFxuICAgIHB1cHBldGVlcjogJ1B1cHBldGVlcicsXG4gICAgc2VsZW5pdW06ICdTZWxlbml1bScsXG4gICAgJ2FudGhyb3BpYy1jb21wdXRlci11c2UnOiAnQW50aHJvcGljIENvbXB1dGVyIFVzZScsXG4gICAgJ29wZW5haS1vcGVyYXRvcic6ICdPcGVuQUkgT3BlcmF0b3InLFxuICAgICdjZHAtZ2VuZXJpYyc6ICdDRFAgQWdlbnQnLFxuICAgICd3ZWJkcml2ZXItZ2VuZXJpYyc6ICdXZWJEcml2ZXIgQWdlbnQnLFxuICAgIHVua25vd246ICdVbmtub3duIEFnZW50JyxcbiAgfTtcbiAgY29uc3QgYWdlbnREaXNwbGF5TmFtZSA9IGFnZW50RGlzcGxheU5hbWVzW2V2ZW50LmFnZW50LnR5cGVdID8/IGV2ZW50LmFnZW50LnR5cGU7XG4gIGNvbnN0IHRpbWVsaW5lRXZlbnQgPSBjcmVhdGVUaW1lbGluZUV2ZW50KCdkZXRlY3Rpb24nLCBldmVudC51cmwsIGBBZ2VudCBkZXRlY3RlZDogJHthZ2VudERpc3BsYXlOYW1lfWAsIHtcbiAgICBvdXRjb21lOiAnaW5mb3JtYXRpb25hbCcsXG4gIH0pO1xuICBjb25zdCB1cGRhdGVkU2Vzc2lvbiA9IGFwcGVuZEV2ZW50VG9TZXNzaW9uKHNlc3Npb24sIHRpbWVsaW5lRXZlbnQpO1xuXG4gIGF3YWl0IHNhdmVTZXNzaW9uKHVwZGF0ZWRTZXNzaW9uKTtcbiAgc3RhdGUuYWN0aXZlU2Vzc2lvbnMuc2V0KHRhYklkLCB1cGRhdGVkU2Vzc2lvbi5pZCk7XG5cbiAgLy8gTG9nIGRldGVjdGlvblxuICBhd2FpdCBhcHBlbmREZXRlY3Rpb25Mb2coZXZlbnQpO1xuXG4gIC8vIFVwZGF0ZSBsaWZldGltZSBzdGF0c1xuICBjb25zdCBhZ2VudFR5cGUgPSBldmVudC5hZ2VudC50eXBlO1xuICBjb25zdCB1cGRhdGVkVHlwZXMgPSB7IC4uLnN0YXRlLmxpZmV0aW1lU3RhdHMuYWdlbnRUeXBlc0RldGVjdGVkIH07XG4gIHVwZGF0ZWRUeXBlc1thZ2VudFR5cGVdID0gKHVwZGF0ZWRUeXBlc1thZ2VudFR5cGVdID8/IDApICsgMTtcbiAgc3RhdGUubGlmZXRpbWVTdGF0cyA9IHtcbiAgICAuLi5zdGF0ZS5saWZldGltZVN0YXRzLFxuICAgIGZpcnN0QWN0aXZlQXQ6IHN0YXRlLmxpZmV0aW1lU3RhdHMuZmlyc3RBY3RpdmVBdCA/PyBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdG90YWxTZXNzaW9uczogc3RhdGUubGlmZXRpbWVTdGF0cy50b3RhbFNlc3Npb25zICsgMSxcbiAgICBhZ2VudFR5cGVzRGV0ZWN0ZWQ6IHVwZGF0ZWRUeXBlcyxcbiAgfTtcbiAgdXBkYXRlTGlmZXRpbWVTdGF0cygoKSA9PiBzdGF0ZS5saWZldGltZVN0YXRzKS5jYXRjaCgoKSA9PiB7IC8qIG5vbi1jcml0aWNhbCAqLyB9KTtcblxuICB1cGRhdGVCYWRnZSgpO1xufVxuXG5mdW5jdGlvbiBoYW5kbGVBZ2VudEFjdGlvbih0YWJJZDogbnVtYmVyLCBldmVudDogQWdlbnRFdmVudCk6IHZvaWQge1xuICBjb25zdCBzZXNzaW9uSWQgPSBzdGF0ZS5hY3RpdmVTZXNzaW9ucy5nZXQodGFiSWQpO1xuICBpZiAoIXNlc3Npb25JZCkgcmV0dXJuO1xuXG4gIHVwZGF0ZVNlc3Npb24oc2Vzc2lvbklkLCAoc2Vzc2lvbikgPT4gYXBwZW5kRXZlbnRUb1Nlc3Npb24oc2Vzc2lvbiwgZXZlbnQpKS5jYXRjaCgoKSA9PiB7XG4gICAgLy8gSWdub3JlIHN0b3JhZ2UgZXJyb3JzIGZvciBpbmRpdmlkdWFsIGV2ZW50c1xuICB9KTtcbn1cblxuZnVuY3Rpb24gaGFuZGxlQm91bmRhcnlWaW9sYXRpb24odGFiSWQ6IG51bWJlciB8IHVuZGVmaW5lZCwgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvbik6IHZvaWQge1xuICBjb25zdCBhY3RpdmVSdWxlID0gc3RhdGUuZGVsZWdhdGlvblJ1bGVzLmZpbmQoKHIpID0+IHIuaXNBY3RpdmUpO1xuICBpZiAoIWFjdGl2ZVJ1bGUpIHJldHVybjtcblxuICAvLyBwcm9jZXNzQm91bmRhcnlWaW9sYXRpb24gY3JlYXRlcyB0aGUgYWxlcnQsIHNob3dzIHRoZSBub3RpZmljYXRpb24sIHN0b3JlcyB0aGUgcGVuZGluZ1xuICAvLyBvdmVycmlkZSwgYW5kIGxvZ3MgdGhlIHRpbWVsaW5lIGV2ZW50LlxuICBjb25zdCBhbGVydCA9IHByb2Nlc3NCb3VuZGFyeVZpb2xhdGlvbih0YWJJZCwgdmlvbGF0aW9uLCBhY3RpdmVSdWxlLCBzdGF0ZS5hY3RpdmVTZXNzaW9ucyk7XG5cbiAgc3RhdGUucmVjZW50QWxlcnRzLnB1c2goYWxlcnQpO1xuICBpZiAoc3RhdGUucmVjZW50QWxlcnRzLmxlbmd0aCA+IDIwKSB7XG4gICAgc3RhdGUucmVjZW50QWxlcnRzLnNoaWZ0KCk7XG4gIH1cblxuICAvLyBVcGRhdGUgbGlmZXRpbWUgc3RhdHNcbiAgc3RhdGUubGlmZXRpbWVTdGF0cyA9IHtcbiAgICAuLi5zdGF0ZS5saWZldGltZVN0YXRzLFxuICAgIHRvdGFsQWN0aW9uc0Jsb2NrZWQ6IHN0YXRlLmxpZmV0aW1lU3RhdHMudG90YWxBY3Rpb25zQmxvY2tlZCArIDEsXG4gIH07XG4gIHVwZGF0ZUxpZmV0aW1lU3RhdHMoKCkgPT4gc3RhdGUubGlmZXRpbWVTdGF0cykuY2F0Y2goKCkgPT4geyAvKiBub24tY3JpdGljYWwgKi8gfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlbGVnYXRpb25VcGRhdGUocnVsZTogRGVsZWdhdGlvblJ1bGUpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gQWRkIG9yIHVwZGF0ZSB0aGUgbmV3IHJ1bGUgZmlyc3QsIHRoZW4gZGVhY3RpdmF0ZSBhbGwgb3RoZXJzIChhdG9taWMgc3dhcCDigJQgYXZvaWRzIGJyaWVmIGdhcCB3aXRoIG5vIGFjdGl2ZSBydWxlKVxuICBjb25zdCBleGlzdGluZ0luZGV4ID0gc3RhdGUuZGVsZWdhdGlvblJ1bGVzLmZpbmRJbmRleCgocikgPT4gci5pZCA9PT0gcnVsZS5pZCk7XG4gIGlmIChleGlzdGluZ0luZGV4ID49IDApIHtcbiAgICBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXNbZXhpc3RpbmdJbmRleF0gPSBydWxlO1xuICB9IGVsc2Uge1xuICAgIHN0YXRlLmRlbGVnYXRpb25SdWxlcy5wdXNoKHJ1bGUpO1xuICB9XG5cbiAgLy8gRGVhY3RpdmF0ZSBhbGwgcnVsZXMgZXhjZXB0IHRoZSBuZXcgb25lXG4gIGZvciAoY29uc3QgciBvZiBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMpIHtcbiAgICBpZiAoci5pZCAhPT0gcnVsZS5pZCkge1xuICAgICAgci5pc0FjdGl2ZSA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIGF3YWl0IHNhdmVEZWxlZ2F0aW9uUnVsZXMoc3RhdGUuZGVsZWdhdGlvblJ1bGVzKTtcblxuICAvLyBCcm9hZGNhc3QgdG8gYWxsIGNvbnRlbnQgc2NyaXB0c1xuICBjb25zdCB0YWJzID0gYXdhaXQgY2hyb21lLnRhYnMucXVlcnkoe30pO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgaWYgKHRhYi5pZCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgIHR5cGU6ICdERUxFR0FUSU9OX1VQREFURScsXG4gICAgICAgIGRhdGE6IHJ1bGUsXG4gICAgICAgIHNlbnRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBUYWIgbWF5IG5vdCBoYXZlIGNvbnRlbnQgc2NyaXB0XG4gICAgfVxuICB9XG5cbiAgdXBkYXRlQmFkZ2UoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZUtpbGxTd2l0Y2goXG4gIHRyaWdnZXI6ICdidXR0b24nIHwgJ2tleWJvYXJkLXNob3J0Y3V0JyB8ICdhcGknXG4pOiBQcm9taXNlPEtpbGxTd2l0Y2hFdmVudD4ge1xuICBjb25zdCBhZ2VudElkcyA9IEFycmF5LmZyb20oc3RhdGUuYWN0aXZlQWdlbnRzLnZhbHVlcygpKS5tYXAoKGEpID0+IGEuaWQpO1xuXG4gIGNvbnN0IGV2ZW50ID0gYXdhaXQgZXhlY3V0ZUJhY2tncm91bmRLaWxsU3dpdGNoKHRyaWdnZXIsIGFnZW50SWRzLCBbXSk7XG5cbiAgc3RhdGUua2lsbFN3aXRjaC5pc0FjdGl2ZSA9IHRydWU7XG4gIHN0YXRlLmtpbGxTd2l0Y2gubGFzdEV2ZW50ID0gZXZlbnQ7XG4gIHN0YXRlLmtpbGxTd2l0Y2gubGFzdEFjdGl2YXRlZEF0ID0gZXZlbnQudGltZXN0YW1wO1xuXG4gIC8vIENsZWFyIGFjdGl2ZSBhZ2VudHNcbiAgc3RhdGUuYWN0aXZlQWdlbnRzLmNsZWFyKCk7XG5cbiAgLy8gRGVhY3RpdmF0ZSBhbGwgZGVsZWdhdGlvbiBydWxlc1xuICBmb3IgKGNvbnN0IHJ1bGUgb2Ygc3RhdGUuZGVsZWdhdGlvblJ1bGVzKSB7XG4gICAgcnVsZS5pc0FjdGl2ZSA9IGZhbHNlO1xuICB9XG4gIGF3YWl0IHNhdmVEZWxlZ2F0aW9uUnVsZXMoc3RhdGUuZGVsZWdhdGlvblJ1bGVzKTtcblxuICAvLyBFbmQgYWxsIGFjdGl2ZSBzZXNzaW9uc1xuICBmb3IgKGNvbnN0IFt0YWJJZCwgc2Vzc2lvbklkXSBvZiBzdGF0ZS5hY3RpdmVTZXNzaW9ucy5lbnRyaWVzKCkpIHtcbiAgICBhd2FpdCB1cGRhdGVTZXNzaW9uKHNlc3Npb25JZCwgKHNlc3Npb24pID0+ICh7XG4gICAgICAuLi5zZXNzaW9uLFxuICAgICAgZW5kZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZW5kUmVhc29uOiAna2lsbC1zd2l0Y2gnIGFzIGNvbnN0LFxuICAgIH0pKTtcbiAgICBzdGF0ZS5hY3RpdmVTZXNzaW9ucy5kZWxldGUodGFiSWQpO1xuICB9XG5cbiAgYXdhaXQgY2xlYXJBbGxOb3RpZmljYXRpb25zKCk7XG4gIHVwZGF0ZUJhZGdlKCk7XG5cbiAgcmV0dXJuIGV2ZW50O1xufVxuXG5mdW5jdGlvbiB1cGRhdGVCYWRnZSgpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBpZiAoc3RhdGUua2lsbFN3aXRjaC5pc0FjdGl2ZSkge1xuICAgICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiAnWCcgfSk7XG4gICAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6ICcjZWY0NDQ0JyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBhZ2VudENvdW50ID0gc3RhdGUuYWN0aXZlQWdlbnRzLnNpemU7XG4gICAgaWYgKGFnZW50Q291bnQgPiAwKSB7XG4gICAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6IFN0cmluZyhhZ2VudENvdW50KSB9KTtcbiAgICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3IoeyBjb2xvcjogJyNmNTllMGInIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGhhc0FjdGl2ZURlbGVnYXRpb24gPSBzdGF0ZS5kZWxlZ2F0aW9uUnVsZXMuc29tZSgocikgPT4gci5pc0FjdGl2ZSk7XG4gICAgaWYgKGhhc0FjdGl2ZURlbGVnYXRpb24pIHtcbiAgICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogJycgfSk7XG4gICAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6ICcjMjJjNTVlJyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6ICcnIH0pO1xuICB9IGNhdGNoIHtcbiAgICAvLyBCYWRnZSBBUEkgbWF5IG5vdCBiZSBhdmFpbGFibGUgaW4gYWxsIGNvbnRleHRzXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlVGFiUmVtb3ZlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNlc3Npb25JZCA9IHN0YXRlLmFjdGl2ZVNlc3Npb25zLmdldCh0YWJJZCk7XG4gIGlmIChzZXNzaW9uSWQpIHtcbiAgICBhd2FpdCB1cGRhdGVTZXNzaW9uKHNlc3Npb25JZCwgKHNlc3Npb24pID0+ICh7XG4gICAgICAuLi5zZXNzaW9uLFxuICAgICAgZW5kZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZW5kUmVhc29uOiAncGFnZS11bmxvYWQnIGFzIGNvbnN0LFxuICAgIH0pKTtcbiAgICBzdGF0ZS5hY3RpdmVTZXNzaW9ucy5kZWxldGUodGFiSWQpO1xuICB9XG4gIHN0YXRlLmFjdGl2ZUFnZW50cy5kZWxldGUodGFiSWQpO1xuICB1cGRhdGVCYWRnZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjaGVja0RlbGVnYXRpb25FeHBpcmF0aW9uKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IHJ1bGUgb2Ygc3RhdGUuZGVsZWdhdGlvblJ1bGVzKSB7XG4gICAgaWYgKHJ1bGUuaXNBY3RpdmUgJiYgaXNUaW1lQm91bmRFeHBpcmVkKHJ1bGUuc2NvcGUudGltZUJvdW5kKSkge1xuICAgICAgcnVsZS5pc0FjdGl2ZSA9IGZhbHNlO1xuICAgICAgY2hhbmdlZCA9IHRydWU7XG5cbiAgICAgIC8vIE5vdGlmeSBjb250ZW50IHNjcmlwdHNcbiAgICAgIGNvbnN0IHRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7fSk7XG4gICAgICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgICAgIGlmICh0YWIuaWQgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgICB0eXBlOiAnREVMRUdBVElPTl9VUERBVEUnLFxuICAgICAgICAgICAgZGF0YTogbnVsbCxcbiAgICAgICAgICAgIHNlbnRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvLyBUYWIgbWF5IG5vdCBoYXZlIGNvbnRlbnQgc2NyaXB0XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpZiAoY2hhbmdlZCkge1xuICAgIGF3YWl0IHNhdmVEZWxlZ2F0aW9uUnVsZXMoc3RhdGUuZGVsZWdhdGlvblJ1bGVzKTtcbiAgICB1cGRhdGVCYWRnZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlZ2lzdGVyS2V5Ym9hcmRTaG9ydGN1dCgpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjaHJvbWUuY29tbWFuZHMub25Db21tYW5kLmFkZExpc3RlbmVyKChjb21tYW5kKSA9PiB7XG4gICAgICBpZiAoY29tbWFuZCA9PT0gJ2tpbGwtc3dpdGNoJykge1xuICAgICAgICBleGVjdXRlS2lsbFN3aXRjaCgna2V5Ym9hcmQtc2hvcnRjdXQnKS5jYXRjaCgoKSA9PiB7IC8qIGlnbm9yZSAqLyB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gQ29tbWFuZHMgQVBJIG1heSBub3QgYmUgYXZhaWxhYmxlXG4gIH1cbn1cblxuaW5pdGlhbGl6ZSgpO1xuIl0sIm5hbWVzIjpbInN0YXRlIl0sIm1hcHBpbmdzIjoiQUE2SE8sTUFBTSx5QkFBd0M7QUFBQSxFQUNuRCxlQUFlO0FBQUEsRUFDZixlQUFlO0FBQUEsRUFDZixxQkFBcUI7QUFBQSxFQUNyQixvQkFBb0IsQ0FBQTtBQUN0QjtBQUtPLE1BQU0sbUJBQWlDO0FBQUEsRUFDNUMsa0JBQWtCO0FBQUEsRUFDbEIsc0JBQXNCO0FBQUEsRUFDdEIsb0JBQW9CO0FBQUEsRUFDcEIsYUFBYTtBQUFBLEVBQ2Isd0JBQXdCO0FBQUEsRUFDeEIsd0JBQXdCO0FBQzFCO0FDbElBLE1BQU0sa0JBQWlDO0FBQUEsRUFDckMsVUFBVSxDQUFBO0FBQUEsRUFDVixpQkFBaUIsQ0FBQTtBQUFBLEVBQ2pCLFVBQVU7QUFBQSxFQUNWLGNBQWMsQ0FBQTtBQUNoQjtBQU1BLGVBQXNCLGtCQUEwQztBQUM5RCxNQUFJO0FBQ0YsVUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxNQUN4QyxPQUFPLEtBQUssZUFBZTtBQUFBLElBQUE7QUFFN0IsV0FBTztBQUFBLE1BQ0wsVUFBVSxPQUFPLFlBQVksZ0JBQWdCO0FBQUEsTUFDN0MsaUJBQWlCLE9BQU8sbUJBQW1CLGdCQUFnQjtBQUFBLE1BQzNELFVBQVUsRUFBRSxHQUFHLGtCQUFrQixHQUFJLE9BQU8sWUFBWSxDQUFBLEVBQUM7QUFBQSxNQUN6RCxjQUFjLE9BQU8sZ0JBQWdCLGdCQUFnQjtBQUFBLElBQUE7QUFBQSxFQUV6RCxTQUFTLEtBQUs7QUFDWixZQUFRLE1BQU0sMENBQTBDLEdBQUc7QUFDM0QsV0FBTyxFQUFFLEdBQUcsZ0JBQUE7QUFBQSxFQUNkO0FBQ0Y7QUFNQSxlQUFzQixZQUFZLFNBQXNDO0FBQ3RFLE1BQUk7QUFDRixVQUFNQSxTQUFRLE1BQU0sZ0JBQUE7QUFDcEIsVUFBTSxXQUFXLENBQUMsU0FBUyxHQUFHQSxPQUFNLFFBQVE7QUFDNUMsVUFBTSxjQUFjQSxPQUFNLFNBQVMsZUFBZTtBQUNsRCxRQUFJLFNBQVMsU0FBUyxhQUFhO0FBQ2pDLGVBQVMsU0FBUztBQUFBLElBQ3BCO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsVUFBVTtBQUFBLEVBQzdDLFNBQVMsS0FBSztBQUNaLFlBQVEsTUFBTSw4Q0FBOEMsR0FBRztBQUFBLEVBQ2pFO0FBQ0Y7QUFLQSxlQUFzQixjQUNwQixXQUNBLFNBQ2U7QUFDZixNQUFJO0FBQ0YsVUFBTUEsU0FBUSxNQUFNLGdCQUFBO0FBQ3BCLFVBQU0sUUFBUUEsT0FBTSxTQUFTLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTO0FBQ2hFLFFBQUksVUFBVSxJQUFJO0FBQ2hCLGNBQVEsS0FBSyx5Q0FBeUMsU0FBUztBQUMvRDtBQUFBLElBQ0Y7QUFDQSxJQUFBQSxPQUFNLFNBQVMsS0FBSyxJQUFJLFFBQVFBLE9BQU0sU0FBUyxLQUFLLENBQUM7QUFDckQsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsVUFBVUEsT0FBTSxVQUFVO0FBQUEsRUFDN0QsU0FBUyxLQUFLO0FBQ1osWUFBUSxNQUFNLGdEQUFnRCxHQUFHO0FBQUEsRUFDbkU7QUFDRjtBQWFBLGVBQXNCLG9CQUFvQixPQUF3QztBQUNoRixNQUFJO0FBQ0YsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsaUJBQWlCLE9BQU87QUFBQSxFQUMzRCxTQUFTLEtBQUs7QUFDWixZQUFRLE1BQU0sdURBQXVELEdBQUc7QUFBQSxFQUMxRTtBQUNGO0FBY0EsZUFBc0IsbUJBQW1CLE9BQXNDO0FBQzdFLE1BQUk7QUFDRixVQUFNQSxTQUFRLE1BQU0sZ0JBQUE7QUFDcEIsVUFBTSxNQUFNLENBQUMsR0FBR0EsT0FBTSxjQUFjLEtBQUs7QUFDekMsVUFBTSxhQUFhQSxPQUFNLFNBQVMsMEJBQTBCO0FBQzVELFFBQUksSUFBSSxTQUFTLFlBQVk7QUFDM0IsVUFBSSxPQUFPLEdBQUcsSUFBSSxTQUFTLFVBQVU7QUFBQSxJQUN2QztBQUNBLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLGNBQWMsS0FBSztBQUFBLEVBQ3RELFNBQVMsS0FBSztBQUNaLFlBQVEsTUFBTSxzREFBc0QsR0FBRztBQUFBLEVBQ3pFO0FBQ0Y7QUFLQSxlQUFzQixjQUFxQztBQUN6RCxRQUFNQSxTQUFRLE1BQU0sZ0JBQUE7QUFDcEIsU0FBT0EsT0FBTTtBQUNmO0FBS0EsZUFBc0IsZUFBZSxTQUErQztBQUNsRixNQUFJO0FBQ0YsVUFBTSxVQUFVLE1BQU0sWUFBQTtBQUN0QixVQUFNLFNBQVMsRUFBRSxHQUFHLFNBQVMsR0FBRyxRQUFBO0FBQ2hDLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLFVBQVUsUUFBUTtBQUFBLEVBQ3JELFNBQVMsS0FBSztBQUNaLFlBQVEsTUFBTSxpREFBaUQsR0FBRztBQUFBLEVBQ3BFO0FBQ0Y7QUFLQSxlQUFzQixtQkFBMkM7QUFDL0QsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksZUFBZTtBQUM3RCxXQUFPLEVBQUUsR0FBRyx3QkFBd0IsR0FBSSxPQUFPLGlCQUFpQixDQUFBLEVBQUM7QUFBQSxFQUNuRSxRQUFRO0FBQ04sV0FBTyxFQUFFLEdBQUcsdUJBQUE7QUFBQSxFQUNkO0FBQ0Y7QUFLQSxlQUFzQixvQkFDcEIsU0FDZTtBQUNmLE1BQUk7QUFDRixVQUFNLFVBQVUsTUFBTSxpQkFBQTtBQUN0QixVQUFNLFVBQVUsUUFBUSxPQUFPO0FBQy9CLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLGVBQWUsU0FBUztBQUFBLEVBQzNELFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUMvSkEsU0FBUyxhQUFxQjtBQUM1QixTQUFPLE9BQU8sV0FBQTtBQUNoQjtBQUtPLFNBQVMsb0JBQ2QsTUFDQSxLQUNBLGFBQ0EsU0FNWTtBQUNaLFNBQU87QUFBQSxJQUNMLElBQUksV0FBQTtBQUFBLElBQ0o7QUFBQSxJQUNBLFlBQVcsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxJQUN0QjtBQUFBLElBQ0E7QUFBQSxJQUNBLFNBQVMsU0FBUyxXQUFXO0FBQUEsSUFDN0IsZ0JBQWdCLFNBQVM7QUFBQSxJQUN6QixpQkFBaUIsU0FBUztBQUFBLElBQzFCLFFBQVEsU0FBUztBQUFBLEVBQUE7QUFFckI7QUFLTyxTQUFTLHFCQUNkLFNBQ0EsT0FDYztBQUNkLFFBQU0sU0FBUyxDQUFDLEdBQUcsUUFBUSxRQUFRLEtBQUs7QUFDeEMsUUFBTSxVQUFVLHNCQUFzQixRQUFRLFFBQVEsU0FBUztBQUMvRCxTQUFPLEVBQUUsR0FBRyxTQUFTLFFBQVEsUUFBQTtBQUMvQjtBQUtPLFNBQVMsc0JBQ2QsUUFDQSxXQUNnQjtBQUNoQixNQUFJLGVBQWU7QUFDbkIsTUFBSSxpQkFBaUI7QUFDckIsTUFBSSxpQkFBaUI7QUFDckIsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sZ0NBQWdCLElBQUE7QUFFdEIsYUFBVyxTQUFTLFFBQVE7QUFDMUIsUUFBSSxNQUFNLFlBQVksV0FBVztBQUMvQjtBQUNBO0FBQUEsSUFDRixXQUFXLE1BQU0sWUFBWSxXQUFXO0FBQ3RDO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxNQUFNLFNBQVMsc0JBQXNCO0FBQ3ZDO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBTSxLQUFLO0FBQ2IsZ0JBQVUsSUFBSSxNQUFNLE1BQU0sVUFBVSxJQUFJLE1BQU0sR0FBRyxLQUFLLEtBQUssQ0FBQztBQUFBLElBQzlEO0FBQUEsRUFDRjtBQUVBLFFBQU0sVUFBVSxDQUFDLEdBQUcsVUFBVSxRQUFBLENBQVMsRUFDcEMsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUMxQixNQUFNLEdBQUcsQ0FBQyxFQUNWLElBQUksQ0FBQyxDQUFDLEdBQUcsTUFBTSxHQUFHO0FBRXJCLE1BQUksa0JBQWlDO0FBQ3JDLE1BQUksT0FBTyxTQUFTLEdBQUc7QUFDckIsVUFBTSxZQUFZLE9BQU8sT0FBTyxTQUFTLENBQUM7QUFDMUMsVUFBTSxRQUFRLElBQUksS0FBSyxTQUFTLEVBQUUsUUFBQTtBQUNsQyxVQUFNLE1BQU0sSUFBSSxLQUFLLFVBQVUsU0FBUyxFQUFFLFFBQUE7QUFDMUMsc0JBQWtCLEtBQUssT0FBTyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQ25EO0FBRUEsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQUE7QUFFSjtBQ2tHTyxTQUFTLG1CQUFtQixXQUFzQztBQUN2RSxNQUFJLGNBQWMsS0FBTSxRQUFPO0FBQy9CLFVBQU8sb0JBQUksS0FBQSxHQUFPLFFBQUEsSUFBWSxJQUFJLEtBQUssVUFBVSxTQUFTLEVBQUUsUUFBQTtBQUM5RDtBQXlCTyxTQUFTLFlBQVksT0FBeUM7QUFDbkUsU0FBTyxFQUFFLEdBQUcsT0FBTyxTQUFTLEtBQUE7QUFDOUI7QUMzS0EsZUFBc0IsNEJBQ3BCLFNBQ0EsZ0JBQ0EsY0FDMEI7QUFDMUIsUUFBTSxrQkFBNEIsQ0FBQTtBQUdsQyxhQUFXLFNBQVMsY0FBYztBQUNoQyxnQkFBWSxLQUFLO0FBQ2pCLG9CQUFnQixLQUFLLE1BQU0sT0FBTztBQUFBLEVBQ3BDO0FBR0EsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSx5QkFBeUI7QUFDN0IsTUFBSTtBQUNGLFVBQU0sT0FBTyxNQUFNLE9BQU8sS0FBSyxNQUFNLENBQUEsQ0FBRTtBQUN2QyxlQUFXLE9BQU8sTUFBTTtBQUN0QixVQUFJLElBQUksT0FBTyxPQUFXO0FBQzFCLFVBQUk7QUFDRixjQUFNLE9BQU8sS0FBSyxZQUFZLElBQUksSUFBSTtBQUFBLFVBQ3BDLE1BQU07QUFBQSxVQUNOLE1BQU0sQ0FBQTtBQUFBLFVBQ04sU0FBUSxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLFFBQVksQ0FDaEM7QUFBQSxNQUNILFFBQVE7QUFBQSxNQUVSO0FBQUEsSUFDRjtBQUNBLG9CQUFnQjtBQUNoQiw2QkFBeUI7QUFBQSxFQUMzQixRQUFRO0FBQUEsRUFFUjtBQUVBLFFBQU0sUUFBeUI7QUFBQSxJQUM3QixJQUFJLE9BQU8sV0FBQTtBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLElBQ3RCO0FBQUEsSUFDQSxvQkFBb0IsQ0FBQyxHQUFHLGNBQWM7QUFBQSxJQUN0QztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBQTtBQUlGLDZCQUEyQixlQUFlLE1BQU07QUFFaEQsU0FBTztBQUNUO0FBOEVPLFNBQVMsMkJBQTJCLFlBQTBCO0FBQ25FLE1BQUk7QUFDRixXQUFPLGNBQWMsT0FBTyxrQkFBa0IsS0FBSyxJQUFBLENBQUssSUFBSTtBQUFBLE1BQzFELE1BQU07QUFBQSxNQUNOLFNBQVMsT0FBTyxRQUFRLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEQsT0FBTztBQUFBLE1BQ1AsU0FBUyxjQUFjLFVBQVU7QUFBQSxNQUNqQyxVQUFVO0FBQUEsSUFBQSxDQUNYO0FBR0QsZUFBVyxNQUFNO0FBQ2YsVUFBSTtBQUNGLGVBQU8sY0FBYyxPQUFPLENBQUMsa0JBQWtCO0FBQzdDLHFCQUFXLE1BQU0sT0FBTyxLQUFLLGFBQWEsR0FBRztBQUMzQyxnQkFBSSxHQUFHLFdBQVcsaUJBQWlCLEdBQUc7QUFDcEMscUJBQU8sY0FBYyxNQUFNLEVBQUU7QUFBQSxZQUMvQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILFFBQVE7QUFBQSxNQUVSO0FBQUEsSUFDRixHQUFHLEdBQUk7QUFBQSxFQUNULFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFLTyxTQUFTLCtCQUFnRDtBQUM5RCxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixXQUFXO0FBQUEsSUFDWCxpQkFBaUI7QUFBQSxFQUFBO0FBRXJCO0FDbk5PLE1BQU0sOEJBQWtEO0FBQUEsRUFDN0QsU0FBUztBQUFBLEVBQ1QsaUJBQWlCO0FBQUEsRUFDakIsV0FBVztBQUFBLEVBQ1gsZUFBZTtBQUNqQjtBQUtPLFNBQVMseUJBQ2QsT0FDQSxRQUNlO0FBQ2YsUUFBTSxlQUFlLEVBQUUsR0FBRyw2QkFBNkIsR0FBRyxPQUFBO0FBRTFELE1BQUksQ0FBQyxhQUFhLFFBQVMsUUFBTztBQUNsQyxNQUFJLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxhQUFhLGVBQWUsRUFBRyxRQUFPO0FBRWxGLFFBQU0saUJBQWlCLGFBQWEsS0FBSyxJQUFBLENBQUs7QUFFOUMsTUFBSTtBQUNGLFVBQU0sVUFBMEQ7QUFBQSxNQUM5RCxNQUFNO0FBQUEsTUFDTixTQUFTLE9BQU8sUUFBUSxPQUFPLG1CQUFtQjtBQUFBLE1BQ2xELE9BQU8sc0JBQXNCLE1BQU0sS0FBSztBQUFBLE1BQ3hDLFNBQVMsTUFBTTtBQUFBLE1BQ2YsVUFBVSxtQkFBbUIsTUFBTSxRQUFRO0FBQUEsTUFDM0Msb0JBQW9CLE1BQU0sYUFBYTtBQUFBLElBQUE7QUFHekMsUUFBSSxNQUFNLHNCQUFzQjtBQUM5QixjQUFRLFVBQVU7QUFBQSxRQUNoQixFQUFFLE9BQU8sYUFBQTtBQUFBLFFBQ1QsRUFBRSxPQUFPLFVBQUE7QUFBQSxNQUFVO0FBQUEsSUFFdkI7QUFFQSxXQUFPLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTztBQUVuRCxRQUFJLGFBQWEsZ0JBQWdCLEtBQUssTUFBTSxhQUFhLFlBQVk7QUFDbkUsaUJBQVcsTUFBTTtBQUNmLFlBQUk7QUFDRixpQkFBTyxjQUFjLE1BQU0sY0FBYztBQUFBLFFBQzNDLFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDRixHQUFHLGFBQWEsYUFBYTtBQUFBLElBQy9CO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixZQUFRLE1BQU0scURBQXFELEdBQUc7QUFDdEUsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPO0FBQ1Q7QUFLTyxTQUFTLG1CQUFtQixVQUFpQztBQUNsRSxRQUFNLGNBQTZDO0FBQUEsSUFDakQsVUFBVTtBQUFBLElBQ1YsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsS0FBSztBQUFBLEVBQUE7QUFFUCxTQUFPLFlBQVksUUFBUTtBQUM3QjtBQUtPLFNBQVMsdUJBQ2QsVUFDQSxTQUNTO0FBQ1QsUUFBTSxRQUF5QixDQUFDLE9BQU8sVUFBVSxRQUFRLFVBQVU7QUFDbkUsU0FBTyxNQUFNLFFBQVEsUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPO0FBQ3pEO0FBS08sU0FBUywwQkFDZCxhQUNZO0FBQ1osUUFBTSxVQUFVLENBQUMsZ0JBQXdCLGdCQUF3QjtBQUMvRCxRQUFJLGdCQUFnQixHQUFHO0FBRXJCLGtCQUFZLGNBQWM7QUFBQSxJQUM1QjtBQUVBLFFBQUk7QUFDRixhQUFPLGNBQWMsTUFBTSxjQUFjO0FBQUEsSUFDM0MsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBRUEsU0FBTyxjQUFjLGdCQUFnQixZQUFZLE9BQU87QUFFeEQsU0FBTyxNQUFNO0FBQ1gsV0FBTyxjQUFjLGdCQUFnQixlQUFlLE9BQU87QUFBQSxFQUM3RDtBQUNGO0FBS0EsZUFBc0Isd0JBQXVDO0FBQzNELFNBQU8sSUFBSSxRQUFjLENBQUMsWUFBWTtBQUNwQyxRQUFJO0FBQ0YsYUFBTyxjQUFjLE9BQU8sQ0FBQyxrQkFBa0I7QUFDN0MsbUJBQVcsTUFBTSxPQUFPLEtBQUssYUFBYSxHQUFHO0FBQzNDLGlCQUFPLGNBQWMsTUFBTSxFQUFFO0FBQUEsUUFDL0I7QUFDQSxnQkFBQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsUUFBUTtBQUNOLGNBQUE7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUNySEEsTUFBTSx5QkFBeUI7QUFBQSxFQUM3QjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBS08sU0FBUyxvQkFDZCxXQUNBLE1BQ2U7QUFDZixRQUFNLFdBQVcsMEJBQTBCLFVBQVUsaUJBQWlCLFVBQVUsR0FBRztBQUNuRixRQUFNLFFBQVEsbUJBQW1CLFVBQVUsZUFBZTtBQUMxRCxRQUFNLFVBQVUscUJBQXFCLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUV6RSxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0Esc0JBQXNCLGFBQWEsWUFBWSxhQUFhO0FBQUEsSUFDNUQsY0FBYztBQUFBLEVBQUE7QUFFbEI7QUFLTyxTQUFTLDBCQUNkLFlBQ0EsS0FDZTtBQUNmLFFBQU0sa0JBQTBEO0FBQUEsSUFDOUQsZUFBZTtBQUFBLElBQ2Ysa0JBQWtCO0FBQUEsSUFDbEIsaUJBQWlCO0FBQUEsSUFDakIsY0FBYztBQUFBLElBQ2QsT0FBTztBQUFBLElBQ1AsYUFBYTtBQUFBLElBQ2IsVUFBVTtBQUFBLElBQ1YsWUFBWTtBQUFBLElBQ1osYUFBYTtBQUFBLElBQ2IsWUFBWTtBQUFBLElBQ1osWUFBWTtBQUFBLEVBQUE7QUFHZCxNQUFJLFdBQVcsZ0JBQWdCLFVBQVUsS0FBSztBQUc5QyxRQUFNLGNBQWMsdUJBQXVCLEtBQUssQ0FBQyxZQUFZLFFBQVEsS0FBSyxHQUFHLENBQUM7QUFDOUUsTUFBSSxhQUFhO0FBQ2YsVUFBTSxVQUFnRDtBQUFBLE1BQ3BELEtBQUs7QUFBQSxNQUNMLFFBQVE7QUFBQSxNQUNSLE1BQU07QUFBQSxNQUNOLFVBQVU7QUFBQSxJQUFBO0FBRVosZUFBVyxRQUFRLFFBQVE7QUFBQSxFQUM3QjtBQUVBLFNBQU87QUFDVDtBQUtPLFNBQVMsbUJBQW1CLFlBQXFDO0FBQ3RFLFFBQU0sU0FBMEM7QUFBQSxJQUM5QyxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWixPQUFPO0FBQUEsSUFDUCxhQUFhO0FBQUEsSUFDYixlQUFlO0FBQUEsSUFDZixpQkFBaUI7QUFBQSxJQUNqQixZQUFZO0FBQUEsSUFDWixhQUFhO0FBQUEsSUFDYixZQUFZO0FBQUEsSUFDWixrQkFBa0I7QUFBQSxJQUNsQixjQUFjO0FBQUEsRUFBQTtBQUVoQixTQUFPLE9BQU8sVUFBVSxLQUFLO0FBQy9CO0FBS08sU0FBUyxxQkFDZCxXQUNBLFVBQ1E7QUFDUixRQUFNLFFBQVE7QUFBQSxJQUNaLGtDQUFrQyxVQUFVLGVBQWU7QUFBQSxJQUMzRCxVQUFVO0FBQUEsSUFDVjtBQUFBLElBQ0Esb0JBQW9CLFFBQVE7QUFBQSxJQUM1QixXQUFXLFVBQVUsTUFBTTtBQUFBLEVBQUE7QUFHN0IsTUFBSSxVQUFVLGdCQUFnQjtBQUM1QixVQUFNLEtBQUssbUJBQW1CLFVBQVUsY0FBYyxFQUFFO0FBQUEsRUFDMUQ7QUFFQSxTQUFPLE1BQU0sS0FBSyxJQUFJO0FBQ3hCO0FDdEdPLE1BQU0sdUNBQXFELElBQUE7QUFXM0QsU0FBUyx5QkFDZCxPQUNBLFdBQ0EsWUFDQSxnQkFDZTtBQUNmLFFBQU0sUUFBUSxvQkFBb0IsV0FBVyxVQUFVO0FBRXZELFFBQU0saUJBQWlCLHlCQUF5QixLQUFLO0FBR3JELE1BQUksbUJBQW1CLFFBQVEsVUFBVSxRQUFXO0FBQ2xELHFCQUFpQixJQUFJLGdCQUFnQjtBQUFBLE1BQ25DO0FBQUEsTUFDQSxZQUFZLFVBQVU7QUFBQSxNQUN0QixLQUFLLFVBQVU7QUFBQSxJQUFBLENBQ2hCO0FBQUEsRUFDSDtBQUdBLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFVBQU0sWUFBWSxlQUFlLElBQUksS0FBSztBQUMxQyxRQUFJLFdBQVc7QUFDYixZQUFNLFFBQVE7QUFBQSxRQUNaO0FBQUEsUUFDQSxVQUFVO0FBQUEsUUFDVixjQUFjLFVBQVUsZUFBZTtBQUFBLFFBQ3ZDO0FBQUEsVUFDRSxpQkFBaUIsVUFBVTtBQUFBLFVBQzNCLFNBQVM7QUFBQSxVQUNULFFBQVEsVUFBVTtBQUFBLFVBQ2xCLGdCQUFnQixVQUFVO0FBQUEsUUFBQTtBQUFBLE1BQzVCO0FBRUYsb0JBQWMsV0FBVyxDQUFDLFlBQVkscUJBQXFCLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFBQSxRQUMxRSxNQUFNO0FBQUEsUUFBZTtBQUFBLE1BQUE7QUFBQSxJQUV6QjtBQUFBLEVBQ0Y7QUFFQSxTQUFPO0FBQ1Q7QUFVQSxlQUFzQixnQkFBZ0IsZ0JBQTBDO0FBQzlFLFFBQU0sV0FBVyxpQkFBaUIsSUFBSSxjQUFjO0FBQ3BELE1BQUksQ0FBQyxTQUFVLFFBQU87QUFFdEIsbUJBQWlCLE9BQU8sY0FBYztBQUV0QyxNQUFJO0FBQ0YsVUFBTSxPQUFPLEtBQUssWUFBWSxTQUFTLE9BQU87QUFBQSxNQUM1QyxNQUFNO0FBQUEsTUFDTixNQUFNLEVBQUUsWUFBWSxTQUFTLFlBQVksS0FBSyxTQUFTLElBQUE7QUFBQSxNQUN2RCxTQUFRLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsSUFBWSxDQUNoQztBQUFBLEVBQ0gsUUFBUTtBQUFBLEVBRVI7QUFHQSxNQUFJO0FBQ0YsV0FBTyxjQUFjLE1BQU0sY0FBYztBQUFBLEVBQzNDLFFBQVE7QUFBQSxFQUVSO0FBRUEsU0FBTztBQUNUO0FDckZBLE1BQU0sUUFBeUI7QUFBQSxFQUM3QixrQ0FBa0IsSUFBQTtBQUFBLEVBQ2xCLG9DQUFvQixJQUFBO0FBQUEsRUFDcEIsaUJBQWlCLENBQUE7QUFBQSxFQUNqQixZQUFZLDZCQUFBO0FBQUEsRUFDWixjQUFjLENBQUE7QUFBQSxFQUNkLGVBQWUsRUFBRSxHQUFHLHVCQUFBO0FBQ3RCO0FBRUEsU0FBUyxhQUFtQjtBQUMxQixxQkFBQSxFQUFxQixLQUFLLE1BQU07QUFDOUIsZ0JBQUE7QUFBQSxFQUNGLENBQUMsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQixZQUFRLE1BQU0sNENBQTRDLEdBQUc7QUFBQSxFQUMvRCxDQUFDO0FBR0QsU0FBTyxRQUFRLFVBQVUsWUFBWSxhQUFhO0FBR2xELFNBQU8sS0FBSyxVQUFVLFlBQVksQ0FBQyxVQUFVO0FBQzNDLHFCQUFpQixLQUFLLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBZSxDQUFDO0FBQUEsRUFDdEQsQ0FBQztBQUdELFNBQU8sT0FBTyxPQUFPLG9CQUFvQixFQUFFLGlCQUFpQixHQUFHO0FBRS9ELFNBQU8sT0FBTyxPQUFPLGtCQUFrQixFQUFFLGlCQUFpQixLQUFLO0FBQy9ELFNBQU8sT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzNDLFFBQUksTUFBTSxTQUFTLG9CQUFvQjtBQUNyQyxnQ0FBQSxFQUE0QixNQUFNLE1BQU07QUFBQSxNQUFlLENBQUM7QUFBQSxJQUMxRDtBQUFBLEVBRUYsQ0FBQztBQUdELDJCQUFBO0FBR0EsNEJBQTBCLENBQUMsbUJBQW1CO0FBQzVDLG9CQUFnQixjQUFjLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBZSxDQUFDO0FBQUEsRUFDOUQsQ0FBQztBQUVELFVBQVEsSUFBSSwwREFBMEQ7QUFDeEU7QUFFQSxlQUFlLHFCQUFvQztBQUNqRCxRQUFNLFNBQVMsTUFBTSxnQkFBQTtBQUNyQixRQUFNLGtCQUFrQixPQUFPO0FBQy9CLFFBQU0sZ0JBQWdCLE1BQU0saUJBQUE7QUFHNUIsYUFBVyxXQUFXLE9BQU8sVUFBVTtBQUNyQyxRQUFJLENBQUMsUUFBUSxTQUFTO0FBRXBCLFlBQU0sY0FBYyxRQUFRLElBQUksQ0FBQyxPQUFPO0FBQUEsUUFDdEMsR0FBRztBQUFBLFFBQ0gsVUFBUyxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLFFBQ3BCLFdBQVc7QUFBQSxNQUFBLEVBQ1g7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxjQUNQLFNBQ0EsUUFDQSxjQUNTO0FBQ1QsTUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQU0sUUFBTztBQUV0QyxRQUFNLFFBQVEsT0FBTyxLQUFLO0FBRTFCLFVBQVEsUUFBUSxNQUFBO0FBQUEsSUFDZCxLQUFLLG9CQUFvQjtBQUN2QixVQUFJLFVBQVUsUUFBVztBQUN2Qix3QkFBZ0IsT0FBTyxRQUFRLElBQXNCLEVBQUUsS0FBSyxNQUFNO0FBQ2hFLHVCQUFhLEVBQUUsU0FBUyxNQUFNO0FBQUEsUUFDaEMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHVCQUFhLEVBQUUsU0FBUyxPQUFPO0FBQUEsUUFDakMsQ0FBQztBQUNELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUVBLEtBQUssZ0JBQWdCO0FBQ25CLFVBQUksVUFBVSxRQUFXO0FBQ3ZCLDBCQUFrQixPQUFPLFFBQVEsSUFBa0I7QUFBQSxNQUNyRDtBQUNBLG1CQUFhLEVBQUUsU0FBUyxNQUFNO0FBQzlCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLDBCQUEwQjtBQUM3QixZQUFNLFlBQVksUUFBUTtBQUMxQiw4QkFBd0IsT0FBTyxTQUFTO0FBQ3hDLG1CQUFhLEVBQUUsU0FBUyxNQUFNO0FBQzlCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLHdCQUF3QjtBQUMzQjtBQUFBLFFBQ0csUUFBUSxNQUErQixXQUFxRDtBQUFBLE1BQUEsRUFDN0YsS0FBSyxDQUFDLFVBQVU7QUFDaEIscUJBQWEsRUFBRSxTQUFTLE1BQU0sTUFBQSxDQUFPO0FBQUEsTUFDdkMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHFCQUFhLEVBQUUsU0FBUyxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLHFCQUFxQjtBQUN4QixZQUFNLFdBQVcsV0FBVztBQUM1QixZQUFNLFdBQVcsWUFBWTtBQUM3QixZQUFNLFdBQVcsa0JBQWtCO0FBQ25DLGtCQUFBO0FBQ0EsbUJBQWEsRUFBRSxTQUFTLE1BQU07QUFDOUIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUVBLEtBQUsscUJBQXFCO0FBQ3hCLFlBQU0sT0FBTyxRQUFRO0FBQ3JCLDZCQUF1QixJQUFJLEVBQUUsS0FBSyxNQUFNO0FBQ3RDLHFCQUFhLEVBQUUsU0FBUyxNQUFNO0FBQUEsTUFDaEMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHFCQUFhLEVBQUUsU0FBUyxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLGlCQUFpQjtBQUNwQixzQkFBQSxFQUFrQixLQUFLLENBQUMsV0FBVztBQUNqQyxxQkFBYSxFQUFFLFVBQVUsT0FBTyxTQUFBLENBQVU7QUFBQSxNQUM1QyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQ2IscUJBQWEsRUFBRSxVQUFVLENBQUEsR0FBSTtBQUFBLE1BQy9CLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBRUEsS0FBSyxnQkFBZ0I7QUFDbkIsWUFBTSxTQUFTLE1BQU0sS0FBSyxNQUFNLGFBQWEsUUFBUTtBQUNyRCxZQUFNLGFBQWEsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLEtBQUs7QUFDcEUsbUJBQWE7QUFBQSxRQUNYLGdCQUFnQjtBQUFBLFFBQ2hCLGtCQUFrQjtBQUFBLFFBQ2xCLGtCQUFrQixNQUFNLFdBQVc7QUFBQSxRQUNuQyxrQkFBa0IsTUFBTTtBQUFBLFFBQ3hCLGlCQUFpQixNQUFNO0FBQUEsUUFDdkIsZUFBZSxNQUFNO0FBQUEsTUFBQSxDQUN0QjtBQUNELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQSxLQUFLLG1CQUFtQjtBQUN0QixZQUFNLFVBQVUsUUFBUTtBQUN4QixxQkFBZSxPQUFPLEVBQUUsS0FBSyxNQUFNO0FBQ2pDLHFCQUFhLEVBQUUsU0FBUyxNQUFNO0FBQUEsTUFDaEMsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUNiLHFCQUFhLEVBQUUsU0FBUyxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFFQTtBQUNFLGFBQU87QUFBQSxFQUFBO0FBRWI7QUFFQSxlQUFlLGdCQUFnQixPQUFlLE9BQXNDO0FBQ2xGLE1BQUksQ0FBQyxNQUFNLE1BQU87QUFFbEIsUUFBTSxhQUFhLElBQUksT0FBTyxNQUFNLEtBQUs7QUFHekMsUUFBTSxVQUF3QjtBQUFBLElBQzVCLElBQUksT0FBTyxXQUFBO0FBQUEsSUFDWCxPQUFPLE1BQU07QUFBQSxJQUNiLGdCQUFnQixNQUFNLGdCQUFnQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsS0FBSztBQUFBLElBQ2pFLFFBQVEsQ0FBQTtBQUFBLElBQ1IsWUFBVyxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLElBQ3RCLFNBQVM7QUFBQSxJQUNULFdBQVc7QUFBQSxJQUNYLFNBQVM7QUFBQSxNQUNQLGNBQWM7QUFBQSxNQUNkLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxNQUNaLFNBQVMsQ0FBQTtBQUFBLE1BQ1QsaUJBQWlCO0FBQUEsSUFBQTtBQUFBLEVBQ25CO0FBSUYsUUFBTSxvQkFBNEM7QUFBQSxJQUNoRCxZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxVQUFVO0FBQUEsSUFDViwwQkFBMEI7QUFBQSxJQUMxQixtQkFBbUI7QUFBQSxJQUNuQixlQUFlO0FBQUEsSUFDZixxQkFBcUI7QUFBQSxJQUNyQixTQUFTO0FBQUEsRUFBQTtBQUVYLFFBQU0sbUJBQW1CLGtCQUFrQixNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU0sTUFBTTtBQUM1RSxRQUFNLGdCQUFnQixvQkFBb0IsYUFBYSxNQUFNLEtBQUssbUJBQW1CLGdCQUFnQixJQUFJO0FBQUEsSUFDdkcsU0FBUztBQUFBLEVBQUEsQ0FDVjtBQUNELFFBQU0saUJBQWlCLHFCQUFxQixTQUFTLGFBQWE7QUFFbEUsUUFBTSxZQUFZLGNBQWM7QUFDaEMsUUFBTSxlQUFlLElBQUksT0FBTyxlQUFlLEVBQUU7QUFHakQsUUFBTSxtQkFBbUIsS0FBSztBQUc5QixRQUFNLFlBQVksTUFBTSxNQUFNO0FBQzlCLFFBQU0sZUFBZSxFQUFFLEdBQUcsTUFBTSxjQUFjLG1CQUFBO0FBQzlDLGVBQWEsU0FBUyxLQUFLLGFBQWEsU0FBUyxLQUFLLEtBQUs7QUFDM0QsUUFBTSxnQkFBZ0I7QUFBQSxJQUNwQixHQUFHLE1BQU07QUFBQSxJQUNULGVBQWUsTUFBTSxjQUFjLGtCQUFpQixvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLElBQy9ELGVBQWUsTUFBTSxjQUFjLGdCQUFnQjtBQUFBLElBQ25ELG9CQUFvQjtBQUFBLEVBQUE7QUFFdEIsc0JBQW9CLE1BQU0sTUFBTSxhQUFhLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBcUIsQ0FBQztBQUVqRixjQUFBO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixPQUFlLE9BQXlCO0FBQ2pFLFFBQU0sWUFBWSxNQUFNLGVBQWUsSUFBSSxLQUFLO0FBQ2hELE1BQUksQ0FBQyxVQUFXO0FBRWhCLGdCQUFjLFdBQVcsQ0FBQyxZQUFZLHFCQUFxQixTQUFTLEtBQUssQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBRXhGLENBQUM7QUFDSDtBQUVBLFNBQVMsd0JBQXdCLE9BQTJCLFdBQW9DO0FBQzlGLFFBQU0sYUFBYSxNQUFNLGdCQUFnQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVE7QUFDL0QsTUFBSSxDQUFDLFdBQVk7QUFJakIsUUFBTSxRQUFRLHlCQUF5QixPQUFPLFdBQVcsWUFBWSxNQUFNLGNBQWM7QUFFekYsUUFBTSxhQUFhLEtBQUssS0FBSztBQUM3QixNQUFJLE1BQU0sYUFBYSxTQUFTLElBQUk7QUFDbEMsVUFBTSxhQUFhLE1BQUE7QUFBQSxFQUNyQjtBQUdBLFFBQU0sZ0JBQWdCO0FBQUEsSUFDcEIsR0FBRyxNQUFNO0FBQUEsSUFDVCxxQkFBcUIsTUFBTSxjQUFjLHNCQUFzQjtBQUFBLEVBQUE7QUFFakUsc0JBQW9CLE1BQU0sTUFBTSxhQUFhLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBcUIsQ0FBQztBQUNuRjtBQUVBLGVBQWUsdUJBQXVCLE1BQXFDO0FBRXpFLFFBQU0sZ0JBQWdCLE1BQU0sZ0JBQWdCLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUU7QUFDN0UsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLGdCQUFnQixhQUFhLElBQUk7QUFBQSxFQUN6QyxPQUFPO0FBQ0wsVUFBTSxnQkFBZ0IsS0FBSyxJQUFJO0FBQUEsRUFDakM7QUFHQSxhQUFXLEtBQUssTUFBTSxpQkFBaUI7QUFDckMsUUFBSSxFQUFFLE9BQU8sS0FBSyxJQUFJO0FBQ3BCLFFBQUUsV0FBVztBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBRUEsUUFBTSxvQkFBb0IsTUFBTSxlQUFlO0FBRy9DLFFBQU0sT0FBTyxNQUFNLE9BQU8sS0FBSyxNQUFNLENBQUEsQ0FBRTtBQUN2QyxhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLElBQUksT0FBTyxPQUFXO0FBQzFCLFFBQUk7QUFDRixZQUFNLE9BQU8sS0FBSyxZQUFZLElBQUksSUFBSTtBQUFBLFFBQ3BDLE1BQU07QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFNBQVEsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxNQUFZLENBQ2hDO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFFQSxjQUFBO0FBQ0Y7QUFFQSxlQUFlLGtCQUNiLFNBQzBCO0FBQzFCLFFBQU0sV0FBVyxNQUFNLEtBQUssTUFBTSxhQUFhLE9BQUEsQ0FBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRTtBQUV4RSxRQUFNLFFBQVEsTUFBTSw0QkFBNEIsU0FBUyxVQUFVLENBQUEsQ0FBRTtBQUVyRSxRQUFNLFdBQVcsV0FBVztBQUM1QixRQUFNLFdBQVcsWUFBWTtBQUM3QixRQUFNLFdBQVcsa0JBQWtCLE1BQU07QUFHekMsUUFBTSxhQUFhLE1BQUE7QUFHbkIsYUFBVyxRQUFRLE1BQU0saUJBQWlCO0FBQ3hDLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQ0EsUUFBTSxvQkFBb0IsTUFBTSxlQUFlO0FBRy9DLGFBQVcsQ0FBQyxPQUFPLFNBQVMsS0FBSyxNQUFNLGVBQWUsV0FBVztBQUMvRCxVQUFNLGNBQWMsV0FBVyxDQUFDLGFBQWE7QUFBQSxNQUMzQyxHQUFHO0FBQUEsTUFDSCxVQUFTLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsTUFDcEIsV0FBVztBQUFBLElBQUEsRUFDWDtBQUNGLFVBQU0sZUFBZSxPQUFPLEtBQUs7QUFBQSxFQUNuQztBQUVBLFFBQU0sc0JBQUE7QUFDTixjQUFBO0FBRUEsU0FBTztBQUNUO0FBRUEsU0FBUyxjQUFvQjtBQUMzQixNQUFJO0FBQ0YsUUFBSSxNQUFNLFdBQVcsVUFBVTtBQUM3QixhQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sS0FBSztBQUN4QyxhQUFPLE9BQU8sd0JBQXdCLEVBQUUsT0FBTyxXQUFXO0FBQzFEO0FBQUEsSUFDRjtBQUVBLFVBQU0sYUFBYSxNQUFNLGFBQWE7QUFDdEMsUUFBSSxhQUFhLEdBQUc7QUFDbEIsYUFBTyxPQUFPLGFBQWEsRUFBRSxNQUFNLE9BQU8sVUFBVSxHQUFHO0FBQ3ZELGFBQU8sT0FBTyx3QkFBd0IsRUFBRSxPQUFPLFdBQVc7QUFDMUQ7QUFBQSxJQUNGO0FBRUEsVUFBTSxzQkFBc0IsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRO0FBQ3hFLFFBQUkscUJBQXFCO0FBQ3ZCLGFBQU8sT0FBTyxhQUFhLEVBQUUsTUFBTSxJQUFJO0FBQ3ZDLGFBQU8sT0FBTyx3QkFBd0IsRUFBRSxPQUFPLFdBQVc7QUFDMUQ7QUFBQSxJQUNGO0FBRUEsV0FBTyxPQUFPLGFBQWEsRUFBRSxNQUFNLElBQUk7QUFBQSxFQUN6QyxRQUFRO0FBQUEsRUFFUjtBQUNGO0FBRUEsZUFBZSxpQkFBaUIsT0FBOEI7QUFDNUQsUUFBTSxZQUFZLE1BQU0sZUFBZSxJQUFJLEtBQUs7QUFDaEQsTUFBSSxXQUFXO0FBQ2IsVUFBTSxjQUFjLFdBQVcsQ0FBQyxhQUFhO0FBQUEsTUFDM0MsR0FBRztBQUFBLE1BQ0gsVUFBUyxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLE1BQ3BCLFdBQVc7QUFBQSxJQUFBLEVBQ1g7QUFDRixVQUFNLGVBQWUsT0FBTyxLQUFLO0FBQUEsRUFDbkM7QUFDQSxRQUFNLGFBQWEsT0FBTyxLQUFLO0FBQy9CLGNBQUE7QUFDRjtBQUVBLGVBQWUsNEJBQTJDO0FBQ3hELE1BQUksVUFBVTtBQUNkLGFBQVcsUUFBUSxNQUFNLGlCQUFpQjtBQUN4QyxRQUFJLEtBQUssWUFBWSxtQkFBbUIsS0FBSyxNQUFNLFNBQVMsR0FBRztBQUM3RCxXQUFLLFdBQVc7QUFDaEIsZ0JBQVU7QUFHVixZQUFNLE9BQU8sTUFBTSxPQUFPLEtBQUssTUFBTSxDQUFBLENBQUU7QUFDdkMsaUJBQVcsT0FBTyxNQUFNO0FBQ3RCLFlBQUksSUFBSSxPQUFPLE9BQVc7QUFDMUIsWUFBSTtBQUNGLGdCQUFNLE9BQU8sS0FBSyxZQUFZLElBQUksSUFBSTtBQUFBLFlBQ3BDLE1BQU07QUFBQSxZQUNOLE1BQU07QUFBQSxZQUNOLFNBQVEsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxVQUFZLENBQ2hDO0FBQUEsUUFDSCxRQUFRO0FBQUEsUUFFUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksU0FBUztBQUNYLFVBQU0sb0JBQW9CLE1BQU0sZUFBZTtBQUMvQyxnQkFBQTtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsMkJBQWlDO0FBQ3hDLE1BQUk7QUFDRixXQUFPLFNBQVMsVUFBVSxZQUFZLENBQUMsWUFBWTtBQUNqRCxVQUFJLFlBQVksZUFBZTtBQUM3QiwwQkFBa0IsbUJBQW1CLEVBQUUsTUFBTSxNQUFNO0FBQUEsUUFBZSxDQUFDO0FBQUEsTUFDckU7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFQSxXQUFBOyJ9
