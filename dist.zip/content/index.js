(function() {
  "use strict";
  function detectCdpConnection() {
    const signals = {};
    const found = [];
    const windowKeys = Object.getOwnPropertyNames(window);
    for (const key of windowKeys) {
      if (key.startsWith("__cdp_") || key.startsWith("__chromium_")) {
        found.push(key);
        signals[key] = true;
      }
    }
    const cdpBindings = [
      "__playwright_evaluation_script__",
      "__puppeteer_evaluation_script__",
      "__playwright",
      "__puppeteer"
    ];
    for (const binding of cdpBindings) {
      if (binding in window) {
        found.push(binding);
        signals[binding] = true;
      }
    }
    if ("DevToolsAPI" in window) {
      found.push("DevToolsAPI");
      signals.devToolsAPI = true;
    }
    const detected = found.length > 0;
    return {
      detected,
      method: "cdp-connection",
      confidence: detected ? found.length >= 2 ? "confirmed" : "high" : "low",
      detail: detected ? `CDP indicators found: ${found.join(", ")}.` : "No CDP connection indicators detected.",
      signals
    };
  }
  function monitorCdpConnections(callback) {
    let stopped = false;
    const knownKeys = new Set(Object.getOwnPropertyNames(window));
    const intervalId = setInterval(() => {
      if (stopped) return;
      const currentKeys = Object.getOwnPropertyNames(window);
      for (const key of currentKeys) {
        if (knownKeys.has(key)) continue;
        knownKeys.add(key);
        if (key.startsWith("__cdp_") || key.startsWith("__playwright") || key.startsWith("__puppeteer") || key.startsWith("__pw_") || key.startsWith("__chromium_")) {
          callback({
            detected: true,
            method: "cdp-connection",
            confidence: "high",
            detail: `New CDP binding detected: ${key}.`,
            signals: { [key]: true, detectedAt: Date.now() }
          });
        }
      }
    }, 2e3);
    return () => {
      stopped = true;
      clearInterval(intervalId);
    };
  }
  function detectWebDriverFlag() {
    const signals = {};
    try {
      const htmlEl = document.documentElement;
      if (htmlEl && typeof htmlEl.getAttribute === "function" && htmlEl.getAttribute("webdriver") !== null) {
        signals.htmlWebdriverAttr = true;
        return {
          detected: true,
          method: "webdriver-flag",
          confidence: "confirmed",
          detail: "HTML element has webdriver attribute set, indicating WebDriver control.",
          signals
        };
      }
    } catch {
    }
    const webdriverValue = navigator.webdriver;
    signals.webdriverValue = webdriverValue;
    const descriptor = Object.getOwnPropertyDescriptor(navigator, "webdriver");
    signals.hasOwnDescriptor = !!descriptor;
    if (descriptor) {
      signals.configurable = descriptor.configurable;
      signals.enumerable = descriptor.enumerable;
      signals.writable = descriptor.writable;
    }
    const protoDescriptor = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(navigator),
      "webdriver"
    );
    signals.protoDescriptor = !!protoDescriptor;
    if (webdriverValue === true) {
      return {
        detected: true,
        method: "webdriver-flag",
        confidence: "high",
        detail: "navigator.webdriver is true, indicating WebDriver automation.",
        signals
      };
    }
    if (descriptor && webdriverValue === false) {
      return {
        detected: true,
        method: "webdriver-flag",
        confidence: "medium",
        detail: "navigator.webdriver was overridden to false, suggesting automation evasion.",
        signals
      };
    }
    return {
      detected: false,
      method: "webdriver-flag",
      confidence: "low",
      detail: "No WebDriver flag detected.",
      signals
    };
  }
  function detectNavigatorAnomalies() {
    const signals = {};
    let detected = false;
    const details = [];
    const pluginsLength = navigator.plugins?.length ?? 0;
    signals.pluginsLength = pluginsLength;
    if (pluginsLength === 0) {
      detected = true;
      details.push("No browser plugins detected (headless indicator).");
    }
    signals.languages = navigator.languages;
    if (!navigator.languages || navigator.languages.length === 0) {
      detected = true;
      details.push("No browser languages set (headless indicator).");
    }
    try {
      signals.notificationPermission = Notification.permission;
      if (Notification.permission === "denied") {
        details.push("Notifications are denied by default.");
      }
    } catch {
      signals.notificationPermission = "unavailable";
    }
    return {
      detected,
      method: "automation-flag",
      confidence: detected ? "medium" : "low",
      detail: details.length > 0 ? details.join(" ") : "No navigator anomalies detected.",
      signals
    };
  }
  function detectSeleniumMarkers() {
    const signals = {};
    const foundMarkers = [];
    const docKeys = Object.getOwnPropertyNames(document);
    for (const key of docKeys) {
      if (key.startsWith("$cdc_") || key.startsWith("$wdc_")) {
        foundMarkers.push(key);
        signals[key] = true;
      }
    }
    const seleniumGlobals = [
      "callSelenium",
      "_selenium",
      "callPhantom",
      "__nightmare",
      "_Selenium_IDE_Recorder"
    ];
    for (const name of seleniumGlobals) {
      if (name in window) {
        foundMarkers.push(name);
        signals[name] = true;
      }
    }
    const windowKeys = Object.getOwnPropertyNames(window);
    for (const key of windowKeys) {
      if (key.startsWith("cdc_") || key.startsWith("$chrome_asyncScriptInfo")) {
        foundMarkers.push(key);
        signals[key] = true;
      }
    }
    return {
      detected: foundMarkers.length > 0,
      method: "framework-fingerprint",
      confidence: foundMarkers.length > 0 ? "confirmed" : "low",
      detail: foundMarkers.length > 0 ? `Selenium markers found: ${foundMarkers.join(", ")}.` : "No Selenium markers detected.",
      signals
    };
  }
  function monitorWebDriverChanges(callback) {
    let stopped = false;
    const intervalId = setInterval(() => {
      if (stopped) return;
      const result = detectWebDriverFlag();
      if (result.detected) {
        callback(result);
      }
    }, 3e3);
    return () => {
      stopped = true;
      clearInterval(intervalId);
    };
  }
  function detectAnthropicComputerUse() {
    const signals = {};
    const found = [];
    const markers = [
      "__anthropic_computer_use__",
      "__computer_use__",
      "__anthropic_tool__"
    ];
    for (const marker of markers) {
      if (marker in window) {
        found.push(marker);
        signals[marker] = true;
      }
    }
    try {
      const canvasProto = HTMLCanvasElement.prototype;
      const toDataURLDesc = Object.getOwnPropertyDescriptor(canvasProto, "toDataURL");
      if (toDataURLDesc && !toDataURLDesc.writable && toDataURLDesc.configurable) {
        signals.toDataURLModified = true;
      }
    } catch {
    }
    return {
      detected: found.length > 0,
      frameworkType: "anthropic-computer-use",
      method: "framework-fingerprint",
      confidence: found.length > 0 ? "high" : "low",
      detail: found.length > 0 ? `Anthropic Computer Use indicators: ${found.join(", ")}.` : "No Anthropic Computer Use indicators detected.",
      signals
    };
  }
  function detectOpenAIOperator() {
    const signals = {};
    const found = [];
    const markers = [
      "__openai_operator__",
      "__operator_runtime__",
      "__openai_browser_tool__"
    ];
    for (const marker of markers) {
      if (marker in window) {
        found.push(marker);
        signals[marker] = true;
      }
    }
    const ua = navigator.userAgent;
    if (ua.includes("Operator") || ua.includes("OpenAI")) {
      found.push("userAgent");
      signals.userAgent = ua;
    }
    if (typeof Element !== "undefined" && "getComputedAccessibleNode" in Element.prototype) {
      signals.accessibilityAPI = true;
    }
    return {
      detected: found.length > 0,
      frameworkType: "openai-operator",
      method: "framework-fingerprint",
      confidence: found.length > 0 ? "high" : "low",
      detail: found.length > 0 ? `OpenAI Operator indicators: ${found.join(", ")}.` : "No OpenAI Operator indicators detected.",
      signals
    };
  }
  function detectAllFrameworks() {
    const results = [];
    const computerUse = detectAnthropicComputerUse();
    if (computerUse.detected) results.push(computerUse);
    const operator = detectOpenAIOperator();
    if (operator.detected) results.push(operator);
    const generic = detectGenericAutomation();
    if (generic.detected) results.push(generic);
    return results;
  }
  function detectGenericAutomation() {
    const signals = {};
    const indicators = [];
    const chromeObj = window.chrome;
    if (chromeObj) {
      signals.hasLoadTimes = "loadTimes" in chromeObj;
      signals.hasCsi = "csi" in chromeObj;
      if (!("loadTimes" in chromeObj)) {
        indicators.push("missing chrome.loadTimes");
      }
      if (!("csi" in chromeObj)) {
        indicators.push("missing chrome.csi");
      }
    }
    if (window.outerWidth === 0 && window.outerHeight === 0) {
      indicators.push("zero outer dimensions");
      signals.outerWidth = window.outerWidth;
      signals.outerHeight = window.outerHeight;
    }
    if (!window.chrome) {
      indicators.push("window.chrome missing");
      signals.chromePresent = false;
    }
    try {
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl");
      if (gl) {
        const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");
        if (debugInfo) {
          const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
          signals.webglRenderer = renderer;
          if (typeof renderer === "string" && (renderer.includes("SwiftShader") || renderer.includes("llvmpipe"))) {
            indicators.push("software renderer (headless indicator)");
          }
        }
      }
    } catch {
    }
    const detected = indicators.length >= 2;
    return {
      detected,
      frameworkType: detected ? "cdp-generic" : "unknown",
      method: "automation-flag",
      confidence: detected ? "medium" : "low",
      detail: detected ? `Generic automation indicators: ${indicators.join(", ")}.` : "No generic automation indicators detected.",
      signals
    };
  }
  const BEHAVIORAL_THRESHOLDS = {
    mouseIntervalStdDevMin: 15,
    integerCoordinateRatioMax: 0.95,
    keyIntervalStdDevMin: 20,
    syntheticEventRatioMax: 0.5,
    minimumEventsRequired: 20
  };
  function computeStdDev(values) {
    if (values.length < 2) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((sum, v) => sum + (v - mean) ** 2, 0) / (values.length - 1);
    return Math.sqrt(variance);
  }
  function computeMean(values) {
    if (values.length === 0) return 0;
    return values.reduce((a, b) => a + b, 0) / values.length;
  }
  function emptyMetrics() {
    return {
      averageMouseInterval: 0,
      mouseIntervalStdDev: 0,
      integerCoordinateRatio: 0,
      averageKeyInterval: 0,
      keyIntervalStdDev: 0,
      syntheticEventRatio: 0,
      clicksWithoutMovement: 0,
      totalEventsAnalyzed: 0
    };
  }
  function analyzeMouseBehavior(events) {
    const metrics = emptyMetrics();
    metrics.totalEventsAnalyzed = events.length;
    if (events.length < BEHAVIORAL_THRESHOLDS.minimumEventsRequired) {
      return {
        detected: false,
        method: "behavioral-timing",
        confidence: "low",
        detail: `Insufficient mouse events for analysis (${events.length}/${BEHAVIORAL_THRESHOLDS.minimumEventsRequired}).`,
        metrics
      };
    }
    const intervals = [];
    for (let i = 1; i < events.length; i++) {
      intervals.push(events[i].timestamp - events[i - 1].timestamp);
    }
    metrics.averageMouseInterval = computeMean(intervals);
    metrics.mouseIntervalStdDev = computeStdDev(intervals);
    let integerCount = 0;
    for (const e of events) {
      if (e.clientX === Math.floor(e.clientX) && e.clientY === Math.floor(e.clientY)) {
        integerCount++;
      }
    }
    metrics.integerCoordinateRatio = integerCount / events.length;
    const syntheticCount = events.filter((e) => !e.isTrusted).length;
    metrics.syntheticEventRatio = syntheticCount / events.length;
    let clicksWithoutMovement = 0;
    for (let i = 0; i < events.length; i++) {
      if (events[i].type === "click") {
        const hasPrecedingMove = i > 0 && events[i - 1].type === "mousemove";
        if (!hasPrecedingMove) clicksWithoutMovement++;
      }
    }
    metrics.clicksWithoutMovement = clicksWithoutMovement;
    const anomalies = [];
    if (metrics.mouseIntervalStdDev < BEHAVIORAL_THRESHOLDS.mouseIntervalStdDevMin) {
      anomalies.push("uniform mouse timing");
    }
    if (metrics.integerCoordinateRatio > BEHAVIORAL_THRESHOLDS.integerCoordinateRatioMax) {
      anomalies.push("integer-only coordinates");
    }
    if (metrics.syntheticEventRatio > BEHAVIORAL_THRESHOLDS.syntheticEventRatioMax) {
      anomalies.push("high synthetic event ratio");
    }
    const detected = anomalies.length > 0;
    let confidence = "low";
    if (anomalies.length >= 3) confidence = "high";
    else if (anomalies.length >= 2) confidence = "medium";
    else if (anomalies.length === 1) confidence = "low";
    return {
      detected,
      method: "behavioral-timing",
      confidence,
      detail: detected ? `Mouse behavioral anomalies: ${anomalies.join(", ")}.` : "Mouse behavior appears human.",
      metrics
    };
  }
  function analyzeKeyboardBehavior(events) {
    const metrics = emptyMetrics();
    metrics.totalEventsAnalyzed = events.length;
    if (events.length < BEHAVIORAL_THRESHOLDS.minimumEventsRequired) {
      return {
        detected: false,
        method: "behavioral-typing",
        confidence: "low",
        detail: `Insufficient keyboard events for analysis (${events.length}/${BEHAVIORAL_THRESHOLDS.minimumEventsRequired}).`,
        metrics
      };
    }
    const keydowns = events.filter((e) => e.type === "keydown");
    const intervals = [];
    for (let i = 1; i < keydowns.length; i++) {
      intervals.push(keydowns[i].timestamp - keydowns[i - 1].timestamp);
    }
    metrics.averageKeyInterval = computeMean(intervals);
    metrics.keyIntervalStdDev = computeStdDev(intervals);
    const syntheticCount = events.filter((e) => !e.isTrusted).length;
    metrics.syntheticEventRatio = syntheticCount / events.length;
    const anomalies = [];
    if (metrics.keyIntervalStdDev < BEHAVIORAL_THRESHOLDS.keyIntervalStdDevMin && keydowns.length > 5) {
      anomalies.push("uniform key timing");
    }
    if (metrics.syntheticEventRatio > BEHAVIORAL_THRESHOLDS.syntheticEventRatioMax) {
      anomalies.push("high synthetic event ratio");
    }
    if (metrics.averageKeyInterval > 0 && metrics.averageKeyInterval < 30 && keydowns.length > 5) {
      anomalies.push("superhuman typing speed");
    }
    const detected = anomalies.length > 0;
    let confidence = "low";
    if (anomalies.length >= 2) confidence = "medium";
    if (metrics.syntheticEventRatio > 0.8) confidence = "high";
    return {
      detected,
      method: "behavioral-typing",
      confidence,
      detail: detected ? `Keyboard behavioral anomalies: ${anomalies.join(", ")}.` : "Keyboard behavior appears human.",
      metrics
    };
  }
  function analyzeClickPrecision(clicks) {
    const metrics = emptyMetrics();
    metrics.totalEventsAnalyzed = clicks.length;
    if (clicks.length < 5) {
      return {
        detected: false,
        method: "behavioral-precision",
        confidence: "low",
        detail: `Insufficient click data for precision analysis (${clicks.length}/5).`,
        metrics
      };
    }
    const offsets = [];
    for (const click of clicks) {
      const centerX = click.targetRect.x + click.targetRect.width / 2;
      const centerY = click.targetRect.y + click.targetRect.height / 2;
      const offset = Math.sqrt(
        (click.clientX - centerX) ** 2 + (click.clientY - centerY) ** 2
      );
      offsets.push(offset);
    }
    const stdDev = computeStdDev(offsets);
    const meanOffset = computeMean(offsets);
    const detected = stdDev < 2 && meanOffset < 3;
    const confidence = detected ? "medium" : "low";
    return {
      detected,
      method: "behavioral-precision",
      confidence,
      detail: detected ? `Click precision is suspiciously uniform (std dev: ${stdDev.toFixed(1)}px, mean offset: ${meanOffset.toFixed(1)}px).` : `Click precision appears human (std dev: ${stdDev.toFixed(1)}px).`,
      metrics
    };
  }
  function aggregateBehavioralAnalysis(mouseResult, keyboardResult, clickResult) {
    const results = [mouseResult, keyboardResult, clickResult].filter(
      (r) => r !== null
    );
    if (results.length === 0) {
      return {
        detected: false,
        method: "behavioral-timing",
        confidence: "low",
        detail: "No behavioral data available for analysis.",
        metrics: emptyMetrics()
      };
    }
    const detectedCount = results.filter((r) => r.detected).length;
    const detected = detectedCount > 0;
    const confidenceOrder = ["low", "medium", "high", "confirmed"];
    let confidence = "low";
    if (detectedCount >= 3) {
      confidence = "confirmed";
    } else if (detectedCount >= 2) {
      confidence = "high";
    } else if (detectedCount === 1) {
      const detectedResult = results.find((r) => r.detected);
      confidence = detectedResult?.confidence ?? "low";
    }
    const bestResult = results.reduce((best, r) => {
      const bestIdx = confidenceOrder.indexOf(best.confidence);
      const rIdx = confidenceOrder.indexOf(r.confidence);
      return rIdx > bestIdx ? r : best;
    });
    const details = results.filter((r) => r.detected).map((r) => r.detail).join(" ");
    return {
      detected,
      method: bestResult.method,
      confidence,
      detail: detected ? details : "Behavioral analysis indicates human interaction.",
      metrics: bestResult.metrics
    };
  }
  const DEFAULT_DETECTOR_CONFIG = {
    enableBehavioral: true,
    minimumConfidence: "low",
    recheckIntervalMs: 5e3,
    behavioralSampleSize: 20
  };
  const CONFIDENCE_ORDER = ["low", "medium", "high", "confirmed"];
  function confidenceRank(c) {
    return CONFIDENCE_ORDER.indexOf(c);
  }
  function maxConfidence(...confidences) {
    return confidences.reduce(
      (best, c) => confidenceRank(c) > confidenceRank(best) ? c : best,
      "low"
    );
  }
  function runDetectionSweep(config) {
    const cfg = { ...DEFAULT_DETECTOR_CONFIG, ...config };
    const methods = [];
    const signals = {};
    const webDriverResult = detectWebDriverFlag();
    if (webDriverResult.detected) {
      methods.push(webDriverResult.method);
      Object.assign(signals, webDriverResult.signals);
    }
    const navigatorResult = detectNavigatorAnomalies();
    if (navigatorResult.detected) {
      methods.push(navigatorResult.method);
      Object.assign(signals, navigatorResult.signals);
    }
    const seleniumResult = detectSeleniumMarkers();
    if (seleniumResult.detected) {
      methods.push(seleniumResult.method);
      Object.assign(signals, seleniumResult.signals);
    }
    const cdpResult = detectCdpConnection();
    if (cdpResult.detected) {
      methods.push(cdpResult.method);
      Object.assign(signals, cdpResult.signals);
    }
    const frameworkResults = detectAllFrameworks();
    for (const fr of frameworkResults) {
      methods.push(fr.method);
      Object.assign(signals, fr.signals);
    }
    const behavioralResult = null;
    const detectedResults = [
      webDriverResult.detected ? webDriverResult : null,
      navigatorResult.detected ? navigatorResult : null,
      seleniumResult.detected ? seleniumResult : null,
      cdpResult.detected ? cdpResult : null,
      ...frameworkResults.filter((r) => r.detected)
    ].filter(Boolean);
    const agentDetected = detectedResults.length > 0;
    let overallConfidence = "low";
    if (agentDetected) {
      const confidences = [];
      if (webDriverResult.detected) confidences.push(webDriverResult.confidence);
      if (seleniumResult.detected) confidences.push(seleniumResult.confidence);
      if (cdpResult.detected) confidences.push(cdpResult.confidence);
      for (const fr of frameworkResults) {
        if (fr.detected) confidences.push(fr.confidence);
      }
      overallConfidence = maxConfidence(...confidences);
      if (detectedResults.length >= 3 && confidenceRank(overallConfidence) < confidenceRank("confirmed")) {
        overallConfidence = "confirmed";
      } else if (detectedResults.length >= 2 && confidenceRank(overallConfidence) < confidenceRank("high")) {
        overallConfidence = "high";
      }
    }
    if (agentDetected && confidenceRank(overallConfidence) < confidenceRank(cfg.minimumConfidence)) {
      const event2 = {
        id: crypto.randomUUID(),
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        methods,
        confidence: overallConfidence,
        agent: null,
        url: window.location.href,
        signals
      };
      return {
        agentDetected: false,
        agent: null,
        cdpResult,
        webDriverResult,
        frameworkResults,
        behavioralResult,
        overallConfidence,
        event: event2
      };
    }
    const agentType = agentDetected ? classifyAgentType(cdpResult, webDriverResult, frameworkResults) : "unknown";
    const agent = agentDetected ? {
      id: crypto.randomUUID(),
      type: agentType,
      detectionMethods: methods,
      confidence: overallConfidence,
      detectedAt: (/* @__PURE__ */ new Date()).toISOString(),
      originUrl: window.location.href,
      observedCapabilities: [],
      isActive: true
    } : null;
    const event = {
      id: crypto.randomUUID(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      methods,
      confidence: overallConfidence,
      agent,
      url: window.location.href,
      signals
    };
    return {
      agentDetected,
      agent,
      cdpResult,
      webDriverResult,
      frameworkResults,
      behavioralResult,
      overallConfidence,
      event
    };
  }
  function startDetectionMonitor(config, onDetection) {
    const cfg = { ...DEFAULT_DETECTOR_CONFIG, ...config };
    const cleanups = [];
    let lastDetectedAgentId = null;
    const mouseEvents = [];
    const keyEvents = [];
    const clickPrecisionData = [];
    const initialResult = runDetectionSweep(cfg);
    if (initialResult.agentDetected) {
      lastDetectedAgentId = initialResult.agent?.id ?? null;
      onDetection(initialResult);
    }
    const intervalId = setInterval(() => {
      const result = runDetectionSweep(cfg);
      if (cfg.enableBehavioral && mouseEvents.length >= cfg.behavioralSampleSize) {
        const mouseResult = analyzeMouseBehavior([...mouseEvents]);
        const keyResult = keyEvents.length >= cfg.behavioralSampleSize ? analyzeKeyboardBehavior([...keyEvents]) : null;
        const clickResult = clickPrecisionData.length >= 5 ? analyzeClickPrecision([...clickPrecisionData]) : null;
        const behavioralResult = aggregateBehavioralAnalysis(mouseResult, keyResult, clickResult);
        result.behavioralResult = behavioralResult;
        if (behavioralResult.detected && !result.agentDetected) {
          result.agentDetected = true;
          result.overallConfidence = behavioralResult.confidence;
          result.event.confidence = behavioralResult.confidence;
          result.event.methods.push(behavioralResult.method);
        }
      }
      if (result.agentDetected) {
        if (result.agent?.id !== lastDetectedAgentId || !lastDetectedAgentId) {
          lastDetectedAgentId = result.agent?.id ?? null;
          onDetection(result);
        }
      }
    }, cfg.recheckIntervalMs);
    cleanups.push(() => clearInterval(intervalId));
    if (cfg.enableBehavioral) {
      const maxBuffer = cfg.behavioralSampleSize * 3;
      const onMouseEvent = (e) => {
        mouseEvents.push({
          type: e.type,
          clientX: e.clientX,
          clientY: e.clientY,
          timestamp: e.timeStamp,
          isTrusted: e.isTrusted
        });
        if (mouseEvents.length > maxBuffer) mouseEvents.shift();
      };
      const onKeyEvent = (e) => {
        keyEvents.push({
          type: e.type,
          key: e.key,
          timestamp: e.timeStamp,
          isTrusted: e.isTrusted
        });
        if (keyEvents.length > maxBuffer) keyEvents.shift();
      };
      const onClickForPrecision = (e) => {
        const target = e.target;
        if (target) {
          const rect = target.getBoundingClientRect();
          clickPrecisionData.push({
            clientX: e.clientX,
            clientY: e.clientY,
            targetRect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
            timestamp: e.timeStamp
          });
          if (clickPrecisionData.length > maxBuffer) clickPrecisionData.shift();
        }
      };
      document.addEventListener("mousemove", onMouseEvent, { passive: true, capture: true });
      document.addEventListener("click", onClickForPrecision, { passive: true, capture: true });
      document.addEventListener("keydown", onKeyEvent, { passive: true, capture: true });
      document.addEventListener("keyup", onKeyEvent, { passive: true, capture: true });
      cleanups.push(() => {
        document.removeEventListener("mousemove", onMouseEvent, { capture: true });
        document.removeEventListener("click", onClickForPrecision, { capture: true });
        document.removeEventListener("keydown", onKeyEvent, { capture: true });
        document.removeEventListener("keyup", onKeyEvent, { capture: true });
      });
    }
    const cdpCleanup = monitorCdpConnections((result) => {
      if (result.detected) {
        const verdict = runDetectionSweep(cfg);
        if (verdict.agentDetected) {
          onDetection(verdict);
        }
      }
    });
    cleanups.push(cdpCleanup);
    const wdCleanup = monitorWebDriverChanges((result) => {
      if (result.detected) {
        const verdict = runDetectionSweep(cfg);
        if (verdict.agentDetected) {
          onDetection(verdict);
        }
      }
    });
    cleanups.push(wdCleanup);
    return () => {
      for (const cleanup of cleanups) {
        try {
          cleanup();
        } catch {
        }
      }
    };
  }
  function classifyAgentType(cdpResult, webDriverResult, frameworkResults, behavioralResult) {
    for (const fr of frameworkResults) {
      if (fr.detected && fr.frameworkType !== "unknown") {
        return fr.frameworkType;
      }
    }
    if (cdpResult?.detected) {
      if (cdpResult.detail.includes("Playwright")) return "playwright";
      if (cdpResult.detail.includes("Puppeteer")) return "puppeteer";
      return "cdp-generic";
    }
    if (webDriverResult?.detected) {
      return "webdriver-generic";
    }
    return "unknown";
  }
  function evaluateRule(rule, action, url) {
    if (!rule.isActive) {
      return { allowed: false, reason: "Delegation rule is not active." };
    }
    if (isTimeBoundExpired(rule.scope.timeBound)) {
      return { allowed: false, reason: "Delegation has expired." };
    }
    const defaultSiteAction = rule.preset === "limited" ? "block" : "allow";
    const siteResult = evaluateSitePatterns(url, rule.scope.sitePatterns, defaultSiteAction);
    if (!siteResult.allowed) {
      const patternDetail = siteResult.matchedPattern ? ` (matched: ${siteResult.matchedPattern.pattern})` : " (default policy)";
      return { allowed: false, reason: `URL blocked by site policy${patternDetail}.` };
    }
    const actionResult = evaluateActionRestrictions(action, rule.scope.actionRestrictions);
    if (!actionResult.allowed) {
      return {
        allowed: false,
        reason: `Action "${action}" is not permitted under ${rule.preset} delegation.`
      };
    }
    return { allowed: true, reason: "Action permitted by delegation rules." };
  }
  function evaluateSitePatterns(url, patterns, defaultAction) {
    for (const pattern of patterns) {
      if (matchGlob(url, pattern.pattern)) {
        return {
          allowed: pattern.action === "allow",
          matchedPattern: pattern
        };
      }
    }
    return { allowed: defaultAction === "allow", matchedPattern: null };
  }
  function matchGlob(url, pattern) {
    try {
      if (!pattern.includes("://")) {
        const parsedUrl = new URL(url);
        const hostname = parsedUrl.hostname;
        const regexStr2 = pattern.replace(/\./g, "\\.").replace(/\*\*/g, ".*").replace(/\*/g, "[^.]*");
        return new RegExp(`^${regexStr2}$`).test(hostname);
      }
      const regexStr = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\\\*/g, ".*");
      return new RegExp(`^${regexStr}$`).test(url);
    } catch {
      return false;
    }
  }
  function evaluateActionRestrictions(action, restrictions) {
    const restriction = restrictions.find((r) => r.capability === action);
    if (!restriction) {
      return { allowed: false, matchedRestriction: null };
    }
    return {
      allowed: restriction.action === "allow",
      matchedRestriction: restriction
    };
  }
  function isTimeBoundExpired(timeBound) {
    if (timeBound === null) return false;
    return (/* @__PURE__ */ new Date()).getTime() > new Date(timeBound.expiresAt).getTime();
  }
  function generateId() {
    return crypto.randomUUID();
  }
  function createTimelineEvent(type, url, description, options) {
    return {
      id: generateId(),
      type,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      url,
      description,
      outcome: options?.outcome ?? "informational",
      targetSelector: options?.targetSelector,
      attemptedAction: options?.attemptedAction,
      ruleId: options?.ruleId
    };
  }
  let monitorState = {
    activeRule: null,
    isMonitoring: false,
    allowedCount: 0,
    blockedCount: 0,
    recentViolations: []
  };
  function checkBoundary(action, url, rule) {
    if (!rule) {
      return {
        allowed: false,
        matchedRule: null,
        reason: "No active delegation rule. All actions are blocked by default."
      };
    }
    if (!rule.isActive) {
      return {
        allowed: false,
        matchedRule: rule,
        reason: "Delegation rule is no longer active."
      };
    }
    if (isDelegationExpired(rule)) {
      return {
        allowed: false,
        matchedRule: rule,
        reason: "Delegation has expired."
      };
    }
    const result = evaluateRule(rule, action, url);
    return {
      allowed: result.allowed,
      matchedRule: rule,
      reason: result.reason
    };
  }
  function mapEventToCapability(eventType) {
    switch (eventType) {
      case "click":
        return "click";
      case "input":
        return "type-text";
      case "submit":
        return "submit-form";
      case "keydown":
        return "type-text";
      default:
        return null;
    }
  }
  function getSelector(el) {
    if (el.id) return `#${el.id}`;
    if (el.className && typeof el.className === "string") {
      const classes = el.className.trim().split(/\s+/).slice(0, 2).join(".");
      if (classes) return `${el.tagName.toLowerCase()}.${classes}`;
    }
    return el.tagName.toLowerCase();
  }
  function startBoundaryMonitor(rule, onViolation, onAction) {
    monitorState = {
      activeRule: rule,
      isMonitoring: true,
      allowedCount: 0,
      blockedCount: 0,
      recentViolations: []
    };
    const cleanups = [];
    const interceptionHandler = (e) => {
      if (!monitorState.isMonitoring) return;
      if (e.isTrusted) return;
      const capability = mapEventToCapability(e.type);
      if (!capability) return;
      const target = e.target;
      const selector = target ? getSelector(target) : void 0;
      const url = window.location.href;
      const result = checkBoundary(capability, url, monitorState.activeRule);
      if (result.allowed) {
        monitorState.allowedCount++;
        const event = createTimelineEvent("action-allowed", url, `${capability} allowed`, {
          targetSelector: selector,
          attemptedAction: capability,
          outcome: "allowed",
          ruleId: monitorState.activeRule?.id
        });
        onAction(event);
      } else {
        monitorState.blockedCount++;
        e.preventDefault();
        e.stopPropagation();
        const violation = {
          id: crypto.randomUUID(),
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          agentId: "",
          attemptedAction: capability,
          url,
          targetSelector: selector,
          blockingRuleId: monitorState.activeRule?.id ?? "none",
          reason: result.reason,
          userOverride: false
        };
        monitorState.recentViolations.push(violation);
        if (monitorState.recentViolations.length > 50) {
          monitorState.recentViolations.shift();
        }
        onViolation(violation);
        const event = createTimelineEvent("action-blocked", url, `${capability} blocked: ${result.reason}`, {
          targetSelector: selector,
          attemptedAction: capability,
          outcome: "blocked",
          ruleId: monitorState.activeRule?.id
        });
        onAction(event);
      }
    };
    const eventTypes = ["click", "input", "submit", "keydown"];
    for (const type of eventTypes) {
      document.addEventListener(type, interceptionHandler, { capture: true });
    }
    cleanups.push(() => {
      for (const type of eventTypes) {
        document.removeEventListener(type, interceptionHandler, { capture: true });
      }
    });
    const observer = new MutationObserver((mutations) => {
      if (!monitorState.isMonitoring) return;
      for (const mutation of mutations) {
        if (mutation.type === "childList" && (mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0)) {
          const url = window.location.href;
          const result = checkBoundary("modify-dom", url, monitorState.activeRule);
          if (!result.allowed) {
            const target = mutation.target;
            const violation = {
              id: crypto.randomUUID(),
              timestamp: (/* @__PURE__ */ new Date()).toISOString(),
              agentId: "",
              attemptedAction: "modify-dom",
              url,
              targetSelector: target?.nodeType === 1 ? getSelector(target) : "document",
              blockingRuleId: monitorState.activeRule?.id ?? "none",
              reason: result.reason,
              userOverride: false
            };
            onViolation(violation);
          }
        }
      }
    });
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    }
    cleanups.push(() => observer.disconnect());
    return () => {
      monitorState.isMonitoring = false;
      for (const cleanup of cleanups) {
        try {
          cleanup();
        } catch {
        }
      }
    };
  }
  function updateActiveRule(rule) {
    monitorState.activeRule = rule;
  }
  function isDelegationExpired(rule) {
    return isTimeBoundExpired(rule.scope.timeBound);
  }
  function getMonitorState() {
    return { ...monitorState };
  }
  const registeredCleanups = [];
  function registerCleanup(cleanup) {
    registeredCleanups.push(cleanup);
  }
  function executeContentKillSwitch() {
    let listenersRemoved = 0;
    let observersDisconnected = 0;
    for (const cleanup of registeredCleanups) {
      try {
        cleanup();
        listenersRemoved++;
      } catch {
      }
    }
    registeredCleanups.length = 0;
    const bindingsCleared = clearAutomationFlags();
    terminateCdpConnections();
    return { listenersRemoved, observersDisconnected, bindingsCleared };
  }
  function terminateCdpConnections() {
    try {
      const windowKeys = Object.getOwnPropertyNames(window);
      let found = false;
      for (const key of windowKeys) {
        if (key.startsWith("__cdp_") || key.startsWith("__chromium_")) {
          try {
            delete window[key];
            found = true;
          } catch {
          }
        }
      }
      return found;
    } catch {
      return false;
    }
  }
  function clearAutomationFlags() {
    const cleared = [];
    try {
      Object.defineProperty(navigator, "webdriver", {
        get: () => false,
        configurable: true
      });
      cleared.push("navigator.webdriver");
    } catch {
    }
    const docKeys = Object.getOwnPropertyNames(document);
    for (const key of docKeys) {
      if (key.startsWith("$cdc_") || key.startsWith("$wdc_")) {
        try {
          delete document[key];
          cleared.push(key);
        } catch {
        }
      }
    }
    const windowKeys = Object.getOwnPropertyNames(window);
    const automationPrefixes = ["__playwright", "__puppeteer", "__pw_"];
    for (const key of windowKeys) {
      if (automationPrefixes.some((prefix) => key.startsWith(prefix))) {
        try {
          delete window[key];
          cleared.push(key);
        } catch {
        }
      }
    }
    return cleared;
  }
  const GUARD_NONCE = crypto.randomUUID();
  const MSG_INIT = "AI_GUARD:INIT";
  const MSG_RULE_UPDATE = "AI_GUARD:RULE_UPDATE";
  const MSG_ACTION = "AI_GUARD:ACTION";
  const MSG_ALLOW_ONCE = "AI_GUARD:ALLOW_ONCE";
  let detectionCleanup = null;
  let monitorCleanup = null;
  let currentAgentId = null;
  function syncRuleToMainWorld(rule) {
    const ruleData = rule ? {
      isActive: rule.isActive,
      expiresAt: rule.scope.timeBound?.expiresAt ?? null,
      actionRestrictions: rule.scope.actionRestrictions.map((r) => ({
        capability: r.capability,
        action: r.action
      })),
      sitePatterns: rule.scope.sitePatterns.map((p) => ({
        pattern: p.pattern,
        action: p.action
      }))
    } : null;
    window.postMessage({ type: MSG_RULE_UPDATE, nonce: GUARD_NONCE, rule: ruleData }, "*");
  }
  function initialize() {
    window.postMessage({ type: MSG_INIT, nonce: GUARD_NONCE }, "*");
    window.addEventListener("message", (e) => {
      if (e.source !== window || !e.data) return;
      if (e.data.type !== MSG_ACTION) return;
      if (!e.data.nonce || e.data.nonce !== GUARD_NONCE) return;
      const { capability, url, blocked, reason, timestamp } = e.data;
      if (blocked) {
        const violation = {
          id: crypto.randomUUID(),
          timestamp: timestamp ?? (/* @__PURE__ */ new Date()).toISOString(),
          agentId: currentAgentId ?? "",
          attemptedAction: capability,
          url,
          targetSelector: void 0,
          blockingRuleId: getMonitorState().activeRule?.id ?? "none",
          reason,
          userOverride: false
        };
        sendToBackground("BOUNDARY_CHECK_REQUEST", violation).catch(() => {
        });
      }
    });
    chrome.runtime.onMessage.addListener(handleMessage);
    const startMonitoring = () => {
      detectionCleanup = startDetectionMonitor({}, onDetectionResult);
      registerCleanup(() => {
        if (detectionCleanup) detectionCleanup();
      });
      monitorCleanup = startBoundaryMonitor(
        null,
        (violation) => {
          sendToBackground("BOUNDARY_CHECK_REQUEST", violation);
        },
        (event) => {
          sendToBackground("AGENT_ACTION", event);
        }
      );
      registerCleanup(() => {
        if (monitorCleanup) monitorCleanup();
      });
      sendToBackground("STATUS_QUERY", {}).then((response) => {
        if (response && typeof response === "object") {
          const data = response;
          if (data.activeDelegation) {
            updateActiveRule(data.activeDelegation);
            syncRuleToMainWorld(data.activeDelegation);
          }
        }
      }).catch(() => {
      });
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", startMonitoring, { once: true });
    } else {
      startMonitoring();
    }
    console.log("[AI Browser Guard] Content script initialized");
  }
  async function sendToBackground(type, data) {
    const message = {
      type,
      data,
      sentAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(response);
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  }
  function handleMessage(message, _sender, sendResponse) {
    if (!message || !message.type) return false;
    switch (message.type) {
      case "DELEGATION_UPDATE": {
        const rule = message.data;
        updateActiveRule(rule);
        syncRuleToMainWorld(rule);
        if (monitorCleanup) monitorCleanup();
        monitorCleanup = startBoundaryMonitor(
          rule,
          (violation) => sendToBackground("BOUNDARY_CHECK_REQUEST", violation),
          (event) => sendToBackground("AGENT_ACTION", event)
        );
        sendResponse({ success: true });
        return false;
      }
      case "KILL_SWITCH_ACTIVATE": {
        const result = executeContentKillSwitch();
        detectionCleanup = null;
        monitorCleanup = null;
        currentAgentId = null;
        sendResponse({ success: true, ...result });
        return false;
      }
      case "STATUS_QUERY": {
        const state = getMonitorState();
        sendResponse({
          agentDetected: currentAgentId !== null,
          agentId: currentAgentId,
          monitorState: state
        });
        return false;
      }
      case "ALLOW_ONCE": {
        const { capability, url } = message.data;
        window.postMessage(
          { type: MSG_ALLOW_ONCE, nonce: GUARD_NONCE, capability, url },
          "*"
        );
        sendResponse({ success: true });
        return false;
      }
      default:
        return false;
    }
  }
  function onDetectionResult(verdict) {
    if (verdict.agentDetected && verdict.agent) {
      currentAgentId = verdict.agent.id;
      sendToBackground("DETECTION_RESULT", verdict.event).catch(() => {
      });
    }
  }
  initialize();
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9kZXRlY3Rpb24vY2RwLXBhdHRlcm5zLnRzIiwiLi4vLi4vc3JjL2RldGVjdGlvbi93ZWJkcml2ZXIudHMiLCIuLi8uLi9zcmMvZGV0ZWN0aW9uL2F1dG9tYXRpb24udHMiLCIuLi8uLi9zcmMvZGV0ZWN0aW9uL2JlaGF2aW9yYWwudHMiLCIuLi8uLi9zcmMvY29udGVudC9kZXRlY3Rvci50cyIsIi4uLy4uL3NyYy9kZWxlZ2F0aW9uL3J1bGVzLnRzIiwiLi4vLi4vc3JjL3Nlc3Npb24vdGltZWxpbmUudHMiLCIuLi8uLi9zcmMvY29udGVudC9tb25pdG9yLnRzIiwiLi4vLi4vc3JjL2tpbGxzd2l0Y2gvaW5kZXgudHMiLCIuLi8uLi9zcmMvY29udGVudC9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENocm9tZSBEZXZUb29scyBQcm90b2NvbCAoQ0RQKSBkZXRlY3Rpb24gcGF0dGVybnMuXG4gKlxuICogRGV0ZWN0cyB3aGVuIGEgQ0RQIGNsaWVudCBpcyBjb25uZWN0ZWQgdG8gdGhlIGJyb3dzZXIsIHdoaWNoIGluZGljYXRlc1xuICogcHJvZ3JhbW1hdGljIGNvbnRyb2wgYnkgYW4gYXV0b21hdGlvbiBmcmFtZXdvcmsuXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBEZXRlY3Rpb25NZXRob2QsIERldGVjdGlvbkNvbmZpZGVuY2UgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2RwRGV0ZWN0aW9uUmVzdWx0IHtcbiAgZGV0ZWN0ZWQ6IGJvb2xlYW47XG4gIG1ldGhvZDogRGV0ZWN0aW9uTWV0aG9kO1xuICBjb25maWRlbmNlOiBEZXRlY3Rpb25Db25maWRlbmNlO1xuICBkZXRhaWw6IHN0cmluZztcbiAgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbi8qKlxuICogQ2hlY2sgZm9yIENEUCBjb25uZWN0aW9uIGluZGljYXRvcnMgaW4gdGhlIGN1cnJlbnQgcGFnZSBjb250ZXh0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGV0ZWN0Q2RwQ29ubmVjdGlvbigpOiBDZHBEZXRlY3Rpb25SZXN1bHQge1xuICBjb25zdCBzaWduYWxzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBjb25zdCBmb3VuZDogc3RyaW5nW10gPSBbXTtcblxuICAvLyBDaGVjayBmb3IgX19jZHBfYmluZGluZ18qIHByb3BlcnRpZXNcbiAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gIGZvciAoY29uc3Qga2V5IG9mIHdpbmRvd0tleXMpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJ19fY2RwXycpIHx8IGtleS5zdGFydHNXaXRoKCdfX2Nocm9taXVtXycpKSB7XG4gICAgICBmb3VuZC5wdXNoKGtleSk7XG4gICAgICBzaWduYWxzW2tleV0gPSB0cnVlO1xuICAgIH1cbiAgfVxuXG4gIC8vIENoZWNrIGZvciBQbGF5d3JpZ2h0L1B1cHBldGVlciBiaW5kaW5ncyAodGhlc2UgdXNlIENEUCBpbnRlcm5hbGx5KVxuICBjb25zdCBjZHBCaW5kaW5ncyA9IFtcbiAgICAnX19wbGF5d3JpZ2h0X2V2YWx1YXRpb25fc2NyaXB0X18nLFxuICAgICdfX3B1cHBldGVlcl9ldmFsdWF0aW9uX3NjcmlwdF9fJyxcbiAgICAnX19wbGF5d3JpZ2h0JyxcbiAgICAnX19wdXBwZXRlZXInLFxuICBdO1xuICBmb3IgKGNvbnN0IGJpbmRpbmcgb2YgY2RwQmluZGluZ3MpIHtcbiAgICBpZiAoYmluZGluZyBpbiB3aW5kb3cpIHtcbiAgICAgIGZvdW5kLnB1c2goYmluZGluZyk7XG4gICAgICBzaWduYWxzW2JpbmRpbmddID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvLyBDaGVjayBmb3IgRGV2VG9vbHNBUEkgcHJlc2VuY2VcbiAgaWYgKCdEZXZUb29sc0FQSScgaW4gd2luZG93KSB7XG4gICAgZm91bmQucHVzaCgnRGV2VG9vbHNBUEknKTtcbiAgICBzaWduYWxzLmRldlRvb2xzQVBJID0gdHJ1ZTtcbiAgfVxuXG4gIGNvbnN0IGRldGVjdGVkID0gZm91bmQubGVuZ3RoID4gMDtcbiAgcmV0dXJuIHtcbiAgICBkZXRlY3RlZCxcbiAgICBtZXRob2Q6ICdjZHAtY29ubmVjdGlvbicsXG4gICAgY29uZmlkZW5jZTogZGV0ZWN0ZWQgPyAoZm91bmQubGVuZ3RoID49IDIgPyAnY29uZmlybWVkJyA6ICdoaWdoJykgOiAnbG93JyxcbiAgICBkZXRhaWw6IGRldGVjdGVkXG4gICAgICA/IGBDRFAgaW5kaWNhdG9ycyBmb3VuZDogJHtmb3VuZC5qb2luKCcsICcpfS5gXG4gICAgICA6ICdObyBDRFAgY29ubmVjdGlvbiBpbmRpY2F0b3JzIGRldGVjdGVkLicsXG4gICAgc2lnbmFscyxcbiAgfTtcbn1cblxuLyoqXG4gKiBDaGVjayBmb3IgUGxheXdyaWdodC1zcGVjaWZpYyBDRFAgYmluZGluZ3MuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlY3RQbGF5d3JpZ2h0QmluZGluZ3MoKTogQ2RwRGV0ZWN0aW9uUmVzdWx0IHtcbiAgY29uc3Qgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgY29uc3QgZm91bmQ6IHN0cmluZ1tdID0gW107XG5cbiAgY29uc3QgcGxheXdyaWdodE1hcmtlcnMgPSBbXG4gICAgJ19fcGxheXdyaWdodF9ldmFsdWF0aW9uX3NjcmlwdF9fJyxcbiAgICAnX19wbGF5d3JpZ2h0JyxcbiAgICAnX19wd18nLFxuICAgICdwbGF5d3JpZ2h0JyxcbiAgXTtcblxuICBjb25zdCB3aW5kb3dLZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMod2luZG93KTtcbiAgZm9yIChjb25zdCBrZXkgb2Ygd2luZG93S2V5cykge1xuICAgIGlmIChrZXkuc3RhcnRzV2l0aCgnX19wd18nKSB8fCBrZXkuc3RhcnRzV2l0aCgnX19wbGF5d3JpZ2h0JykpIHtcbiAgICAgIGZvdW5kLnB1c2goa2V5KTtcbiAgICAgIHNpZ25hbHNba2V5XSA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgZm9yIChjb25zdCBtYXJrZXIgb2YgcGxheXdyaWdodE1hcmtlcnMpIHtcbiAgICBpZiAobWFya2VyIGluIHdpbmRvdyAmJiAhZm91bmQuaW5jbHVkZXMobWFya2VyKSkge1xuICAgICAgZm91bmQucHVzaChtYXJrZXIpO1xuICAgICAgc2lnbmFsc1ttYXJrZXJdID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvLyBDaGVjayBmb3IgUGxheXdyaWdodC1pbmplY3RlZCB1dGlsaXR5IHNlbGVjdG9yc1xuICB0cnkge1xuICAgIGNvbnN0IHV0aWxpdHlTZWxlY3RvcnMgPSBbJ19wbGF5d3JpZ2h0X3NlbGVjdG9yX2VuZ2luZV8nXTtcbiAgICBmb3IgKGNvbnN0IHNlbCBvZiB1dGlsaXR5U2VsZWN0b3JzKSB7XG4gICAgICBpZiAoc2VsIGluIHdpbmRvdykge1xuICAgICAgICBmb3VuZC5wdXNoKHNlbCk7XG4gICAgICAgIHNpZ25hbHNbc2VsXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvLyBJZ25vcmUgYWNjZXNzIGVycm9yc1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBkZXRlY3RlZDogZm91bmQubGVuZ3RoID4gMCxcbiAgICBtZXRob2Q6ICdmcmFtZXdvcmstZmluZ2VycHJpbnQnLFxuICAgIGNvbmZpZGVuY2U6IGZvdW5kLmxlbmd0aCA+IDAgPyAnY29uZmlybWVkJyA6ICdsb3cnLFxuICAgIGRldGFpbDogZm91bmQubGVuZ3RoID4gMFxuICAgICAgPyBgUGxheXdyaWdodCBiaW5kaW5ncyBmb3VuZDogJHtmb3VuZC5qb2luKCcsICcpfS5gXG4gICAgICA6ICdObyBQbGF5d3JpZ2h0IGJpbmRpbmdzIGRldGVjdGVkLicsXG4gICAgc2lnbmFscyxcbiAgfTtcbn1cblxuLyoqXG4gKiBDaGVjayBmb3IgUHVwcGV0ZWVyLXNwZWNpZmljIENEUCBtYXJrZXJzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGV0ZWN0UHVwcGV0ZWVyQmluZGluZ3MoKTogQ2RwRGV0ZWN0aW9uUmVzdWx0IHtcbiAgY29uc3Qgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgY29uc3QgZm91bmQ6IHN0cmluZ1tdID0gW107XG5cbiAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gIGZvciAoY29uc3Qga2V5IG9mIHdpbmRvd0tleXMpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJ19fcHVwcGV0ZWVyJykgfHwga2V5LnN0YXJ0c1dpdGgoJ3B1cHBldGVlcl8nKSkge1xuICAgICAgZm91bmQucHVzaChrZXkpO1xuICAgICAgc2lnbmFsc1trZXldID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvLyBDaGVjayBmb3IgRGV2VG9vbHNBUEktcmVsYXRlZCBnbG9iYWxzIHVzZWQgYnkgUHVwcGV0ZWVyXG4gIGNvbnN0IHB1cHBldGVlck1hcmtlcnMgPSBbXG4gICAgJ19fcHVwcGV0ZWVyX2V2YWx1YXRpb25fc2NyaXB0X18nLFxuICAgICdwdXBwZXRlZXInLFxuICBdO1xuICBmb3IgKGNvbnN0IG1hcmtlciBvZiBwdXBwZXRlZXJNYXJrZXJzKSB7XG4gICAgaWYgKG1hcmtlciBpbiB3aW5kb3cgJiYgIWZvdW5kLmluY2x1ZGVzKG1hcmtlcikpIHtcbiAgICAgIGZvdW5kLnB1c2gobWFya2VyKTtcbiAgICAgIHNpZ25hbHNbbWFya2VyXSA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBkZXRlY3RlZDogZm91bmQubGVuZ3RoID4gMCxcbiAgICBtZXRob2Q6ICdmcmFtZXdvcmstZmluZ2VycHJpbnQnLFxuICAgIGNvbmZpZGVuY2U6IGZvdW5kLmxlbmd0aCA+IDAgPyAnY29uZmlybWVkJyA6ICdsb3cnLFxuICAgIGRldGFpbDogZm91bmQubGVuZ3RoID4gMFxuICAgICAgPyBgUHVwcGV0ZWVyIGJpbmRpbmdzIGZvdW5kOiAke2ZvdW5kLmpvaW4oJywgJyl9LmBcbiAgICAgIDogJ05vIFB1cHBldGVlciBiaW5kaW5ncyBkZXRlY3RlZC4nLFxuICAgIHNpZ25hbHMsXG4gIH07XG59XG5cbi8qKlxuICogTW9uaXRvciBmb3IgbmV3IENEUCBjb25uZWN0aW9ucyBieSBvYnNlcnZpbmcgd2luZG93IHByb3BlcnR5IGFkZGl0aW9ucy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vbml0b3JDZHBDb25uZWN0aW9ucyhcbiAgY2FsbGJhY2s6IChyZXN1bHQ6IENkcERldGVjdGlvblJlc3VsdCkgPT4gdm9pZFxuKTogKCkgPT4gdm9pZCB7XG4gIGxldCBzdG9wcGVkID0gZmFsc2U7XG4gIGNvbnN0IGtub3duS2V5cyA9IG5ldyBTZXQoT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMod2luZG93KSk7XG5cbiAgY29uc3QgaW50ZXJ2YWxJZCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICBpZiAoc3RvcHBlZCkgcmV0dXJuO1xuICAgIGNvbnN0IGN1cnJlbnRLZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMod2luZG93KTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBjdXJyZW50S2V5cykge1xuICAgICAgaWYgKGtub3duS2V5cy5oYXMoa2V5KSkgY29udGludWU7XG4gICAgICBrbm93bktleXMuYWRkKGtleSk7XG5cbiAgICAgIGlmIChcbiAgICAgICAga2V5LnN0YXJ0c1dpdGgoJ19fY2RwXycpIHx8XG4gICAgICAgIGtleS5zdGFydHNXaXRoKCdfX3BsYXl3cmlnaHQnKSB8fFxuICAgICAgICBrZXkuc3RhcnRzV2l0aCgnX19wdXBwZXRlZXInKSB8fFxuICAgICAgICBrZXkuc3RhcnRzV2l0aCgnX19wd18nKSB8fFxuICAgICAgICBrZXkuc3RhcnRzV2l0aCgnX19jaHJvbWl1bV8nKVxuICAgICAgKSB7XG4gICAgICAgIGNhbGxiYWNrKHtcbiAgICAgICAgICBkZXRlY3RlZDogdHJ1ZSxcbiAgICAgICAgICBtZXRob2Q6ICdjZHAtY29ubmVjdGlvbicsXG4gICAgICAgICAgY29uZmlkZW5jZTogJ2hpZ2gnLFxuICAgICAgICAgIGRldGFpbDogYE5ldyBDRFAgYmluZGluZyBkZXRlY3RlZDogJHtrZXl9LmAsXG4gICAgICAgICAgc2lnbmFsczogeyBba2V5XTogdHJ1ZSwgZGV0ZWN0ZWRBdDogRGF0ZS5ub3coKSB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIDIwMDApO1xuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgc3RvcHBlZCA9IHRydWU7XG4gICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKTtcbiAgfTtcbn1cbiIsIi8qKlxuICogV2ViRHJpdmVyIGZsYWcgZGV0ZWN0aW9uLlxuICpcbiAqIERldGVjdHMgdGhlIG5hdmlnYXRvci53ZWJkcml2ZXIgcHJvcGVydHkgYW5kIHJlbGF0ZWQgYXV0b21hdGlvbiBmbGFnc1xuICogdGhhdCBhcmUgc2V0IHdoZW4gYSBicm93c2VyIGlzIGNvbnRyb2xsZWQgYnkgV2ViRHJpdmVyLWNvbXBsaWFudCB0b29scy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IERldGVjdGlvbk1ldGhvZCwgRGV0ZWN0aW9uQ29uZmlkZW5jZSB9IGZyb20gJy4uL3R5cGVzL2FnZW50JztcblxuZXhwb3J0IGludGVyZmFjZSBXZWJEcml2ZXJEZXRlY3Rpb25SZXN1bHQge1xuICBkZXRlY3RlZDogYm9vbGVhbjtcbiAgbWV0aG9kOiBEZXRlY3Rpb25NZXRob2Q7XG4gIGNvbmZpZGVuY2U6IERldGVjdGlvbkNvbmZpZGVuY2U7XG4gIGRldGFpbDogc3RyaW5nO1xuICBzaWduYWxzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbn1cblxuLyoqXG4gKiBDaGVjayB0aGUgbmF2aWdhdG9yLndlYmRyaXZlciBwcm9wZXJ0eS5cbiAqIEFsc28gY2hlY2tzIHdoZXRoZXIgdGhlIHByb3BlcnR5IGRlc2NyaXB0b3IgaGFzIGJlZW4gdGFtcGVyZWQgd2l0aC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRldGVjdFdlYkRyaXZlckZsYWcoKTogV2ViRHJpdmVyRGV0ZWN0aW9uUmVzdWx0IHtcbiAgY29uc3Qgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcblxuICAvLyBDaGVjayBmb3Igd2ViZHJpdmVyIGF0dHJpYnV0ZSBvbiB0aGUgSFRNTCBlbGVtZW50IChzZXQgYnkgc29tZSBXZWJEcml2ZXIgaW1wbGVtZW50YXRpb25zKVxuICB0cnkge1xuICAgIGNvbnN0IGh0bWxFbCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtcbiAgICBpZiAoaHRtbEVsICYmIHR5cGVvZiBodG1sRWwuZ2V0QXR0cmlidXRlID09PSAnZnVuY3Rpb24nICYmIGh0bWxFbC5nZXRBdHRyaWJ1dGUoJ3dlYmRyaXZlcicpICE9PSBudWxsKSB7XG4gICAgICBzaWduYWxzLmh0bWxXZWJkcml2ZXJBdHRyID0gdHJ1ZTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRldGVjdGVkOiB0cnVlLFxuICAgICAgICBtZXRob2Q6ICd3ZWJkcml2ZXItZmxhZycsXG4gICAgICAgIGNvbmZpZGVuY2U6ICdjb25maXJtZWQnLFxuICAgICAgICBkZXRhaWw6ICdIVE1MIGVsZW1lbnQgaGFzIHdlYmRyaXZlciBhdHRyaWJ1dGUgc2V0LCBpbmRpY2F0aW5nIFdlYkRyaXZlciBjb250cm9sLicsXG4gICAgICAgIHNpZ25hbHMsXG4gICAgICB9O1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50IG1heSBub3QgYmUgYXZhaWxhYmxlXG4gIH1cblxuICAvLyBEaXJlY3QgdmFsdWUgY2hlY2tcbiAgY29uc3Qgd2ViZHJpdmVyVmFsdWUgPSBuYXZpZ2F0b3Iud2ViZHJpdmVyO1xuICBzaWduYWxzLndlYmRyaXZlclZhbHVlID0gd2ViZHJpdmVyVmFsdWU7XG5cbiAgLy8gUHJvcGVydHkgZGVzY3JpcHRvciBjaGVjayBmb3IgdGFtcGVyaW5nXG4gIGNvbnN0IGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG5hdmlnYXRvciwgJ3dlYmRyaXZlcicpO1xuICBzaWduYWxzLmhhc093bkRlc2NyaXB0b3IgPSAhIWRlc2NyaXB0b3I7XG4gIGlmIChkZXNjcmlwdG9yKSB7XG4gICAgc2lnbmFscy5jb25maWd1cmFibGUgPSBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZTtcbiAgICBzaWduYWxzLmVudW1lcmFibGUgPSBkZXNjcmlwdG9yLmVudW1lcmFibGU7XG4gICAgc2lnbmFscy53cml0YWJsZSA9IGRlc2NyaXB0b3Iud3JpdGFibGU7XG4gIH1cblxuICAvLyBDaGVjayBwcm90b3R5cGUgZGVzY3JpcHRvclxuICBjb25zdCBwcm90b0Rlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKFxuICAgIE9iamVjdC5nZXRQcm90b3R5cGVPZihuYXZpZ2F0b3IpLFxuICAgICd3ZWJkcml2ZXInXG4gICk7XG4gIHNpZ25hbHMucHJvdG9EZXNjcmlwdG9yID0gISFwcm90b0Rlc2NyaXB0b3I7XG5cbiAgaWYgKHdlYmRyaXZlclZhbHVlID09PSB0cnVlKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGRldGVjdGVkOiB0cnVlLFxuICAgICAgbWV0aG9kOiAnd2ViZHJpdmVyLWZsYWcnLFxuICAgICAgY29uZmlkZW5jZTogJ2hpZ2gnLFxuICAgICAgZGV0YWlsOiAnbmF2aWdhdG9yLndlYmRyaXZlciBpcyB0cnVlLCBpbmRpY2F0aW5nIFdlYkRyaXZlciBhdXRvbWF0aW9uLicsXG4gICAgICBzaWduYWxzLFxuICAgIH07XG4gIH1cblxuICAvLyBDaGVjayBmb3IgdGFtcGVyaW5nOiBpZiB0aGUgcHJvcGVydHkgaXMgb3duIChvdmVycmlkZGVuKSBhbmQgc2V0IHRvIGZhbHNlXG4gIGlmIChkZXNjcmlwdG9yICYmIHdlYmRyaXZlclZhbHVlID09PSBmYWxzZSkge1xuICAgIHJldHVybiB7XG4gICAgICBkZXRlY3RlZDogdHJ1ZSxcbiAgICAgIG1ldGhvZDogJ3dlYmRyaXZlci1mbGFnJyxcbiAgICAgIGNvbmZpZGVuY2U6ICdtZWRpdW0nLFxuICAgICAgZGV0YWlsOiAnbmF2aWdhdG9yLndlYmRyaXZlciB3YXMgb3ZlcnJpZGRlbiB0byBmYWxzZSwgc3VnZ2VzdGluZyBhdXRvbWF0aW9uIGV2YXNpb24uJyxcbiAgICAgIHNpZ25hbHMsXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgZGV0ZWN0ZWQ6IGZhbHNlLFxuICAgIG1ldGhvZDogJ3dlYmRyaXZlci1mbGFnJyxcbiAgICBjb25maWRlbmNlOiAnbG93JyxcbiAgICBkZXRhaWw6ICdObyBXZWJEcml2ZXIgZmxhZyBkZXRlY3RlZC4nLFxuICAgIHNpZ25hbHMsXG4gIH07XG59XG5cbi8qKlxuICogQ2hlY2sgZm9yIGFkZGl0aW9uYWwgYXV0b21hdGlvbi1yZWxhdGVkIG5hdmlnYXRvciBhbm9tYWxpZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlY3ROYXZpZ2F0b3JBbm9tYWxpZXMoKTogV2ViRHJpdmVyRGV0ZWN0aW9uUmVzdWx0IHtcbiAgY29uc3Qgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgbGV0IGRldGVjdGVkID0gZmFsc2U7XG4gIGNvbnN0IGRldGFpbHM6IHN0cmluZ1tdID0gW107XG5cbiAgLy8gSGVhZGxlc3M6IHBsdWdpbnMgbGVuZ3RoIGlzIDBcbiAgY29uc3QgcGx1Z2luc0xlbmd0aCA9IG5hdmlnYXRvci5wbHVnaW5zPy5sZW5ndGggPz8gMDtcbiAgc2lnbmFscy5wbHVnaW5zTGVuZ3RoID0gcGx1Z2luc0xlbmd0aDtcbiAgaWYgKHBsdWdpbnNMZW5ndGggPT09IDApIHtcbiAgICBkZXRlY3RlZCA9IHRydWU7XG4gICAgZGV0YWlscy5wdXNoKCdObyBicm93c2VyIHBsdWdpbnMgZGV0ZWN0ZWQgKGhlYWRsZXNzIGluZGljYXRvcikuJyk7XG4gIH1cblxuICAvLyBFbXB0eSBvciBtaXNzaW5nIGxhbmd1YWdlc1xuICBzaWduYWxzLmxhbmd1YWdlcyA9IG5hdmlnYXRvci5sYW5ndWFnZXM7XG4gIGlmICghbmF2aWdhdG9yLmxhbmd1YWdlcyB8fCBuYXZpZ2F0b3IubGFuZ3VhZ2VzLmxlbmd0aCA9PT0gMCkge1xuICAgIGRldGVjdGVkID0gdHJ1ZTtcbiAgICBkZXRhaWxzLnB1c2goJ05vIGJyb3dzZXIgbGFuZ3VhZ2VzIHNldCAoaGVhZGxlc3MgaW5kaWNhdG9yKS4nKTtcbiAgfVxuXG4gIC8vIE5vdGlmaWNhdGlvbiBwZXJtaXNzaW9uIGNoZWNrIChoZWFkbGVzcyBkZWZhdWx0cyB0byBkZW5pZWQpXG4gIHRyeSB7XG4gICAgc2lnbmFscy5ub3RpZmljYXRpb25QZXJtaXNzaW9uID0gTm90aWZpY2F0aW9uLnBlcm1pc3Npb247XG4gICAgaWYgKE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uID09PSAnZGVuaWVkJykge1xuICAgICAgZGV0YWlscy5wdXNoKCdOb3RpZmljYXRpb25zIGFyZSBkZW5pZWQgYnkgZGVmYXVsdC4nKTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIHNpZ25hbHMubm90aWZpY2F0aW9uUGVybWlzc2lvbiA9ICd1bmF2YWlsYWJsZSc7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGRldGVjdGVkLFxuICAgIG1ldGhvZDogJ2F1dG9tYXRpb24tZmxhZycsXG4gICAgY29uZmlkZW5jZTogZGV0ZWN0ZWQgPyAnbWVkaXVtJyA6ICdsb3cnLFxuICAgIGRldGFpbDogZGV0YWlscy5sZW5ndGggPiAwID8gZGV0YWlscy5qb2luKCcgJykgOiAnTm8gbmF2aWdhdG9yIGFub21hbGllcyBkZXRlY3RlZC4nLFxuICAgIHNpZ25hbHMsXG4gIH07XG59XG5cbi8qKlxuICogQ2hlY2sgZm9yIFNlbGVuaXVtLXNwZWNpZmljIG1hcmtlcnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlY3RTZWxlbml1bU1hcmtlcnMoKTogV2ViRHJpdmVyRGV0ZWN0aW9uUmVzdWx0IHtcbiAgY29uc3Qgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgY29uc3QgZm91bmRNYXJrZXJzOiBzdHJpbmdbXSA9IFtdO1xuXG4gIC8vIENoZWNrIGZvciAkY2RjXyBwcmVmaXhlZCBwcm9wZXJ0aWVzIG9uIGRvY3VtZW50XG4gIGNvbnN0IGRvY0tleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhkb2N1bWVudCk7XG4gIGZvciAoY29uc3Qga2V5IG9mIGRvY0tleXMpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJyRjZGNfJykgfHwga2V5LnN0YXJ0c1dpdGgoJyR3ZGNfJykpIHtcbiAgICAgIGZvdW5kTWFya2Vycy5wdXNoKGtleSk7XG4gICAgICBzaWduYWxzW2tleV0gPSB0cnVlO1xuICAgIH1cbiAgfVxuXG4gIC8vIENoZWNrIGZvciBTZWxlbml1bSBnbG9iYWxzIG9uIHdpbmRvd1xuICBjb25zdCBzZWxlbml1bUdsb2JhbHMgPSBbXG4gICAgJ2NhbGxTZWxlbml1bScsXG4gICAgJ19zZWxlbml1bScsXG4gICAgJ2NhbGxQaGFudG9tJyxcbiAgICAnX19uaWdodG1hcmUnLFxuICAgICdfU2VsZW5pdW1fSURFX1JlY29yZGVyJyxcbiAgXTtcbiAgZm9yIChjb25zdCBuYW1lIG9mIHNlbGVuaXVtR2xvYmFscykge1xuICAgIGlmIChuYW1lIGluIHdpbmRvdykge1xuICAgICAgZm91bmRNYXJrZXJzLnB1c2gobmFtZSk7XG4gICAgICBzaWduYWxzW25hbWVdID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvLyBDaGVjayBmb3IgQ2hyb21lRHJpdmVyIHByb3BlcnRpZXNcbiAgY29uc3Qgd2luZG93S2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHdpbmRvdyk7XG4gIGZvciAoY29uc3Qga2V5IG9mIHdpbmRvd0tleXMpIHtcbiAgICBpZiAoa2V5LnN0YXJ0c1dpdGgoJ2NkY18nKSB8fCBrZXkuc3RhcnRzV2l0aCgnJGNocm9tZV9hc3luY1NjcmlwdEluZm8nKSkge1xuICAgICAgZm91bmRNYXJrZXJzLnB1c2goa2V5KTtcbiAgICAgIHNpZ25hbHNba2V5XSA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBkZXRlY3RlZDogZm91bmRNYXJrZXJzLmxlbmd0aCA+IDAsXG4gICAgbWV0aG9kOiAnZnJhbWV3b3JrLWZpbmdlcnByaW50JyxcbiAgICBjb25maWRlbmNlOiBmb3VuZE1hcmtlcnMubGVuZ3RoID4gMCA/ICdjb25maXJtZWQnIDogJ2xvdycsXG4gICAgZGV0YWlsOiBmb3VuZE1hcmtlcnMubGVuZ3RoID4gMFxuICAgICAgPyBgU2VsZW5pdW0gbWFya2VycyBmb3VuZDogJHtmb3VuZE1hcmtlcnMuam9pbignLCAnKX0uYFxuICAgICAgOiAnTm8gU2VsZW5pdW0gbWFya2VycyBkZXRlY3RlZC4nLFxuICAgIHNpZ25hbHMsXG4gIH07XG59XG5cbi8qKlxuICogTW9uaXRvciBmb3IgbGF0ZS1zZXQgV2ViRHJpdmVyIGZsYWdzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbW9uaXRvcldlYkRyaXZlckNoYW5nZXMoXG4gIGNhbGxiYWNrOiAocmVzdWx0OiBXZWJEcml2ZXJEZXRlY3Rpb25SZXN1bHQpID0+IHZvaWRcbik6ICgpID0+IHZvaWQge1xuICBsZXQgc3RvcHBlZCA9IGZhbHNlO1xuXG4gIC8vIFBvbGwgcGVyaW9kaWNhbGx5IHNpbmNlIHByb3BlcnR5IGludGVyY2VwdGlvbiBtYXkgbm90IGJlIHBvc3NpYmxlXG4gIGNvbnN0IGludGVydmFsSWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgaWYgKHN0b3BwZWQpIHJldHVybjtcbiAgICBjb25zdCByZXN1bHQgPSBkZXRlY3RXZWJEcml2ZXJGbGFnKCk7XG4gICAgaWYgKHJlc3VsdC5kZXRlY3RlZCkge1xuICAgICAgY2FsbGJhY2socmVzdWx0KTtcbiAgICB9XG4gIH0sIDMwMDApO1xuXG4gIC8vIEFsc28gdHJ5IHRvIGludGVyY2VwdCBwcm9wZXJ0eSBkZWZpbml0aW9uXG4gIHJldHVybiAoKSA9PiB7XG4gICAgc3RvcHBlZCA9IHRydWU7XG4gICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKTtcbiAgfTtcbn1cbiIsIi8qKlxuICogR2VuZXJpYyBhdXRvbWF0aW9uIGZyYW1ld29yayBkZXRlY3Rpb24uXG4gKlxuICogRGV0ZWN0cyBhdXRvbWF0aW9uIGZyYW1ld29ya3MgdGhhdCBtYXkgbm90IGxlYXZlIFdlYkRyaXZlciBvciBDRFAgdHJhY2VzLFxuICogaW5jbHVkaW5nIGJyb3dzZXItYmFzZWQgQUkgYWdlbnRzIGFuZCBuZXdlciBmcmFtZXdvcmtzLlxuICovXG5cbmltcG9ydCB0eXBlIHsgQWdlbnRUeXBlLCBEZXRlY3Rpb25NZXRob2QsIERldGVjdGlvbkNvbmZpZGVuY2UgfSBmcm9tICcuLi90eXBlcy9hZ2VudCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRnJhbWV3b3JrRGV0ZWN0aW9uUmVzdWx0IHtcbiAgZGV0ZWN0ZWQ6IGJvb2xlYW47XG4gIGZyYW1ld29ya1R5cGU6IEFnZW50VHlwZTtcbiAgbWV0aG9kOiBEZXRlY3Rpb25NZXRob2Q7XG4gIGNvbmZpZGVuY2U6IERldGVjdGlvbkNvbmZpZGVuY2U7XG4gIGRldGFpbDogc3RyaW5nO1xuICBzaWduYWxzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbn1cblxuLyoqXG4gKiBEZXRlY3QgQW50aHJvcGljIENvbXB1dGVyIFVzZSBhZ2VudCBwYXR0ZXJucy5cbiAqXG4gKiBBbnRocm9waWMgQ29tcHV0ZXIgVXNlIG9wZXJhdGVzIHZpYSBzY3JlZW5zaG90ICsgY2xpY2sgcGF0dGVybnNcbiAqIHdpdGggcGl4ZWwtcGVyZmVjdCBjb29yZGluYXRlcyBhbmQgZml4ZWQgaW5mZXJlbmNlIHRpbWluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRldGVjdEFudGhyb3BpY0NvbXB1dGVyVXNlKCk6IEZyYW1ld29ya0RldGVjdGlvblJlc3VsdCB7XG4gIGNvbnN0IHNpZ25hbHM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGNvbnN0IGZvdW5kOiBzdHJpbmdbXSA9IFtdO1xuXG4gIC8vIENoZWNrIGZvciBDb21wdXRlciBVc2Utc3BlY2lmaWMgaW5qZWN0ZWQgZ2xvYmFsc1xuICBjb25zdCBtYXJrZXJzID0gW1xuICAgICdfX2FudGhyb3BpY19jb21wdXRlcl91c2VfXycsXG4gICAgJ19fY29tcHV0ZXJfdXNlX18nLFxuICAgICdfX2FudGhyb3BpY190b29sX18nLFxuICBdO1xuICBmb3IgKGNvbnN0IG1hcmtlciBvZiBtYXJrZXJzKSB7XG4gICAgaWYgKG1hcmtlciBpbiB3aW5kb3cpIHtcbiAgICAgIGZvdW5kLnB1c2gobWFya2VyKTtcbiAgICAgIHNpZ25hbHNbbWFya2VyXSA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIHNjcmVlbnNob3QgQVBJIG92ZXJyaWRlcyAoY2FudmFzLnRvRGF0YVVSTCwgZ2V0RGlzcGxheU1lZGlhKVxuICB0cnkge1xuICAgIGNvbnN0IGNhbnZhc1Byb3RvID0gSFRNTENhbnZhc0VsZW1lbnQucHJvdG90eXBlO1xuICAgIGNvbnN0IHRvRGF0YVVSTERlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGNhbnZhc1Byb3RvLCAndG9EYXRhVVJMJyk7XG4gICAgaWYgKHRvRGF0YVVSTERlc2MgJiYgIXRvRGF0YVVSTERlc2Mud3JpdGFibGUgJiYgdG9EYXRhVVJMRGVzYy5jb25maWd1cmFibGUpIHtcbiAgICAgIHNpZ25hbHMudG9EYXRhVVJMTW9kaWZpZWQgPSB0cnVlO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlXG4gIH1cblxuICByZXR1cm4ge1xuICAgIGRldGVjdGVkOiBmb3VuZC5sZW5ndGggPiAwLFxuICAgIGZyYW1ld29ya1R5cGU6ICdhbnRocm9waWMtY29tcHV0ZXItdXNlJyxcbiAgICBtZXRob2Q6ICdmcmFtZXdvcmstZmluZ2VycHJpbnQnLFxuICAgIGNvbmZpZGVuY2U6IGZvdW5kLmxlbmd0aCA+IDAgPyAnaGlnaCcgOiAnbG93JyxcbiAgICBkZXRhaWw6IGZvdW5kLmxlbmd0aCA+IDBcbiAgICAgID8gYEFudGhyb3BpYyBDb21wdXRlciBVc2UgaW5kaWNhdG9yczogJHtmb3VuZC5qb2luKCcsICcpfS5gXG4gICAgICA6ICdObyBBbnRocm9waWMgQ29tcHV0ZXIgVXNlIGluZGljYXRvcnMgZGV0ZWN0ZWQuJyxcbiAgICBzaWduYWxzLFxuICB9O1xufVxuXG4vKipcbiAqIERldGVjdCBPcGVuQUkgT3BlcmF0b3IgYWdlbnQgcGF0dGVybnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlY3RPcGVuQUlPcGVyYXRvcigpOiBGcmFtZXdvcmtEZXRlY3Rpb25SZXN1bHQge1xuICBjb25zdCBzaWduYWxzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBjb25zdCBmb3VuZDogc3RyaW5nW10gPSBbXTtcblxuICAvLyBDaGVjayBmb3IgT3BlcmF0b3Itc3BlY2lmaWMgZ2xvYmFsc1xuICBjb25zdCBtYXJrZXJzID0gW1xuICAgICdfX29wZW5haV9vcGVyYXRvcl9fJyxcbiAgICAnX19vcGVyYXRvcl9ydW50aW1lX18nLFxuICAgICdfX29wZW5haV9icm93c2VyX3Rvb2xfXycsXG4gIF07XG4gIGZvciAoY29uc3QgbWFya2VyIG9mIG1hcmtlcnMpIHtcbiAgICBpZiAobWFya2VyIGluIHdpbmRvdykge1xuICAgICAgZm91bmQucHVzaChtYXJrZXIpO1xuICAgICAgc2lnbmFsc1ttYXJrZXJdID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvLyBDaGVjayBmb3IgbW9kaWZpZWQgdXNlciBhZ2VudCBpbmRpY2F0aW5nIGN1c3RvbSBDaHJvbWl1bVxuICBjb25zdCB1YSA9IG5hdmlnYXRvci51c2VyQWdlbnQ7XG4gIGlmICh1YS5pbmNsdWRlcygnT3BlcmF0b3InKSB8fCB1YS5pbmNsdWRlcygnT3BlbkFJJykpIHtcbiAgICBmb3VuZC5wdXNoKCd1c2VyQWdlbnQnKTtcbiAgICBzaWduYWxzLnVzZXJBZ2VudCA9IHVhO1xuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIGFjY2Vzc2liaWxpdHkgdHJlZSBxdWVyeSBwYXR0ZXJuc1xuICBpZiAodHlwZW9mIEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmICdnZXRDb21wdXRlZEFjY2Vzc2libGVOb2RlJyBpbiBFbGVtZW50LnByb3RvdHlwZSkge1xuICAgIHNpZ25hbHMuYWNjZXNzaWJpbGl0eUFQSSA9IHRydWU7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGRldGVjdGVkOiBmb3VuZC5sZW5ndGggPiAwLFxuICAgIGZyYW1ld29ya1R5cGU6ICdvcGVuYWktb3BlcmF0b3InLFxuICAgIG1ldGhvZDogJ2ZyYW1ld29yay1maW5nZXJwcmludCcsXG4gICAgY29uZmlkZW5jZTogZm91bmQubGVuZ3RoID4gMCA/ICdoaWdoJyA6ICdsb3cnLFxuICAgIGRldGFpbDogZm91bmQubGVuZ3RoID4gMFxuICAgICAgPyBgT3BlbkFJIE9wZXJhdG9yIGluZGljYXRvcnM6ICR7Zm91bmQuam9pbignLCAnKX0uYFxuICAgICAgOiAnTm8gT3BlbkFJIE9wZXJhdG9yIGluZGljYXRvcnMgZGV0ZWN0ZWQuJyxcbiAgICBzaWduYWxzLFxuICB9O1xufVxuXG4vKipcbiAqIFJ1biBhbGwgZnJhbWV3b3JrLXNwZWNpZmljIGRldGVjdGlvbiBjaGVja3MuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlY3RBbGxGcmFtZXdvcmtzKCk6IEZyYW1ld29ya0RldGVjdGlvblJlc3VsdFtdIHtcbiAgY29uc3QgcmVzdWx0czogRnJhbWV3b3JrRGV0ZWN0aW9uUmVzdWx0W10gPSBbXTtcblxuICBjb25zdCBjb21wdXRlclVzZSA9IGRldGVjdEFudGhyb3BpY0NvbXB1dGVyVXNlKCk7XG4gIGlmIChjb21wdXRlclVzZS5kZXRlY3RlZCkgcmVzdWx0cy5wdXNoKGNvbXB1dGVyVXNlKTtcblxuICBjb25zdCBvcGVyYXRvciA9IGRldGVjdE9wZW5BSU9wZXJhdG9yKCk7XG4gIGlmIChvcGVyYXRvci5kZXRlY3RlZCkgcmVzdWx0cy5wdXNoKG9wZXJhdG9yKTtcblxuICBjb25zdCBnZW5lcmljID0gZGV0ZWN0R2VuZXJpY0F1dG9tYXRpb24oKTtcbiAgaWYgKGdlbmVyaWMuZGV0ZWN0ZWQpIHJlc3VsdHMucHVzaChnZW5lcmljKTtcblxuICByZXR1cm4gcmVzdWx0cztcbn1cblxuLyoqXG4gKiBDaGVjayBmb3IgZ2VuZXJpYyBhdXRvbWF0aW9uIGluZGljYXRvcnMgdGhhdCBhcmUgbm90IGZyYW1ld29yay1zcGVjaWZpYy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRldGVjdEdlbmVyaWNBdXRvbWF0aW9uKCk6IEZyYW1ld29ya0RldGVjdGlvblJlc3VsdCB7XG4gIGNvbnN0IHNpZ25hbHM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGNvbnN0IGluZGljYXRvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgLy8gSGVhZGxlc3MgQ2hyb21lIGluZGljYXRvcnNcbiAgLy8gY2hyb21lLmxvYWRUaW1lcyBhbmQgY2hyb21lLmNzaSBhcmUgbWlzc2luZyBpbiBoZWFkbGVzcyBtb2RlXG4gIGNvbnN0IGNocm9tZU9iaiA9ICh3aW5kb3cgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuY2hyb21lIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgdW5kZWZpbmVkO1xuICBpZiAoY2hyb21lT2JqKSB7XG4gICAgc2lnbmFscy5oYXNMb2FkVGltZXMgPSAnbG9hZFRpbWVzJyBpbiBjaHJvbWVPYmo7XG4gICAgc2lnbmFscy5oYXNDc2kgPSAnY3NpJyBpbiBjaHJvbWVPYmo7XG5cbiAgICBpZiAoISgnbG9hZFRpbWVzJyBpbiBjaHJvbWVPYmopKSB7XG4gICAgICBpbmRpY2F0b3JzLnB1c2goJ21pc3NpbmcgY2hyb21lLmxvYWRUaW1lcycpO1xuICAgIH1cbiAgICBpZiAoISgnY3NpJyBpbiBjaHJvbWVPYmopKSB7XG4gICAgICBpbmRpY2F0b3JzLnB1c2goJ21pc3NpbmcgY2hyb21lLmNzaScpO1xuICAgIH1cbiAgfVxuXG4gIC8vIENoZWNrIHNjcmVlbiBkaW1lbnNpb25zIHZzIHZpZXdwb3J0IGZvciBoZWFkbGVzc1xuICBpZiAod2luZG93Lm91dGVyV2lkdGggPT09IDAgJiYgd2luZG93Lm91dGVySGVpZ2h0ID09PSAwKSB7XG4gICAgaW5kaWNhdG9ycy5wdXNoKCd6ZXJvIG91dGVyIGRpbWVuc2lvbnMnKTtcbiAgICBzaWduYWxzLm91dGVyV2lkdGggPSB3aW5kb3cub3V0ZXJXaWR0aDtcbiAgICBzaWduYWxzLm91dGVySGVpZ2h0ID0gd2luZG93Lm91dGVySGVpZ2h0O1xuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIG1pc3NpbmcgYnJvd3Nlci1zcGVjaWZpYyBBUElzXG4gIGlmICghd2luZG93LmNocm9tZSkge1xuICAgIGluZGljYXRvcnMucHVzaCgnd2luZG93LmNocm9tZSBtaXNzaW5nJyk7XG4gICAgc2lnbmFscy5jaHJvbWVQcmVzZW50ID0gZmFsc2U7XG4gIH1cblxuICAvLyBDaGVjayBXZWJHTCByZW5kZXJlciBmb3IgaGVhZGxlc3MgaW5kaWNhdG9yc1xuICB0cnkge1xuICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgIGNvbnN0IGdsID0gY2FudmFzLmdldENvbnRleHQoJ3dlYmdsJyk7XG4gICAgaWYgKGdsKSB7XG4gICAgICBjb25zdCBkZWJ1Z0luZm8gPSBnbC5nZXRFeHRlbnNpb24oJ1dFQkdMX2RlYnVnX3JlbmRlcmVyX2luZm8nKTtcbiAgICAgIGlmIChkZWJ1Z0luZm8pIHtcbiAgICAgICAgY29uc3QgcmVuZGVyZXIgPSBnbC5nZXRQYXJhbWV0ZXIoZGVidWdJbmZvLlVOTUFTS0VEX1JFTkRFUkVSX1dFQkdMKTtcbiAgICAgICAgc2lnbmFscy53ZWJnbFJlbmRlcmVyID0gcmVuZGVyZXI7XG4gICAgICAgIGlmICh0eXBlb2YgcmVuZGVyZXIgPT09ICdzdHJpbmcnICYmIChyZW5kZXJlci5pbmNsdWRlcygnU3dpZnRTaGFkZXInKSB8fCByZW5kZXJlci5pbmNsdWRlcygnbGx2bXBpcGUnKSkpIHtcbiAgICAgICAgICBpbmRpY2F0b3JzLnB1c2goJ3NvZnR3YXJlIHJlbmRlcmVyIChoZWFkbGVzcyBpbmRpY2F0b3IpJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIElnbm9yZSBXZWJHTCBlcnJvcnNcbiAgfVxuXG4gIGNvbnN0IGRldGVjdGVkID0gaW5kaWNhdG9ycy5sZW5ndGggPj0gMjtcbiAgcmV0dXJuIHtcbiAgICBkZXRlY3RlZCxcbiAgICBmcmFtZXdvcmtUeXBlOiBkZXRlY3RlZCA/ICdjZHAtZ2VuZXJpYycgOiAndW5rbm93bicsXG4gICAgbWV0aG9kOiAnYXV0b21hdGlvbi1mbGFnJyxcbiAgICBjb25maWRlbmNlOiBkZXRlY3RlZCA/ICdtZWRpdW0nIDogJ2xvdycsXG4gICAgZGV0YWlsOiBkZXRlY3RlZFxuICAgICAgPyBgR2VuZXJpYyBhdXRvbWF0aW9uIGluZGljYXRvcnM6ICR7aW5kaWNhdG9ycy5qb2luKCcsICcpfS5gXG4gICAgICA6ICdObyBnZW5lcmljIGF1dG9tYXRpb24gaW5kaWNhdG9ycyBkZXRlY3RlZC4nLFxuICAgIHNpZ25hbHMsXG4gIH07XG59XG4iLCIvKipcbiAqIEJlaGF2aW9yYWwgaGV1cmlzdGljcyBmb3IgYXV0b21hdGlvbiBkZXRlY3Rpb24uXG4gKlxuICogQW5hbHl6ZXMgdXNlciBpbnRlcmFjdGlvbiBwYXR0ZXJucyB0byBkaXN0aW5ndWlzaCBodW1hbiBpbnB1dCBmcm9tXG4gKiBwcm9ncmFtbWF0aWMgYXV0b21hdGlvbi5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IERldGVjdGlvbk1ldGhvZCwgRGV0ZWN0aW9uQ29uZmlkZW5jZSB9IGZyb20gJy4uL3R5cGVzL2FnZW50JztcblxuZXhwb3J0IGludGVyZmFjZSBCZWhhdmlvcmFsRGV0ZWN0aW9uUmVzdWx0IHtcbiAgZGV0ZWN0ZWQ6IGJvb2xlYW47XG4gIG1ldGhvZDogRGV0ZWN0aW9uTWV0aG9kO1xuICBjb25maWRlbmNlOiBEZXRlY3Rpb25Db25maWRlbmNlO1xuICBkZXRhaWw6IHN0cmluZztcbiAgbWV0cmljczogQmVoYXZpb3JhbE1ldHJpY3M7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQmVoYXZpb3JhbE1ldHJpY3Mge1xuICBhdmVyYWdlTW91c2VJbnRlcnZhbDogbnVtYmVyO1xuICBtb3VzZUludGVydmFsU3RkRGV2OiBudW1iZXI7XG4gIGludGVnZXJDb29yZGluYXRlUmF0aW86IG51bWJlcjtcbiAgYXZlcmFnZUtleUludGVydmFsOiBudW1iZXI7XG4gIGtleUludGVydmFsU3RkRGV2OiBudW1iZXI7XG4gIHN5bnRoZXRpY0V2ZW50UmF0aW86IG51bWJlcjtcbiAgY2xpY2tzV2l0aG91dE1vdmVtZW50OiBudW1iZXI7XG4gIHRvdGFsRXZlbnRzQW5hbHl6ZWQ6IG51bWJlcjtcbn1cblxuY29uc3QgQkVIQVZJT1JBTF9USFJFU0hPTERTID0ge1xuICBtb3VzZUludGVydmFsU3RkRGV2TWluOiAxNSxcbiAgaW50ZWdlckNvb3JkaW5hdGVSYXRpb01heDogMC45NSxcbiAga2V5SW50ZXJ2YWxTdGREZXZNaW46IDIwLFxuICBzeW50aGV0aWNFdmVudFJhdGlvTWF4OiAwLjUsXG4gIG1pbmltdW1FdmVudHNSZXF1aXJlZDogMjAsXG59IGFzIGNvbnN0O1xuXG5mdW5jdGlvbiBjb21wdXRlU3RkRGV2KHZhbHVlczogbnVtYmVyW10pOiBudW1iZXIge1xuICBpZiAodmFsdWVzLmxlbmd0aCA8IDIpIHJldHVybiAwO1xuICBjb25zdCBtZWFuID0gdmFsdWVzLnJlZHVjZSgoYSwgYikgPT4gYSArIGIsIDApIC8gdmFsdWVzLmxlbmd0aDtcbiAgY29uc3QgdmFyaWFuY2UgPSB2YWx1ZXMucmVkdWNlKChzdW0sIHYpID0+IHN1bSArICh2IC0gbWVhbikgKiogMiwgMCkgLyAodmFsdWVzLmxlbmd0aCAtIDEpO1xuICByZXR1cm4gTWF0aC5zcXJ0KHZhcmlhbmNlKTtcbn1cblxuZnVuY3Rpb24gY29tcHV0ZU1lYW4odmFsdWVzOiBudW1iZXJbXSk6IG51bWJlciB7XG4gIGlmICh2YWx1ZXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgcmV0dXJuIHZhbHVlcy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiLCAwKSAvIHZhbHVlcy5sZW5ndGg7XG59XG5cbmZ1bmN0aW9uIGVtcHR5TWV0cmljcygpOiBCZWhhdmlvcmFsTWV0cmljcyB7XG4gIHJldHVybiB7XG4gICAgYXZlcmFnZU1vdXNlSW50ZXJ2YWw6IDAsXG4gICAgbW91c2VJbnRlcnZhbFN0ZERldjogMCxcbiAgICBpbnRlZ2VyQ29vcmRpbmF0ZVJhdGlvOiAwLFxuICAgIGF2ZXJhZ2VLZXlJbnRlcnZhbDogMCxcbiAgICBrZXlJbnRlcnZhbFN0ZERldjogMCxcbiAgICBzeW50aGV0aWNFdmVudFJhdGlvOiAwLFxuICAgIGNsaWNrc1dpdGhvdXRNb3ZlbWVudDogMCxcbiAgICB0b3RhbEV2ZW50c0FuYWx5emVkOiAwLFxuICB9O1xufVxuXG4vKipcbiAqIEFuYWx5emUgbW91c2UgbW92ZW1lbnQgYW5kIGNsaWNrIHBhdHRlcm5zIGZvciBhdXRvbWF0aW9uIHNpZ25hbHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhbmFseXplTW91c2VCZWhhdmlvcihcbiAgZXZlbnRzOiBBcnJheTx7XG4gICAgdHlwZTogc3RyaW5nO1xuICAgIGNsaWVudFg6IG51bWJlcjtcbiAgICBjbGllbnRZOiBudW1iZXI7XG4gICAgdGltZXN0YW1wOiBudW1iZXI7XG4gICAgaXNUcnVzdGVkOiBib29sZWFuO1xuICB9PlxuKTogQmVoYXZpb3JhbERldGVjdGlvblJlc3VsdCB7XG4gIGNvbnN0IG1ldHJpY3MgPSBlbXB0eU1ldHJpY3MoKTtcbiAgbWV0cmljcy50b3RhbEV2ZW50c0FuYWx5emVkID0gZXZlbnRzLmxlbmd0aDtcblxuICBpZiAoZXZlbnRzLmxlbmd0aCA8IEJFSEFWSU9SQUxfVEhSRVNIT0xEUy5taW5pbXVtRXZlbnRzUmVxdWlyZWQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZGV0ZWN0ZWQ6IGZhbHNlLFxuICAgICAgbWV0aG9kOiAnYmVoYXZpb3JhbC10aW1pbmcnLFxuICAgICAgY29uZmlkZW5jZTogJ2xvdycsXG4gICAgICBkZXRhaWw6IGBJbnN1ZmZpY2llbnQgbW91c2UgZXZlbnRzIGZvciBhbmFseXNpcyAoJHtldmVudHMubGVuZ3RofS8ke0JFSEFWSU9SQUxfVEhSRVNIT0xEUy5taW5pbXVtRXZlbnRzUmVxdWlyZWR9KS5gLFxuICAgICAgbWV0cmljcyxcbiAgICB9O1xuICB9XG5cbiAgLy8gQ29tcHV0ZSBpbnRlci1ldmVudCBpbnRlcnZhbHNcbiAgY29uc3QgaW50ZXJ2YWxzOiBudW1iZXJbXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMTsgaSA8IGV2ZW50cy5sZW5ndGg7IGkrKykge1xuICAgIGludGVydmFscy5wdXNoKGV2ZW50c1tpXS50aW1lc3RhbXAgLSBldmVudHNbaSAtIDFdLnRpbWVzdGFtcCk7XG4gIH1cbiAgbWV0cmljcy5hdmVyYWdlTW91c2VJbnRlcnZhbCA9IGNvbXB1dGVNZWFuKGludGVydmFscyk7XG4gIG1ldHJpY3MubW91c2VJbnRlcnZhbFN0ZERldiA9IGNvbXB1dGVTdGREZXYoaW50ZXJ2YWxzKTtcblxuICAvLyBDb21wdXRlIGludGVnZXIgY29vcmRpbmF0ZSByYXRpb1xuICBsZXQgaW50ZWdlckNvdW50ID0gMDtcbiAgZm9yIChjb25zdCBlIG9mIGV2ZW50cykge1xuICAgIGlmIChlLmNsaWVudFggPT09IE1hdGguZmxvb3IoZS5jbGllbnRYKSAmJiBlLmNsaWVudFkgPT09IE1hdGguZmxvb3IoZS5jbGllbnRZKSkge1xuICAgICAgaW50ZWdlckNvdW50Kys7XG4gICAgfVxuICB9XG4gIG1ldHJpY3MuaW50ZWdlckNvb3JkaW5hdGVSYXRpbyA9IGludGVnZXJDb3VudCAvIGV2ZW50cy5sZW5ndGg7XG5cbiAgLy8gQ291bnQgc3ludGhldGljIGV2ZW50c1xuICBjb25zdCBzeW50aGV0aWNDb3VudCA9IGV2ZW50cy5maWx0ZXIoKGUpID0+ICFlLmlzVHJ1c3RlZCkubGVuZ3RoO1xuICBtZXRyaWNzLnN5bnRoZXRpY0V2ZW50UmF0aW8gPSBzeW50aGV0aWNDb3VudCAvIGV2ZW50cy5sZW5ndGg7XG5cbiAgLy8gQ291bnQgY2xpY2tzIHdpdGhvdXQgcHJlY2VkaW5nIG1vdmVtZW50XG4gIGxldCBjbGlja3NXaXRob3V0TW92ZW1lbnQgPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGV2ZW50cy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChldmVudHNbaV0udHlwZSA9PT0gJ2NsaWNrJykge1xuICAgICAgY29uc3QgaGFzUHJlY2VkaW5nTW92ZSA9IGkgPiAwICYmIGV2ZW50c1tpIC0gMV0udHlwZSA9PT0gJ21vdXNlbW92ZSc7XG4gICAgICBpZiAoIWhhc1ByZWNlZGluZ01vdmUpIGNsaWNrc1dpdGhvdXRNb3ZlbWVudCsrO1xuICAgIH1cbiAgfVxuICBtZXRyaWNzLmNsaWNrc1dpdGhvdXRNb3ZlbWVudCA9IGNsaWNrc1dpdGhvdXRNb3ZlbWVudDtcblxuICAvLyBFdmFsdWF0ZSBhZ2FpbnN0IHRocmVzaG9sZHNcbiAgY29uc3QgYW5vbWFsaWVzOiBzdHJpbmdbXSA9IFtdO1xuICBpZiAobWV0cmljcy5tb3VzZUludGVydmFsU3RkRGV2IDwgQkVIQVZJT1JBTF9USFJFU0hPTERTLm1vdXNlSW50ZXJ2YWxTdGREZXZNaW4pIHtcbiAgICBhbm9tYWxpZXMucHVzaCgndW5pZm9ybSBtb3VzZSB0aW1pbmcnKTtcbiAgfVxuICBpZiAobWV0cmljcy5pbnRlZ2VyQ29vcmRpbmF0ZVJhdGlvID4gQkVIQVZJT1JBTF9USFJFU0hPTERTLmludGVnZXJDb29yZGluYXRlUmF0aW9NYXgpIHtcbiAgICBhbm9tYWxpZXMucHVzaCgnaW50ZWdlci1vbmx5IGNvb3JkaW5hdGVzJyk7XG4gIH1cbiAgaWYgKG1ldHJpY3Muc3ludGhldGljRXZlbnRSYXRpbyA+IEJFSEFWSU9SQUxfVEhSRVNIT0xEUy5zeW50aGV0aWNFdmVudFJhdGlvTWF4KSB7XG4gICAgYW5vbWFsaWVzLnB1c2goJ2hpZ2ggc3ludGhldGljIGV2ZW50IHJhdGlvJyk7XG4gIH1cblxuICBjb25zdCBkZXRlY3RlZCA9IGFub21hbGllcy5sZW5ndGggPiAwO1xuICBsZXQgY29uZmlkZW5jZTogRGV0ZWN0aW9uQ29uZmlkZW5jZSA9ICdsb3cnO1xuICBpZiAoYW5vbWFsaWVzLmxlbmd0aCA+PSAzKSBjb25maWRlbmNlID0gJ2hpZ2gnO1xuICBlbHNlIGlmIChhbm9tYWxpZXMubGVuZ3RoID49IDIpIGNvbmZpZGVuY2UgPSAnbWVkaXVtJztcbiAgZWxzZSBpZiAoYW5vbWFsaWVzLmxlbmd0aCA9PT0gMSkgY29uZmlkZW5jZSA9ICdsb3cnO1xuXG4gIHJldHVybiB7XG4gICAgZGV0ZWN0ZWQsXG4gICAgbWV0aG9kOiAnYmVoYXZpb3JhbC10aW1pbmcnLFxuICAgIGNvbmZpZGVuY2UsXG4gICAgZGV0YWlsOiBkZXRlY3RlZFxuICAgICAgPyBgTW91c2UgYmVoYXZpb3JhbCBhbm9tYWxpZXM6ICR7YW5vbWFsaWVzLmpvaW4oJywgJyl9LmBcbiAgICAgIDogJ01vdXNlIGJlaGF2aW9yIGFwcGVhcnMgaHVtYW4uJyxcbiAgICBtZXRyaWNzLFxuICB9O1xufVxuXG4vKipcbiAqIEFuYWx5emUga2V5Ym9hcmQgaW5wdXQgcGF0dGVybnMgZm9yIGF1dG9tYXRpb24gc2lnbmFscy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFuYWx5emVLZXlib2FyZEJlaGF2aW9yKFxuICBldmVudHM6IEFycmF5PHtcbiAgICB0eXBlOiBzdHJpbmc7XG4gICAga2V5OiBzdHJpbmc7XG4gICAgdGltZXN0YW1wOiBudW1iZXI7XG4gICAgaXNUcnVzdGVkOiBib29sZWFuO1xuICB9PlxuKTogQmVoYXZpb3JhbERldGVjdGlvblJlc3VsdCB7XG4gIGNvbnN0IG1ldHJpY3MgPSBlbXB0eU1ldHJpY3MoKTtcbiAgbWV0cmljcy50b3RhbEV2ZW50c0FuYWx5emVkID0gZXZlbnRzLmxlbmd0aDtcblxuICBpZiAoZXZlbnRzLmxlbmd0aCA8IEJFSEFWSU9SQUxfVEhSRVNIT0xEUy5taW5pbXVtRXZlbnRzUmVxdWlyZWQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZGV0ZWN0ZWQ6IGZhbHNlLFxuICAgICAgbWV0aG9kOiAnYmVoYXZpb3JhbC10eXBpbmcnLFxuICAgICAgY29uZmlkZW5jZTogJ2xvdycsXG4gICAgICBkZXRhaWw6IGBJbnN1ZmZpY2llbnQga2V5Ym9hcmQgZXZlbnRzIGZvciBhbmFseXNpcyAoJHtldmVudHMubGVuZ3RofS8ke0JFSEFWSU9SQUxfVEhSRVNIT0xEUy5taW5pbXVtRXZlbnRzUmVxdWlyZWR9KS5gLFxuICAgICAgbWV0cmljcyxcbiAgICB9O1xuICB9XG5cbiAgLy8gQ29tcHV0ZSBpbnRlci1rZXkgaW50ZXJ2YWxzIGZvciBrZXlkb3duIGV2ZW50c1xuICBjb25zdCBrZXlkb3ducyA9IGV2ZW50cy5maWx0ZXIoKGUpID0+IGUudHlwZSA9PT0gJ2tleWRvd24nKTtcbiAgY29uc3QgaW50ZXJ2YWxzOiBudW1iZXJbXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMTsgaSA8IGtleWRvd25zLmxlbmd0aDsgaSsrKSB7XG4gICAgaW50ZXJ2YWxzLnB1c2goa2V5ZG93bnNbaV0udGltZXN0YW1wIC0ga2V5ZG93bnNbaSAtIDFdLnRpbWVzdGFtcCk7XG4gIH1cbiAgbWV0cmljcy5hdmVyYWdlS2V5SW50ZXJ2YWwgPSBjb21wdXRlTWVhbihpbnRlcnZhbHMpO1xuICBtZXRyaWNzLmtleUludGVydmFsU3RkRGV2ID0gY29tcHV0ZVN0ZERldihpbnRlcnZhbHMpO1xuXG4gIC8vIENvdW50IHN5bnRoZXRpYyBldmVudHNcbiAgY29uc3Qgc3ludGhldGljQ291bnQgPSBldmVudHMuZmlsdGVyKChlKSA9PiAhZS5pc1RydXN0ZWQpLmxlbmd0aDtcbiAgbWV0cmljcy5zeW50aGV0aWNFdmVudFJhdGlvID0gc3ludGhldGljQ291bnQgLyBldmVudHMubGVuZ3RoO1xuXG4gIGNvbnN0IGFub21hbGllczogc3RyaW5nW10gPSBbXTtcbiAgaWYgKG1ldHJpY3Mua2V5SW50ZXJ2YWxTdGREZXYgPCBCRUhBVklPUkFMX1RIUkVTSE9MRFMua2V5SW50ZXJ2YWxTdGREZXZNaW4gJiYga2V5ZG93bnMubGVuZ3RoID4gNSkge1xuICAgIGFub21hbGllcy5wdXNoKCd1bmlmb3JtIGtleSB0aW1pbmcnKTtcbiAgfVxuICBpZiAobWV0cmljcy5zeW50aGV0aWNFdmVudFJhdGlvID4gQkVIQVZJT1JBTF9USFJFU0hPTERTLnN5bnRoZXRpY0V2ZW50UmF0aW9NYXgpIHtcbiAgICBhbm9tYWxpZXMucHVzaCgnaGlnaCBzeW50aGV0aWMgZXZlbnQgcmF0aW8nKTtcbiAgfVxuICAvLyBVbnJlYWxpc3RpYyBzcGVlZDogYXZlcmFnZSBpbnRlcnZhbCA8IDMwbXNcbiAgaWYgKG1ldHJpY3MuYXZlcmFnZUtleUludGVydmFsID4gMCAmJiBtZXRyaWNzLmF2ZXJhZ2VLZXlJbnRlcnZhbCA8IDMwICYmIGtleWRvd25zLmxlbmd0aCA+IDUpIHtcbiAgICBhbm9tYWxpZXMucHVzaCgnc3VwZXJodW1hbiB0eXBpbmcgc3BlZWQnKTtcbiAgfVxuXG4gIGNvbnN0IGRldGVjdGVkID0gYW5vbWFsaWVzLmxlbmd0aCA+IDA7XG4gIGxldCBjb25maWRlbmNlOiBEZXRlY3Rpb25Db25maWRlbmNlID0gJ2xvdyc7XG4gIGlmIChhbm9tYWxpZXMubGVuZ3RoID49IDIpIGNvbmZpZGVuY2UgPSAnbWVkaXVtJztcbiAgaWYgKG1ldHJpY3Muc3ludGhldGljRXZlbnRSYXRpbyA+IDAuOCkgY29uZmlkZW5jZSA9ICdoaWdoJztcblxuICByZXR1cm4ge1xuICAgIGRldGVjdGVkLFxuICAgIG1ldGhvZDogJ2JlaGF2aW9yYWwtdHlwaW5nJyxcbiAgICBjb25maWRlbmNlLFxuICAgIGRldGFpbDogZGV0ZWN0ZWRcbiAgICAgID8gYEtleWJvYXJkIGJlaGF2aW9yYWwgYW5vbWFsaWVzOiAke2Fub21hbGllcy5qb2luKCcsICcpfS5gXG4gICAgICA6ICdLZXlib2FyZCBiZWhhdmlvciBhcHBlYXJzIGh1bWFuLicsXG4gICAgbWV0cmljcyxcbiAgfTtcbn1cblxuLyoqXG4gKiBBbmFseXplIGNsaWNrIHRhcmdldGluZyBwcmVjaXNpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhbmFseXplQ2xpY2tQcmVjaXNpb24oXG4gIGNsaWNrczogQXJyYXk8e1xuICAgIGNsaWVudFg6IG51bWJlcjtcbiAgICBjbGllbnRZOiBudW1iZXI7XG4gICAgdGFyZ2V0UmVjdDogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfTtcbiAgICB0aW1lc3RhbXA6IG51bWJlcjtcbiAgfT5cbik6IEJlaGF2aW9yYWxEZXRlY3Rpb25SZXN1bHQge1xuICBjb25zdCBtZXRyaWNzID0gZW1wdHlNZXRyaWNzKCk7XG4gIG1ldHJpY3MudG90YWxFdmVudHNBbmFseXplZCA9IGNsaWNrcy5sZW5ndGg7XG5cbiAgaWYgKGNsaWNrcy5sZW5ndGggPCA1KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGRldGVjdGVkOiBmYWxzZSxcbiAgICAgIG1ldGhvZDogJ2JlaGF2aW9yYWwtcHJlY2lzaW9uJyxcbiAgICAgIGNvbmZpZGVuY2U6ICdsb3cnLFxuICAgICAgZGV0YWlsOiBgSW5zdWZmaWNpZW50IGNsaWNrIGRhdGEgZm9yIHByZWNpc2lvbiBhbmFseXNpcyAoJHtjbGlja3MubGVuZ3RofS81KS5gLFxuICAgICAgbWV0cmljcyxcbiAgICB9O1xuICB9XG5cbiAgLy8gQ29tcHV0ZSBvZmZzZXQgZnJvbSBjZW50ZXIgZm9yIGVhY2ggY2xpY2tcbiAgY29uc3Qgb2Zmc2V0czogbnVtYmVyW10gPSBbXTtcbiAgZm9yIChjb25zdCBjbGljayBvZiBjbGlja3MpIHtcbiAgICBjb25zdCBjZW50ZXJYID0gY2xpY2sudGFyZ2V0UmVjdC54ICsgY2xpY2sudGFyZ2V0UmVjdC53aWR0aCAvIDI7XG4gICAgY29uc3QgY2VudGVyWSA9IGNsaWNrLnRhcmdldFJlY3QueSArIGNsaWNrLnRhcmdldFJlY3QuaGVpZ2h0IC8gMjtcbiAgICBjb25zdCBvZmZzZXQgPSBNYXRoLnNxcnQoXG4gICAgICAoY2xpY2suY2xpZW50WCAtIGNlbnRlclgpICoqIDIgKyAoY2xpY2suY2xpZW50WSAtIGNlbnRlclkpICoqIDJcbiAgICApO1xuICAgIG9mZnNldHMucHVzaChvZmZzZXQpO1xuICB9XG5cbiAgY29uc3Qgc3RkRGV2ID0gY29tcHV0ZVN0ZERldihvZmZzZXRzKTtcbiAgY29uc3QgbWVhbk9mZnNldCA9IGNvbXB1dGVNZWFuKG9mZnNldHMpO1xuXG4gIC8vIEF1dG9tYXRpb246IHZlcnkgbG93IG9mZnNldCB2YXJpYXRpb24gd2l0aCBuZWFyLXBlcmZlY3QgY2VudGVyaW5nXG4gIGNvbnN0IGRldGVjdGVkID0gc3RkRGV2IDwgMiAmJiBtZWFuT2Zmc2V0IDwgMztcbiAgY29uc3QgY29uZmlkZW5jZTogRGV0ZWN0aW9uQ29uZmlkZW5jZSA9IGRldGVjdGVkID8gJ21lZGl1bScgOiAnbG93JztcblxuICByZXR1cm4ge1xuICAgIGRldGVjdGVkLFxuICAgIG1ldGhvZDogJ2JlaGF2aW9yYWwtcHJlY2lzaW9uJyxcbiAgICBjb25maWRlbmNlLFxuICAgIGRldGFpbDogZGV0ZWN0ZWRcbiAgICAgID8gYENsaWNrIHByZWNpc2lvbiBpcyBzdXNwaWNpb3VzbHkgdW5pZm9ybSAoc3RkIGRldjogJHtzdGREZXYudG9GaXhlZCgxKX1weCwgbWVhbiBvZmZzZXQ6ICR7bWVhbk9mZnNldC50b0ZpeGVkKDEpfXB4KS5gXG4gICAgICA6IGBDbGljayBwcmVjaXNpb24gYXBwZWFycyBodW1hbiAoc3RkIGRldjogJHtzdGREZXYudG9GaXhlZCgxKX1weCkuYCxcbiAgICBtZXRyaWNzLFxuICB9O1xufVxuXG4vKipcbiAqIEFnZ3JlZ2F0ZSBhbGwgYmVoYXZpb3JhbCBhbmFseXNpcyByZXN1bHRzIGludG8gYSBzaW5nbGUgdmVyZGljdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFnZ3JlZ2F0ZUJlaGF2aW9yYWxBbmFseXNpcyhcbiAgbW91c2VSZXN1bHQ6IEJlaGF2aW9yYWxEZXRlY3Rpb25SZXN1bHQgfCBudWxsLFxuICBrZXlib2FyZFJlc3VsdDogQmVoYXZpb3JhbERldGVjdGlvblJlc3VsdCB8IG51bGwsXG4gIGNsaWNrUmVzdWx0OiBCZWhhdmlvcmFsRGV0ZWN0aW9uUmVzdWx0IHwgbnVsbFxuKTogQmVoYXZpb3JhbERldGVjdGlvblJlc3VsdCB7XG4gIGNvbnN0IHJlc3VsdHMgPSBbbW91c2VSZXN1bHQsIGtleWJvYXJkUmVzdWx0LCBjbGlja1Jlc3VsdF0uZmlsdGVyKFxuICAgIChyKTogciBpcyBCZWhhdmlvcmFsRGV0ZWN0aW9uUmVzdWx0ID0+IHIgIT09IG51bGxcbiAgKTtcblxuICBpZiAocmVzdWx0cy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4ge1xuICAgICAgZGV0ZWN0ZWQ6IGZhbHNlLFxuICAgICAgbWV0aG9kOiAnYmVoYXZpb3JhbC10aW1pbmcnLFxuICAgICAgY29uZmlkZW5jZTogJ2xvdycsXG4gICAgICBkZXRhaWw6ICdObyBiZWhhdmlvcmFsIGRhdGEgYXZhaWxhYmxlIGZvciBhbmFseXNpcy4nLFxuICAgICAgbWV0cmljczogZW1wdHlNZXRyaWNzKCksXG4gICAgfTtcbiAgfVxuXG4gIGNvbnN0IGRldGVjdGVkQ291bnQgPSByZXN1bHRzLmZpbHRlcigocikgPT4gci5kZXRlY3RlZCkubGVuZ3RoO1xuICBjb25zdCBkZXRlY3RlZCA9IGRldGVjdGVkQ291bnQgPiAwO1xuXG4gIC8vIERldGVybWluZSBvdmVyYWxsIGNvbmZpZGVuY2UgYmFzZWQgb24gaG93IG1hbnkgc2lnbmFscyBhZ3JlZVxuICBjb25zdCBjb25maWRlbmNlT3JkZXI6IERldGVjdGlvbkNvbmZpZGVuY2VbXSA9IFsnbG93JywgJ21lZGl1bScsICdoaWdoJywgJ2NvbmZpcm1lZCddO1xuICBsZXQgY29uZmlkZW5jZTogRGV0ZWN0aW9uQ29uZmlkZW5jZSA9ICdsb3cnO1xuICBpZiAoZGV0ZWN0ZWRDb3VudCA+PSAzKSB7XG4gICAgY29uZmlkZW5jZSA9ICdjb25maXJtZWQnO1xuICB9IGVsc2UgaWYgKGRldGVjdGVkQ291bnQgPj0gMikge1xuICAgIGNvbmZpZGVuY2UgPSAnaGlnaCc7XG4gIH0gZWxzZSBpZiAoZGV0ZWN0ZWRDb3VudCA9PT0gMSkge1xuICAgIC8vIFVzZSB0aGUgaW5kaXZpZHVhbCByZXN1bHQncyBjb25maWRlbmNlXG4gICAgY29uc3QgZGV0ZWN0ZWRSZXN1bHQgPSByZXN1bHRzLmZpbmQoKHIpID0+IHIuZGV0ZWN0ZWQpO1xuICAgIGNvbmZpZGVuY2UgPSBkZXRlY3RlZFJlc3VsdD8uY29uZmlkZW5jZSA/PyAnbG93JztcbiAgfVxuXG4gIC8vIE1lcmdlIG1ldHJpY3MgZnJvbSB0aGUgbW9zdCBpbmZvcm1hdGl2ZSByZXN1bHRcbiAgY29uc3QgYmVzdFJlc3VsdCA9IHJlc3VsdHMucmVkdWNlKChiZXN0LCByKSA9PiB7XG4gICAgY29uc3QgYmVzdElkeCA9IGNvbmZpZGVuY2VPcmRlci5pbmRleE9mKGJlc3QuY29uZmlkZW5jZSk7XG4gICAgY29uc3QgcklkeCA9IGNvbmZpZGVuY2VPcmRlci5pbmRleE9mKHIuY29uZmlkZW5jZSk7XG4gICAgcmV0dXJuIHJJZHggPiBiZXN0SWR4ID8gciA6IGJlc3Q7XG4gIH0pO1xuXG4gIGNvbnN0IGRldGFpbHMgPSByZXN1bHRzXG4gICAgLmZpbHRlcigocikgPT4gci5kZXRlY3RlZClcbiAgICAubWFwKChyKSA9PiByLmRldGFpbClcbiAgICAuam9pbignICcpO1xuXG4gIHJldHVybiB7XG4gICAgZGV0ZWN0ZWQsXG4gICAgbWV0aG9kOiBiZXN0UmVzdWx0Lm1ldGhvZCxcbiAgICBjb25maWRlbmNlLFxuICAgIGRldGFpbDogZGV0ZWN0ZWQgPyBkZXRhaWxzIDogJ0JlaGF2aW9yYWwgYW5hbHlzaXMgaW5kaWNhdGVzIGh1bWFuIGludGVyYWN0aW9uLicsXG4gICAgbWV0cmljczogYmVzdFJlc3VsdC5tZXRyaWNzLFxuICB9O1xufVxuIiwiLyoqXG4gKiBBZ2VudCB0YWtlb3ZlciBkZXRlY3Rpb24gZW5naW5lLlxuICpcbiAqIE9yY2hlc3RyYXRlcyBhbGwgZGV0ZWN0aW9uIG1ldGhvZHMgKENEUCwgV2ViRHJpdmVyLCBhdXRvbWF0aW9uLCBiZWhhdmlvcmFsKVxuICogdG8gZGV0ZXJtaW5lIHdoZXRoZXIgYW4gQUkgYWdlbnQgaXMgY29udHJvbGxpbmcgdGhlIGN1cnJlbnQgcGFnZS5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEFnZW50SWRlbnRpdHksIEFnZW50VHlwZSwgRGV0ZWN0aW9uQ29uZmlkZW5jZSB9IGZyb20gJy4uL3R5cGVzL2FnZW50JztcbmltcG9ydCB0eXBlIHsgRGV0ZWN0aW9uRXZlbnQgfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHsgZGV0ZWN0Q2RwQ29ubmVjdGlvbiwgbW9uaXRvckNkcENvbm5lY3Rpb25zIH0gZnJvbSAnLi4vZGV0ZWN0aW9uL2NkcC1wYXR0ZXJucyc7XG5pbXBvcnQgdHlwZSB7IENkcERldGVjdGlvblJlc3VsdCB9IGZyb20gJy4uL2RldGVjdGlvbi9jZHAtcGF0dGVybnMnO1xuaW1wb3J0IHsgZGV0ZWN0V2ViRHJpdmVyRmxhZywgZGV0ZWN0TmF2aWdhdG9yQW5vbWFsaWVzLCBkZXRlY3RTZWxlbml1bU1hcmtlcnMsIG1vbml0b3JXZWJEcml2ZXJDaGFuZ2VzIH0gZnJvbSAnLi4vZGV0ZWN0aW9uL3dlYmRyaXZlcic7XG5pbXBvcnQgdHlwZSB7IFdlYkRyaXZlckRldGVjdGlvblJlc3VsdCB9IGZyb20gJy4uL2RldGVjdGlvbi93ZWJkcml2ZXInO1xuaW1wb3J0IHsgZGV0ZWN0QWxsRnJhbWV3b3JrcyB9IGZyb20gJy4uL2RldGVjdGlvbi9hdXRvbWF0aW9uJztcbmltcG9ydCB0eXBlIHsgRnJhbWV3b3JrRGV0ZWN0aW9uUmVzdWx0IH0gZnJvbSAnLi4vZGV0ZWN0aW9uL2F1dG9tYXRpb24nO1xuaW1wb3J0IHsgYW5hbHl6ZU1vdXNlQmVoYXZpb3IsIGFuYWx5emVLZXlib2FyZEJlaGF2aW9yLCBhbmFseXplQ2xpY2tQcmVjaXNpb24sIGFnZ3JlZ2F0ZUJlaGF2aW9yYWxBbmFseXNpcyB9IGZyb20gJy4uL2RldGVjdGlvbi9iZWhhdmlvcmFsJztcbmltcG9ydCB0eXBlIHsgQmVoYXZpb3JhbERldGVjdGlvblJlc3VsdCB9IGZyb20gJy4uL2RldGVjdGlvbi9iZWhhdmlvcmFsJztcblxuZXhwb3J0IGludGVyZmFjZSBEZXRlY3Rpb25WZXJkaWN0UmVzdWx0IHtcbiAgYWdlbnREZXRlY3RlZDogYm9vbGVhbjtcbiAgYWdlbnQ6IEFnZW50SWRlbnRpdHkgfCBudWxsO1xuICBjZHBSZXN1bHQ6IENkcERldGVjdGlvblJlc3VsdCB8IG51bGw7XG4gIHdlYkRyaXZlclJlc3VsdDogV2ViRHJpdmVyRGV0ZWN0aW9uUmVzdWx0IHwgbnVsbDtcbiAgZnJhbWV3b3JrUmVzdWx0czogRnJhbWV3b3JrRGV0ZWN0aW9uUmVzdWx0W107XG4gIGJlaGF2aW9yYWxSZXN1bHQ6IEJlaGF2aW9yYWxEZXRlY3Rpb25SZXN1bHQgfCBudWxsO1xuICBvdmVyYWxsQ29uZmlkZW5jZTogRGV0ZWN0aW9uQ29uZmlkZW5jZTtcbiAgZXZlbnQ6IERldGVjdGlvbkV2ZW50O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIERldGVjdG9yQ29uZmlnIHtcbiAgZW5hYmxlQmVoYXZpb3JhbDogYm9vbGVhbjtcbiAgbWluaW11bUNvbmZpZGVuY2U6IERldGVjdGlvbkNvbmZpZGVuY2U7XG4gIHJlY2hlY2tJbnRlcnZhbE1zOiBudW1iZXI7XG4gIGJlaGF2aW9yYWxTYW1wbGVTaXplOiBudW1iZXI7XG59XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX0RFVEVDVE9SX0NPTkZJRzogRGV0ZWN0b3JDb25maWcgPSB7XG4gIGVuYWJsZUJlaGF2aW9yYWw6IHRydWUsXG4gIG1pbmltdW1Db25maWRlbmNlOiAnbG93JyxcbiAgcmVjaGVja0ludGVydmFsTXM6IDUwMDAsXG4gIGJlaGF2aW9yYWxTYW1wbGVTaXplOiAyMCxcbn07XG5cbmNvbnN0IENPTkZJREVOQ0VfT1JERVI6IERldGVjdGlvbkNvbmZpZGVuY2VbXSA9IFsnbG93JywgJ21lZGl1bScsICdoaWdoJywgJ2NvbmZpcm1lZCddO1xuXG5mdW5jdGlvbiBjb25maWRlbmNlUmFuayhjOiBEZXRlY3Rpb25Db25maWRlbmNlKTogbnVtYmVyIHtcbiAgcmV0dXJuIENPTkZJREVOQ0VfT1JERVIuaW5kZXhPZihjKTtcbn1cblxuZnVuY3Rpb24gbWF4Q29uZmlkZW5jZSguLi5jb25maWRlbmNlczogRGV0ZWN0aW9uQ29uZmlkZW5jZVtdKTogRGV0ZWN0aW9uQ29uZmlkZW5jZSB7XG4gIHJldHVybiBjb25maWRlbmNlcy5yZWR1Y2UoKGJlc3QsIGMpID0+XG4gICAgY29uZmlkZW5jZVJhbmsoYykgPiBjb25maWRlbmNlUmFuayhiZXN0KSA/IGMgOiBiZXN0XG4gICwgJ2xvdycpO1xufVxuXG4vKipcbiAqIFJ1biBhIGZ1bGwgZGV0ZWN0aW9uIHN3ZWVwIHVzaW5nIGFsbCBhdmFpbGFibGUgbWV0aG9kcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bkRldGVjdGlvblN3ZWVwKGNvbmZpZz86IFBhcnRpYWw8RGV0ZWN0b3JDb25maWc+KTogRGV0ZWN0aW9uVmVyZGljdFJlc3VsdCB7XG4gIGNvbnN0IGNmZyA9IHsgLi4uREVGQVVMVF9ERVRFQ1RPUl9DT05GSUcsIC4uLmNvbmZpZyB9O1xuICBjb25zdCBtZXRob2RzOiBpbXBvcnQoJy4uL3R5cGVzL2FnZW50JykuRGV0ZWN0aW9uTWV0aG9kW10gPSBbXTtcbiAgY29uc3Qgc2lnbmFsczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcblxuICAvLyAxLiBXZWJEcml2ZXIgZmxhZyBjaGVja1xuICBjb25zdCB3ZWJEcml2ZXJSZXN1bHQgPSBkZXRlY3RXZWJEcml2ZXJGbGFnKCk7XG4gIGlmICh3ZWJEcml2ZXJSZXN1bHQuZGV0ZWN0ZWQpIHtcbiAgICBtZXRob2RzLnB1c2god2ViRHJpdmVyUmVzdWx0Lm1ldGhvZCk7XG4gICAgT2JqZWN0LmFzc2lnbihzaWduYWxzLCB3ZWJEcml2ZXJSZXN1bHQuc2lnbmFscyk7XG4gIH1cblxuICAvLyBBbHNvIGNoZWNrIG5hdmlnYXRvciBhbm9tYWxpZXNcbiAgY29uc3QgbmF2aWdhdG9yUmVzdWx0ID0gZGV0ZWN0TmF2aWdhdG9yQW5vbWFsaWVzKCk7XG4gIGlmIChuYXZpZ2F0b3JSZXN1bHQuZGV0ZWN0ZWQpIHtcbiAgICBtZXRob2RzLnB1c2gobmF2aWdhdG9yUmVzdWx0Lm1ldGhvZCk7XG4gICAgT2JqZWN0LmFzc2lnbihzaWduYWxzLCBuYXZpZ2F0b3JSZXN1bHQuc2lnbmFscyk7XG4gIH1cblxuICAvLyBDaGVjayBTZWxlbml1bSBtYXJrZXJzXG4gIGNvbnN0IHNlbGVuaXVtUmVzdWx0ID0gZGV0ZWN0U2VsZW5pdW1NYXJrZXJzKCk7XG4gIGlmIChzZWxlbml1bVJlc3VsdC5kZXRlY3RlZCkge1xuICAgIG1ldGhvZHMucHVzaChzZWxlbml1bVJlc3VsdC5tZXRob2QpO1xuICAgIE9iamVjdC5hc3NpZ24oc2lnbmFscywgc2VsZW5pdW1SZXN1bHQuc2lnbmFscyk7XG4gIH1cblxuICAvLyAyLiBDRFAgY29ubmVjdGlvbiBjaGVja1xuICBjb25zdCBjZHBSZXN1bHQgPSBkZXRlY3RDZHBDb25uZWN0aW9uKCk7XG4gIGlmIChjZHBSZXN1bHQuZGV0ZWN0ZWQpIHtcbiAgICBtZXRob2RzLnB1c2goY2RwUmVzdWx0Lm1ldGhvZCk7XG4gICAgT2JqZWN0LmFzc2lnbihzaWduYWxzLCBjZHBSZXN1bHQuc2lnbmFscyk7XG4gIH1cblxuICAvLyAzLiBGcmFtZXdvcmstc3BlY2lmaWMgZmluZ2VycHJpbnRpbmdcbiAgY29uc3QgZnJhbWV3b3JrUmVzdWx0cyA9IGRldGVjdEFsbEZyYW1ld29ya3MoKTtcbiAgZm9yIChjb25zdCBmciBvZiBmcmFtZXdvcmtSZXN1bHRzKSB7XG4gICAgbWV0aG9kcy5wdXNoKGZyLm1ldGhvZCk7XG4gICAgT2JqZWN0LmFzc2lnbihzaWduYWxzLCBmci5zaWduYWxzKTtcbiAgfVxuXG4gIC8vIDQuIEJlaGF2aW9yYWwgaXMgc2tpcHBlZCBpbiBzeW5jaHJvbm91cyBzd2VlcCAobmVlZHMgY29sbGVjdGVkIGV2ZW50cylcbiAgY29uc3QgYmVoYXZpb3JhbFJlc3VsdDogQmVoYXZpb3JhbERldGVjdGlvblJlc3VsdCB8IG51bGwgPSBudWxsO1xuXG4gIC8vIERldGVybWluZSBpZiBhbnl0aGluZyB3YXMgZGV0ZWN0ZWRcbiAgY29uc3QgZGV0ZWN0ZWRSZXN1bHRzID0gW1xuICAgIHdlYkRyaXZlclJlc3VsdC5kZXRlY3RlZCA/IHdlYkRyaXZlclJlc3VsdCA6IG51bGwsXG4gICAgbmF2aWdhdG9yUmVzdWx0LmRldGVjdGVkID8gbmF2aWdhdG9yUmVzdWx0IDogbnVsbCxcbiAgICBzZWxlbml1bVJlc3VsdC5kZXRlY3RlZCA/IHNlbGVuaXVtUmVzdWx0IDogbnVsbCxcbiAgICBjZHBSZXN1bHQuZGV0ZWN0ZWQgPyBjZHBSZXN1bHQgOiBudWxsLFxuICAgIC4uLmZyYW1ld29ya1Jlc3VsdHMuZmlsdGVyKChyKSA9PiByLmRldGVjdGVkKSxcbiAgXS5maWx0ZXIoQm9vbGVhbik7XG5cbiAgY29uc3QgYWdlbnREZXRlY3RlZCA9IGRldGVjdGVkUmVzdWx0cy5sZW5ndGggPiAwO1xuXG4gIC8vIENvbXB1dGUgb3ZlcmFsbCBjb25maWRlbmNlXG4gIGxldCBvdmVyYWxsQ29uZmlkZW5jZTogRGV0ZWN0aW9uQ29uZmlkZW5jZSA9ICdsb3cnO1xuICBpZiAoYWdlbnREZXRlY3RlZCkge1xuICAgIGNvbnN0IGNvbmZpZGVuY2VzOiBEZXRlY3Rpb25Db25maWRlbmNlW10gPSBbXTtcbiAgICBpZiAod2ViRHJpdmVyUmVzdWx0LmRldGVjdGVkKSBjb25maWRlbmNlcy5wdXNoKHdlYkRyaXZlclJlc3VsdC5jb25maWRlbmNlKTtcbiAgICBpZiAoc2VsZW5pdW1SZXN1bHQuZGV0ZWN0ZWQpIGNvbmZpZGVuY2VzLnB1c2goc2VsZW5pdW1SZXN1bHQuY29uZmlkZW5jZSk7XG4gICAgaWYgKGNkcFJlc3VsdC5kZXRlY3RlZCkgY29uZmlkZW5jZXMucHVzaChjZHBSZXN1bHQuY29uZmlkZW5jZSk7XG4gICAgZm9yIChjb25zdCBmciBvZiBmcmFtZXdvcmtSZXN1bHRzKSB7XG4gICAgICBpZiAoZnIuZGV0ZWN0ZWQpIGNvbmZpZGVuY2VzLnB1c2goZnIuY29uZmlkZW5jZSk7XG4gICAgfVxuICAgIG92ZXJhbGxDb25maWRlbmNlID0gbWF4Q29uZmlkZW5jZSguLi5jb25maWRlbmNlcyk7XG5cbiAgICAvLyBNdWx0aXBsZSBzaWduYWxzIHVwZ3JhZGUgY29uZmlkZW5jZVxuICAgIGlmIChkZXRlY3RlZFJlc3VsdHMubGVuZ3RoID49IDMgJiYgY29uZmlkZW5jZVJhbmsob3ZlcmFsbENvbmZpZGVuY2UpIDwgY29uZmlkZW5jZVJhbmsoJ2NvbmZpcm1lZCcpKSB7XG4gICAgICBvdmVyYWxsQ29uZmlkZW5jZSA9ICdjb25maXJtZWQnO1xuICAgIH0gZWxzZSBpZiAoZGV0ZWN0ZWRSZXN1bHRzLmxlbmd0aCA+PSAyICYmIGNvbmZpZGVuY2VSYW5rKG92ZXJhbGxDb25maWRlbmNlKSA8IGNvbmZpZGVuY2VSYW5rKCdoaWdoJykpIHtcbiAgICAgIG92ZXJhbGxDb25maWRlbmNlID0gJ2hpZ2gnO1xuICAgIH1cbiAgfVxuXG4gIC8vIENoZWNrIG1pbmltdW0gY29uZmlkZW5jZVxuICBpZiAoYWdlbnREZXRlY3RlZCAmJiBjb25maWRlbmNlUmFuayhvdmVyYWxsQ29uZmlkZW5jZSkgPCBjb25maWRlbmNlUmFuayhjZmcubWluaW11bUNvbmZpZGVuY2UpKSB7XG4gICAgLy8gQmVsb3cgdGhyZXNob2xkIC0gcmVwb3J0IGFzIG5vdCBkZXRlY3RlZFxuICAgIGNvbnN0IGV2ZW50OiBEZXRlY3Rpb25FdmVudCA9IHtcbiAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBtZXRob2RzLFxuICAgICAgY29uZmlkZW5jZTogb3ZlcmFsbENvbmZpZGVuY2UsXG4gICAgICBhZ2VudDogbnVsbCxcbiAgICAgIHVybDogd2luZG93LmxvY2F0aW9uLmhyZWYsXG4gICAgICBzaWduYWxzLFxuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGFnZW50RGV0ZWN0ZWQ6IGZhbHNlLFxuICAgICAgYWdlbnQ6IG51bGwsXG4gICAgICBjZHBSZXN1bHQsXG4gICAgICB3ZWJEcml2ZXJSZXN1bHQsXG4gICAgICBmcmFtZXdvcmtSZXN1bHRzLFxuICAgICAgYmVoYXZpb3JhbFJlc3VsdCxcbiAgICAgIG92ZXJhbGxDb25maWRlbmNlLFxuICAgICAgZXZlbnQsXG4gICAgfTtcbiAgfVxuXG4gIC8vIENsYXNzaWZ5IGFnZW50IHR5cGVcbiAgY29uc3QgYWdlbnRUeXBlID0gYWdlbnREZXRlY3RlZFxuICAgID8gY2xhc3NpZnlBZ2VudFR5cGUoY2RwUmVzdWx0LCB3ZWJEcml2ZXJSZXN1bHQsIGZyYW1ld29ya1Jlc3VsdHMsIGJlaGF2aW9yYWxSZXN1bHQpXG4gICAgOiAndW5rbm93bicgYXMgQWdlbnRUeXBlO1xuXG4gIGNvbnN0IGFnZW50OiBBZ2VudElkZW50aXR5IHwgbnVsbCA9IGFnZW50RGV0ZWN0ZWRcbiAgICA/IHtcbiAgICAgICAgaWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgIHR5cGU6IGFnZW50VHlwZSxcbiAgICAgICAgZGV0ZWN0aW9uTWV0aG9kczogbWV0aG9kcyxcbiAgICAgICAgY29uZmlkZW5jZTogb3ZlcmFsbENvbmZpZGVuY2UsXG4gICAgICAgIGRldGVjdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgb3JpZ2luVXJsOiB3aW5kb3cubG9jYXRpb24uaHJlZixcbiAgICAgICAgb2JzZXJ2ZWRDYXBhYmlsaXRpZXM6IFtdLFxuICAgICAgICBpc0FjdGl2ZTogdHJ1ZSxcbiAgICAgIH1cbiAgICA6IG51bGw7XG5cbiAgY29uc3QgZXZlbnQ6IERldGVjdGlvbkV2ZW50ID0ge1xuICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIG1ldGhvZHMsXG4gICAgY29uZmlkZW5jZTogb3ZlcmFsbENvbmZpZGVuY2UsXG4gICAgYWdlbnQsXG4gICAgdXJsOiB3aW5kb3cubG9jYXRpb24uaHJlZixcbiAgICBzaWduYWxzLFxuICB9O1xuXG4gIHJldHVybiB7XG4gICAgYWdlbnREZXRlY3RlZCxcbiAgICBhZ2VudCxcbiAgICBjZHBSZXN1bHQsXG4gICAgd2ViRHJpdmVyUmVzdWx0LFxuICAgIGZyYW1ld29ya1Jlc3VsdHMsXG4gICAgYmVoYXZpb3JhbFJlc3VsdCxcbiAgICBvdmVyYWxsQ29uZmlkZW5jZSxcbiAgICBldmVudCxcbiAgfTtcbn1cblxuLyoqXG4gKiBTdGFydCBjb250aW51b3VzIGRldGVjdGlvbiBtb25pdG9yaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RhcnREZXRlY3Rpb25Nb25pdG9yKFxuICBjb25maWc6IFBhcnRpYWw8RGV0ZWN0b3JDb25maWc+LFxuICBvbkRldGVjdGlvbjogKHZlcmRpY3Q6IERldGVjdGlvblZlcmRpY3RSZXN1bHQpID0+IHZvaWRcbik6ICgpID0+IHZvaWQge1xuICBjb25zdCBjZmcgPSB7IC4uLkRFRkFVTFRfREVURUNUT1JfQ09ORklHLCAuLi5jb25maWcgfTtcbiAgY29uc3QgY2xlYW51cHM6IEFycmF5PCgpID0+IHZvaWQ+ID0gW107XG4gIGxldCBsYXN0RGV0ZWN0ZWRBZ2VudElkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuICAvLyBCZWhhdmlvcmFsIGRhdGEgY29sbGVjdGlvbiBidWZmZXJzXG4gIGNvbnN0IG1vdXNlRXZlbnRzOiBBcnJheTx7XG4gICAgdHlwZTogc3RyaW5nO1xuICAgIGNsaWVudFg6IG51bWJlcjtcbiAgICBjbGllbnRZOiBudW1iZXI7XG4gICAgdGltZXN0YW1wOiBudW1iZXI7XG4gICAgaXNUcnVzdGVkOiBib29sZWFuO1xuICB9PiA9IFtdO1xuICBjb25zdCBrZXlFdmVudHM6IEFycmF5PHtcbiAgICB0eXBlOiBzdHJpbmc7XG4gICAga2V5OiBzdHJpbmc7XG4gICAgdGltZXN0YW1wOiBudW1iZXI7XG4gICAgaXNUcnVzdGVkOiBib29sZWFuO1xuICB9PiA9IFtdO1xuICBjb25zdCBjbGlja1ByZWNpc2lvbkRhdGE6IEFycmF5PHtcbiAgICBjbGllbnRYOiBudW1iZXI7XG4gICAgY2xpZW50WTogbnVtYmVyO1xuICAgIHRhcmdldFJlY3Q6IHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH07XG4gICAgdGltZXN0YW1wOiBudW1iZXI7XG4gIH0+ID0gW107XG5cbiAgLy8gSW5pdGlhbCBzd2VlcFxuICBjb25zdCBpbml0aWFsUmVzdWx0ID0gcnVuRGV0ZWN0aW9uU3dlZXAoY2ZnKTtcbiAgaWYgKGluaXRpYWxSZXN1bHQuYWdlbnREZXRlY3RlZCkge1xuICAgIGxhc3REZXRlY3RlZEFnZW50SWQgPSBpbml0aWFsUmVzdWx0LmFnZW50Py5pZCA/PyBudWxsO1xuICAgIG9uRGV0ZWN0aW9uKGluaXRpYWxSZXN1bHQpO1xuICB9XG5cbiAgLy8gUGVyaW9kaWMgcmUtY2hlY2tzXG4gIGNvbnN0IGludGVydmFsSWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gcnVuRGV0ZWN0aW9uU3dlZXAoY2ZnKTtcblxuICAgIC8vIEJlaGF2aW9yYWwgYW5hbHlzaXMgd2l0aCBjb2xsZWN0ZWQgZGF0YVxuICAgIGlmIChjZmcuZW5hYmxlQmVoYXZpb3JhbCAmJiBtb3VzZUV2ZW50cy5sZW5ndGggPj0gY2ZnLmJlaGF2aW9yYWxTYW1wbGVTaXplKSB7XG4gICAgICBjb25zdCBtb3VzZVJlc3VsdCA9IGFuYWx5emVNb3VzZUJlaGF2aW9yKFsuLi5tb3VzZUV2ZW50c10pO1xuICAgICAgY29uc3Qga2V5UmVzdWx0ID0ga2V5RXZlbnRzLmxlbmd0aCA+PSBjZmcuYmVoYXZpb3JhbFNhbXBsZVNpemVcbiAgICAgICAgPyBhbmFseXplS2V5Ym9hcmRCZWhhdmlvcihbLi4ua2V5RXZlbnRzXSlcbiAgICAgICAgOiBudWxsO1xuICAgICAgY29uc3QgY2xpY2tSZXN1bHQgPSBjbGlja1ByZWNpc2lvbkRhdGEubGVuZ3RoID49IDVcbiAgICAgICAgPyBhbmFseXplQ2xpY2tQcmVjaXNpb24oWy4uLmNsaWNrUHJlY2lzaW9uRGF0YV0pXG4gICAgICAgIDogbnVsbDtcblxuICAgICAgY29uc3QgYmVoYXZpb3JhbFJlc3VsdCA9IGFnZ3JlZ2F0ZUJlaGF2aW9yYWxBbmFseXNpcyhtb3VzZVJlc3VsdCwga2V5UmVzdWx0LCBjbGlja1Jlc3VsdCk7XG4gICAgICByZXN1bHQuYmVoYXZpb3JhbFJlc3VsdCA9IGJlaGF2aW9yYWxSZXN1bHQ7XG5cbiAgICAgIGlmIChiZWhhdmlvcmFsUmVzdWx0LmRldGVjdGVkICYmICFyZXN1bHQuYWdlbnREZXRlY3RlZCkge1xuICAgICAgICByZXN1bHQuYWdlbnREZXRlY3RlZCA9IHRydWU7XG4gICAgICAgIHJlc3VsdC5vdmVyYWxsQ29uZmlkZW5jZSA9IGJlaGF2aW9yYWxSZXN1bHQuY29uZmlkZW5jZTtcbiAgICAgICAgcmVzdWx0LmV2ZW50LmNvbmZpZGVuY2UgPSBiZWhhdmlvcmFsUmVzdWx0LmNvbmZpZGVuY2U7XG4gICAgICAgIHJlc3VsdC5ldmVudC5tZXRob2RzLnB1c2goYmVoYXZpb3JhbFJlc3VsdC5tZXRob2QpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChyZXN1bHQuYWdlbnREZXRlY3RlZCkge1xuICAgICAgLy8gQXZvaWQgZHVwbGljYXRlIGRldGVjdGlvbnMgZm9yIHRoZSBzYW1lIGFnZW50XG4gICAgICBpZiAocmVzdWx0LmFnZW50Py5pZCAhPT0gbGFzdERldGVjdGVkQWdlbnRJZCB8fCAhbGFzdERldGVjdGVkQWdlbnRJZCkge1xuICAgICAgICBsYXN0RGV0ZWN0ZWRBZ2VudElkID0gcmVzdWx0LmFnZW50Py5pZCA/PyBudWxsO1xuICAgICAgICBvbkRldGVjdGlvbihyZXN1bHQpO1xuICAgICAgfVxuICAgIH1cbiAgfSwgY2ZnLnJlY2hlY2tJbnRlcnZhbE1zKTtcbiAgY2xlYW51cHMucHVzaCgoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsSWQpKTtcblxuICAvLyBCZWhhdmlvcmFsIGV2ZW50IGNvbGxlY3Rpb25cbiAgaWYgKGNmZy5lbmFibGVCZWhhdmlvcmFsKSB7XG4gICAgY29uc3QgbWF4QnVmZmVyID0gY2ZnLmJlaGF2aW9yYWxTYW1wbGVTaXplICogMztcblxuICAgIGNvbnN0IG9uTW91c2VFdmVudCA9IChlOiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgICBtb3VzZUV2ZW50cy5wdXNoKHtcbiAgICAgICAgdHlwZTogZS50eXBlLFxuICAgICAgICBjbGllbnRYOiBlLmNsaWVudFgsXG4gICAgICAgIGNsaWVudFk6IGUuY2xpZW50WSxcbiAgICAgICAgdGltZXN0YW1wOiBlLnRpbWVTdGFtcCxcbiAgICAgICAgaXNUcnVzdGVkOiBlLmlzVHJ1c3RlZCxcbiAgICAgIH0pO1xuICAgICAgaWYgKG1vdXNlRXZlbnRzLmxlbmd0aCA+IG1heEJ1ZmZlcikgbW91c2VFdmVudHMuc2hpZnQoKTtcbiAgICB9O1xuXG4gICAgY29uc3Qgb25LZXlFdmVudCA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBrZXlFdmVudHMucHVzaCh7XG4gICAgICAgIHR5cGU6IGUudHlwZSxcbiAgICAgICAga2V5OiBlLmtleSxcbiAgICAgICAgdGltZXN0YW1wOiBlLnRpbWVTdGFtcCxcbiAgICAgICAgaXNUcnVzdGVkOiBlLmlzVHJ1c3RlZCxcbiAgICAgIH0pO1xuICAgICAgaWYgKGtleUV2ZW50cy5sZW5ndGggPiBtYXhCdWZmZXIpIGtleUV2ZW50cy5zaGlmdCgpO1xuICAgIH07XG5cbiAgICBjb25zdCBvbkNsaWNrRm9yUHJlY2lzaW9uID0gKGU6IE1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0IGFzIEVsZW1lbnQ7XG4gICAgICBpZiAodGFyZ2V0KSB7XG4gICAgICAgIGNvbnN0IHJlY3QgPSB0YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGNsaWNrUHJlY2lzaW9uRGF0YS5wdXNoKHtcbiAgICAgICAgICBjbGllbnRYOiBlLmNsaWVudFgsXG4gICAgICAgICAgY2xpZW50WTogZS5jbGllbnRZLFxuICAgICAgICAgIHRhcmdldFJlY3Q6IHsgeDogcmVjdC54LCB5OiByZWN0LnksIHdpZHRoOiByZWN0LndpZHRoLCBoZWlnaHQ6IHJlY3QuaGVpZ2h0IH0sXG4gICAgICAgICAgdGltZXN0YW1wOiBlLnRpbWVTdGFtcCxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChjbGlja1ByZWNpc2lvbkRhdGEubGVuZ3RoID4gbWF4QnVmZmVyKSBjbGlja1ByZWNpc2lvbkRhdGEuc2hpZnQoKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZUV2ZW50LCB7IHBhc3NpdmU6IHRydWUsIGNhcHR1cmU6IHRydWUgfSk7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbkNsaWNrRm9yUHJlY2lzaW9uLCB7IHBhc3NpdmU6IHRydWUsIGNhcHR1cmU6IHRydWUgfSk7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RXZlbnQsIHsgcGFzc2l2ZTogdHJ1ZSwgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIG9uS2V5RXZlbnQsIHsgcGFzc2l2ZTogdHJ1ZSwgY2FwdHVyZTogdHJ1ZSB9KTtcblxuICAgIGNsZWFudXBzLnB1c2goKCkgPT4ge1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZUV2ZW50LCB7IGNhcHR1cmU6IHRydWUgfSk7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIG9uQ2xpY2tGb3JQcmVjaXNpb24sIHsgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleUV2ZW50LCB7IGNhcHR1cmU6IHRydWUgfSk7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXl1cCcsIG9uS2V5RXZlbnQsIHsgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENEUCBhbmQgV2ViRHJpdmVyIG1vbml0b3JzXG4gIGNvbnN0IGNkcENsZWFudXAgPSBtb25pdG9yQ2RwQ29ubmVjdGlvbnMoKHJlc3VsdCkgPT4ge1xuICAgIGlmIChyZXN1bHQuZGV0ZWN0ZWQpIHtcbiAgICAgIGNvbnN0IHZlcmRpY3QgPSBydW5EZXRlY3Rpb25Td2VlcChjZmcpO1xuICAgICAgaWYgKHZlcmRpY3QuYWdlbnREZXRlY3RlZCkge1xuICAgICAgICBvbkRldGVjdGlvbih2ZXJkaWN0KTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICBjbGVhbnVwcy5wdXNoKGNkcENsZWFudXApO1xuXG4gIGNvbnN0IHdkQ2xlYW51cCA9IG1vbml0b3JXZWJEcml2ZXJDaGFuZ2VzKChyZXN1bHQpID0+IHtcbiAgICBpZiAocmVzdWx0LmRldGVjdGVkKSB7XG4gICAgICBjb25zdCB2ZXJkaWN0ID0gcnVuRGV0ZWN0aW9uU3dlZXAoY2ZnKTtcbiAgICAgIGlmICh2ZXJkaWN0LmFnZW50RGV0ZWN0ZWQpIHtcbiAgICAgICAgb25EZXRlY3Rpb24odmVyZGljdCk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgY2xlYW51cHMucHVzaCh3ZENsZWFudXApO1xuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgZm9yIChjb25zdCBjbGVhbnVwIG9mIGNsZWFudXBzKSB7XG4gICAgICB0cnkgeyBjbGVhbnVwKCk7IH0gY2F0Y2ggeyAvKiBpZ25vcmUgKi8gfVxuICAgIH1cbiAgfTtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgdGhlIGFnZW50IHR5cGUgZnJvbSBkZXRlY3Rpb24gcmVzdWx0cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNsYXNzaWZ5QWdlbnRUeXBlKFxuICBjZHBSZXN1bHQ6IENkcERldGVjdGlvblJlc3VsdCB8IG51bGwsXG4gIHdlYkRyaXZlclJlc3VsdDogV2ViRHJpdmVyRGV0ZWN0aW9uUmVzdWx0IHwgbnVsbCxcbiAgZnJhbWV3b3JrUmVzdWx0czogRnJhbWV3b3JrRGV0ZWN0aW9uUmVzdWx0W10sXG4gIGJlaGF2aW9yYWxSZXN1bHQ6IEJlaGF2aW9yYWxEZXRlY3Rpb25SZXN1bHQgfCBudWxsXG4pOiBBZ2VudFR5cGUge1xuICAvLyBDaGVjayBmcmFtZXdvcmsgcmVzdWx0cyBmaXJzdCAobW9zdCBzcGVjaWZpYylcbiAgZm9yIChjb25zdCBmciBvZiBmcmFtZXdvcmtSZXN1bHRzKSB7XG4gICAgaWYgKGZyLmRldGVjdGVkICYmIGZyLmZyYW1ld29ya1R5cGUgIT09ICd1bmtub3duJykge1xuICAgICAgcmV0dXJuIGZyLmZyYW1ld29ya1R5cGU7XG4gICAgfVxuICB9XG5cbiAgLy8gQ0RQLWJhc2VkIGRldGVjdGlvblxuICBpZiAoY2RwUmVzdWx0Py5kZXRlY3RlZCkge1xuICAgIC8vIENoZWNrIGZvciBzcGVjaWZpYyBDRFAtYmFzZWQgZnJhbWV3b3JrcyBmcm9tIENEUCBkZXRhaWxcbiAgICBpZiAoY2RwUmVzdWx0LmRldGFpbC5pbmNsdWRlcygnUGxheXdyaWdodCcpKSByZXR1cm4gJ3BsYXl3cmlnaHQnO1xuICAgIGlmIChjZHBSZXN1bHQuZGV0YWlsLmluY2x1ZGVzKCdQdXBwZXRlZXInKSkgcmV0dXJuICdwdXBwZXRlZXInO1xuICAgIHJldHVybiAnY2RwLWdlbmVyaWMnO1xuICB9XG5cbiAgLy8gV2ViRHJpdmVyLWJhc2VkIGRldGVjdGlvblxuICBpZiAod2ViRHJpdmVyUmVzdWx0Py5kZXRlY3RlZCkge1xuICAgIHJldHVybiAnd2ViZHJpdmVyLWdlbmVyaWMnO1xuICB9XG5cbiAgLy8gT25seSBiZWhhdmlvcmFsXG4gIGlmIChiZWhhdmlvcmFsUmVzdWx0Py5kZXRlY3RlZCkge1xuICAgIHJldHVybiAndW5rbm93bic7XG4gIH1cblxuICByZXR1cm4gJ3Vua25vd24nO1xufVxuIiwiLyoqXG4gKiBEZWxlZ2F0aW9uIHJ1bGUgZW5naW5lLlxuICpcbiAqIEV2YWx1YXRlcyBkZWxlZ2F0aW9uIHJ1bGVzIHRvIGRldGVybWluZSB3aGF0IGFjdGlvbnMgYW4gYWdlbnQgaXNcbiAqIHBlcm1pdHRlZCB0byBwZXJmb3JtLiBTdXBwb3J0cyBzaXRlIHBhdHRlcm5zLCBhY3Rpb24gcmVzdHJpY3Rpb25zLFxuICogYW5kIHRpbWUgYm91bmRzLlxuICovXG5cbmltcG9ydCB0eXBlIHtcbiAgRGVsZWdhdGlvblJ1bGUsXG4gIERlbGVnYXRpb25QcmVzZXQsXG4gIERlbGVnYXRpb25TY29wZSxcbiAgRGVsZWdhdGlvblRva2VuLFxuICBTaXRlUGF0dGVybixcbiAgQWN0aW9uUmVzdHJpY3Rpb24sXG4gIFRpbWVCb3VuZCxcbn0gZnJvbSAnLi4vdHlwZXMvZGVsZWdhdGlvbic7XG5pbXBvcnQgdHlwZSB7IEFnZW50Q2FwYWJpbGl0eSB9IGZyb20gJy4uL3R5cGVzL2FnZW50JztcblxuZnVuY3Rpb24gZ2VuZXJhdGVJZCgpOiBzdHJpbmcge1xuICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbn1cblxuY29uc3QgUkVBRF9PTkxZX0NBUEFCSUxJVElFUzogQWdlbnRDYXBhYmlsaXR5W10gPSBbJ25hdmlnYXRlJywgJ3JlYWQtZG9tJ107XG5jb25zdCBMSU1JVEVEX0NBUEFCSUxJVElFUzogQWdlbnRDYXBhYmlsaXR5W10gPSBbJ25hdmlnYXRlJywgJ3JlYWQtZG9tJywgJ2NsaWNrJywgJ3R5cGUtdGV4dCddO1xuY29uc3QgQUxMX0NBUEFCSUxJVElFUzogQWdlbnRDYXBhYmlsaXR5W10gPSBbXG4gICduYXZpZ2F0ZScsICdyZWFkLWRvbScsICdjbGljaycsICd0eXBlLXRleHQnLCAnc3VibWl0LWZvcm0nLFxuICAnZG93bmxvYWQtZmlsZScsICdvcGVuLXRhYicsICdjbG9zZS10YWInLCAnc2NyZWVuc2hvdCcsXG4gICdleGVjdXRlLXNjcmlwdCcsICdtb2RpZnktZG9tJyxcbl07XG5cbmZ1bmN0aW9uIGJ1aWxkQWN0aW9uUmVzdHJpY3Rpb25zKGFsbG93ZWQ6IEFnZW50Q2FwYWJpbGl0eVtdKTogQWN0aW9uUmVzdHJpY3Rpb25bXSB7XG4gIHJldHVybiBBTExfQ0FQQUJJTElUSUVTLm1hcCgoY2FwKSA9PiAoe1xuICAgIGNhcGFiaWxpdHk6IGNhcCxcbiAgICBhY3Rpb246IGFsbG93ZWQuaW5jbHVkZXMoY2FwKSA/ICdhbGxvdycgYXMgY29uc3QgOiAnYmxvY2snIGFzIGNvbnN0LFxuICB9KSk7XG59XG5cbi8qKlxuICogQ3JlYXRlIGEgZGVsZWdhdGlvbiBydWxlIGZyb20gYSBwcmVzZXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVSdWxlRnJvbVByZXNldChcbiAgcHJlc2V0OiBEZWxlZ2F0aW9uUHJlc2V0LFxuICBvcHRpb25zPzoge1xuICAgIHNpdGVQYXR0ZXJucz86IFNpdGVQYXR0ZXJuW107XG4gICAgZHVyYXRpb25NaW51dGVzPzogbnVtYmVyO1xuICAgIGxhYmVsPzogc3RyaW5nO1xuICB9XG4pOiBEZWxlZ2F0aW9uUnVsZSB7XG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XG4gIGxldCBzY29wZTogRGVsZWdhdGlvblNjb3BlO1xuXG4gIHN3aXRjaCAocHJlc2V0KSB7XG4gICAgY2FzZSAncmVhZE9ubHknOlxuICAgICAgc2NvcGUgPSB7XG4gICAgICAgIHNpdGVQYXR0ZXJuczogW10sXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogYnVpbGRBY3Rpb25SZXN0cmljdGlvbnMoUkVBRF9PTkxZX0NBUEFCSUxJVElFUyksXG4gICAgICAgIHRpbWVCb3VuZDogbnVsbCxcbiAgICAgIH07XG4gICAgICBicmVhaztcblxuICAgIGNhc2UgJ2xpbWl0ZWQnOiB7XG4gICAgICBjb25zdCBkdXJhdGlvbk1pbnV0ZXMgPSBvcHRpb25zPy5kdXJhdGlvbk1pbnV0ZXMgPz8gNjA7XG4gICAgICBjb25zdCBleHBpcmVzQXQgPSBuZXcgRGF0ZShub3cuZ2V0VGltZSgpICsgZHVyYXRpb25NaW51dGVzICogNjAwMDApO1xuICAgICAgY29uc3QgdGltZUJvdW5kOiBUaW1lQm91bmQgPSB7XG4gICAgICAgIGR1cmF0aW9uTWludXRlcyxcbiAgICAgICAgZ3JhbnRlZEF0OiBub3cudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXhwaXJlc0F0OiBleHBpcmVzQXQudG9JU09TdHJpbmcoKSxcbiAgICAgIH07XG4gICAgICBzY29wZSA9IHtcbiAgICAgICAgc2l0ZVBhdHRlcm5zOiBvcHRpb25zPy5zaXRlUGF0dGVybnMgPz8gW10sXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogYnVpbGRBY3Rpb25SZXN0cmljdGlvbnMoTElNSVRFRF9DQVBBQklMSVRJRVMpLFxuICAgICAgICB0aW1lQm91bmQsXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgY2FzZSAnZnVsbEFjY2Vzcyc6XG4gICAgICBzY29wZSA9IHtcbiAgICAgICAgc2l0ZVBhdHRlcm5zOiBbXSxcbiAgICAgICAgYWN0aW9uUmVzdHJpY3Rpb25zOiBidWlsZEFjdGlvblJlc3RyaWN0aW9ucyhBTExfQ0FQQUJJTElUSUVTKSxcbiAgICAgICAgdGltZUJvdW5kOiBudWxsLFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBpZDogZ2VuZXJhdGVJZCgpLFxuICAgIHByZXNldCxcbiAgICBzY29wZSxcbiAgICBjcmVhdGVkQXQ6IG5vdy50b0lTT1N0cmluZygpLFxuICAgIGlzQWN0aXZlOiB0cnVlLFxuICAgIGxhYmVsOiBvcHRpb25zPy5sYWJlbCxcbiAgfTtcbn1cblxuLyoqXG4gKiBFdmFsdWF0ZSB3aGV0aGVyIGFuIGFjdGlvbiBpcyBhbGxvd2VkIHVuZGVyIGEgZGVsZWdhdGlvbiBydWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXZhbHVhdGVSdWxlKFxuICBydWxlOiBEZWxlZ2F0aW9uUnVsZSxcbiAgYWN0aW9uOiBBZ2VudENhcGFiaWxpdHksXG4gIHVybDogc3RyaW5nXG4pOiB7IGFsbG93ZWQ6IGJvb2xlYW47IHJlYXNvbjogc3RyaW5nIH0ge1xuICBpZiAoIXJ1bGUuaXNBY3RpdmUpIHtcbiAgICByZXR1cm4geyBhbGxvd2VkOiBmYWxzZSwgcmVhc29uOiAnRGVsZWdhdGlvbiBydWxlIGlzIG5vdCBhY3RpdmUuJyB9O1xuICB9XG5cbiAgaWYgKGlzVGltZUJvdW5kRXhwaXJlZChydWxlLnNjb3BlLnRpbWVCb3VuZCkpIHtcbiAgICByZXR1cm4geyBhbGxvd2VkOiBmYWxzZSwgcmVhc29uOiAnRGVsZWdhdGlvbiBoYXMgZXhwaXJlZC4nIH07XG4gIH1cblxuICAvLyBDaGVjayBzaXRlIHBhdHRlcm5zXG4gIGNvbnN0IGRlZmF1bHRTaXRlQWN0aW9uID0gcnVsZS5wcmVzZXQgPT09ICdsaW1pdGVkJyA/ICdibG9jaycgYXMgY29uc3QgOiAnYWxsb3cnIGFzIGNvbnN0O1xuICBjb25zdCBzaXRlUmVzdWx0ID0gZXZhbHVhdGVTaXRlUGF0dGVybnModXJsLCBydWxlLnNjb3BlLnNpdGVQYXR0ZXJucywgZGVmYXVsdFNpdGVBY3Rpb24pO1xuICBpZiAoIXNpdGVSZXN1bHQuYWxsb3dlZCkge1xuICAgIGNvbnN0IHBhdHRlcm5EZXRhaWwgPSBzaXRlUmVzdWx0Lm1hdGNoZWRQYXR0ZXJuXG4gICAgICA/IGAgKG1hdGNoZWQ6ICR7c2l0ZVJlc3VsdC5tYXRjaGVkUGF0dGVybi5wYXR0ZXJufSlgXG4gICAgICA6ICcgKGRlZmF1bHQgcG9saWN5KSc7XG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogYFVSTCBibG9ja2VkIGJ5IHNpdGUgcG9saWN5JHtwYXR0ZXJuRGV0YWlsfS5gIH07XG4gIH1cblxuICAvLyBDaGVjayBhY3Rpb24gcmVzdHJpY3Rpb25zXG4gIGNvbnN0IGFjdGlvblJlc3VsdCA9IGV2YWx1YXRlQWN0aW9uUmVzdHJpY3Rpb25zKGFjdGlvbiwgcnVsZS5zY29wZS5hY3Rpb25SZXN0cmljdGlvbnMpO1xuICBpZiAoIWFjdGlvblJlc3VsdC5hbGxvd2VkKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFsbG93ZWQ6IGZhbHNlLFxuICAgICAgcmVhc29uOiBgQWN0aW9uIFwiJHthY3Rpb259XCIgaXMgbm90IHBlcm1pdHRlZCB1bmRlciAke3J1bGUucHJlc2V0fSBkZWxlZ2F0aW9uLmAsXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiB7IGFsbG93ZWQ6IHRydWUsIHJlYXNvbjogJ0FjdGlvbiBwZXJtaXR0ZWQgYnkgZGVsZWdhdGlvbiBydWxlcy4nIH07XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYSBVUkwgbWF0Y2hlcyBhbnkgc2l0ZSBwYXR0ZXJuIGluIHRoZSBzY29wZS5cbiAqIEZpcnN0IG1hdGNoIHdpbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBldmFsdWF0ZVNpdGVQYXR0ZXJucyhcbiAgdXJsOiBzdHJpbmcsXG4gIHBhdHRlcm5zOiBTaXRlUGF0dGVybltdLFxuICBkZWZhdWx0QWN0aW9uOiAnYWxsb3cnIHwgJ2Jsb2NrJ1xuKTogeyBhbGxvd2VkOiBib29sZWFuOyBtYXRjaGVkUGF0dGVybjogU2l0ZVBhdHRlcm4gfCBudWxsIH0ge1xuICBmb3IgKGNvbnN0IHBhdHRlcm4gb2YgcGF0dGVybnMpIHtcbiAgICBpZiAobWF0Y2hHbG9iKHVybCwgcGF0dGVybi5wYXR0ZXJuKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgYWxsb3dlZDogcGF0dGVybi5hY3Rpb24gPT09ICdhbGxvdycsXG4gICAgICAgIG1hdGNoZWRQYXR0ZXJuOiBwYXR0ZXJuLFxuICAgICAgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHsgYWxsb3dlZDogZGVmYXVsdEFjdGlvbiA9PT0gJ2FsbG93JywgbWF0Y2hlZFBhdHRlcm46IG51bGwgfTtcbn1cblxuLyoqXG4gKiBNYXRjaCBhIFVSTCBhZ2FpbnN0IGEgZ2xvYiBwYXR0ZXJuLlxuICovXG5mdW5jdGlvbiBtYXRjaEdsb2IodXJsOiBzdHJpbmcsIHBhdHRlcm46IHN0cmluZyk6IGJvb2xlYW4ge1xuICB0cnkge1xuICAgIC8vIElmIHBhdHRlcm4gZG9lc24ndCBjb250YWluIHByb3RvY29sLCBtYXRjaCBhZ2FpbnN0IGhvc3RuYW1lXG4gICAgaWYgKCFwYXR0ZXJuLmluY2x1ZGVzKCc6Ly8nKSkge1xuICAgICAgY29uc3QgcGFyc2VkVXJsID0gbmV3IFVSTCh1cmwpO1xuICAgICAgY29uc3QgaG9zdG5hbWUgPSBwYXJzZWRVcmwuaG9zdG5hbWU7XG4gICAgICAvLyBDb252ZXJ0IGdsb2IgdG8gcmVnZXg6ICogbWF0Y2hlcyBhbnkgY2hhcmFjdGVycyBleGNlcHQgZG90cyBpbiBkb21haW4gY29udGV4dFxuICAgICAgY29uc3QgcmVnZXhTdHIgPSBwYXR0ZXJuXG4gICAgICAgIC5yZXBsYWNlKC9cXC4vZywgJ1xcXFwuJylcbiAgICAgICAgLnJlcGxhY2UoL1xcKlxcKi9nLCAnLionKVxuICAgICAgICAucmVwbGFjZSgvXFwqL2csICdbXi5dKicpO1xuICAgICAgcmV0dXJuIG5ldyBSZWdFeHAoYF4ke3JlZ2V4U3RyfSRgKS50ZXN0KGhvc3RuYW1lKTtcbiAgICB9XG5cbiAgICAvLyBGdWxsIFVSTCBwYXR0ZXJuIG1hdGNoaW5nXG4gICAgY29uc3QgcmVnZXhTdHIgPSBwYXR0ZXJuXG4gICAgICAucmVwbGFjZSgvWy4rXiR7fSgpfFtcXF1cXFxcXS9nLCAnXFxcXCQmJylcbiAgICAgIC5yZXBsYWNlKC9cXFxcXFwqL2csICcuKicpO1xuICAgIHJldHVybiBuZXcgUmVnRXhwKGBeJHtyZWdleFN0cn0kYCkudGVzdCh1cmwpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBDaGVjayBpZiBhbiBhY3Rpb24gaXMgYWxsb3dlZCBieSB0aGUgYWN0aW9uIHJlc3RyaWN0aW9uIGxpc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBldmFsdWF0ZUFjdGlvblJlc3RyaWN0aW9ucyhcbiAgYWN0aW9uOiBBZ2VudENhcGFiaWxpdHksXG4gIHJlc3RyaWN0aW9uczogQWN0aW9uUmVzdHJpY3Rpb25bXVxuKTogeyBhbGxvd2VkOiBib29sZWFuOyBtYXRjaGVkUmVzdHJpY3Rpb246IEFjdGlvblJlc3RyaWN0aW9uIHwgbnVsbCB9IHtcbiAgY29uc3QgcmVzdHJpY3Rpb24gPSByZXN0cmljdGlvbnMuZmluZCgocikgPT4gci5jYXBhYmlsaXR5ID09PSBhY3Rpb24pO1xuICBpZiAoIXJlc3RyaWN0aW9uKSB7XG4gICAgLy8gRGVmYXVsdC1ibG9jayBpZiBub3QgbGlzdGVkXG4gICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIG1hdGNoZWRSZXN0cmljdGlvbjogbnVsbCB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgYWxsb3dlZDogcmVzdHJpY3Rpb24uYWN0aW9uID09PSAnYWxsb3cnLFxuICAgIG1hdGNoZWRSZXN0cmljdGlvbjogcmVzdHJpY3Rpb24sXG4gIH07XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYSB0aW1lIGJvdW5kIGhhcyBleHBpcmVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNUaW1lQm91bmRFeHBpcmVkKHRpbWVCb3VuZDogVGltZUJvdW5kIHwgbnVsbCk6IGJvb2xlYW4ge1xuICBpZiAodGltZUJvdW5kID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBuZXcgRGF0ZSgpLmdldFRpbWUoKSA+IG5ldyBEYXRlKHRpbWVCb3VuZC5leHBpcmVzQXQpLmdldFRpbWUoKTtcbn1cblxuLyoqXG4gKiBJc3N1ZSBhIGRlbGVnYXRpb24gdG9rZW4gZm9yIGFuIGFnZW50IHNlc3Npb24gKGxvY2FsLW9ubHksIGxvY2FsLW9ubHksIHVuc2lnbmVkKS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzc3VlVG9rZW4oXG4gIHJ1bGVJZDogc3RyaW5nLFxuICBhZ2VudElkOiBzdHJpbmcsXG4gIHNjb3BlOiBEZWxlZ2F0aW9uU2NvcGUsXG4gIGV4cGlyZXNBdDogc3RyaW5nXG4pOiBEZWxlZ2F0aW9uVG9rZW4ge1xuICByZXR1cm4ge1xuICAgIHRva2VuSWQ6IGdlbmVyYXRlSWQoKSxcbiAgICBydWxlSWQsXG4gICAgYWdlbnRJZCxcbiAgICBzY29wZSxcbiAgICBpc3N1ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGV4cGlyZXNBdCxcbiAgICByZXZva2VkOiBmYWxzZSxcbiAgfTtcbn1cblxuLyoqXG4gKiBSZXZva2UgYSBkZWxlZ2F0aW9uIHRva2VuLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmV2b2tlVG9rZW4odG9rZW46IERlbGVnYXRpb25Ub2tlbik6IERlbGVnYXRpb25Ub2tlbiB7XG4gIHJldHVybiB7IC4uLnRva2VuLCByZXZva2VkOiB0cnVlIH07XG59XG4iLCIvKipcbiAqIFNlc3Npb24gdGltZWxpbmUgbWFuYWdlbWVudC5cbiAqXG4gKiBNYWludGFpbnMgYSBjaHJvbm9sb2dpY2FsIGxvZyBvZiBhZ2VudCBhY3Rpb25zIHBlciBzZXNzaW9uLlxuICogRWFjaCBlbnRyeSByZWNvcmRzIHdoYXQgaGFwcGVuZWQsIHdoZXJlLCBhbmQgd2hldGhlciBpdCB3YXMgYWxsb3dlZC5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEFnZW50RXZlbnQsIEFnZW50RXZlbnRUeXBlIH0gZnJvbSAnLi4vdHlwZXMvZXZlbnRzJztcbmltcG9ydCB0eXBlIHsgQWdlbnRDYXBhYmlsaXR5IH0gZnJvbSAnLi4vdHlwZXMvYWdlbnQnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudFNlc3Npb24sIFNlc3Npb25TdW1tYXJ5IH0gZnJvbSAnLi90eXBlcyc7XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSWQoKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKCk7XG59XG5cbi8qKlxuICogQ3JlYXRlIGEgbmV3IHRpbWVsaW5lIGV2ZW50LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVGltZWxpbmVFdmVudChcbiAgdHlwZTogQWdlbnRFdmVudFR5cGUsXG4gIHVybDogc3RyaW5nLFxuICBkZXNjcmlwdGlvbjogc3RyaW5nLFxuICBvcHRpb25zPzoge1xuICAgIHRhcmdldFNlbGVjdG9yPzogc3RyaW5nO1xuICAgIGF0dGVtcHRlZEFjdGlvbj86IEFnZW50Q2FwYWJpbGl0eTtcbiAgICBvdXRjb21lPzogJ2FsbG93ZWQnIHwgJ2Jsb2NrZWQnIHwgJ2luZm9ybWF0aW9uYWwnO1xuICAgIHJ1bGVJZD86IHN0cmluZztcbiAgfVxuKTogQWdlbnRFdmVudCB7XG4gIHJldHVybiB7XG4gICAgaWQ6IGdlbmVyYXRlSWQoKSxcbiAgICB0eXBlLFxuICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHVybCxcbiAgICBkZXNjcmlwdGlvbixcbiAgICBvdXRjb21lOiBvcHRpb25zPy5vdXRjb21lID8/ICdpbmZvcm1hdGlvbmFsJyxcbiAgICB0YXJnZXRTZWxlY3Rvcjogb3B0aW9ucz8udGFyZ2V0U2VsZWN0b3IsXG4gICAgYXR0ZW1wdGVkQWN0aW9uOiBvcHRpb25zPy5hdHRlbXB0ZWRBY3Rpb24sXG4gICAgcnVsZUlkOiBvcHRpb25zPy5ydWxlSWQsXG4gIH07XG59XG5cbi8qKlxuICogQXBwZW5kIGFuIGV2ZW50IHRvIGEgc2Vzc2lvbidzIHRpbWVsaW5lIGFuZCByZWNhbGN1bGF0ZSBzdW1tYXJ5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwZW5kRXZlbnRUb1Nlc3Npb24oXG4gIHNlc3Npb246IEFnZW50U2Vzc2lvbixcbiAgZXZlbnQ6IEFnZW50RXZlbnRcbik6IEFnZW50U2Vzc2lvbiB7XG4gIGNvbnN0IGV2ZW50cyA9IFsuLi5zZXNzaW9uLmV2ZW50cywgZXZlbnRdO1xuICBjb25zdCBzdW1tYXJ5ID0gY29tcHV0ZVNlc3Npb25TdW1tYXJ5KGV2ZW50cywgc2Vzc2lvbi5zdGFydGVkQXQpO1xuICByZXR1cm4geyAuLi5zZXNzaW9uLCBldmVudHMsIHN1bW1hcnkgfTtcbn1cblxuLyoqXG4gKiBDb21wdXRlIHN1bW1hcnkgc3RhdGlzdGljcyBmcm9tIGEgc2Vzc2lvbidzIGV2ZW50IHRpbWVsaW5lLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY29tcHV0ZVNlc3Npb25TdW1tYXJ5KFxuICBldmVudHM6IEFnZW50RXZlbnRbXSxcbiAgc3RhcnRlZEF0OiBzdHJpbmdcbik6IFNlc3Npb25TdW1tYXJ5IHtcbiAgbGV0IHRvdGFsQWN0aW9ucyA9IDA7XG4gIGxldCBhbGxvd2VkQWN0aW9ucyA9IDA7XG4gIGxldCBibG9ja2VkQWN0aW9ucyA9IDA7XG4gIGxldCB2aW9sYXRpb25zID0gMDtcbiAgY29uc3QgdXJsQ291bnRzID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKTtcblxuICBmb3IgKGNvbnN0IGV2ZW50IG9mIGV2ZW50cykge1xuICAgIGlmIChldmVudC5vdXRjb21lID09PSAnYWxsb3dlZCcpIHtcbiAgICAgIHRvdGFsQWN0aW9ucysrO1xuICAgICAgYWxsb3dlZEFjdGlvbnMrKztcbiAgICB9IGVsc2UgaWYgKGV2ZW50Lm91dGNvbWUgPT09ICdibG9ja2VkJykge1xuICAgICAgdG90YWxBY3Rpb25zKys7XG4gICAgICBibG9ja2VkQWN0aW9ucysrO1xuICAgIH1cbiAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ2JvdW5kYXJ5LXZpb2xhdGlvbicpIHtcbiAgICAgIHZpb2xhdGlvbnMrKztcbiAgICB9XG4gICAgaWYgKGV2ZW50LnVybCkge1xuICAgICAgdXJsQ291bnRzLnNldChldmVudC51cmwsICh1cmxDb3VudHMuZ2V0KGV2ZW50LnVybCkgPz8gMCkgKyAxKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCB0b3BVcmxzID0gWy4uLnVybENvdW50cy5lbnRyaWVzKCldXG4gICAgLnNvcnQoKGEsIGIpID0+IGJbMV0gLSBhWzFdKVxuICAgIC5zbGljZSgwLCA1KVxuICAgIC5tYXAoKFt1cmxdKSA9PiB1cmwpO1xuXG4gIGxldCBkdXJhdGlvblNlY29uZHM6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICBpZiAoZXZlbnRzLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBsYXN0RXZlbnQgPSBldmVudHNbZXZlbnRzLmxlbmd0aCAtIDFdO1xuICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoc3RhcnRlZEF0KS5nZXRUaW1lKCk7XG4gICAgY29uc3QgZW5kID0gbmV3IERhdGUobGFzdEV2ZW50LnRpbWVzdGFtcCkuZ2V0VGltZSgpO1xuICAgIGR1cmF0aW9uU2Vjb25kcyA9IE1hdGgucm91bmQoKGVuZCAtIHN0YXJ0KSAvIDEwMDApO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICB0b3RhbEFjdGlvbnMsXG4gICAgYWxsb3dlZEFjdGlvbnMsXG4gICAgYmxvY2tlZEFjdGlvbnMsXG4gICAgdmlvbGF0aW9ucyxcbiAgICB0b3BVcmxzLFxuICAgIGR1cmF0aW9uU2Vjb25kcyxcbiAgfTtcbn1cblxuLyoqXG4gKiBGaWx0ZXIgdGltZWxpbmUgZXZlbnRzIGJ5IHR5cGUsIFVSTCwgb3Igb3V0Y29tZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlclRpbWVsaW5lRXZlbnRzKFxuICBldmVudHM6IEFnZW50RXZlbnRbXSxcbiAgZmlsdGVyczoge1xuICAgIHR5cGU/OiBBZ2VudEV2ZW50VHlwZTtcbiAgICB1cmw/OiBzdHJpbmc7XG4gICAgb3V0Y29tZT86ICdhbGxvd2VkJyB8ICdibG9ja2VkJyB8ICdpbmZvcm1hdGlvbmFsJztcbiAgfVxuKTogQWdlbnRFdmVudFtdIHtcbiAgcmV0dXJuIGV2ZW50cy5maWx0ZXIoKGV2ZW50KSA9PiB7XG4gICAgaWYgKGZpbHRlcnMudHlwZSAhPT0gdW5kZWZpbmVkICYmIGV2ZW50LnR5cGUgIT09IGZpbHRlcnMudHlwZSkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChmaWx0ZXJzLnVybCAhPT0gdW5kZWZpbmVkICYmIGV2ZW50LnVybCAhPT0gZmlsdGVycy51cmwpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoZmlsdGVycy5vdXRjb21lICE9PSB1bmRlZmluZWQgJiYgZXZlbnQub3V0Y29tZSAhPT0gZmlsdGVycy5vdXRjb21lKSByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xufVxuXG4vKipcbiAqIEdldCB0aGUgbW9zdCByZWNlbnQgTiBldmVudHMsIG5ld2VzdCBmaXJzdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFJlY2VudEV2ZW50cyhldmVudHM6IEFnZW50RXZlbnRbXSwgY291bnQ6IG51bWJlcik6IEFnZW50RXZlbnRbXSB7XG4gIHJldHVybiBldmVudHMuc2xpY2UoLWNvdW50KS5yZXZlcnNlKCk7XG59XG4iLCIvKipcbiAqIENhcGFiaWxpdHkgYm91bmRhcnkgbW9uaXRvci5cbiAqXG4gKiBUcmFja3Mgd2hhdCBhbiBhZ2VudCBkb2VzIHZzLiB3aGF0IGl0IGlzIGFsbG93ZWQgdG8gZG8gdW5kZXIgdGhlXG4gKiBhY3RpdmUgZGVsZWdhdGlvbiBydWxlcy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEFnZW50Q2FwYWJpbGl0eSB9IGZyb20gJy4uL3R5cGVzL2FnZW50JztcbmltcG9ydCB0eXBlIHsgQWdlbnRFdmVudCwgQm91bmRhcnlWaW9sYXRpb24gfSBmcm9tICcuLi90eXBlcy9ldmVudHMnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uUnVsZSB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHsgZXZhbHVhdGVSdWxlLCBpc1RpbWVCb3VuZEV4cGlyZWQgfSBmcm9tICcuLi9kZWxlZ2F0aW9uL3J1bGVzJztcbmltcG9ydCB7IGNyZWF0ZVRpbWVsaW5lRXZlbnQgfSBmcm9tICcuLi9zZXNzaW9uL3RpbWVsaW5lJztcblxuZXhwb3J0IGludGVyZmFjZSBNb25pdG9yU3RhdGUge1xuICBhY3RpdmVSdWxlOiBEZWxlZ2F0aW9uUnVsZSB8IG51bGw7XG4gIGlzTW9uaXRvcmluZzogYm9vbGVhbjtcbiAgYWxsb3dlZENvdW50OiBudW1iZXI7XG4gIGJsb2NrZWRDb3VudDogbnVtYmVyO1xuICByZWNlbnRWaW9sYXRpb25zOiBCb3VuZGFyeVZpb2xhdGlvbltdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJvdW5kYXJ5Q2hlY2tSZXN1bHQge1xuICBhbGxvd2VkOiBib29sZWFuO1xuICBtYXRjaGVkUnVsZTogRGVsZWdhdGlvblJ1bGUgfCBudWxsO1xuICByZWFzb246IHN0cmluZztcbiAgbWF0Y2hEZXRhaWw/OiBzdHJpbmc7XG59XG5cbmxldCBtb25pdG9yU3RhdGU6IE1vbml0b3JTdGF0ZSA9IHtcbiAgYWN0aXZlUnVsZTogbnVsbCxcbiAgaXNNb25pdG9yaW5nOiBmYWxzZSxcbiAgYWxsb3dlZENvdW50OiAwLFxuICBibG9ja2VkQ291bnQ6IDAsXG4gIHJlY2VudFZpb2xhdGlvbnM6IFtdLFxufTtcblxuLyoqXG4gKiBDaGVjayB3aGV0aGVyIGFuIGFnZW50IGFjdGlvbiBpcyBwZXJtaXR0ZWQgdW5kZXIgZGVsZWdhdGlvbiBydWxlcy5cbiAqIEZhaWwtY2xvc2VkOiBubyBydWxlID0gYmxvY2tlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrQm91bmRhcnkoXG4gIGFjdGlvbjogQWdlbnRDYXBhYmlsaXR5LFxuICB1cmw6IHN0cmluZyxcbiAgcnVsZTogRGVsZWdhdGlvblJ1bGUgfCBudWxsXG4pOiBCb3VuZGFyeUNoZWNrUmVzdWx0IHtcbiAgaWYgKCFydWxlKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFsbG93ZWQ6IGZhbHNlLFxuICAgICAgbWF0Y2hlZFJ1bGU6IG51bGwsXG4gICAgICByZWFzb246ICdObyBhY3RpdmUgZGVsZWdhdGlvbiBydWxlLiBBbGwgYWN0aW9ucyBhcmUgYmxvY2tlZCBieSBkZWZhdWx0LicsXG4gICAgfTtcbiAgfVxuXG4gIGlmICghcnVsZS5pc0FjdGl2ZSkge1xuICAgIHJldHVybiB7XG4gICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgIG1hdGNoZWRSdWxlOiBydWxlLFxuICAgICAgcmVhc29uOiAnRGVsZWdhdGlvbiBydWxlIGlzIG5vIGxvbmdlciBhY3RpdmUuJyxcbiAgICB9O1xuICB9XG5cbiAgaWYgKGlzRGVsZWdhdGlvbkV4cGlyZWQocnVsZSkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgYWxsb3dlZDogZmFsc2UsXG4gICAgICBtYXRjaGVkUnVsZTogcnVsZSxcbiAgICAgIHJlYXNvbjogJ0RlbGVnYXRpb24gaGFzIGV4cGlyZWQuJyxcbiAgICB9O1xuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gZXZhbHVhdGVSdWxlKHJ1bGUsIGFjdGlvbiwgdXJsKTtcbiAgcmV0dXJuIHtcbiAgICBhbGxvd2VkOiByZXN1bHQuYWxsb3dlZCxcbiAgICBtYXRjaGVkUnVsZTogcnVsZSxcbiAgICByZWFzb246IHJlc3VsdC5yZWFzb24sXG4gIH07XG59XG5cbi8qKlxuICogTWF0Y2ggYSBVUkwgYWdhaW5zdCBhIHNpdGUgcGF0dGVybiB1c2luZyBnbG9iLXN0eWxlIG1hdGNoaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0Y2hTaXRlUGF0dGVybih1cmw6IHN0cmluZywgcGF0dGVybjogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHRyeSB7XG4gICAgaWYgKCFwYXR0ZXJuLmluY2x1ZGVzKCc6Ly8nKSkge1xuICAgICAgY29uc3QgcGFyc2VkVXJsID0gbmV3IFVSTCh1cmwpO1xuICAgICAgY29uc3QgaG9zdG5hbWUgPSBwYXJzZWRVcmwuaG9zdG5hbWU7XG4gICAgICBjb25zdCByZWdleFN0ciA9IHBhdHRlcm5cbiAgICAgICAgLnJlcGxhY2UoL1xcLi9nLCAnXFxcXC4nKVxuICAgICAgICAucmVwbGFjZSgvXFwqXFwqL2csICdcXHgwMCcpXG4gICAgICAgIC5yZXBsYWNlKC9cXCovZywgJ1teLl0qJylcbiAgICAgICAgLnJlcGxhY2UoL1xceDAwL2csICcuKicpO1xuICAgICAgcmV0dXJuIG5ldyBSZWdFeHAoYF4ke3JlZ2V4U3RyfSRgKS50ZXN0KGhvc3RuYW1lKTtcbiAgICB9XG4gICAgY29uc3QgcmVnZXhTdHIgPSBwYXR0ZXJuXG4gICAgICAucmVwbGFjZSgvWy4rXiR7fSgpfFtcXF1cXFxcXS9nLCAnXFxcXCQmJylcbiAgICAgIC5yZXBsYWNlKC9cXFxcXFwqL2csICcuKicpO1xuICAgIHJldHVybiBuZXcgUmVnRXhwKGBeJHtyZWdleFN0cn0kYCkudGVzdCh1cmwpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gbWFwRXZlbnRUb0NhcGFiaWxpdHkoZXZlbnRUeXBlOiBzdHJpbmcpOiBBZ2VudENhcGFiaWxpdHkgfCBudWxsIHtcbiAgc3dpdGNoIChldmVudFR5cGUpIHtcbiAgICBjYXNlICdjbGljayc6IHJldHVybiAnY2xpY2snO1xuICAgIGNhc2UgJ2lucHV0JzogcmV0dXJuICd0eXBlLXRleHQnO1xuICAgIGNhc2UgJ3N1Ym1pdCc6IHJldHVybiAnc3VibWl0LWZvcm0nO1xuICAgIGNhc2UgJ2tleWRvd24nOiByZXR1cm4gJ3R5cGUtdGV4dCc7XG4gICAgZGVmYXVsdDogcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0U2VsZWN0b3IoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwuaWQpIHJldHVybiBgIyR7ZWwuaWR9YDtcbiAgaWYgKGVsLmNsYXNzTmFtZSAmJiB0eXBlb2YgZWwuY2xhc3NOYW1lID09PSAnc3RyaW5nJykge1xuICAgIGNvbnN0IGNsYXNzZXMgPSBlbC5jbGFzc05hbWUudHJpbSgpLnNwbGl0KC9cXHMrLykuc2xpY2UoMCwgMikuam9pbignLicpO1xuICAgIGlmIChjbGFzc2VzKSByZXR1cm4gYCR7ZWwudGFnTmFtZS50b0xvd2VyQ2FzZSgpfS4ke2NsYXNzZXN9YDtcbiAgfVxuICByZXR1cm4gZWwudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xufVxuXG4vKipcbiAqIFN0YXJ0IG1vbml0b3JpbmcgYWdlbnQgYWN0aW9ucyBpbiB0aGUgY3VycmVudCBwYWdlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RhcnRCb3VuZGFyeU1vbml0b3IoXG4gIHJ1bGU6IERlbGVnYXRpb25SdWxlIHwgbnVsbCxcbiAgb25WaW9sYXRpb246ICh2aW9sYXRpb246IEJvdW5kYXJ5VmlvbGF0aW9uKSA9PiB2b2lkLFxuICBvbkFjdGlvbjogKGV2ZW50OiBBZ2VudEV2ZW50KSA9PiB2b2lkXG4pOiAoKSA9PiB2b2lkIHtcbiAgbW9uaXRvclN0YXRlID0ge1xuICAgIGFjdGl2ZVJ1bGU6IHJ1bGUsXG4gICAgaXNNb25pdG9yaW5nOiB0cnVlLFxuICAgIGFsbG93ZWRDb3VudDogMCxcbiAgICBibG9ja2VkQ291bnQ6IDAsXG4gICAgcmVjZW50VmlvbGF0aW9uczogW10sXG4gIH07XG5cbiAgY29uc3QgY2xlYW51cHM6IEFycmF5PCgpID0+IHZvaWQ+ID0gW107XG5cbiAgLy8gSW50ZXJjZXB0IHVzZXIgaW50ZXJhY3Rpb24gZXZlbnRzXG4gIGNvbnN0IGludGVyY2VwdGlvbkhhbmRsZXIgPSAoZTogRXZlbnQpID0+IHtcbiAgICBpZiAoIW1vbml0b3JTdGF0ZS5pc01vbml0b3JpbmcpIHJldHVybjtcbiAgICBpZiAoZS5pc1RydXN0ZWQpIHJldHVybjsgLy8gT25seSBpbnRlcmNlcHQgc3ludGhldGljL3VudHJ1c3RlZCBldmVudHMgZnJvbSBhZ2VudHNcblxuICAgIGNvbnN0IGNhcGFiaWxpdHkgPSBtYXBFdmVudFRvQ2FwYWJpbGl0eShlLnR5cGUpO1xuICAgIGlmICghY2FwYWJpbGl0eSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdGFyZ2V0ID0gZS50YXJnZXQgYXMgRWxlbWVudDtcbiAgICBjb25zdCBzZWxlY3RvciA9IHRhcmdldCA/IGdldFNlbGVjdG9yKHRhcmdldCkgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgdXJsID0gd2luZG93LmxvY2F0aW9uLmhyZWY7XG5cbiAgICBjb25zdCByZXN1bHQgPSBjaGVja0JvdW5kYXJ5KGNhcGFiaWxpdHksIHVybCwgbW9uaXRvclN0YXRlLmFjdGl2ZVJ1bGUpO1xuXG4gICAgaWYgKHJlc3VsdC5hbGxvd2VkKSB7XG4gICAgICBtb25pdG9yU3RhdGUuYWxsb3dlZENvdW50Kys7XG4gICAgICBjb25zdCBldmVudCA9IGNyZWF0ZVRpbWVsaW5lRXZlbnQoJ2FjdGlvbi1hbGxvd2VkJywgdXJsLCBgJHtjYXBhYmlsaXR5fSBhbGxvd2VkYCwge1xuICAgICAgICB0YXJnZXRTZWxlY3Rvcjogc2VsZWN0b3IsXG4gICAgICAgIGF0dGVtcHRlZEFjdGlvbjogY2FwYWJpbGl0eSxcbiAgICAgICAgb3V0Y29tZTogJ2FsbG93ZWQnLFxuICAgICAgICBydWxlSWQ6IG1vbml0b3JTdGF0ZS5hY3RpdmVSdWxlPy5pZCxcbiAgICAgIH0pO1xuICAgICAgb25BY3Rpb24oZXZlbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBtb25pdG9yU3RhdGUuYmxvY2tlZENvdW50Kys7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgICBjb25zdCB2aW9sYXRpb246IEJvdW5kYXJ5VmlvbGF0aW9uID0ge1xuICAgICAgICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGFnZW50SWQ6ICcnLFxuICAgICAgICBhdHRlbXB0ZWRBY3Rpb246IGNhcGFiaWxpdHksXG4gICAgICAgIHVybCxcbiAgICAgICAgdGFyZ2V0U2VsZWN0b3I6IHNlbGVjdG9yLFxuICAgICAgICBibG9ja2luZ1J1bGVJZDogbW9uaXRvclN0YXRlLmFjdGl2ZVJ1bGU/LmlkID8/ICdub25lJyxcbiAgICAgICAgcmVhc29uOiByZXN1bHQucmVhc29uLFxuICAgICAgICB1c2VyT3ZlcnJpZGU6IGZhbHNlLFxuICAgICAgfTtcbiAgICAgIG1vbml0b3JTdGF0ZS5yZWNlbnRWaW9sYXRpb25zLnB1c2godmlvbGF0aW9uKTtcbiAgICAgIGlmIChtb25pdG9yU3RhdGUucmVjZW50VmlvbGF0aW9ucy5sZW5ndGggPiA1MCkge1xuICAgICAgICBtb25pdG9yU3RhdGUucmVjZW50VmlvbGF0aW9ucy5zaGlmdCgpO1xuICAgICAgfVxuICAgICAgb25WaW9sYXRpb24odmlvbGF0aW9uKTtcblxuICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVUaW1lbGluZUV2ZW50KCdhY3Rpb24tYmxvY2tlZCcsIHVybCwgYCR7Y2FwYWJpbGl0eX0gYmxvY2tlZDogJHtyZXN1bHQucmVhc29ufWAsIHtcbiAgICAgICAgdGFyZ2V0U2VsZWN0b3I6IHNlbGVjdG9yLFxuICAgICAgICBhdHRlbXB0ZWRBY3Rpb246IGNhcGFiaWxpdHksXG4gICAgICAgIG91dGNvbWU6ICdibG9ja2VkJyxcbiAgICAgICAgcnVsZUlkOiBtb25pdG9yU3RhdGUuYWN0aXZlUnVsZT8uaWQsXG4gICAgICB9KTtcbiAgICAgIG9uQWN0aW9uKGV2ZW50KTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgZXZlbnRUeXBlcyA9IFsnY2xpY2snLCAnaW5wdXQnLCAnc3VibWl0JywgJ2tleWRvd24nXTtcbiAgZm9yIChjb25zdCB0eXBlIG9mIGV2ZW50VHlwZXMpIHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGludGVyY2VwdGlvbkhhbmRsZXIsIHsgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgfVxuICBjbGVhbnVwcy5wdXNoKCgpID0+IHtcbiAgICBmb3IgKGNvbnN0IHR5cGUgb2YgZXZlbnRUeXBlcykge1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlLCBpbnRlcmNlcHRpb25IYW5kbGVyLCB7IGNhcHR1cmU6IHRydWUgfSk7XG4gICAgfVxuICB9KTtcblxuICAvLyBNdXRhdGlvbk9ic2VydmVyIGZvciBET00gbW9kaWZpY2F0aW9uc1xuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKChtdXRhdGlvbnMpID0+IHtcbiAgICBpZiAoIW1vbml0b3JTdGF0ZS5pc01vbml0b3JpbmcpIHJldHVybjtcblxuICAgIGZvciAoY29uc3QgbXV0YXRpb24gb2YgbXV0YXRpb25zKSB7XG4gICAgICBpZiAobXV0YXRpb24udHlwZSA9PT0gJ2NoaWxkTGlzdCcgJiYgKG11dGF0aW9uLmFkZGVkTm9kZXMubGVuZ3RoID4gMCB8fCBtdXRhdGlvbi5yZW1vdmVkTm9kZXMubGVuZ3RoID4gMCkpIHtcbiAgICAgICAgY29uc3QgdXJsID0gd2luZG93LmxvY2F0aW9uLmhyZWY7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGNoZWNrQm91bmRhcnkoJ21vZGlmeS1kb20nLCB1cmwsIG1vbml0b3JTdGF0ZS5hY3RpdmVSdWxlKTtcblxuICAgICAgICBpZiAoIXJlc3VsdC5hbGxvd2VkKSB7XG4gICAgICAgICAgY29uc3QgdGFyZ2V0ID0gbXV0YXRpb24udGFyZ2V0IGFzIEVsZW1lbnQ7XG4gICAgICAgICAgY29uc3QgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvbiA9IHtcbiAgICAgICAgICAgIGlkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgICBhZ2VudElkOiAnJyxcbiAgICAgICAgICAgIGF0dGVtcHRlZEFjdGlvbjogJ21vZGlmeS1kb20nLFxuICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgdGFyZ2V0U2VsZWN0b3I6IHRhcmdldD8ubm9kZVR5cGUgPT09IDEgPyBnZXRTZWxlY3Rvcih0YXJnZXQpIDogJ2RvY3VtZW50JyxcbiAgICAgICAgICAgIGJsb2NraW5nUnVsZUlkOiBtb25pdG9yU3RhdGUuYWN0aXZlUnVsZT8uaWQgPz8gJ25vbmUnLFxuICAgICAgICAgICAgcmVhc29uOiByZXN1bHQucmVhc29uLFxuICAgICAgICAgICAgdXNlck92ZXJyaWRlOiBmYWxzZSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIG9uVmlvbGF0aW9uKHZpb2xhdGlvbik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gIGlmIChkb2N1bWVudC5ib2R5KSB7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5ib2R5LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgfVxuICBjbGVhbnVwcy5wdXNoKCgpID0+IG9ic2VydmVyLmRpc2Nvbm5lY3QoKSk7XG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBtb25pdG9yU3RhdGUuaXNNb25pdG9yaW5nID0gZmFsc2U7XG4gICAgZm9yIChjb25zdCBjbGVhbnVwIG9mIGNsZWFudXBzKSB7XG4gICAgICB0cnkgeyBjbGVhbnVwKCk7IH0gY2F0Y2ggeyAvKiBpZ25vcmUgKi8gfVxuICAgIH1cbiAgfTtcbn1cblxuLyoqXG4gKiBVcGRhdGUgdGhlIGFjdGl2ZSBkZWxlZ2F0aW9uIHJ1bGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVBY3RpdmVSdWxlKHJ1bGU6IERlbGVnYXRpb25SdWxlIHwgbnVsbCk6IHZvaWQge1xuICBtb25pdG9yU3RhdGUuYWN0aXZlUnVsZSA9IHJ1bGU7XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgdGhlIGN1cnJlbnQgZGVsZWdhdGlvbiBoYXMgZXhwaXJlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzRGVsZWdhdGlvbkV4cGlyZWQocnVsZTogRGVsZWdhdGlvblJ1bGUpOiBib29sZWFuIHtcbiAgcmV0dXJuIGlzVGltZUJvdW5kRXhwaXJlZChydWxlLnNjb3BlLnRpbWVCb3VuZCk7XG59XG5cbi8qKlxuICogR2V0IHRoZSBjdXJyZW50IG1vbml0b3Igc3RhdGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRNb25pdG9yU3RhdGUoKTogTW9uaXRvclN0YXRlIHtcbiAgcmV0dXJuIHsgLi4ubW9uaXRvclN0YXRlIH07XG59XG4iLCIvKipcbiAqIEVtZXJnZW5jeSBraWxsIHN3aXRjaCBtb2R1bGUuXG4gKlxuICogUHJvdmlkZXMgb25lLWNsaWNrIHJldm9jYXRpb24gb2YgYWxsIGFnZW50IGFjY2Vzcy5cbiAqL1xuXG5pbXBvcnQgdHlwZSB7IEtpbGxTd2l0Y2hFdmVudCB9IGZyb20gJy4uL3R5cGVzL2V2ZW50cyc7XG5pbXBvcnQgdHlwZSB7IERlbGVnYXRpb25Ub2tlbiB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuaW1wb3J0IHsgcmV2b2tlVG9rZW4gfSBmcm9tICcuLi9kZWxlZ2F0aW9uL3J1bGVzJztcblxuZXhwb3J0IGludGVyZmFjZSBLaWxsU3dpdGNoU3RhdGUge1xuICBpc0FjdGl2ZTogYm9vbGVhbjtcbiAgbGFzdEV2ZW50OiBLaWxsU3dpdGNoRXZlbnQgfCBudWxsO1xuICBsYXN0QWN0aXZhdGVkQXQ6IHN0cmluZyB8IG51bGw7XG59XG5cbi8vIFRyYWNrIGNsZWFudXAgZnVuY3Rpb25zIHJlZ2lzdGVyZWQgYnkgY29udGVudC1zaWRlIG1vZHVsZXNcbmNvbnN0IHJlZ2lzdGVyZWRDbGVhbnVwczogQXJyYXk8KCkgPT4gdm9pZD4gPSBbXTtcblxuLyoqXG4gKiBSZWdpc3RlciBhIGNsZWFudXAgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIGR1cmluZyBraWxsIHN3aXRjaCBleGVjdXRpb24uXG4gKiBVc2VkIGJ5IGRldGVjdG9yIGFuZCBtb25pdG9yIG1vZHVsZXMgdG8gcmVnaXN0ZXIgdGhlaXIgdGVhcmRvd24gbG9naWMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3RlckNsZWFudXAoY2xlYW51cDogKCkgPT4gdm9pZCk6IHZvaWQge1xuICByZWdpc3RlcmVkQ2xlYW51cHMucHVzaChjbGVhbnVwKTtcbn1cblxuLyoqXG4gKiBFeGVjdXRlIHRoZSBraWxsIHN3aXRjaCBmcm9tIHRoZSBjb250ZW50IHNjcmlwdCBzaWRlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXhlY3V0ZUNvbnRlbnRLaWxsU3dpdGNoKCk6IHtcbiAgbGlzdGVuZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBvYnNlcnZlcnNEaXNjb25uZWN0ZWQ6IG51bWJlcjtcbiAgYmluZGluZ3NDbGVhcmVkOiBzdHJpbmdbXTtcbn0ge1xuICBsZXQgbGlzdGVuZXJzUmVtb3ZlZCA9IDA7XG4gIGxldCBvYnNlcnZlcnNEaXNjb25uZWN0ZWQgPSAwO1xuXG4gIC8vIENhbGwgYWxsIHJlZ2lzdGVyZWQgY2xlYW51cCBmdW5jdGlvbnNcbiAgZm9yIChjb25zdCBjbGVhbnVwIG9mIHJlZ2lzdGVyZWRDbGVhbnVwcykge1xuICAgIHRyeSB7XG4gICAgICBjbGVhbnVwKCk7XG4gICAgICBsaXN0ZW5lcnNSZW1vdmVkKys7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBCZXN0IGVmZm9ydFxuICAgIH1cbiAgfVxuICByZWdpc3RlcmVkQ2xlYW51cHMubGVuZ3RoID0gMDtcblxuICAvLyBDbGVhciBhdXRvbWF0aW9uIGJpbmRpbmdzXG4gIGNvbnN0IGJpbmRpbmdzQ2xlYXJlZCA9IGNsZWFyQXV0b21hdGlvbkZsYWdzKCk7XG5cbiAgLy8gQXR0ZW1wdCBDRFAgdGVybWluYXRpb25cbiAgdGVybWluYXRlQ2RwQ29ubmVjdGlvbnMoKTtcblxuICByZXR1cm4geyBsaXN0ZW5lcnNSZW1vdmVkLCBvYnNlcnZlcnNEaXNjb25uZWN0ZWQsIGJpbmRpbmdzQ2xlYXJlZCB9O1xufVxuXG4vKipcbiAqIEV4ZWN1dGUgdGhlIGtpbGwgc3dpdGNoIGZyb20gdGhlIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgc2lkZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVCYWNrZ3JvdW5kS2lsbFN3aXRjaChcbiAgdHJpZ2dlcjogJ2J1dHRvbicgfCAna2V5Ym9hcmQtc2hvcnRjdXQnIHwgJ2FwaScsXG4gIGFjdGl2ZUFnZW50SWRzOiBzdHJpbmdbXSxcbiAgYWN0aXZlVG9rZW5zOiBEZWxlZ2F0aW9uVG9rZW5bXVxuKTogUHJvbWlzZTxLaWxsU3dpdGNoRXZlbnQ+IHtcbiAgY29uc3QgcmV2b2tlZFRva2VuSWRzOiBzdHJpbmdbXSA9IFtdO1xuXG4gIC8vIFJldm9rZSBhbGwgdG9rZW5zXG4gIGZvciAoY29uc3QgdG9rZW4gb2YgYWN0aXZlVG9rZW5zKSB7XG4gICAgcmV2b2tlVG9rZW4odG9rZW4pO1xuICAgIHJldm9rZWRUb2tlbklkcy5wdXNoKHRva2VuLnRva2VuSWQpO1xuICB9XG5cbiAgLy8gU2VuZCBraWxsIGNvbW1hbmQgdG8gYWxsIHRhYnNcbiAgbGV0IGNkcFRlcm1pbmF0ZWQgPSBmYWxzZTtcbiAgbGV0IGF1dG9tYXRpb25GbGFnc0NsZWFyZWQgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgY2hyb21lLnRhYnMucXVlcnkoe30pO1xuICAgIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICAgIGlmICh0YWIuaWQgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcbiAgICAgICAgICB0eXBlOiAnS0lMTF9TV0lUQ0hfQUNUSVZBVEUnLFxuICAgICAgICAgIGRhdGE6IHt9LFxuICAgICAgICAgIHNlbnRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBUYWIgbWF5IG5vdCBoYXZlIGNvbnRlbnQgc2NyaXB0XG4gICAgICB9XG4gICAgfVxuICAgIGNkcFRlcm1pbmF0ZWQgPSB0cnVlO1xuICAgIGF1dG9tYXRpb25GbGFnc0NsZWFyZWQgPSB0cnVlO1xuICB9IGNhdGNoIHtcbiAgICAvLyBCZXN0IGVmZm9ydFxuICB9XG5cbiAgY29uc3QgZXZlbnQ6IEtpbGxTd2l0Y2hFdmVudCA9IHtcbiAgICBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB0cmlnZ2VyLFxuICAgIHRlcm1pbmF0ZWRBZ2VudElkczogWy4uLmFjdGl2ZUFnZW50SWRzXSxcbiAgICByZXZva2VkVG9rZW5JZHMsXG4gICAgY2RwVGVybWluYXRlZCxcbiAgICBhdXRvbWF0aW9uRmxhZ3NDbGVhcmVkLFxuICB9O1xuXG4gIC8vIFNob3cgbm90aWZpY2F0aW9uXG4gIHNob3dLaWxsU3dpdGNoTm90aWZpY2F0aW9uKGFjdGl2ZUFnZW50SWRzLmxlbmd0aCk7XG5cbiAgcmV0dXJuIGV2ZW50O1xufVxuXG4vKipcbiAqIEF0dGVtcHQgdG8gdGVybWluYXRlIENEUCBjb25uZWN0aW9ucyAoYmVzdC1lZmZvcnQgZnJvbSBjb250ZW50IHNjcmlwdCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0ZXJtaW5hdGVDZHBDb25uZWN0aW9ucygpOiBib29sZWFuIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB3aW5kb3dLZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMod2luZG93KTtcbiAgICBsZXQgZm91bmQgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiB3aW5kb3dLZXlzKSB7XG4gICAgICBpZiAoXG4gICAgICAgIGtleS5zdGFydHNXaXRoKCdfX2NkcF8nKSB8fFxuICAgICAgICBrZXkuc3RhcnRzV2l0aCgnX19jaHJvbWl1bV8nKVxuICAgICAgKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZGVsZXRlICh3aW5kb3cgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilba2V5XTtcbiAgICAgICAgICBmb3VuZCA9IHRydWU7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIFByb3BlcnR5IG1heSBub3QgYmUgZGVsZXRhYmxlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZvdW5kO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBDbGVhciBhdXRvbWF0aW9uIGZsYWdzIGZyb20gdGhlIGN1cnJlbnQgcGFnZSBjb250ZXh0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJBdXRvbWF0aW9uRmxhZ3MoKTogc3RyaW5nW10ge1xuICBjb25zdCBjbGVhcmVkOiBzdHJpbmdbXSA9IFtdO1xuXG4gIC8vIFRyeSB0byBjbGVhciBuYXZpZ2F0b3Iud2ViZHJpdmVyXG4gIHRyeSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG5hdmlnYXRvciwgJ3dlYmRyaXZlcicsIHtcbiAgICAgIGdldDogKCkgPT4gZmFsc2UsXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgfSk7XG4gICAgY2xlYXJlZC5wdXNoKCduYXZpZ2F0b3Iud2ViZHJpdmVyJyk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIE1heSBub3QgYmUgd3JpdGFibGVcbiAgfVxuXG4gIC8vIENsZWFyIFNlbGVuaXVtIG1hcmtlcnNcbiAgY29uc3QgZG9jS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKGRvY3VtZW50KTtcbiAgZm9yIChjb25zdCBrZXkgb2YgZG9jS2V5cykge1xuICAgIGlmIChrZXkuc3RhcnRzV2l0aCgnJGNkY18nKSB8fCBrZXkuc3RhcnRzV2l0aCgnJHdkY18nKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgZGVsZXRlIChkb2N1bWVudCBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtrZXldO1xuICAgICAgICBjbGVhcmVkLnB1c2goa2V5KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBCZXN0IGVmZm9ydFxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIENsZWFyIFBsYXl3cmlnaHQgYW5kIFB1cHBldGVlciBiaW5kaW5nc1xuICBjb25zdCB3aW5kb3dLZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMod2luZG93KTtcbiAgY29uc3QgYXV0b21hdGlvblByZWZpeGVzID0gWydfX3BsYXl3cmlnaHQnLCAnX19wdXBwZXRlZXInLCAnX19wd18nXTtcbiAgZm9yIChjb25zdCBrZXkgb2Ygd2luZG93S2V5cykge1xuICAgIGlmIChhdXRvbWF0aW9uUHJlZml4ZXMuc29tZSgocHJlZml4KSA9PiBrZXkuc3RhcnRzV2l0aChwcmVmaXgpKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgZGVsZXRlICh3aW5kb3cgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilba2V5XTtcbiAgICAgICAgY2xlYXJlZC5wdXNoKGtleSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gQmVzdCBlZmZvcnRcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gY2xlYXJlZDtcbn1cblxuLyoqXG4gKiBTaG93IGEgQ2hyb21lIG5vdGlmaWNhdGlvbiBjb25maXJtaW5nIGtpbGwgc3dpdGNoIGFjdGl2YXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzaG93S2lsbFN3aXRjaE5vdGlmaWNhdGlvbihhZ2VudENvdW50OiBudW1iZXIpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjaHJvbWUubm90aWZpY2F0aW9ucy5jcmVhdGUoYGFiZy1raWxsc3dpdGNoLSR7RGF0ZS5ub3coKX1gLCB7XG4gICAgICB0eXBlOiAnYmFzaWMnLFxuICAgICAgaWNvblVybDogY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKCdpY29ucy9pY29uMTI4LnBuZycpLFxuICAgICAgdGl0bGU6ICdBSSBCcm93c2VyIEd1YXJkIC0gS2lsbCBTd2l0Y2ggQWN0aXZhdGVkJyxcbiAgICAgIG1lc3NhZ2U6IGBUZXJtaW5hdGVkICR7YWdlbnRDb3VudH0gYWdlbnQgc2Vzc2lvbihzKS4gQWxsIGRlbGVnYXRpb25zIHJldm9rZWQuYCxcbiAgICAgIHByaW9yaXR5OiAyLFxuICAgIH0pO1xuXG4gICAgLy8gQXV0by1kaXNtaXNzIGFmdGVyIDUgc2Vjb25kc1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY2hyb21lLm5vdGlmaWNhdGlvbnMuZ2V0QWxsKChub3RpZmljYXRpb25zKSA9PiB7XG4gICAgICAgICAgZm9yIChjb25zdCBpZCBvZiBPYmplY3Qua2V5cyhub3RpZmljYXRpb25zKSkge1xuICAgICAgICAgICAgaWYgKGlkLnN0YXJ0c1dpdGgoJ2FiZy1raWxsc3dpdGNoLScpKSB7XG4gICAgICAgICAgICAgIGNocm9tZS5ub3RpZmljYXRpb25zLmNsZWFyKGlkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIElnbm9yZVxuICAgICAgfVxuICAgIH0sIDUwMDApO1xuICB9IGNhdGNoIHtcbiAgICAvLyBOb3RpZmljYXRpb25zIG1heSBub3QgYmUgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0IGNvbnRleHRcbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZSB0aGUgaW5pdGlhbCBraWxsIHN3aXRjaCBzdGF0ZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxLaWxsU3dpdGNoU3RhdGUoKTogS2lsbFN3aXRjaFN0YXRlIHtcbiAgcmV0dXJuIHtcbiAgICBpc0FjdGl2ZTogZmFsc2UsXG4gICAgbGFzdEV2ZW50OiBudWxsLFxuICAgIGxhc3RBY3RpdmF0ZWRBdDogbnVsbCxcbiAgfTtcbn1cbiIsIi8qKlxuICogQ29udGVudCBzY3JpcHQgZW50cnkgcG9pbnQuXG4gKlxuICogSW5qZWN0ZWQgaW50byBldmVyeSBwYWdlIGF0IGRvY3VtZW50X3N0YXJ0LiBJbml0aWFsaXplcyB0aGUgZGV0ZWN0aW9uXG4gKiBlbmdpbmUgYW5kIGJvdW5kYXJ5IG1vbml0b3IsIHRoZW4gcmVsYXlzIHJlc3VsdHMgdG8gdGhlIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLlxuICovXG5cbmltcG9ydCB0eXBlIHsgTWVzc2FnZVBheWxvYWQsIE1lc3NhZ2VUeXBlLCBCb3VuZGFyeVZpb2xhdGlvbiB9IGZyb20gJy4uL3R5cGVzL2V2ZW50cyc7XG5pbXBvcnQgeyBzdGFydERldGVjdGlvbk1vbml0b3IgfSBmcm9tICcuL2RldGVjdG9yJztcbmltcG9ydCB0eXBlIHsgRGV0ZWN0aW9uVmVyZGljdFJlc3VsdCB9IGZyb20gJy4vZGV0ZWN0b3InO1xuaW1wb3J0IHsgc3RhcnRCb3VuZGFyeU1vbml0b3IsIHVwZGF0ZUFjdGl2ZVJ1bGUsIGdldE1vbml0b3JTdGF0ZSB9IGZyb20gJy4vbW9uaXRvcic7XG5pbXBvcnQgeyBleGVjdXRlQ29udGVudEtpbGxTd2l0Y2gsIHJlZ2lzdGVyQ2xlYW51cCB9IGZyb20gJy4uL2tpbGxzd2l0Y2gvaW5kZXgnO1xuaW1wb3J0IHR5cGUgeyBEZWxlZ2F0aW9uUnVsZSB9IGZyb20gJy4uL3R5cGVzL2RlbGVnYXRpb24nO1xuXG5jb25zdCBHVUFSRF9OT05DRSA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG5jb25zdCBNU0dfSU5JVCA9ICdBSV9HVUFSRDpJTklUJztcbmNvbnN0IE1TR19SVUxFX1VQREFURSA9ICdBSV9HVUFSRDpSVUxFX1VQREFURSc7XG5jb25zdCBNU0dfQUNUSU9OID0gJ0FJX0dVQVJEOkFDVElPTic7XG5jb25zdCBNU0dfQUxMT1dfT05DRSA9ICdBSV9HVUFSRDpBTExPV19PTkNFJztcblxubGV0IGRldGVjdGlvbkNsZWFudXA6ICgoKSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xubGV0IG1vbml0b3JDbGVhbnVwOiAoKCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcbmxldCBjdXJyZW50QWdlbnRJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbi8qKiBTZW5kIHRoZSBjdXJyZW50IGRlbGVnYXRpb24gcnVsZSB0byB0aGUgTUFJTiB3b3JsZCBpbnRlcmNlcHRvci4gKi9cbmZ1bmN0aW9uIHN5bmNSdWxlVG9NYWluV29ybGQocnVsZTogRGVsZWdhdGlvblJ1bGUgfCBudWxsKTogdm9pZCB7XG4gIGNvbnN0IHJ1bGVEYXRhID0gcnVsZVxuICAgID8ge1xuICAgICAgICBpc0FjdGl2ZTogcnVsZS5pc0FjdGl2ZSxcbiAgICAgICAgZXhwaXJlc0F0OiBydWxlLnNjb3BlLnRpbWVCb3VuZD8uZXhwaXJlc0F0ID8/IG51bGwsXG4gICAgICAgIGFjdGlvblJlc3RyaWN0aW9uczogcnVsZS5zY29wZS5hY3Rpb25SZXN0cmljdGlvbnMubWFwKChyKSA9PiAoe1xuICAgICAgICAgIGNhcGFiaWxpdHk6IHIuY2FwYWJpbGl0eSxcbiAgICAgICAgICBhY3Rpb246IHIuYWN0aW9uLFxuICAgICAgICB9KSksXG4gICAgICAgIHNpdGVQYXR0ZXJuczogcnVsZS5zY29wZS5zaXRlUGF0dGVybnMubWFwKChwKSA9PiAoe1xuICAgICAgICAgIHBhdHRlcm46IHAucGF0dGVybixcbiAgICAgICAgICBhY3Rpb246IHAuYWN0aW9uLFxuICAgICAgICB9KSksXG4gICAgICB9XG4gICAgOiBudWxsO1xuICB3aW5kb3cucG9zdE1lc3NhZ2UoeyB0eXBlOiBNU0dfUlVMRV9VUERBVEUsIG5vbmNlOiBHVUFSRF9OT05DRSwgcnVsZTogcnVsZURhdGEgfSwgJyonKTtcbn1cblxuZnVuY3Rpb24gaW5pdGlhbGl6ZSgpOiB2b2lkIHtcbiAgLy8gSW50cm9kdWNlIG91cnNlbHZlcyB0byB0aGUgTUFJTiB3b3JsZCBpbnRlcmNlcHRvciB3aXRoIG91ciBub25jZVxuICB3aW5kb3cucG9zdE1lc3NhZ2UoeyB0eXBlOiBNU0dfSU5JVCwgbm9uY2U6IEdVQVJEX05PTkNFIH0sICcqJyk7XG5cbiAgLy8gUmVjZWl2ZSBhY3Rpb24gcmVwb3J0cyBmcm9tIHRoZSBNQUlOIHdvcmxkIGludGVyY2VwdG9yXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGU6IE1lc3NhZ2VFdmVudCkgPT4ge1xuICAgIGlmIChlLnNvdXJjZSAhPT0gd2luZG93IHx8ICFlLmRhdGEpIHJldHVybjtcbiAgICBpZiAoZS5kYXRhLnR5cGUgIT09IE1TR19BQ1RJT04pIHJldHVybjtcbiAgICBpZiAoIWUuZGF0YS5ub25jZSB8fCBlLmRhdGEubm9uY2UgIT09IEdVQVJEX05PTkNFKSByZXR1cm47XG5cbiAgICBjb25zdCB7IGNhcGFiaWxpdHksIHVybCwgYmxvY2tlZCwgcmVhc29uLCB0aW1lc3RhbXAgfSA9IGUuZGF0YSBhcyB7XG4gICAgICBjYXBhYmlsaXR5OiBzdHJpbmc7XG4gICAgICB1cmw6IHN0cmluZztcbiAgICAgIGJsb2NrZWQ6IGJvb2xlYW47XG4gICAgICByZWFzb246IHN0cmluZztcbiAgICAgIHRpbWVzdGFtcDogc3RyaW5nO1xuICAgIH07XG5cbiAgICBpZiAoYmxvY2tlZCkge1xuICAgICAgY29uc3QgdmlvbGF0aW9uOiBCb3VuZGFyeVZpb2xhdGlvbiA9IHtcbiAgICAgICAgaWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgIHRpbWVzdGFtcDogdGltZXN0YW1wID8/IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgYWdlbnRJZDogY3VycmVudEFnZW50SWQgPz8gJycsXG4gICAgICAgIGF0dGVtcHRlZEFjdGlvbjogY2FwYWJpbGl0eSBhcyBCb3VuZGFyeVZpb2xhdGlvblsnYXR0ZW1wdGVkQWN0aW9uJ10sXG4gICAgICAgIHVybCxcbiAgICAgICAgdGFyZ2V0U2VsZWN0b3I6IHVuZGVmaW5lZCxcbiAgICAgICAgYmxvY2tpbmdSdWxlSWQ6IGdldE1vbml0b3JTdGF0ZSgpLmFjdGl2ZVJ1bGU/LmlkID8/ICdub25lJyxcbiAgICAgICAgcmVhc29uLFxuICAgICAgICB1c2VyT3ZlcnJpZGU6IGZhbHNlLFxuICAgICAgfTtcbiAgICAgIHNlbmRUb0JhY2tncm91bmQoJ0JPVU5EQVJZX0NIRUNLX1JFUVVFU1QnLCB2aW9sYXRpb24pLmNhdGNoKCgpID0+IHsgLyogaWdub3JlICovIH0pO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gU2V0IHVwIG1lc3NhZ2UgbGlzdGVuZXIgZm9yIGJhY2tncm91bmQgY29tbXVuaWNhdGlvblxuICBjaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoaGFuZGxlTWVzc2FnZSk7XG5cbiAgY29uc3Qgc3RhcnRNb25pdG9yaW5nID0gKCkgPT4ge1xuICAgIC8vIFN0YXJ0IGRldGVjdGlvbiBtb25pdG9yXG4gICAgZGV0ZWN0aW9uQ2xlYW51cCA9IHN0YXJ0RGV0ZWN0aW9uTW9uaXRvcih7fSwgb25EZXRlY3Rpb25SZXN1bHQpO1xuICAgIHJlZ2lzdGVyQ2xlYW51cCgoKSA9PiB7XG4gICAgICBpZiAoZGV0ZWN0aW9uQ2xlYW51cCkgZGV0ZWN0aW9uQ2xlYW51cCgpO1xuICAgIH0pO1xuXG4gICAgLy8gU3RhcnQgYm91bmRhcnkgbW9uaXRvciAobm8gcnVsZSBpbml0aWFsbHkgPSBmYWlsLWNsb3NlZClcbiAgICBtb25pdG9yQ2xlYW51cCA9IHN0YXJ0Qm91bmRhcnlNb25pdG9yKFxuICAgICAgbnVsbCxcbiAgICAgICh2aW9sYXRpb24pID0+IHtcbiAgICAgICAgc2VuZFRvQmFja2dyb3VuZCgnQk9VTkRBUllfQ0hFQ0tfUkVRVUVTVCcsIHZpb2xhdGlvbik7XG4gICAgICB9LFxuICAgICAgKGV2ZW50KSA9PiB7XG4gICAgICAgIHNlbmRUb0JhY2tncm91bmQoJ0FHRU5UX0FDVElPTicsIGV2ZW50KTtcbiAgICAgIH1cbiAgICApO1xuICAgIHJlZ2lzdGVyQ2xlYW51cCgoKSA9PiB7XG4gICAgICBpZiAobW9uaXRvckNsZWFudXApIG1vbml0b3JDbGVhbnVwKCk7XG4gICAgfSk7XG5cbiAgICAvLyBSZXF1ZXN0IGFjdGl2ZSBkZWxlZ2F0aW9uIHJ1bGVzIGZyb20gYmFja2dyb3VuZFxuICAgIHNlbmRUb0JhY2tncm91bmQoJ1NUQVRVU19RVUVSWScsIHt9KS50aGVuKChyZXNwb25zZSkgPT4ge1xuICAgICAgaWYgKHJlc3BvbnNlICYmIHR5cGVvZiByZXNwb25zZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHJlc3BvbnNlIGFzIHsgYWN0aXZlRGVsZWdhdGlvbj86IERlbGVnYXRpb25SdWxlIH07XG4gICAgICAgIGlmIChkYXRhLmFjdGl2ZURlbGVnYXRpb24pIHtcbiAgICAgICAgICB1cGRhdGVBY3RpdmVSdWxlKGRhdGEuYWN0aXZlRGVsZWdhdGlvbik7XG4gICAgICAgICAgc3luY1J1bGVUb01haW5Xb3JsZChkYXRhLmFjdGl2ZURlbGVnYXRpb24pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgLy8gQmFja2dyb3VuZCBtYXkgbm90IGJlIHJlYWR5XG4gICAgfSk7XG4gIH07XG5cbiAgaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09ICdsb2FkaW5nJykge1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBzdGFydE1vbml0b3JpbmcsIHsgb25jZTogdHJ1ZSB9KTtcbiAgfSBlbHNlIHtcbiAgICBzdGFydE1vbml0b3JpbmcoKTtcbiAgfVxuXG4gIGNvbnNvbGUubG9nKCdbQUkgQnJvd3NlciBHdWFyZF0gQ29udGVudCBzY3JpcHQgaW5pdGlhbGl6ZWQnKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2VuZFRvQmFja2dyb3VuZCh0eXBlOiBNZXNzYWdlVHlwZSwgZGF0YTogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICBjb25zdCBtZXNzYWdlOiBNZXNzYWdlUGF5bG9hZCA9IHtcbiAgICB0eXBlLFxuICAgIGRhdGEsXG4gICAgc2VudEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gIH07XG5cbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICB0cnkge1xuICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobWVzc2FnZSwgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgcmVqZWN0KGVycik7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShcbiAgbWVzc2FnZTogTWVzc2FnZVBheWxvYWQsXG4gIF9zZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gIHNlbmRSZXNwb25zZTogKHJlc3BvbnNlOiB1bmtub3duKSA9PiB2b2lkXG4pOiBib29sZWFuIHtcbiAgaWYgKCFtZXNzYWdlIHx8ICFtZXNzYWdlLnR5cGUpIHJldHVybiBmYWxzZTtcblxuICBzd2l0Y2ggKG1lc3NhZ2UudHlwZSkge1xuICAgIGNhc2UgJ0RFTEVHQVRJT05fVVBEQVRFJzoge1xuICAgICAgY29uc3QgcnVsZSA9IG1lc3NhZ2UuZGF0YSBhcyBEZWxlZ2F0aW9uUnVsZSB8IG51bGw7XG4gICAgICB1cGRhdGVBY3RpdmVSdWxlKHJ1bGUpO1xuICAgICAgc3luY1J1bGVUb01haW5Xb3JsZChydWxlKTtcblxuICAgICAgLy8gUmVzdGFydCBtb25pdG9yIHdpdGggbmV3IHJ1bGVcbiAgICAgIGlmIChtb25pdG9yQ2xlYW51cCkgbW9uaXRvckNsZWFudXAoKTtcbiAgICAgIG1vbml0b3JDbGVhbnVwID0gc3RhcnRCb3VuZGFyeU1vbml0b3IoXG4gICAgICAgIHJ1bGUsXG4gICAgICAgICh2aW9sYXRpb24pID0+IHNlbmRUb0JhY2tncm91bmQoJ0JPVU5EQVJZX0NIRUNLX1JFUVVFU1QnLCB2aW9sYXRpb24pLFxuICAgICAgICAoZXZlbnQpID0+IHNlbmRUb0JhY2tncm91bmQoJ0FHRU5UX0FDVElPTicsIGV2ZW50KVxuICAgICAgKTtcbiAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUgfSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY2FzZSAnS0lMTF9TV0lUQ0hfQUNUSVZBVEUnOiB7XG4gICAgICAvLyBTdG9wIGFsbCBtb25pdG9yaW5nIGFuZCBjbGVhbiB1cFxuICAgICAgY29uc3QgcmVzdWx0ID0gZXhlY3V0ZUNvbnRlbnRLaWxsU3dpdGNoKCk7XG4gICAgICBkZXRlY3Rpb25DbGVhbnVwID0gbnVsbDtcbiAgICAgIG1vbml0b3JDbGVhbnVwID0gbnVsbDtcbiAgICAgIGN1cnJlbnRBZ2VudElkID0gbnVsbDtcbiAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUsIC4uLnJlc3VsdCB9KTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjYXNlICdTVEFUVVNfUVVFUlknOiB7XG4gICAgICBjb25zdCBzdGF0ZSA9IGdldE1vbml0b3JTdGF0ZSgpO1xuICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgYWdlbnREZXRlY3RlZDogY3VycmVudEFnZW50SWQgIT09IG51bGwsXG4gICAgICAgIGFnZW50SWQ6IGN1cnJlbnRBZ2VudElkLFxuICAgICAgICBtb25pdG9yU3RhdGU6IHN0YXRlLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY2FzZSAnQUxMT1dfT05DRSc6IHtcbiAgICAgIGNvbnN0IHsgY2FwYWJpbGl0eSwgdXJsIH0gPSBtZXNzYWdlLmRhdGEgYXMgeyBjYXBhYmlsaXR5OiBzdHJpbmc7IHVybDogc3RyaW5nIH07XG4gICAgICAvLyBSZWxheSB0aGUgYWxsb3ctb25jZSBzaWduYWwgdG8gdGhlIE1BSU4gd29ybGQgaW50ZXJjZXB0b3IgdmlhIHBvc3RNZXNzYWdlLlxuICAgICAgd2luZG93LnBvc3RNZXNzYWdlKFxuICAgICAgICB7IHR5cGU6IE1TR19BTExPV19PTkNFLCBub25jZTogR1VBUkRfTk9OQ0UsIGNhcGFiaWxpdHksIHVybCB9LFxuICAgICAgICAnKidcbiAgICAgICk7XG4gICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gb25EZXRlY3Rpb25SZXN1bHQodmVyZGljdDogRGV0ZWN0aW9uVmVyZGljdFJlc3VsdCk6IHZvaWQge1xuICBpZiAodmVyZGljdC5hZ2VudERldGVjdGVkICYmIHZlcmRpY3QuYWdlbnQpIHtcbiAgICBjdXJyZW50QWdlbnRJZCA9IHZlcmRpY3QuYWdlbnQuaWQ7XG4gICAgc2VuZFRvQmFja2dyb3VuZCgnREVURUNUSU9OX1JFU1VMVCcsIHZlcmRpY3QuZXZlbnQpLmNhdGNoKCgpID0+IHtcbiAgICAgIC8vIEJhY2tncm91bmQgbWF5IG5vdCBiZSBhdmFpbGFibGVcbiAgICB9KTtcbiAgfVxufVxuXG5pbml0aWFsaXplKCk7XG4iXSwibmFtZXMiOlsiZXZlbnQiLCJyZWdleFN0ciJdLCJtYXBwaW5ncyI6Ijs7QUFvQk8sV0FBUyxzQkFBMEM7QUFDeEQsVUFBTSxVQUFtQyxDQUFBO0FBQ3pDLFVBQU0sUUFBa0IsQ0FBQTtBQUd4QixVQUFNLGFBQWEsT0FBTyxvQkFBb0IsTUFBTTtBQUNwRCxlQUFXLE9BQU8sWUFBWTtBQUM1QixVQUFJLElBQUksV0FBVyxRQUFRLEtBQUssSUFBSSxXQUFXLGFBQWEsR0FBRztBQUM3RCxjQUFNLEtBQUssR0FBRztBQUNkLGdCQUFRLEdBQUcsSUFBSTtBQUFBLE1BQ2pCO0FBQUEsSUFDRjtBQUdBLFVBQU0sY0FBYztBQUFBLE1BQ2xCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBQTtBQUVGLGVBQVcsV0FBVyxhQUFhO0FBQ2pDLFVBQUksV0FBVyxRQUFRO0FBQ3JCLGNBQU0sS0FBSyxPQUFPO0FBQ2xCLGdCQUFRLE9BQU8sSUFBSTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUdBLFFBQUksaUJBQWlCLFFBQVE7QUFDM0IsWUFBTSxLQUFLLGFBQWE7QUFDeEIsY0FBUSxjQUFjO0FBQUEsSUFDeEI7QUFFQSxVQUFNLFdBQVcsTUFBTSxTQUFTO0FBQ2hDLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQSxRQUFRO0FBQUEsTUFDUixZQUFZLFdBQVksTUFBTSxVQUFVLElBQUksY0FBYyxTQUFVO0FBQUEsTUFDcEUsUUFBUSxXQUNKLHlCQUF5QixNQUFNLEtBQUssSUFBSSxDQUFDLE1BQ3pDO0FBQUEsTUFDSjtBQUFBLElBQUE7QUFBQSxFQUVKO0FBZ0dPLFdBQVMsc0JBQ2QsVUFDWTtBQUNaLFFBQUksVUFBVTtBQUNkLFVBQU0sWUFBWSxJQUFJLElBQUksT0FBTyxvQkFBb0IsTUFBTSxDQUFDO0FBRTVELFVBQU0sYUFBYSxZQUFZLE1BQU07QUFDbkMsVUFBSSxRQUFTO0FBQ2IsWUFBTSxjQUFjLE9BQU8sb0JBQW9CLE1BQU07QUFDckQsaUJBQVcsT0FBTyxhQUFhO0FBQzdCLFlBQUksVUFBVSxJQUFJLEdBQUcsRUFBRztBQUN4QixrQkFBVSxJQUFJLEdBQUc7QUFFakIsWUFDRSxJQUFJLFdBQVcsUUFBUSxLQUN2QixJQUFJLFdBQVcsY0FBYyxLQUM3QixJQUFJLFdBQVcsYUFBYSxLQUM1QixJQUFJLFdBQVcsT0FBTyxLQUN0QixJQUFJLFdBQVcsYUFBYSxHQUM1QjtBQUNBLG1CQUFTO0FBQUEsWUFDUCxVQUFVO0FBQUEsWUFDVixRQUFRO0FBQUEsWUFDUixZQUFZO0FBQUEsWUFDWixRQUFRLDZCQUE2QixHQUFHO0FBQUEsWUFDeEMsU0FBUyxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sWUFBWSxLQUFLLElBQUEsRUFBSTtBQUFBLFVBQUUsQ0FDaEQ7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0YsR0FBRyxHQUFJO0FBRVAsV0FBTyxNQUFNO0FBQ1gsZ0JBQVU7QUFDVixvQkFBYyxVQUFVO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FDN0tPLFdBQVMsc0JBQWdEO0FBQzlELFVBQU0sVUFBbUMsQ0FBQTtBQUd6QyxRQUFJO0FBQ0YsWUFBTSxTQUFTLFNBQVM7QUFDeEIsVUFBSSxVQUFVLE9BQU8sT0FBTyxpQkFBaUIsY0FBYyxPQUFPLGFBQWEsV0FBVyxNQUFNLE1BQU07QUFDcEcsZ0JBQVEsb0JBQW9CO0FBQzVCLGVBQU87QUFBQSxVQUNMLFVBQVU7QUFBQSxVQUNWLFFBQVE7QUFBQSxVQUNSLFlBQVk7QUFBQSxVQUNaLFFBQVE7QUFBQSxVQUNSO0FBQUEsUUFBQTtBQUFBLE1BRUo7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUVSO0FBR0EsVUFBTSxpQkFBaUIsVUFBVTtBQUNqQyxZQUFRLGlCQUFpQjtBQUd6QixVQUFNLGFBQWEsT0FBTyx5QkFBeUIsV0FBVyxXQUFXO0FBQ3pFLFlBQVEsbUJBQW1CLENBQUMsQ0FBQztBQUM3QixRQUFJLFlBQVk7QUFDZCxjQUFRLGVBQWUsV0FBVztBQUNsQyxjQUFRLGFBQWEsV0FBVztBQUNoQyxjQUFRLFdBQVcsV0FBVztBQUFBLElBQ2hDO0FBR0EsVUFBTSxrQkFBa0IsT0FBTztBQUFBLE1BQzdCLE9BQU8sZUFBZSxTQUFTO0FBQUEsTUFDL0I7QUFBQSxJQUFBO0FBRUYsWUFBUSxrQkFBa0IsQ0FBQyxDQUFDO0FBRTVCLFFBQUksbUJBQW1CLE1BQU07QUFDM0IsYUFBTztBQUFBLFFBQ0wsVUFBVTtBQUFBLFFBQ1YsUUFBUTtBQUFBLFFBQ1IsWUFBWTtBQUFBLFFBQ1osUUFBUTtBQUFBLFFBQ1I7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUdBLFFBQUksY0FBYyxtQkFBbUIsT0FBTztBQUMxQyxhQUFPO0FBQUEsUUFDTCxVQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsUUFDUixZQUFZO0FBQUEsUUFDWixRQUFRO0FBQUEsUUFDUjtBQUFBLE1BQUE7QUFBQSxJQUVKO0FBRUEsV0FBTztBQUFBLE1BQ0wsVUFBVTtBQUFBLE1BQ1YsUUFBUTtBQUFBLE1BQ1IsWUFBWTtBQUFBLE1BQ1osUUFBUTtBQUFBLE1BQ1I7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUtPLFdBQVMsMkJBQXFEO0FBQ25FLFVBQU0sVUFBbUMsQ0FBQTtBQUN6QyxRQUFJLFdBQVc7QUFDZixVQUFNLFVBQW9CLENBQUE7QUFHMUIsVUFBTSxnQkFBZ0IsVUFBVSxTQUFTLFVBQVU7QUFDbkQsWUFBUSxnQkFBZ0I7QUFDeEIsUUFBSSxrQkFBa0IsR0FBRztBQUN2QixpQkFBVztBQUNYLGNBQVEsS0FBSyxtREFBbUQ7QUFBQSxJQUNsRTtBQUdBLFlBQVEsWUFBWSxVQUFVO0FBQzlCLFFBQUksQ0FBQyxVQUFVLGFBQWEsVUFBVSxVQUFVLFdBQVcsR0FBRztBQUM1RCxpQkFBVztBQUNYLGNBQVEsS0FBSyxnREFBZ0Q7QUFBQSxJQUMvRDtBQUdBLFFBQUk7QUFDRixjQUFRLHlCQUF5QixhQUFhO0FBQzlDLFVBQUksYUFBYSxlQUFlLFVBQVU7QUFDeEMsZ0JBQVEsS0FBSyxzQ0FBc0M7QUFBQSxNQUNyRDtBQUFBLElBQ0YsUUFBUTtBQUNOLGNBQVEseUJBQXlCO0FBQUEsSUFDbkM7QUFFQSxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsUUFBUTtBQUFBLE1BQ1IsWUFBWSxXQUFXLFdBQVc7QUFBQSxNQUNsQyxRQUFRLFFBQVEsU0FBUyxJQUFJLFFBQVEsS0FBSyxHQUFHLElBQUk7QUFBQSxNQUNqRDtBQUFBLElBQUE7QUFBQSxFQUVKO0FBS08sV0FBUyx3QkFBa0Q7QUFDaEUsVUFBTSxVQUFtQyxDQUFBO0FBQ3pDLFVBQU0sZUFBeUIsQ0FBQTtBQUcvQixVQUFNLFVBQVUsT0FBTyxvQkFBb0IsUUFBUTtBQUNuRCxlQUFXLE9BQU8sU0FBUztBQUN6QixVQUFJLElBQUksV0FBVyxPQUFPLEtBQUssSUFBSSxXQUFXLE9BQU8sR0FBRztBQUN0RCxxQkFBYSxLQUFLLEdBQUc7QUFDckIsZ0JBQVEsR0FBRyxJQUFJO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBR0EsVUFBTSxrQkFBa0I7QUFBQSxNQUN0QjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBRUYsZUFBVyxRQUFRLGlCQUFpQjtBQUNsQyxVQUFJLFFBQVEsUUFBUTtBQUNsQixxQkFBYSxLQUFLLElBQUk7QUFDdEIsZ0JBQVEsSUFBSSxJQUFJO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBR0EsVUFBTSxhQUFhLE9BQU8sb0JBQW9CLE1BQU07QUFDcEQsZUFBVyxPQUFPLFlBQVk7QUFDNUIsVUFBSSxJQUFJLFdBQVcsTUFBTSxLQUFLLElBQUksV0FBVyx5QkFBeUIsR0FBRztBQUN2RSxxQkFBYSxLQUFLLEdBQUc7QUFDckIsZ0JBQVEsR0FBRyxJQUFJO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLE1BQ0wsVUFBVSxhQUFhLFNBQVM7QUFBQSxNQUNoQyxRQUFRO0FBQUEsTUFDUixZQUFZLGFBQWEsU0FBUyxJQUFJLGNBQWM7QUFBQSxNQUNwRCxRQUFRLGFBQWEsU0FBUyxJQUMxQiwyQkFBMkIsYUFBYSxLQUFLLElBQUksQ0FBQyxNQUNsRDtBQUFBLE1BQ0o7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUtPLFdBQVMsd0JBQ2QsVUFDWTtBQUNaLFFBQUksVUFBVTtBQUdkLFVBQU0sYUFBYSxZQUFZLE1BQU07QUFDbkMsVUFBSSxRQUFTO0FBQ2IsWUFBTSxTQUFTLG9CQUFBO0FBQ2YsVUFBSSxPQUFPLFVBQVU7QUFDbkIsaUJBQVMsTUFBTTtBQUFBLE1BQ2pCO0FBQUEsSUFDRixHQUFHLEdBQUk7QUFHUCxXQUFPLE1BQU07QUFDWCxnQkFBVTtBQUNWLG9CQUFjLFVBQVU7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUN0TE8sV0FBUyw2QkFBdUQ7QUFDckUsVUFBTSxVQUFtQyxDQUFBO0FBQ3pDLFVBQU0sUUFBa0IsQ0FBQTtBQUd4QixVQUFNLFVBQVU7QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBRUYsZUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBSSxVQUFVLFFBQVE7QUFDcEIsY0FBTSxLQUFLLE1BQU07QUFDakIsZ0JBQVEsTUFBTSxJQUFJO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBR0EsUUFBSTtBQUNGLFlBQU0sY0FBYyxrQkFBa0I7QUFDdEMsWUFBTSxnQkFBZ0IsT0FBTyx5QkFBeUIsYUFBYSxXQUFXO0FBQzlFLFVBQUksaUJBQWlCLENBQUMsY0FBYyxZQUFZLGNBQWMsY0FBYztBQUMxRSxnQkFBUSxvQkFBb0I7QUFBQSxNQUM5QjtBQUFBLElBQ0YsUUFBUTtBQUFBLElBRVI7QUFFQSxXQUFPO0FBQUEsTUFDTCxVQUFVLE1BQU0sU0FBUztBQUFBLE1BQ3pCLGVBQWU7QUFBQSxNQUNmLFFBQVE7QUFBQSxNQUNSLFlBQVksTUFBTSxTQUFTLElBQUksU0FBUztBQUFBLE1BQ3hDLFFBQVEsTUFBTSxTQUFTLElBQ25CLHNDQUFzQyxNQUFNLEtBQUssSUFBSSxDQUFDLE1BQ3REO0FBQUEsTUFDSjtBQUFBLElBQUE7QUFBQSxFQUVKO0FBS08sV0FBUyx1QkFBaUQ7QUFDL0QsVUFBTSxVQUFtQyxDQUFBO0FBQ3pDLFVBQU0sUUFBa0IsQ0FBQTtBQUd4QixVQUFNLFVBQVU7QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBRUYsZUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBSSxVQUFVLFFBQVE7QUFDcEIsY0FBTSxLQUFLLE1BQU07QUFDakIsZ0JBQVEsTUFBTSxJQUFJO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBR0EsVUFBTSxLQUFLLFVBQVU7QUFDckIsUUFBSSxHQUFHLFNBQVMsVUFBVSxLQUFLLEdBQUcsU0FBUyxRQUFRLEdBQUc7QUFDcEQsWUFBTSxLQUFLLFdBQVc7QUFDdEIsY0FBUSxZQUFZO0FBQUEsSUFDdEI7QUFHQSxRQUFJLE9BQU8sWUFBWSxlQUFlLCtCQUErQixRQUFRLFdBQVc7QUFDdEYsY0FBUSxtQkFBbUI7QUFBQSxJQUM3QjtBQUVBLFdBQU87QUFBQSxNQUNMLFVBQVUsTUFBTSxTQUFTO0FBQUEsTUFDekIsZUFBZTtBQUFBLE1BQ2YsUUFBUTtBQUFBLE1BQ1IsWUFBWSxNQUFNLFNBQVMsSUFBSSxTQUFTO0FBQUEsTUFDeEMsUUFBUSxNQUFNLFNBQVMsSUFDbkIsK0JBQStCLE1BQU0sS0FBSyxJQUFJLENBQUMsTUFDL0M7QUFBQSxNQUNKO0FBQUEsSUFBQTtBQUFBLEVBRUo7QUFLTyxXQUFTLHNCQUFrRDtBQUNoRSxVQUFNLFVBQXNDLENBQUE7QUFFNUMsVUFBTSxjQUFjLDJCQUFBO0FBQ3BCLFFBQUksWUFBWSxTQUFVLFNBQVEsS0FBSyxXQUFXO0FBRWxELFVBQU0sV0FBVyxxQkFBQTtBQUNqQixRQUFJLFNBQVMsU0FBVSxTQUFRLEtBQUssUUFBUTtBQUU1QyxVQUFNLFVBQVUsd0JBQUE7QUFDaEIsUUFBSSxRQUFRLFNBQVUsU0FBUSxLQUFLLE9BQU87QUFFMUMsV0FBTztBQUFBLEVBQ1Q7QUFLTyxXQUFTLDBCQUFvRDtBQUNsRSxVQUFNLFVBQW1DLENBQUE7QUFDekMsVUFBTSxhQUF1QixDQUFBO0FBSTdCLFVBQU0sWUFBYSxPQUE4QztBQUNqRSxRQUFJLFdBQVc7QUFDYixjQUFRLGVBQWUsZUFBZTtBQUN0QyxjQUFRLFNBQVMsU0FBUztBQUUxQixVQUFJLEVBQUUsZUFBZSxZQUFZO0FBQy9CLG1CQUFXLEtBQUssMEJBQTBCO0FBQUEsTUFDNUM7QUFDQSxVQUFJLEVBQUUsU0FBUyxZQUFZO0FBQ3pCLG1CQUFXLEtBQUssb0JBQW9CO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBR0EsUUFBSSxPQUFPLGVBQWUsS0FBSyxPQUFPLGdCQUFnQixHQUFHO0FBQ3ZELGlCQUFXLEtBQUssdUJBQXVCO0FBQ3ZDLGNBQVEsYUFBYSxPQUFPO0FBQzVCLGNBQVEsY0FBYyxPQUFPO0FBQUEsSUFDL0I7QUFHQSxRQUFJLENBQUMsT0FBTyxRQUFRO0FBQ2xCLGlCQUFXLEtBQUssdUJBQXVCO0FBQ3ZDLGNBQVEsZ0JBQWdCO0FBQUEsSUFDMUI7QUFHQSxRQUFJO0FBQ0YsWUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLFlBQU0sS0FBSyxPQUFPLFdBQVcsT0FBTztBQUNwQyxVQUFJLElBQUk7QUFDTixjQUFNLFlBQVksR0FBRyxhQUFhLDJCQUEyQjtBQUM3RCxZQUFJLFdBQVc7QUFDYixnQkFBTSxXQUFXLEdBQUcsYUFBYSxVQUFVLHVCQUF1QjtBQUNsRSxrQkFBUSxnQkFBZ0I7QUFDeEIsY0FBSSxPQUFPLGFBQWEsYUFBYSxTQUFTLFNBQVMsYUFBYSxLQUFLLFNBQVMsU0FBUyxVQUFVLElBQUk7QUFDdkcsdUJBQVcsS0FBSyx3Q0FBd0M7QUFBQSxVQUMxRDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUVBLFVBQU0sV0FBVyxXQUFXLFVBQVU7QUFDdEMsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLGVBQWUsV0FBVyxnQkFBZ0I7QUFBQSxNQUMxQyxRQUFRO0FBQUEsTUFDUixZQUFZLFdBQVcsV0FBVztBQUFBLE1BQ2xDLFFBQVEsV0FDSixrQ0FBa0MsV0FBVyxLQUFLLElBQUksQ0FBQyxNQUN2RDtBQUFBLE1BQ0o7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQ2xLQSxRQUFNLHdCQUF3QjtBQUFBLElBQzVCLHdCQUF3QjtBQUFBLElBQ3hCLDJCQUEyQjtBQUFBLElBQzNCLHNCQUFzQjtBQUFBLElBQ3RCLHdCQUF3QjtBQUFBLElBQ3hCLHVCQUF1QjtBQUFBLEVBQ3pCO0FBRUEsV0FBUyxjQUFjLFFBQTBCO0FBQy9DLFFBQUksT0FBTyxTQUFTLEVBQUcsUUFBTztBQUM5QixVQUFNLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxNQUFNLElBQUksR0FBRyxDQUFDLElBQUksT0FBTztBQUN4RCxVQUFNLFdBQVcsT0FBTyxPQUFPLENBQUMsS0FBSyxNQUFNLE9BQU8sSUFBSSxTQUFTLEdBQUcsQ0FBQyxLQUFLLE9BQU8sU0FBUztBQUN4RixXQUFPLEtBQUssS0FBSyxRQUFRO0FBQUEsRUFDM0I7QUFFQSxXQUFTLFlBQVksUUFBMEI7QUFDN0MsUUFBSSxPQUFPLFdBQVcsRUFBRyxRQUFPO0FBQ2hDLFdBQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxNQUFNLElBQUksR0FBRyxDQUFDLElBQUksT0FBTztBQUFBLEVBQ3BEO0FBRUEsV0FBUyxlQUFrQztBQUN6QyxXQUFPO0FBQUEsTUFDTCxzQkFBc0I7QUFBQSxNQUN0QixxQkFBcUI7QUFBQSxNQUNyQix3QkFBd0I7QUFBQSxNQUN4QixvQkFBb0I7QUFBQSxNQUNwQixtQkFBbUI7QUFBQSxNQUNuQixxQkFBcUI7QUFBQSxNQUNyQix1QkFBdUI7QUFBQSxNQUN2QixxQkFBcUI7QUFBQSxJQUFBO0FBQUEsRUFFekI7QUFLTyxXQUFTLHFCQUNkLFFBTzJCO0FBQzNCLFVBQU0sVUFBVSxhQUFBO0FBQ2hCLFlBQVEsc0JBQXNCLE9BQU87QUFFckMsUUFBSSxPQUFPLFNBQVMsc0JBQXNCLHVCQUF1QjtBQUMvRCxhQUFPO0FBQUEsUUFDTCxVQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsUUFDUixZQUFZO0FBQUEsUUFDWixRQUFRLDJDQUEyQyxPQUFPLE1BQU0sSUFBSSxzQkFBc0IscUJBQXFCO0FBQUEsUUFDL0c7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUdBLFVBQU0sWUFBc0IsQ0FBQTtBQUM1QixhQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0FBQ3RDLGdCQUFVLEtBQUssT0FBTyxDQUFDLEVBQUUsWUFBWSxPQUFPLElBQUksQ0FBQyxFQUFFLFNBQVM7QUFBQSxJQUM5RDtBQUNBLFlBQVEsdUJBQXVCLFlBQVksU0FBUztBQUNwRCxZQUFRLHNCQUFzQixjQUFjLFNBQVM7QUFHckQsUUFBSSxlQUFlO0FBQ25CLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFVBQUksRUFBRSxZQUFZLEtBQUssTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFFLFlBQVksS0FBSyxNQUFNLEVBQUUsT0FBTyxHQUFHO0FBQzlFO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxZQUFRLHlCQUF5QixlQUFlLE9BQU87QUFHdkQsVUFBTSxpQkFBaUIsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsU0FBUyxFQUFFO0FBQzFELFlBQVEsc0JBQXNCLGlCQUFpQixPQUFPO0FBR3RELFFBQUksd0JBQXdCO0FBQzVCLGFBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7QUFDdEMsVUFBSSxPQUFPLENBQUMsRUFBRSxTQUFTLFNBQVM7QUFDOUIsY0FBTSxtQkFBbUIsSUFBSSxLQUFLLE9BQU8sSUFBSSxDQUFDLEVBQUUsU0FBUztBQUN6RCxZQUFJLENBQUMsaUJBQWtCO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQ0EsWUFBUSx3QkFBd0I7QUFHaEMsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksUUFBUSxzQkFBc0Isc0JBQXNCLHdCQUF3QjtBQUM5RSxnQkFBVSxLQUFLLHNCQUFzQjtBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxRQUFRLHlCQUF5QixzQkFBc0IsMkJBQTJCO0FBQ3BGLGdCQUFVLEtBQUssMEJBQTBCO0FBQUEsSUFDM0M7QUFDQSxRQUFJLFFBQVEsc0JBQXNCLHNCQUFzQix3QkFBd0I7QUFDOUUsZ0JBQVUsS0FBSyw0QkFBNEI7QUFBQSxJQUM3QztBQUVBLFVBQU0sV0FBVyxVQUFVLFNBQVM7QUFDcEMsUUFBSSxhQUFrQztBQUN0QyxRQUFJLFVBQVUsVUFBVSxFQUFHLGNBQWE7QUFBQSxhQUMvQixVQUFVLFVBQVUsRUFBRyxjQUFhO0FBQUEsYUFDcEMsVUFBVSxXQUFXLEVBQUcsY0FBYTtBQUU5QyxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsUUFBUTtBQUFBLE1BQ1I7QUFBQSxNQUNBLFFBQVEsV0FDSiwrQkFBK0IsVUFBVSxLQUFLLElBQUksQ0FBQyxNQUNuRDtBQUFBLE1BQ0o7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUtPLFdBQVMsd0JBQ2QsUUFNMkI7QUFDM0IsVUFBTSxVQUFVLGFBQUE7QUFDaEIsWUFBUSxzQkFBc0IsT0FBTztBQUVyQyxRQUFJLE9BQU8sU0FBUyxzQkFBc0IsdUJBQXVCO0FBQy9ELGFBQU87QUFBQSxRQUNMLFVBQVU7QUFBQSxRQUNWLFFBQVE7QUFBQSxRQUNSLFlBQVk7QUFBQSxRQUNaLFFBQVEsOENBQThDLE9BQU8sTUFBTSxJQUFJLHNCQUFzQixxQkFBcUI7QUFBQSxRQUNsSDtBQUFBLE1BQUE7QUFBQSxJQUVKO0FBR0EsVUFBTSxXQUFXLE9BQU8sT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLFNBQVM7QUFDMUQsVUFBTSxZQUFzQixDQUFBO0FBQzVCLGFBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDeEMsZ0JBQVUsS0FBSyxTQUFTLENBQUMsRUFBRSxZQUFZLFNBQVMsSUFBSSxDQUFDLEVBQUUsU0FBUztBQUFBLElBQ2xFO0FBQ0EsWUFBUSxxQkFBcUIsWUFBWSxTQUFTO0FBQ2xELFlBQVEsb0JBQW9CLGNBQWMsU0FBUztBQUduRCxVQUFNLGlCQUFpQixPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxTQUFTLEVBQUU7QUFDMUQsWUFBUSxzQkFBc0IsaUJBQWlCLE9BQU87QUFFdEQsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksUUFBUSxvQkFBb0Isc0JBQXNCLHdCQUF3QixTQUFTLFNBQVMsR0FBRztBQUNqRyxnQkFBVSxLQUFLLG9CQUFvQjtBQUFBLElBQ3JDO0FBQ0EsUUFBSSxRQUFRLHNCQUFzQixzQkFBc0Isd0JBQXdCO0FBQzlFLGdCQUFVLEtBQUssNEJBQTRCO0FBQUEsSUFDN0M7QUFFQSxRQUFJLFFBQVEscUJBQXFCLEtBQUssUUFBUSxxQkFBcUIsTUFBTSxTQUFTLFNBQVMsR0FBRztBQUM1RixnQkFBVSxLQUFLLHlCQUF5QjtBQUFBLElBQzFDO0FBRUEsVUFBTSxXQUFXLFVBQVUsU0FBUztBQUNwQyxRQUFJLGFBQWtDO0FBQ3RDLFFBQUksVUFBVSxVQUFVLEVBQUcsY0FBYTtBQUN4QyxRQUFJLFFBQVEsc0JBQXNCLElBQUssY0FBYTtBQUVwRCxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsUUFBUTtBQUFBLE1BQ1I7QUFBQSxNQUNBLFFBQVEsV0FDSixrQ0FBa0MsVUFBVSxLQUFLLElBQUksQ0FBQyxNQUN0RDtBQUFBLE1BQ0o7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUtPLFdBQVMsc0JBQ2QsUUFNMkI7QUFDM0IsVUFBTSxVQUFVLGFBQUE7QUFDaEIsWUFBUSxzQkFBc0IsT0FBTztBQUVyQyxRQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxRQUNMLFVBQVU7QUFBQSxRQUNWLFFBQVE7QUFBQSxRQUNSLFlBQVk7QUFBQSxRQUNaLFFBQVEsbURBQW1ELE9BQU8sTUFBTTtBQUFBLFFBQ3hFO0FBQUEsTUFBQTtBQUFBLElBRUo7QUFHQSxVQUFNLFVBQW9CLENBQUE7QUFDMUIsZUFBVyxTQUFTLFFBQVE7QUFDMUIsWUFBTSxVQUFVLE1BQU0sV0FBVyxJQUFJLE1BQU0sV0FBVyxRQUFRO0FBQzlELFlBQU0sVUFBVSxNQUFNLFdBQVcsSUFBSSxNQUFNLFdBQVcsU0FBUztBQUMvRCxZQUFNLFNBQVMsS0FBSztBQUFBLFNBQ2pCLE1BQU0sVUFBVSxZQUFZLEtBQUssTUFBTSxVQUFVLFlBQVk7QUFBQSxNQUFBO0FBRWhFLGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFFQSxVQUFNLFNBQVMsY0FBYyxPQUFPO0FBQ3BDLFVBQU0sYUFBYSxZQUFZLE9BQU87QUFHdEMsVUFBTSxXQUFXLFNBQVMsS0FBSyxhQUFhO0FBQzVDLFVBQU0sYUFBa0MsV0FBVyxXQUFXO0FBRTlELFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQSxRQUFRO0FBQUEsTUFDUjtBQUFBLE1BQ0EsUUFBUSxXQUNKLHFEQUFxRCxPQUFPLFFBQVEsQ0FBQyxDQUFDLG9CQUFvQixXQUFXLFFBQVEsQ0FBQyxDQUFDLFNBQy9HLDJDQUEyQyxPQUFPLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDaEU7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUtPLFdBQVMsNEJBQ2QsYUFDQSxnQkFDQSxhQUMyQjtBQUMzQixVQUFNLFVBQVUsQ0FBQyxhQUFhLGdCQUFnQixXQUFXLEVBQUU7QUFBQSxNQUN6RCxDQUFDLE1BQXNDLE1BQU07QUFBQSxJQUFBO0FBRy9DLFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsYUFBTztBQUFBLFFBQ0wsVUFBVTtBQUFBLFFBQ1YsUUFBUTtBQUFBLFFBQ1IsWUFBWTtBQUFBLFFBQ1osUUFBUTtBQUFBLFFBQ1IsU0FBUyxhQUFBO0FBQUEsTUFBYTtBQUFBLElBRTFCO0FBRUEsVUFBTSxnQkFBZ0IsUUFBUSxPQUFPLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRTtBQUN4RCxVQUFNLFdBQVcsZ0JBQWdCO0FBR2pDLFVBQU0sa0JBQXlDLENBQUMsT0FBTyxVQUFVLFFBQVEsV0FBVztBQUNwRixRQUFJLGFBQWtDO0FBQ3RDLFFBQUksaUJBQWlCLEdBQUc7QUFDdEIsbUJBQWE7QUFBQSxJQUNmLFdBQVcsaUJBQWlCLEdBQUc7QUFDN0IsbUJBQWE7QUFBQSxJQUNmLFdBQVcsa0JBQWtCLEdBQUc7QUFFOUIsWUFBTSxpQkFBaUIsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVE7QUFDckQsbUJBQWEsZ0JBQWdCLGNBQWM7QUFBQSxJQUM3QztBQUdBLFVBQU0sYUFBYSxRQUFRLE9BQU8sQ0FBQyxNQUFNLE1BQU07QUFDN0MsWUFBTSxVQUFVLGdCQUFnQixRQUFRLEtBQUssVUFBVTtBQUN2RCxZQUFNLE9BQU8sZ0JBQWdCLFFBQVEsRUFBRSxVQUFVO0FBQ2pELGFBQU8sT0FBTyxVQUFVLElBQUk7QUFBQSxJQUM5QixDQUFDO0FBRUQsVUFBTSxVQUFVLFFBQ2IsT0FBTyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQ3hCLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUNuQixLQUFLLEdBQUc7QUFFWCxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsUUFBUSxXQUFXO0FBQUEsTUFDbkI7QUFBQSxNQUNBLFFBQVEsV0FBVyxVQUFVO0FBQUEsTUFDN0IsU0FBUyxXQUFXO0FBQUEsSUFBQTtBQUFBLEVBRXhCO0FDN1JPLFFBQU0sMEJBQTBDO0FBQUEsSUFDckQsa0JBQWtCO0FBQUEsSUFDbEIsbUJBQW1CO0FBQUEsSUFDbkIsbUJBQW1CO0FBQUEsSUFDbkIsc0JBQXNCO0FBQUEsRUFDeEI7QUFFQSxRQUFNLG1CQUEwQyxDQUFDLE9BQU8sVUFBVSxRQUFRLFdBQVc7QUFFckYsV0FBUyxlQUFlLEdBQWdDO0FBQ3RELFdBQU8saUJBQWlCLFFBQVEsQ0FBQztBQUFBLEVBQ25DO0FBRUEsV0FBUyxpQkFBaUIsYUFBeUQ7QUFDakYsV0FBTyxZQUFZO0FBQUEsTUFBTyxDQUFDLE1BQU0sTUFDL0IsZUFBZSxDQUFDLElBQUksZUFBZSxJQUFJLElBQUksSUFBSTtBQUFBLE1BQy9DO0FBQUEsSUFBQTtBQUFBLEVBQ0o7QUFLTyxXQUFTLGtCQUFrQixRQUEwRDtBQUMxRixVQUFNLE1BQU0sRUFBRSxHQUFHLHlCQUF5QixHQUFHLE9BQUE7QUFDN0MsVUFBTSxVQUFzRCxDQUFBO0FBQzVELFVBQU0sVUFBbUMsQ0FBQTtBQUd6QyxVQUFNLGtCQUFrQixvQkFBQTtBQUN4QixRQUFJLGdCQUFnQixVQUFVO0FBQzVCLGNBQVEsS0FBSyxnQkFBZ0IsTUFBTTtBQUNuQyxhQUFPLE9BQU8sU0FBUyxnQkFBZ0IsT0FBTztBQUFBLElBQ2hEO0FBR0EsVUFBTSxrQkFBa0IseUJBQUE7QUFDeEIsUUFBSSxnQkFBZ0IsVUFBVTtBQUM1QixjQUFRLEtBQUssZ0JBQWdCLE1BQU07QUFDbkMsYUFBTyxPQUFPLFNBQVMsZ0JBQWdCLE9BQU87QUFBQSxJQUNoRDtBQUdBLFVBQU0saUJBQWlCLHNCQUFBO0FBQ3ZCLFFBQUksZUFBZSxVQUFVO0FBQzNCLGNBQVEsS0FBSyxlQUFlLE1BQU07QUFDbEMsYUFBTyxPQUFPLFNBQVMsZUFBZSxPQUFPO0FBQUEsSUFDL0M7QUFHQSxVQUFNLFlBQVksb0JBQUE7QUFDbEIsUUFBSSxVQUFVLFVBQVU7QUFDdEIsY0FBUSxLQUFLLFVBQVUsTUFBTTtBQUM3QixhQUFPLE9BQU8sU0FBUyxVQUFVLE9BQU87QUFBQSxJQUMxQztBQUdBLFVBQU0sbUJBQW1CLG9CQUFBO0FBQ3pCLGVBQVcsTUFBTSxrQkFBa0I7QUFDakMsY0FBUSxLQUFLLEdBQUcsTUFBTTtBQUN0QixhQUFPLE9BQU8sU0FBUyxHQUFHLE9BQU87QUFBQSxJQUNuQztBQUdBLFVBQU0sbUJBQXFEO0FBRzNELFVBQU0sa0JBQWtCO0FBQUEsTUFDdEIsZ0JBQWdCLFdBQVcsa0JBQWtCO0FBQUEsTUFDN0MsZ0JBQWdCLFdBQVcsa0JBQWtCO0FBQUEsTUFDN0MsZUFBZSxXQUFXLGlCQUFpQjtBQUFBLE1BQzNDLFVBQVUsV0FBVyxZQUFZO0FBQUEsTUFDakMsR0FBRyxpQkFBaUIsT0FBTyxDQUFDLE1BQU0sRUFBRSxRQUFRO0FBQUEsSUFBQSxFQUM1QyxPQUFPLE9BQU87QUFFaEIsVUFBTSxnQkFBZ0IsZ0JBQWdCLFNBQVM7QUFHL0MsUUFBSSxvQkFBeUM7QUFDN0MsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sY0FBcUMsQ0FBQTtBQUMzQyxVQUFJLGdCQUFnQixTQUFVLGFBQVksS0FBSyxnQkFBZ0IsVUFBVTtBQUN6RSxVQUFJLGVBQWUsU0FBVSxhQUFZLEtBQUssZUFBZSxVQUFVO0FBQ3ZFLFVBQUksVUFBVSxTQUFVLGFBQVksS0FBSyxVQUFVLFVBQVU7QUFDN0QsaUJBQVcsTUFBTSxrQkFBa0I7QUFDakMsWUFBSSxHQUFHLFNBQVUsYUFBWSxLQUFLLEdBQUcsVUFBVTtBQUFBLE1BQ2pEO0FBQ0EsMEJBQW9CLGNBQWMsR0FBRyxXQUFXO0FBR2hELFVBQUksZ0JBQWdCLFVBQVUsS0FBSyxlQUFlLGlCQUFpQixJQUFJLGVBQWUsV0FBVyxHQUFHO0FBQ2xHLDRCQUFvQjtBQUFBLE1BQ3RCLFdBQVcsZ0JBQWdCLFVBQVUsS0FBSyxlQUFlLGlCQUFpQixJQUFJLGVBQWUsTUFBTSxHQUFHO0FBQ3BHLDRCQUFvQjtBQUFBLE1BQ3RCO0FBQUEsSUFDRjtBQUdBLFFBQUksaUJBQWlCLGVBQWUsaUJBQWlCLElBQUksZUFBZSxJQUFJLGlCQUFpQixHQUFHO0FBRTlGLFlBQU1BLFNBQXdCO0FBQUEsUUFDNUIsSUFBSSxPQUFPLFdBQUE7QUFBQSxRQUNYLFlBQVcsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxRQUN0QjtBQUFBLFFBQ0EsWUFBWTtBQUFBLFFBQ1osT0FBTztBQUFBLFFBQ1AsS0FBSyxPQUFPLFNBQVM7QUFBQSxRQUNyQjtBQUFBLE1BQUE7QUFFRixhQUFPO0FBQUEsUUFDTCxlQUFlO0FBQUEsUUFDZixPQUFPO0FBQUEsUUFDUDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLE9BQUFBO0FBQUFBLE1BQUE7QUFBQSxJQUVKO0FBR0EsVUFBTSxZQUFZLGdCQUNkLGtCQUFrQixXQUFXLGlCQUFpQixnQkFBa0MsSUFDaEY7QUFFSixVQUFNLFFBQThCLGdCQUNoQztBQUFBLE1BQ0UsSUFBSSxPQUFPLFdBQUE7QUFBQSxNQUNYLE1BQU07QUFBQSxNQUNOLGtCQUFrQjtBQUFBLE1BQ2xCLFlBQVk7QUFBQSxNQUNaLGFBQVksb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxNQUN2QixXQUFXLE9BQU8sU0FBUztBQUFBLE1BQzNCLHNCQUFzQixDQUFBO0FBQUEsTUFDdEIsVUFBVTtBQUFBLElBQUEsSUFFWjtBQUVKLFVBQU0sUUFBd0I7QUFBQSxNQUM1QixJQUFJLE9BQU8sV0FBQTtBQUFBLE1BQ1gsWUFBVyxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLE1BQ3RCO0FBQUEsTUFDQSxZQUFZO0FBQUEsTUFDWjtBQUFBLE1BQ0EsS0FBSyxPQUFPLFNBQVM7QUFBQSxNQUNyQjtBQUFBLElBQUE7QUFHRixXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUtPLFdBQVMsc0JBQ2QsUUFDQSxhQUNZO0FBQ1osVUFBTSxNQUFNLEVBQUUsR0FBRyx5QkFBeUIsR0FBRyxPQUFBO0FBQzdDLFVBQU0sV0FBOEIsQ0FBQTtBQUNwQyxRQUFJLHNCQUFxQztBQUd6QyxVQUFNLGNBTUQsQ0FBQTtBQUNMLFVBQU0sWUFLRCxDQUFBO0FBQ0wsVUFBTSxxQkFLRCxDQUFBO0FBR0wsVUFBTSxnQkFBZ0Isa0JBQWtCLEdBQUc7QUFDM0MsUUFBSSxjQUFjLGVBQWU7QUFDL0IsNEJBQXNCLGNBQWMsT0FBTyxNQUFNO0FBQ2pELGtCQUFZLGFBQWE7QUFBQSxJQUMzQjtBQUdBLFVBQU0sYUFBYSxZQUFZLE1BQU07QUFDbkMsWUFBTSxTQUFTLGtCQUFrQixHQUFHO0FBR3BDLFVBQUksSUFBSSxvQkFBb0IsWUFBWSxVQUFVLElBQUksc0JBQXNCO0FBQzFFLGNBQU0sY0FBYyxxQkFBcUIsQ0FBQyxHQUFHLFdBQVcsQ0FBQztBQUN6RCxjQUFNLFlBQVksVUFBVSxVQUFVLElBQUksdUJBQ3RDLHdCQUF3QixDQUFDLEdBQUcsU0FBUyxDQUFDLElBQ3RDO0FBQ0osY0FBTSxjQUFjLG1CQUFtQixVQUFVLElBQzdDLHNCQUFzQixDQUFDLEdBQUcsa0JBQWtCLENBQUMsSUFDN0M7QUFFSixjQUFNLG1CQUFtQiw0QkFBNEIsYUFBYSxXQUFXLFdBQVc7QUFDeEYsZUFBTyxtQkFBbUI7QUFFMUIsWUFBSSxpQkFBaUIsWUFBWSxDQUFDLE9BQU8sZUFBZTtBQUN0RCxpQkFBTyxnQkFBZ0I7QUFDdkIsaUJBQU8sb0JBQW9CLGlCQUFpQjtBQUM1QyxpQkFBTyxNQUFNLGFBQWEsaUJBQWlCO0FBQzNDLGlCQUFPLE1BQU0sUUFBUSxLQUFLLGlCQUFpQixNQUFNO0FBQUEsUUFDbkQ7QUFBQSxNQUNGO0FBRUEsVUFBSSxPQUFPLGVBQWU7QUFFeEIsWUFBSSxPQUFPLE9BQU8sT0FBTyx1QkFBdUIsQ0FBQyxxQkFBcUI7QUFDcEUsZ0NBQXNCLE9BQU8sT0FBTyxNQUFNO0FBQzFDLHNCQUFZLE1BQU07QUFBQSxRQUNwQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLEdBQUcsSUFBSSxpQkFBaUI7QUFDeEIsYUFBUyxLQUFLLE1BQU0sY0FBYyxVQUFVLENBQUM7QUFHN0MsUUFBSSxJQUFJLGtCQUFrQjtBQUN4QixZQUFNLFlBQVksSUFBSSx1QkFBdUI7QUFFN0MsWUFBTSxlQUFlLENBQUMsTUFBa0I7QUFDdEMsb0JBQVksS0FBSztBQUFBLFVBQ2YsTUFBTSxFQUFFO0FBQUEsVUFDUixTQUFTLEVBQUU7QUFBQSxVQUNYLFNBQVMsRUFBRTtBQUFBLFVBQ1gsV0FBVyxFQUFFO0FBQUEsVUFDYixXQUFXLEVBQUU7QUFBQSxRQUFBLENBQ2Q7QUFDRCxZQUFJLFlBQVksU0FBUyxVQUFXLGFBQVksTUFBQTtBQUFBLE1BQ2xEO0FBRUEsWUFBTSxhQUFhLENBQUMsTUFBcUI7QUFDdkMsa0JBQVUsS0FBSztBQUFBLFVBQ2IsTUFBTSxFQUFFO0FBQUEsVUFDUixLQUFLLEVBQUU7QUFBQSxVQUNQLFdBQVcsRUFBRTtBQUFBLFVBQ2IsV0FBVyxFQUFFO0FBQUEsUUFBQSxDQUNkO0FBQ0QsWUFBSSxVQUFVLFNBQVMsVUFBVyxXQUFVLE1BQUE7QUFBQSxNQUM5QztBQUVBLFlBQU0sc0JBQXNCLENBQUMsTUFBa0I7QUFDN0MsY0FBTSxTQUFTLEVBQUU7QUFDakIsWUFBSSxRQUFRO0FBQ1YsZ0JBQU0sT0FBTyxPQUFPLHNCQUFBO0FBQ3BCLDZCQUFtQixLQUFLO0FBQUEsWUFDdEIsU0FBUyxFQUFFO0FBQUEsWUFDWCxTQUFTLEVBQUU7QUFBQSxZQUNYLFlBQVksRUFBRSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxPQUFPLEtBQUssT0FBTyxRQUFRLEtBQUssT0FBQTtBQUFBLFlBQ3BFLFdBQVcsRUFBRTtBQUFBLFVBQUEsQ0FDZDtBQUNELGNBQUksbUJBQW1CLFNBQVMsVUFBVyxvQkFBbUIsTUFBQTtBQUFBLFFBQ2hFO0FBQUEsTUFDRjtBQUVBLGVBQVMsaUJBQWlCLGFBQWEsY0FBYyxFQUFFLFNBQVMsTUFBTSxTQUFTLE1BQU07QUFDckYsZUFBUyxpQkFBaUIsU0FBUyxxQkFBcUIsRUFBRSxTQUFTLE1BQU0sU0FBUyxNQUFNO0FBQ3hGLGVBQVMsaUJBQWlCLFdBQVcsWUFBWSxFQUFFLFNBQVMsTUFBTSxTQUFTLE1BQU07QUFDakYsZUFBUyxpQkFBaUIsU0FBUyxZQUFZLEVBQUUsU0FBUyxNQUFNLFNBQVMsTUFBTTtBQUUvRSxlQUFTLEtBQUssTUFBTTtBQUNsQixpQkFBUyxvQkFBb0IsYUFBYSxjQUFjLEVBQUUsU0FBUyxNQUFNO0FBQ3pFLGlCQUFTLG9CQUFvQixTQUFTLHFCQUFxQixFQUFFLFNBQVMsTUFBTTtBQUM1RSxpQkFBUyxvQkFBb0IsV0FBVyxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ3JFLGlCQUFTLG9CQUFvQixTQUFTLFlBQVksRUFBRSxTQUFTLE1BQU07QUFBQSxNQUNyRSxDQUFDO0FBQUEsSUFDSDtBQUdBLFVBQU0sYUFBYSxzQkFBc0IsQ0FBQyxXQUFXO0FBQ25ELFVBQUksT0FBTyxVQUFVO0FBQ25CLGNBQU0sVUFBVSxrQkFBa0IsR0FBRztBQUNyQyxZQUFJLFFBQVEsZUFBZTtBQUN6QixzQkFBWSxPQUFPO0FBQUEsUUFDckI7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQ0QsYUFBUyxLQUFLLFVBQVU7QUFFeEIsVUFBTSxZQUFZLHdCQUF3QixDQUFDLFdBQVc7QUFDcEQsVUFBSSxPQUFPLFVBQVU7QUFDbkIsY0FBTSxVQUFVLGtCQUFrQixHQUFHO0FBQ3JDLFlBQUksUUFBUSxlQUFlO0FBQ3pCLHNCQUFZLE9BQU87QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFDRCxhQUFTLEtBQUssU0FBUztBQUV2QixXQUFPLE1BQU07QUFDWCxpQkFBVyxXQUFXLFVBQVU7QUFDOUIsWUFBSTtBQUFFLGtCQUFBO0FBQUEsUUFBVyxRQUFRO0FBQUEsUUFBZTtBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFLTyxXQUFTLGtCQUNkLFdBQ0EsaUJBQ0Esa0JBQ0Esa0JBQ1c7QUFFWCxlQUFXLE1BQU0sa0JBQWtCO0FBQ2pDLFVBQUksR0FBRyxZQUFZLEdBQUcsa0JBQWtCLFdBQVc7QUFDakQsZUFBTyxHQUFHO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFHQSxRQUFJLFdBQVcsVUFBVTtBQUV2QixVQUFJLFVBQVUsT0FBTyxTQUFTLFlBQVksRUFBRyxRQUFPO0FBQ3BELFVBQUksVUFBVSxPQUFPLFNBQVMsV0FBVyxFQUFHLFFBQU87QUFDbkQsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLGlCQUFpQixVQUFVO0FBQzdCLGFBQU87QUFBQSxJQUNUO0FBT0EsV0FBTztBQUFBLEVBQ1Q7QUM5Uk8sV0FBUyxhQUNkLE1BQ0EsUUFDQSxLQUNzQztBQUN0QyxRQUFJLENBQUMsS0FBSyxVQUFVO0FBQ2xCLGFBQU8sRUFBRSxTQUFTLE9BQU8sUUFBUSxpQ0FBQTtBQUFBLElBQ25DO0FBRUEsUUFBSSxtQkFBbUIsS0FBSyxNQUFNLFNBQVMsR0FBRztBQUM1QyxhQUFPLEVBQUUsU0FBUyxPQUFPLFFBQVEsMEJBQUE7QUFBQSxJQUNuQztBQUdBLFVBQU0sb0JBQW9CLEtBQUssV0FBVyxZQUFZLFVBQW1CO0FBQ3pFLFVBQU0sYUFBYSxxQkFBcUIsS0FBSyxLQUFLLE1BQU0sY0FBYyxpQkFBaUI7QUFDdkYsUUFBSSxDQUFDLFdBQVcsU0FBUztBQUN2QixZQUFNLGdCQUFnQixXQUFXLGlCQUM3QixjQUFjLFdBQVcsZUFBZSxPQUFPLE1BQy9DO0FBQ0osYUFBTyxFQUFFLFNBQVMsT0FBTyxRQUFRLDZCQUE2QixhQUFhLElBQUE7QUFBQSxJQUM3RTtBQUdBLFVBQU0sZUFBZSwyQkFBMkIsUUFBUSxLQUFLLE1BQU0sa0JBQWtCO0FBQ3JGLFFBQUksQ0FBQyxhQUFhLFNBQVM7QUFDekIsYUFBTztBQUFBLFFBQ0wsU0FBUztBQUFBLFFBQ1QsUUFBUSxXQUFXLE1BQU0sNEJBQTRCLEtBQUssTUFBTTtBQUFBLE1BQUE7QUFBQSxJQUVwRTtBQUVBLFdBQU8sRUFBRSxTQUFTLE1BQU0sUUFBUSx3Q0FBQTtBQUFBLEVBQ2xDO0FBTU8sV0FBUyxxQkFDZCxLQUNBLFVBQ0EsZUFDMEQ7QUFDMUQsZUFBVyxXQUFXLFVBQVU7QUFDOUIsVUFBSSxVQUFVLEtBQUssUUFBUSxPQUFPLEdBQUc7QUFDbkMsZUFBTztBQUFBLFVBQ0wsU0FBUyxRQUFRLFdBQVc7QUFBQSxVQUM1QixnQkFBZ0I7QUFBQSxRQUFBO0FBQUEsTUFFcEI7QUFBQSxJQUNGO0FBQ0EsV0FBTyxFQUFFLFNBQVMsa0JBQWtCLFNBQVMsZ0JBQWdCLEtBQUE7QUFBQSxFQUMvRDtBQUtBLFdBQVMsVUFBVSxLQUFhLFNBQTBCO0FBQ3hELFFBQUk7QUFFRixVQUFJLENBQUMsUUFBUSxTQUFTLEtBQUssR0FBRztBQUM1QixjQUFNLFlBQVksSUFBSSxJQUFJLEdBQUc7QUFDN0IsY0FBTSxXQUFXLFVBQVU7QUFFM0IsY0FBTUMsWUFBVyxRQUNkLFFBQVEsT0FBTyxLQUFLLEVBQ3BCLFFBQVEsU0FBUyxJQUFJLEVBQ3JCLFFBQVEsT0FBTyxPQUFPO0FBQ3pCLGVBQU8sSUFBSSxPQUFPLElBQUlBLFNBQVEsR0FBRyxFQUFFLEtBQUssUUFBUTtBQUFBLE1BQ2xEO0FBR0EsWUFBTSxXQUFXLFFBQ2QsUUFBUSxxQkFBcUIsTUFBTSxFQUNuQyxRQUFRLFNBQVMsSUFBSTtBQUN4QixhQUFPLElBQUksT0FBTyxJQUFJLFFBQVEsR0FBRyxFQUFFLEtBQUssR0FBRztBQUFBLElBQzdDLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFLTyxXQUFTLDJCQUNkLFFBQ0EsY0FDb0U7QUFDcEUsVUFBTSxjQUFjLGFBQWEsS0FBSyxDQUFDLE1BQU0sRUFBRSxlQUFlLE1BQU07QUFDcEUsUUFBSSxDQUFDLGFBQWE7QUFFaEIsYUFBTyxFQUFFLFNBQVMsT0FBTyxvQkFBb0IsS0FBQTtBQUFBLElBQy9DO0FBQ0EsV0FBTztBQUFBLE1BQ0wsU0FBUyxZQUFZLFdBQVc7QUFBQSxNQUNoQyxvQkFBb0I7QUFBQSxJQUFBO0FBQUEsRUFFeEI7QUFLTyxXQUFTLG1CQUFtQixXQUFzQztBQUN2RSxRQUFJLGNBQWMsS0FBTSxRQUFPO0FBQy9CLFlBQU8sb0JBQUksS0FBQSxHQUFPLFFBQUEsSUFBWSxJQUFJLEtBQUssVUFBVSxTQUFTLEVBQUUsUUFBQTtBQUFBLEVBQzlEO0FDbE1BLFdBQVMsYUFBcUI7QUFDNUIsV0FBTyxPQUFPLFdBQUE7QUFBQSxFQUNoQjtBQUtPLFdBQVMsb0JBQ2QsTUFDQSxLQUNBLGFBQ0EsU0FNWTtBQUNaLFdBQU87QUFBQSxNQUNMLElBQUksV0FBQTtBQUFBLE1BQ0o7QUFBQSxNQUNBLFlBQVcsb0JBQUksS0FBQSxHQUFPLFlBQUE7QUFBQSxNQUN0QjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFNBQVMsU0FBUyxXQUFXO0FBQUEsTUFDN0IsZ0JBQWdCLFNBQVM7QUFBQSxNQUN6QixpQkFBaUIsU0FBUztBQUFBLE1BQzFCLFFBQVEsU0FBUztBQUFBLElBQUE7QUFBQSxFQUVyQjtBQ1pBLE1BQUksZUFBNkI7QUFBQSxJQUMvQixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxjQUFjO0FBQUEsSUFDZCxjQUFjO0FBQUEsSUFDZCxrQkFBa0IsQ0FBQTtBQUFBLEVBQ3BCO0FBTU8sV0FBUyxjQUNkLFFBQ0EsS0FDQSxNQUNxQjtBQUNyQixRQUFJLENBQUMsTUFBTTtBQUNULGFBQU87QUFBQSxRQUNMLFNBQVM7QUFBQSxRQUNULGFBQWE7QUFBQSxRQUNiLFFBQVE7QUFBQSxNQUFBO0FBQUEsSUFFWjtBQUVBLFFBQUksQ0FBQyxLQUFLLFVBQVU7QUFDbEIsYUFBTztBQUFBLFFBQ0wsU0FBUztBQUFBLFFBQ1QsYUFBYTtBQUFBLFFBQ2IsUUFBUTtBQUFBLE1BQUE7QUFBQSxJQUVaO0FBRUEsUUFBSSxvQkFBb0IsSUFBSSxHQUFHO0FBQzdCLGFBQU87QUFBQSxRQUNMLFNBQVM7QUFBQSxRQUNULGFBQWE7QUFBQSxRQUNiLFFBQVE7QUFBQSxNQUFBO0FBQUEsSUFFWjtBQUVBLFVBQU0sU0FBUyxhQUFhLE1BQU0sUUFBUSxHQUFHO0FBQzdDLFdBQU87QUFBQSxNQUNMLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGFBQWE7QUFBQSxNQUNiLFFBQVEsT0FBTztBQUFBLElBQUE7QUFBQSxFQUVuQjtBQTBCQSxXQUFTLHFCQUFxQixXQUEyQztBQUN2RSxZQUFRLFdBQUE7QUFBQSxNQUNOLEtBQUs7QUFBUyxlQUFPO0FBQUEsTUFDckIsS0FBSztBQUFTLGVBQU87QUFBQSxNQUNyQixLQUFLO0FBQVUsZUFBTztBQUFBLE1BQ3RCLEtBQUs7QUFBVyxlQUFPO0FBQUEsTUFDdkI7QUFBUyxlQUFPO0FBQUEsSUFBQTtBQUFBLEVBRXBCO0FBRUEsV0FBUyxZQUFZLElBQXFCO0FBQ3hDLFFBQUksR0FBRyxHQUFJLFFBQU8sSUFBSSxHQUFHLEVBQUU7QUFDM0IsUUFBSSxHQUFHLGFBQWEsT0FBTyxHQUFHLGNBQWMsVUFBVTtBQUNwRCxZQUFNLFVBQVUsR0FBRyxVQUFVLEtBQUEsRUFBTyxNQUFNLEtBQUssRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUNyRSxVQUFJLGdCQUFnQixHQUFHLEdBQUcsUUFBUSxZQUFBLENBQWEsSUFBSSxPQUFPO0FBQUEsSUFDNUQ7QUFDQSxXQUFPLEdBQUcsUUFBUSxZQUFBO0FBQUEsRUFDcEI7QUFLTyxXQUFTLHFCQUNkLE1BQ0EsYUFDQSxVQUNZO0FBQ1osbUJBQWU7QUFBQSxNQUNiLFlBQVk7QUFBQSxNQUNaLGNBQWM7QUFBQSxNQUNkLGNBQWM7QUFBQSxNQUNkLGNBQWM7QUFBQSxNQUNkLGtCQUFrQixDQUFBO0FBQUEsSUFBQztBQUdyQixVQUFNLFdBQThCLENBQUE7QUFHcEMsVUFBTSxzQkFBc0IsQ0FBQyxNQUFhO0FBQ3hDLFVBQUksQ0FBQyxhQUFhLGFBQWM7QUFDaEMsVUFBSSxFQUFFLFVBQVc7QUFFakIsWUFBTSxhQUFhLHFCQUFxQixFQUFFLElBQUk7QUFDOUMsVUFBSSxDQUFDLFdBQVk7QUFFakIsWUFBTSxTQUFTLEVBQUU7QUFDakIsWUFBTSxXQUFXLFNBQVMsWUFBWSxNQUFNLElBQUk7QUFDaEQsWUFBTSxNQUFNLE9BQU8sU0FBUztBQUU1QixZQUFNLFNBQVMsY0FBYyxZQUFZLEtBQUssYUFBYSxVQUFVO0FBRXJFLFVBQUksT0FBTyxTQUFTO0FBQ2xCLHFCQUFhO0FBQ2IsY0FBTSxRQUFRLG9CQUFvQixrQkFBa0IsS0FBSyxHQUFHLFVBQVUsWUFBWTtBQUFBLFVBQ2hGLGdCQUFnQjtBQUFBLFVBQ2hCLGlCQUFpQjtBQUFBLFVBQ2pCLFNBQVM7QUFBQSxVQUNULFFBQVEsYUFBYSxZQUFZO0FBQUEsUUFBQSxDQUNsQztBQUNELGlCQUFTLEtBQUs7QUFBQSxNQUNoQixPQUFPO0FBQ0wscUJBQWE7QUFDYixVQUFFLGVBQUE7QUFDRixVQUFFLGdCQUFBO0FBRUYsY0FBTSxZQUErQjtBQUFBLFVBQ25DLElBQUksT0FBTyxXQUFBO0FBQUEsVUFDWCxZQUFXLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsVUFDdEIsU0FBUztBQUFBLFVBQ1QsaUJBQWlCO0FBQUEsVUFDakI7QUFBQSxVQUNBLGdCQUFnQjtBQUFBLFVBQ2hCLGdCQUFnQixhQUFhLFlBQVksTUFBTTtBQUFBLFVBQy9DLFFBQVEsT0FBTztBQUFBLFVBQ2YsY0FBYztBQUFBLFFBQUE7QUFFaEIscUJBQWEsaUJBQWlCLEtBQUssU0FBUztBQUM1QyxZQUFJLGFBQWEsaUJBQWlCLFNBQVMsSUFBSTtBQUM3Qyx1QkFBYSxpQkFBaUIsTUFBQTtBQUFBLFFBQ2hDO0FBQ0Esb0JBQVksU0FBUztBQUVyQixjQUFNLFFBQVEsb0JBQW9CLGtCQUFrQixLQUFLLEdBQUcsVUFBVSxhQUFhLE9BQU8sTUFBTSxJQUFJO0FBQUEsVUFDbEcsZ0JBQWdCO0FBQUEsVUFDaEIsaUJBQWlCO0FBQUEsVUFDakIsU0FBUztBQUFBLFVBQ1QsUUFBUSxhQUFhLFlBQVk7QUFBQSxRQUFBLENBQ2xDO0FBQ0QsaUJBQVMsS0FBSztBQUFBLE1BQ2hCO0FBQUEsSUFDRjtBQUVBLFVBQU0sYUFBYSxDQUFDLFNBQVMsU0FBUyxVQUFVLFNBQVM7QUFDekQsZUFBVyxRQUFRLFlBQVk7QUFDN0IsZUFBUyxpQkFBaUIsTUFBTSxxQkFBcUIsRUFBRSxTQUFTLE1BQU07QUFBQSxJQUN4RTtBQUNBLGFBQVMsS0FBSyxNQUFNO0FBQ2xCLGlCQUFXLFFBQVEsWUFBWTtBQUM3QixpQkFBUyxvQkFBb0IsTUFBTSxxQkFBcUIsRUFBRSxTQUFTLE1BQU07QUFBQSxNQUMzRTtBQUFBLElBQ0YsQ0FBQztBQUdELFVBQU0sV0FBVyxJQUFJLGlCQUFpQixDQUFDLGNBQWM7QUFDbkQsVUFBSSxDQUFDLGFBQWEsYUFBYztBQUVoQyxpQkFBVyxZQUFZLFdBQVc7QUFDaEMsWUFBSSxTQUFTLFNBQVMsZ0JBQWdCLFNBQVMsV0FBVyxTQUFTLEtBQUssU0FBUyxhQUFhLFNBQVMsSUFBSTtBQUN6RyxnQkFBTSxNQUFNLE9BQU8sU0FBUztBQUM1QixnQkFBTSxTQUFTLGNBQWMsY0FBYyxLQUFLLGFBQWEsVUFBVTtBQUV2RSxjQUFJLENBQUMsT0FBTyxTQUFTO0FBQ25CLGtCQUFNLFNBQVMsU0FBUztBQUN4QixrQkFBTSxZQUErQjtBQUFBLGNBQ25DLElBQUksT0FBTyxXQUFBO0FBQUEsY0FDWCxZQUFXLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsY0FDdEIsU0FBUztBQUFBLGNBQ1QsaUJBQWlCO0FBQUEsY0FDakI7QUFBQSxjQUNBLGdCQUFnQixRQUFRLGFBQWEsSUFBSSxZQUFZLE1BQU0sSUFBSTtBQUFBLGNBQy9ELGdCQUFnQixhQUFhLFlBQVksTUFBTTtBQUFBLGNBQy9DLFFBQVEsT0FBTztBQUFBLGNBQ2YsY0FBYztBQUFBLFlBQUE7QUFFaEIsd0JBQVksU0FBUztBQUFBLFVBQ3ZCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFFRCxRQUFJLFNBQVMsTUFBTTtBQUNqQixlQUFTLFFBQVEsU0FBUyxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsTUFBTTtBQUFBLElBQ3BFO0FBQ0EsYUFBUyxLQUFLLE1BQU0sU0FBUyxXQUFBLENBQVk7QUFFekMsV0FBTyxNQUFNO0FBQ1gsbUJBQWEsZUFBZTtBQUM1QixpQkFBVyxXQUFXLFVBQVU7QUFDOUIsWUFBSTtBQUFFLGtCQUFBO0FBQUEsUUFBVyxRQUFRO0FBQUEsUUFBZTtBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFLTyxXQUFTLGlCQUFpQixNQUFtQztBQUNsRSxpQkFBYSxhQUFhO0FBQUEsRUFDNUI7QUFLTyxXQUFTLG9CQUFvQixNQUErQjtBQUNqRSxXQUFPLG1CQUFtQixLQUFLLE1BQU0sU0FBUztBQUFBLEVBQ2hEO0FBS08sV0FBUyxrQkFBZ0M7QUFDOUMsV0FBTyxFQUFFLEdBQUcsYUFBQTtBQUFBLEVBQ2Q7QUN0UEEsUUFBTSxxQkFBd0MsQ0FBQTtBQU12QyxXQUFTLGdCQUFnQixTQUEyQjtBQUN6RCx1QkFBbUIsS0FBSyxPQUFPO0FBQUEsRUFDakM7QUFLTyxXQUFTLDJCQUlkO0FBQ0EsUUFBSSxtQkFBbUI7QUFDdkIsUUFBSSx3QkFBd0I7QUFHNUIsZUFBVyxXQUFXLG9CQUFvQjtBQUN4QyxVQUFJO0FBQ0YsZ0JBQUE7QUFDQTtBQUFBLE1BQ0YsUUFBUTtBQUFBLE1BRVI7QUFBQSxJQUNGO0FBQ0EsdUJBQW1CLFNBQVM7QUFHNUIsVUFBTSxrQkFBa0IscUJBQUE7QUFHeEIsNEJBQUE7QUFFQSxXQUFPLEVBQUUsa0JBQWtCLHVCQUF1QixnQkFBQTtBQUFBLEVBQ3BEO0FBNERPLFdBQVMsMEJBQW1DO0FBQ2pELFFBQUk7QUFDRixZQUFNLGFBQWEsT0FBTyxvQkFBb0IsTUFBTTtBQUNwRCxVQUFJLFFBQVE7QUFDWixpQkFBVyxPQUFPLFlBQVk7QUFDNUIsWUFDRSxJQUFJLFdBQVcsUUFBUSxLQUN2QixJQUFJLFdBQVcsYUFBYSxHQUM1QjtBQUNBLGNBQUk7QUFDRixtQkFBUSxPQUE4QyxHQUFHO0FBQ3pELG9CQUFRO0FBQUEsVUFDVixRQUFRO0FBQUEsVUFFUjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1QsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUtPLFdBQVMsdUJBQWlDO0FBQy9DLFVBQU0sVUFBb0IsQ0FBQTtBQUcxQixRQUFJO0FBQ0YsYUFBTyxlQUFlLFdBQVcsYUFBYTtBQUFBLFFBQzVDLEtBQUssTUFBTTtBQUFBLFFBQ1gsY0FBYztBQUFBLE1BQUEsQ0FDZjtBQUNELGNBQVEsS0FBSyxxQkFBcUI7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUdBLFVBQU0sVUFBVSxPQUFPLG9CQUFvQixRQUFRO0FBQ25ELGVBQVcsT0FBTyxTQUFTO0FBQ3pCLFVBQUksSUFBSSxXQUFXLE9BQU8sS0FBSyxJQUFJLFdBQVcsT0FBTyxHQUFHO0FBQ3RELFlBQUk7QUFDRixpQkFBUSxTQUFnRCxHQUFHO0FBQzNELGtCQUFRLEtBQUssR0FBRztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFHQSxVQUFNLGFBQWEsT0FBTyxvQkFBb0IsTUFBTTtBQUNwRCxVQUFNLHFCQUFxQixDQUFDLGdCQUFnQixlQUFlLE9BQU87QUFDbEUsZUFBVyxPQUFPLFlBQVk7QUFDNUIsVUFBSSxtQkFBbUIsS0FBSyxDQUFDLFdBQVcsSUFBSSxXQUFXLE1BQU0sQ0FBQyxHQUFHO0FBQy9ELFlBQUk7QUFDRixpQkFBUSxPQUE4QyxHQUFHO0FBQ3pELGtCQUFRLEtBQUssR0FBRztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQ3pLQSxRQUFNLGNBQWMsT0FBTyxXQUFBO0FBQzNCLFFBQU0sV0FBVztBQUNqQixRQUFNLGtCQUFrQjtBQUN4QixRQUFNLGFBQWE7QUFDbkIsUUFBTSxpQkFBaUI7QUFFdkIsTUFBSSxtQkFBd0M7QUFDNUMsTUFBSSxpQkFBc0M7QUFDMUMsTUFBSSxpQkFBZ0M7QUFHcEMsV0FBUyxvQkFBb0IsTUFBbUM7QUFDOUQsVUFBTSxXQUFXLE9BQ2I7QUFBQSxNQUNFLFVBQVUsS0FBSztBQUFBLE1BQ2YsV0FBVyxLQUFLLE1BQU0sV0FBVyxhQUFhO0FBQUEsTUFDOUMsb0JBQW9CLEtBQUssTUFBTSxtQkFBbUIsSUFBSSxDQUFDLE9BQU87QUFBQSxRQUM1RCxZQUFZLEVBQUU7QUFBQSxRQUNkLFFBQVEsRUFBRTtBQUFBLE1BQUEsRUFDVjtBQUFBLE1BQ0YsY0FBYyxLQUFLLE1BQU0sYUFBYSxJQUFJLENBQUMsT0FBTztBQUFBLFFBQ2hELFNBQVMsRUFBRTtBQUFBLFFBQ1gsUUFBUSxFQUFFO0FBQUEsTUFBQSxFQUNWO0FBQUEsSUFBQSxJQUVKO0FBQ0osV0FBTyxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsT0FBTyxhQUFhLE1BQU0sU0FBQSxHQUFZLEdBQUc7QUFBQSxFQUN2RjtBQUVBLFdBQVMsYUFBbUI7QUFFMUIsV0FBTyxZQUFZLEVBQUUsTUFBTSxVQUFVLE9BQU8sWUFBQSxHQUFlLEdBQUc7QUFHOUQsV0FBTyxpQkFBaUIsV0FBVyxDQUFDLE1BQW9CO0FBQ3RELFVBQUksRUFBRSxXQUFXLFVBQVUsQ0FBQyxFQUFFLEtBQU07QUFDcEMsVUFBSSxFQUFFLEtBQUssU0FBUyxXQUFZO0FBQ2hDLFVBQUksQ0FBQyxFQUFFLEtBQUssU0FBUyxFQUFFLEtBQUssVUFBVSxZQUFhO0FBRW5ELFlBQU0sRUFBRSxZQUFZLEtBQUssU0FBUyxRQUFRLFVBQUEsSUFBYyxFQUFFO0FBUTFELFVBQUksU0FBUztBQUNYLGNBQU0sWUFBK0I7QUFBQSxVQUNuQyxJQUFJLE9BQU8sV0FBQTtBQUFBLFVBQ1gsV0FBVyxjQUFhLG9CQUFJLEtBQUEsR0FBTyxZQUFBO0FBQUEsVUFDbkMsU0FBUyxrQkFBa0I7QUFBQSxVQUMzQixpQkFBaUI7QUFBQSxVQUNqQjtBQUFBLFVBQ0EsZ0JBQWdCO0FBQUEsVUFDaEIsZ0JBQWdCLGdCQUFBLEVBQWtCLFlBQVksTUFBTTtBQUFBLFVBQ3BEO0FBQUEsVUFDQSxjQUFjO0FBQUEsUUFBQTtBQUVoQix5QkFBaUIsMEJBQTBCLFNBQVMsRUFBRSxNQUFNLE1BQU07QUFBQSxRQUFlLENBQUM7QUFBQSxNQUNwRjtBQUFBLElBQ0YsQ0FBQztBQUdELFdBQU8sUUFBUSxVQUFVLFlBQVksYUFBYTtBQUVsRCxVQUFNLGtCQUFrQixNQUFNO0FBRTVCLHlCQUFtQixzQkFBc0IsQ0FBQSxHQUFJLGlCQUFpQjtBQUM5RCxzQkFBZ0IsTUFBTTtBQUNwQixZQUFJLGlCQUFrQixrQkFBQTtBQUFBLE1BQ3hCLENBQUM7QUFHRCx1QkFBaUI7QUFBQSxRQUNmO0FBQUEsUUFDQSxDQUFDLGNBQWM7QUFDYiwyQkFBaUIsMEJBQTBCLFNBQVM7QUFBQSxRQUN0RDtBQUFBLFFBQ0EsQ0FBQyxVQUFVO0FBQ1QsMkJBQWlCLGdCQUFnQixLQUFLO0FBQUEsUUFDeEM7QUFBQSxNQUFBO0FBRUYsc0JBQWdCLE1BQU07QUFDcEIsWUFBSSxlQUFnQixnQkFBQTtBQUFBLE1BQ3RCLENBQUM7QUFHRCx1QkFBaUIsZ0JBQWdCLENBQUEsQ0FBRSxFQUFFLEtBQUssQ0FBQyxhQUFhO0FBQ3RELFlBQUksWUFBWSxPQUFPLGFBQWEsVUFBVTtBQUM1QyxnQkFBTSxPQUFPO0FBQ2IsY0FBSSxLQUFLLGtCQUFrQjtBQUN6Qiw2QkFBaUIsS0FBSyxnQkFBZ0I7QUFDdEMsZ0NBQW9CLEtBQUssZ0JBQWdCO0FBQUEsVUFDM0M7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsTUFFZixDQUFDO0FBQUEsSUFDSDtBQUVBLFFBQUksU0FBUyxlQUFlLFdBQVc7QUFDckMsZUFBUyxpQkFBaUIsb0JBQW9CLGlCQUFpQixFQUFFLE1BQU0sTUFBTTtBQUFBLElBQy9FLE9BQU87QUFDTCxzQkFBQTtBQUFBLElBQ0Y7QUFFQSxZQUFRLElBQUksK0NBQStDO0FBQUEsRUFDN0Q7QUFFQSxpQkFBZSxpQkFBaUIsTUFBbUIsTUFBaUM7QUFDbEYsVUFBTSxVQUEwQjtBQUFBLE1BQzlCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsU0FBUSxvQkFBSSxLQUFBLEdBQU8sWUFBQTtBQUFBLElBQVk7QUFHakMsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsVUFBSTtBQUNGLGVBQU8sUUFBUSxZQUFZLFNBQVMsQ0FBQyxhQUFhO0FBQ2hELGNBQUksT0FBTyxRQUFRLFdBQVc7QUFDNUIsbUJBQU8sSUFBSSxNQUFNLE9BQU8sUUFBUSxVQUFVLE9BQU8sQ0FBQztBQUFBLFVBQ3BELE9BQU87QUFDTCxvQkFBUSxRQUFRO0FBQUEsVUFDbEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILFNBQVMsS0FBSztBQUNaLGVBQU8sR0FBRztBQUFBLE1BQ1o7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxjQUNQLFNBQ0EsU0FDQSxjQUNTO0FBQ1QsUUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQU0sUUFBTztBQUV0QyxZQUFRLFFBQVEsTUFBQTtBQUFBLE1BQ2QsS0FBSyxxQkFBcUI7QUFDeEIsY0FBTSxPQUFPLFFBQVE7QUFDckIseUJBQWlCLElBQUk7QUFDckIsNEJBQW9CLElBQUk7QUFHeEIsWUFBSSxlQUFnQixnQkFBQTtBQUNwQix5QkFBaUI7QUFBQSxVQUNmO0FBQUEsVUFDQSxDQUFDLGNBQWMsaUJBQWlCLDBCQUEwQixTQUFTO0FBQUEsVUFDbkUsQ0FBQyxVQUFVLGlCQUFpQixnQkFBZ0IsS0FBSztBQUFBLFFBQUE7QUFFbkQscUJBQWEsRUFBRSxTQUFTLE1BQU07QUFDOUIsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLEtBQUssd0JBQXdCO0FBRTNCLGNBQU0sU0FBUyx5QkFBQTtBQUNmLDJCQUFtQjtBQUNuQix5QkFBaUI7QUFDakIseUJBQWlCO0FBQ2pCLHFCQUFhLEVBQUUsU0FBUyxNQUFNLEdBQUcsUUFBUTtBQUN6QyxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsS0FBSyxnQkFBZ0I7QUFDbkIsY0FBTSxRQUFRLGdCQUFBO0FBQ2QscUJBQWE7QUFBQSxVQUNYLGVBQWUsbUJBQW1CO0FBQUEsVUFDbEMsU0FBUztBQUFBLFVBQ1QsY0FBYztBQUFBLFFBQUEsQ0FDZjtBQUNELGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxLQUFLLGNBQWM7QUFDakIsY0FBTSxFQUFFLFlBQVksSUFBQSxJQUFRLFFBQVE7QUFFcEMsZUFBTztBQUFBLFVBQ0wsRUFBRSxNQUFNLGdCQUFnQixPQUFPLGFBQWEsWUFBWSxJQUFBO0FBQUEsVUFDeEQ7QUFBQSxRQUFBO0FBRUYscUJBQWEsRUFBRSxTQUFTLE1BQU07QUFDOUIsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBO0FBQ0UsZUFBTztBQUFBLElBQUE7QUFBQSxFQUViO0FBRUEsV0FBUyxrQkFBa0IsU0FBdUM7QUFDaEUsUUFBSSxRQUFRLGlCQUFpQixRQUFRLE9BQU87QUFDMUMsdUJBQWlCLFFBQVEsTUFBTTtBQUMvQix1QkFBaUIsb0JBQW9CLFFBQVEsS0FBSyxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BRWhFLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLGFBQUE7OyJ9
